# -*- coding: utf-8 -*-
"""💸 费损入账（甲处方·2026-09-29 老板令「准」· 火印 ED-20260929-319）
病: 子引擎本机账本只记**毛盈亏**(价差), 交易所真实**手续费(fee)+资金费(fund)** 不入账
    ⇒ 护栏(连亏冷却/日亏熔断)与门户都看不见真亏 ⇒ XWU 连环翻手"没输赢却出血"无反馈。
药: 按交易所流水(account book)**条目号(id)**水位, 把**新增** fee/fund 并入本机账本:
    · 在仓 → 累计到 `pos['_费']`, 平仓时并入本笔 pnl(护栏 `_dpnl` 与 `realized` 同步可见);
    · 空仓 → 直接入 `realized` + 记一条"费损"trade(日亏重算亦可见)。
口径: 只记**新增**(id 唯一·同秒同额亦不失真) · 历史不回补(要回补置 FEE_BOOK_BACKFILL=1)。
开关: FEE_BOOK_ON(默认1·=0 关) · FEE_BOOK_SEC(对账间隔·默认120秒)。
"""
import os, time


def _rows(api, off):
    try:
        return api.list_futures_account_book('usdt', limit=1000, offset=off) or []
    except Exception:
        return None


def book(st, api, live, node, log=print, note_close=None, now=None):
    """按条目号水位把新增 fee+fund 并入账本。返回 True=状态有变(调用方需 save)。"""
    if not live or not api:
        return False
    if os.environ.get('FEE_BOOK_ON', '1') == '0':
        return False
    _now = float(now if now is not None else time.time())
    _sec = int(os.environ.get('FEE_BOOK_SEC', '120'))
    if _now - float(st.get('_费损_上次') or 0) < _sec:
        return False
    st['_费损_上次'] = _now
    rows0 = _rows(api, 0)
    if not rows0:
        return False
    try:
        _ids0 = [int(getattr(b, 'id', 0) or 0) for b in rows0]
    except Exception:
        return False
    cur = int(st.get('_费损_尾号') or 0)
    if not cur:
        if os.environ.get('FEE_BOOK_BACKFILL', '0') != '1':
            st['_费损_尾号'] = max(_ids0)                 # 立水位: 只记此后新增(防一次性回补历史把护栏打爆)
            log('💸 费损入账·立水位 尾号=%d(只记此后新增·历史不回补; 要回补置 FEE_BOOK_BACKFILL=1)' % max(_ids0))
            return True
        cur = 0
    tot = 0.0; n = 0; mx = cur; off = 0; rows = rows0
    while True:
        if rows is None:
            log('⚠️ 费损入账·流水查询失败')
            return False
        if not rows:
            break
        try:
            _pgmin = min(int(getattr(b, 'id', 0) or 0) for b in rows)
        except Exception:
            break
        for b in rows:
            try:
                bid = int(getattr(b, 'id', 0) or 0)
            except Exception:
                continue
            if bid > mx:
                mx = bid
            if bid <= cur:
                continue
            if str(getattr(b, 'type', '')) in ('fee', 'fund'):
                tot += float(getattr(b, 'change', 0) or 0); n += 1
        if _pgmin <= cur or len(rows) < 1000:             # 已到水位 / 末页
            break
        off += 1000
        if off >= 5000:
            break
        rows = _rows(api, off)
    if tot:
        if st.get('pos'):
            _p = st['pos']
            _p['_费'] = round(float(_p.get('_费') or 0.0) + tot, 8)
            log('💸 费损入账: %+.4f$(%d条) → 计入持仓 %s 待平仓并入' % (tot, n, _p.get('coin')))
        else:
            st['realized'] = round(float(st.get('realized') or 0) + tot, 8)
            st.setdefault('trades', []).append({
                'coin': '—', 'side': '—', 'entry': None, 'exit': None,
                'pnl': round(tot, 4), 'pnl_pct': 0.0, '费': round(tot, 4),
                'why': '费损入账(空仓期手续费/资金费)', 'peak_pct': 0.0,
                'ts': round(time.time(), 1), 'day': time.strftime('%Y-%m-%d')})
            if note_close:
                try:
                    note_close(st, tot, '费损入账')
                except Exception:
                    pass
            log('💸 费损入账: %+.4f$(%d条·空仓期) → 本机已实现 %+.2f$' % (tot, n, float(st.get('realized') or 0)))
    st['_费损_尾号'] = mx or cur
    return True


def close_fee(pos):
    """平仓时取该笔持仓期间累计的费损(负值)。"""
    try:
        return float((pos or {}).get('_费') or 0.0)
    except Exception:
        return 0.0
