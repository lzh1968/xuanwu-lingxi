# -*- coding: utf-8 -*-
"""🕐 系统级·同币同步冷却（ED-20260929-324）

老板令(2026-09-29 07:49)「给系统添加同步冷却，link一直占位开仓不是什么好事」。

一份账本、全户共享: **任一户平掉某币 ⇒ 该币在 SYNC_COOL_SEC 内，全系统任何户、任何路径(含费率腿/等回抽挂单)不得再开**。
- 现状病根(诊断): 内核 `_coin_cool` 是**本户内**账本, 且 `FUND_LEG_NO_HUIZHU=1` 时**费率腿免疫同币冷却** ⇒ LINK 被费率腿反复占位开仓。
- 本件不动内核(纯跑器侧硬闸) ⇒ 沙盘法案对照不受污染。
- 开关: `SYNC_COOL_ON`(默认1·=0关) · `SYNC_COOL_SEC`(默认1800秒=30分) · `SYNC_COOL_FILE`(可选覆盖账本路径)。
- 账本: `data_v2/mtsim/_同步冷却_<live|paper>.jsonl`(追加式·免锁·后台自动压实)。

回退: 删接线即可(见 `_补_同步冷却_20260929.py --revert`)。
"""
import json, os, time

HERE = os.path.dirname(os.path.abspath(__file__))
TAIL = 800
COMPACT_BYTES = 60000


def on():
    return os.environ.get('SYNC_COOL_ON', '1') != '0'


def sec():
    try:
        return max(0, int(float(os.environ.get('SYNC_COOL_SEC', '1800'))))
    except (TypeError, ValueError):
        return 1800


def path(mode):
    p = os.environ.get('SYNC_COOL_FILE')
    if p:
        return p
    return os.path.join(HERE, 'data_v2', 'mtsim', '_同步冷却_%s.jsonl' % ('live' if mode else 'paper'))


def mark(mode, coin, ts=None, badge=''):
    """平仓后登记(追加式·多进程安全)"""
    if not on() or not coin:
        return
    try:
        p = path(mode)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'a', encoding='utf-8') as f:
            f.write(json.dumps({'t': int(ts or time.time()), 'c': str(coin), 'b': str(badge)},
                               ensure_ascii=False) + '\n')
        _compact(mode)
    except Exception:
        pass


def left(mode, coin):
    """该币还剩多少秒冷却(0=可开)"""
    if not on() or not coin:
        return 0.0
    try:
        return max(0.0, _last_ts(mode, str(coin)) + sec() - time.time())
    except Exception:
        return 0.0


def active(mode, n=12):
    """当前处于冷却中的币 [(币, 剩余秒)]"""
    try:
        d = {}
        for o in _rows(mode):
            c = o.get('c')
            if c and int(o.get('t', 0) or 0) > d.get(c, 0):
                d[c] = int(o.get('t', 0) or 0)
        now = time.time()
        out = [(c, int(t + sec() - now)) for c, t in d.items() if t + sec() > now]
        out.sort(key=lambda x: -x[1])
        return out[:n]
    except Exception:
        return []


def report(mode):
    a = active(mode)
    return '、'.join('%s(剩%d分)' % (c, (l + 59) // 60) for c, l in a) if a else '无'


def _rows(mode):
    p = path(mode)
    if not os.path.exists(p):
        return []
    try:
        raw = open(p, encoding='utf-8').read().splitlines()[-TAIL:]
    except Exception:
        return []
    r = []
    for ln in raw:
        try:
            o = json.loads(ln)
            if isinstance(o, dict):
                r.append(o)
        except Exception:
            pass
    return r


def _last_ts(mode, coin):
    last = 0
    for o in _rows(mode):
        if o.get('c') == coin and int(o.get('t', 0) or 0) > last:
            last = int(o['t'])
    return last


def _compact(mode, keep=400):
    p = path(mode)
    try:
        if os.path.getsize(p) < COMPACT_BYTES:
            return
        d = {}
        for o in _rows(mode):
            c = o.get('c')
            if c and int(o.get('t', 0) or 0) > d.get(c, 0):
                d[c] = int(o.get('t', 0) or 0)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            for c, t in sorted(d.items(), key=lambda kv: -kv[1])[:keep]:
                f.write(json.dumps({'t': t, 'c': c, 'b': 'compact'}, ensure_ascii=False) + '\n')
        os.replace(tmp, p)
    except Exception:
        pass
