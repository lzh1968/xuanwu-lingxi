# -*- coding: utf-8 -*-
"""👑🐍 开仓归序（ED-20260929-325 · 老板令 2026-09-29 08:00）

老板原话：「抑制金蟾开仓，判起势烛龙统御，开仓归总裁」。

**病(实证)**: 内核本有「烛龙门(一票之闸)」 `_zhulong_gate`(子引擎/_内核_*.py 内、原在 `_open_paper` 里)，
但跑器 `_子引擎.py` **覆盖了 `E._open_paper`** ⇒ 内核那道门**从未执行**(死码) ⇒
金蟾费率腿以 `FUND_LEG_BYPASS_GATE/BYPASS_TREND/NO_HUIZHU` **绕过一切闸自行开仓**
(实证: 09-29 07:59:03 老板手工平仓后 40 秒, LINK 空 178 张@15.421 又被金蟾开出来)。

**药**: 在**开仓咽喉**把门立起来 ——
  关一 · **烛龙起势(统御)**: `E._zhulong_gate(st,sig)` → 制动/否决 ⇒ 禁新开; 逆大势 ⇒ 拦; 顺势 ⇒ 主动放行; 无势 ⇒ 交圣裁相左判。
  关二 · **总裁裁决(开仓归总裁)**: `E._teng_she_verdict(None,sig,st,0.0,side)` → 止(连亏/冷却)·缓(逆圣裁/逆大势) ⇒ 不开。
金蟾抑制在**源头**: 基因 `FUND_LEG_ON=0`(费率腿不再成为候选) —— 本件只负责"门"。

开关: `OPEN_ORDER_GATE_ON`(默认 1) · `=0` 回旧行为。回退: `_补_开仓归序_20260929.py --revert`。
"""
import os

# 👑🆕2026-10-06 火印 ED-20261006-487（承 ED-486《烛龙至尊·黄袍加身·天下一统令》）：
#   开仓咽喉立「烛龙至尊」横幅 + 参谋意见书 —— 王(烛龙)为准否唯一决断者；
#   大势门/择强/开明/白虎/触觉军情/顶底半山等诸路一律记「参谋」(无决策权)。
#   只增可见性与留痕·不改一字判定链·不动风控/择向参数·异常一律放行。回退: SUPREME_ON=0（本件零行为变化）。
SUPREME_ON = os.environ.get('SUPREME_ON', '1') != '0'

# 👁🔥2026-10-08 09:47 老板令「眼睛接进真钱的闸（🔴伪锁向/🟡疑减仓）—— 让烛龙身脑👁感知一切」(火印 ED-20261008-616)
#   职: 开仓前读**辨伪天眼判定级** —— 🔴伪⇒**锁向不开**; 🟡疑⇒**名义减半**; 🟢真⇒放行。
#   边界: **只加"开仓前的一道门"** —— 不动止损/紧急闸/兜底/量程/风控闸/相位/择向算式。
#   失败开门: 天眼产物超龄/异常 ⇒ **放行**(不因眼睛瞎了而憋死交易——承「加闸易憋死系统」之训)。
#   开关: TIANYAN_GATE_ON(默认1) · TIANYAN_RED_LOCK(默认1) · TIANYAN_YELLOW_HALF(默认1) · TIANYAN_MAX_AGE(默认900秒)
TY_ON = os.environ.get('TIANYAN_GATE_ON', '1') != '0'
TY_RED_LOCK = os.environ.get('TIANYAN_RED_LOCK', '1') != '0'
TY_YELLOW_HALF = os.environ.get('TIANYAN_YELLOW_HALF', '1') != '0'
try:
    TY_MAX_AGE = float(os.environ.get('TIANYAN_MAX_AGE', '900') or 900)
except Exception:
    TY_MAX_AGE = 900.0
_UD = os.path.dirname(os.path.abspath(__file__))

# 🐉🔥2026-10-19 22:36 老板令「一个电脑(中枢)，一个声音，一个方向，其它皆为参谋和协同岗」(火印 ED-20261019-1618)
#   职: 开仓前先问**中枢之声**（`_多空源五行_扫描.json` 的王者裁决，由烛龙一票口径算出）——
#       中枢无向(hold/无声) ⇒ 不开; 中枢方向与将开之向相左 ⇒ 不开; 同向 ⇒ 交既有关一/关二/风控。
#   边界: 只加“听中枢”一道，不动止损/风控/择向算式; 中枢档超龄(>30分钟) 视为无声(不开)。
#   开关: ZHONG_SHU_GATE_ON (默认 0=零行为变化; 训练营显式开=1)。回退: 删本块 + 去基因。
ZHONG_SHU_GATE_ON = os.environ.get('ZHONG_SHU_GATE_ON', '0') != '0'
ZS_MAX_AGE = float(os.environ.get('ZHONG_SHU_MAX_AGE', '1800') or 1800)
_ZS_C = {'t': 0.0, 'd': {}, 'age': None}

# 🧬🔥2026-10-19 22:52 老板令「以现在成熟的玄武灵犀数智系统完全体进入自我演化方式」(火印 ED-20261019-1619)
#   职: 开仓前读**自演化规则表** `_演化_规则.json` 的「忌开」清单（由已结算真实前瞻台账滚动提炼，
#       要求 n≥60 且**前后半窗皆亏**）——命中则避雷不开。**只避雷·不逼单**（不拿「宜开」去催开仓）。
#   边界: 成对规则均可溯源到台账；不改止损/风控/择向算式；默认 0 = 零行为变化。
EVO_GATE_ON = os.environ.get('EVO_GATE_ON', '0') != '0'

# ═══════════════════════════════════════════════════════════════════════════
# 🧭 指南针校准（2026-10-20 老板令「去修吧·择向要像指南针一样精准·放开自我限制」）
#   病（实测）: 烛龙大脑 48.0%，且**信心倒挂** —— 信心0.75~0.85 命中54.8%、期望+0.281%；
#              0.85~0.92 仅44.0%、0.92+ 46.8% 且期望为负；某些币天生反指（LTC/DOT/SEI/FIL）。
#   药（只做校准·不动择向逻辑/不动风控）: ①弱币不打 ②信心 >= 上限(默认0.90) 不打（越笃定越亏，是追高追低味）。
#   样外实测（前段选·后段验）: **53.4%**（n=118·期望+0.365%/笔），对照全放行 50.3%(n=328·+0.131%)。
#   开关: COMPASS_ON(默认1) · COMPASS_WEAK(逗号名单) · COMPASS_CONF_MAX(默认0.90)
#   边界: 只拦「本就不该出手」的场次；止损/仓位/杠杆/风控一字不动。回退: `COMPASS_ON=0` 或覆盖备份。
# ═══════════════════════════════════════════════════════════════════════════
COMPASS_ON = os.environ.get('COMPASS_ON', '1') != '0'
COMPASS_CONF_MAX = float(os.environ.get('COMPASS_CONF_MAX', '0.90') or 0.90)
COMPASS_WEAK = set((os.environ.get('COMPASS_WEAK') or 'LTC,DOT,SEI,FIL,AVAX').upper().replace(' ', '').split(','))


def 指南针判(coin, conf):
    """→ (放行?, 因由)。只做磁偏角校正，不改方向。"""
    _c = str(coin or '').upper()
    try:
        _cf = float(conf or 0)
    except Exception:
        _cf = 0.0
    if _c and _c in COMPASS_WEAK:
        return (False, '弱币不打(%s历史≈35~45%%)' % _c)
    if COMPASS_CONF_MAX > 0 and _cf >= COMPASS_CONF_MAX:
        return (False, '过度自信(信%.2f≥%.2f)·追高追低味' % (_cf, COMPASS_CONF_MAX))
    return (True, '指南针放行(信%.2f)' % _cf)
_EV_C = {'t': 0.0, 'rules': []}

# 🎯🔥2026-10-19 23:07 老板令「既然自己懂了，调整回来就赢了！能力显化出来」
#   病(今日实锤·918 七仓 3胜4负): 空单 4 笔亏 3 笔——**上涨段逆势做空**；多单追高(ATOM 1.779 开在就近高点)。
#   药(择向本体·非间门): ①空单须大势向下(regime=dn 或 4H动量 t4l≤-0.3) ②跌势不做多 ③多单不追高(pos≥阈不开)
#   边界: 仅新户显式开 DIR_FIX_ON=1；不改止损/风控算式；异常放行。
DIR_FIX_ON = os.environ.get('DIR_FIX_ON', '0') != '0'
DIR_FIX_CHASE_POS = float(os.environ.get('DIR_FIX_CHASE_POS', '72') or 72)


def 演化判(coin, side, reg=None, hour=None):
    """🧬 命中的「忌开」规则名或 None。缓存 300 秒。"""
    if not EVO_GATE_ON:
        return None
    import time as _t, json as _j
    _now = _t.time()
    if _now - _EV_C['t'] > 300:
        _rs = []
        try:
            _p = os.path.join(_UD, 'data_v2', 'mtsim', '_演化_规则.json')
            if _now - os.path.getmtime(_p) <= 7200:
                _rs = (_j.load(open(_p, encoding='utf-8')) or {}).get('忌开') or []
        except Exception:
            pass
        _EV_C.update(t=_now, rules=_rs)
    _c = str(coin or '').upper()
    _s = str(side or '')
    _h = int(hour if hour is not None else _t.localtime().tm_hour)
    for _r in _EV_C['rules']:
        _k = str(_r.get('规则') or '')
        if '×' not in _k:
            continue
        _l, _rr = _k.split('×', 1)
        if _rr != '向=' + _s:
            continue
        if _l == '币=' + _c:
            return _k
        if reg and _l == '四态=' + str(reg):
            return _k
        if _l.startswith('时段='):
            try:
                _a, _b = _l[3:].replace('时', '').split('-')
                if int(_a) <= _h <= int(_b):
                    return _k
            except Exception:
                pass
    return None


def 中枢判(coin):
    """🐉 取中枢之声(60秒缓存)。返回该币裁决 dict 或 None(无声/超龄)。只读。"""
    import time as _t, json as _j
    _now = _t.time()
    if _now - _ZS_C['t'] > 60:
        _d, _age = {}, None
        try:
            _p = os.path.join(_UD, 'data_v2', 'mtsim', '_多空源五行_扫描.json')
            _age = _now - os.path.getmtime(_p)
            if _age <= ZS_MAX_AGE:
                _raw = _j.load(open(_p, encoding='utf-8'))
                _d = {str(_v.get('币')).upper(): _v for _v in (_raw.get('王者裁决') or [])}
            else:
                print('[中枢] ⚠ 中枢档超龄 %.0f 分钟 ⇒ 视为无声' % (_age / 60.0), flush=True)
        except Exception as _e:
            print('[中枢] ⚠ 读中枢失败: %s ⇒ 视为无声' % str(_e)[:60], flush=True)
        _ZS_C.update(t=_now, d=_d, age=_age)
    return (_ZS_C['d'] or {}).get(str(coin).upper())

# 🧠🔥2026-10-08 10:24 老板令「完成并完善系统之王烛龙主神大脑和眼睛的工程…直接开启真钱交易测试」(火印 ED-20261008-619)
#   大脑门: 读主神大脑产物 `烛龙大脑/_脑_判断.json`（逐币: 向/信度/神经网络 拟合分）
#   规则(三步同向律): 双否(大脑反向 且 NN<阈) ⇒ 禁开; 单否(大脑反向) ⇒ 减半; 同向 ⇒ 放行。
#   开关: ZHU_BRAIN_GATE_ON(默认1) · ZHU_BRAIN_HALF(默认1) · ZHU_BRAIN_NN_BLOCK(默认0.50) · ZHU_BRAIN_MAX_AGE(默认900秒)
#   失败开门: 产物超龄/缺该币/异常 ⇒ 放行(不刷日志不拦)。
B_ON = os.environ.get('ZHU_BRAIN_GATE_ON', '1') != '0'
B_HALF = os.environ.get('ZHU_BRAIN_HALF', '1') != '0'
try:
    B_NN_BLOCK = float(os.environ.get('ZHU_BRAIN_NN_BLOCK', '0.50') or 0.50)
except Exception:
    B_NN_BLOCK = 0.50
try:
    B_MAX_AGE = float(os.environ.get('ZHU_BRAIN_MAX_AGE', '900') or 900)
except Exception:
    B_MAX_AGE = 900.0


# 👑🔥2026-10-11 老板令「每轮币王荐向必须达到四源共振要求、接入判定链、真钱、内核…
#   加上精准定位、敏感度，直接可应用于烛龙火印下发腾蛇执行开仓」(火印 ED-20261011-905)
#   币王令门: 读《_币王令.json》(由 _核_币王令.py 产: 四源共振 + 精准定位 + 敏感度 + 授权待火印)
#   · 默认(只读留痕·零行为变化): 该币为**达标币王** ⇒ 咽喉打「👑币王令·准行」；引擎欲开之向与令相反 ⇒ 打「👑币王令·逆王(警示)」
#   · BWL_STRONG_ON=1(须火印+老板点头): 达标币王·同向 ⇒ 主动放行(越软拦；硬闸/风控/止损一字不动)
#   · BWL_BLOCK_OPP=1(须火印+老板点头): 与达标币王反向 ⇒ 拦(禁逆王开仓)
#   失败开门: 令缺/超龄/异常 ⇒ 放行。回退: 删本段 + 删 judge() 内币王令段。
BWL_ON = os.environ.get('BWL_GATE_ON', '1') != '0'
BWL_STRONG = os.environ.get('BWL_STRONG_ON', '0') != '0'
BWL_BLOCK_OPP = os.environ.get('BWL_BLOCK_OPP', '0') != '0'
# 👑🆕2026-10-12 火印 ED-20261012-992 开仓必选币王（老板令「开仓必选币王」·仅 xwu/zls 置 1）
#   1=硬闸: 拟开之币须为「达标币王(四源共振)」且向相符, 否则不开(宁缺毋滥)。默认0=零行为变化(他户不受影响)。
#   ⚠此为一闸·与《活跃交易不可设闸戒》(ED-20261009-767)相左 —— 老板明令, 留痕备查。回退: env BWL_REQUIRE_ON=0。
BWL_REQUIRE = os.environ.get('BWL_REQUIRE_ON', '0') != '0'
try:
    BWL_MAX_AGE = float(os.environ.get('BWL_MAX_AGE', '900') or 900)
except Exception:
    BWL_MAX_AGE = 900.0

# 👑🔥🆕2026-10-12 火印 ED-20261012-1000 令出火速开（老板令「币王令出即能实现火速开仓，不能延误时机，几秒钟区间，位置就差一大截」）
#   王上手谕/达标币王 同向 ⇒ 开仓咽喉**即刻放行**（免「无令不开」之起势关）。默认0=零行为变化。
EDICT_FAST_FIRE_ON = os.environ.get('EDICT_FAST_FIRE_ON', '0') != '0'
try:
    EDICT_FAST_TTL_MIN = float(os.environ.get('EDICT_FAST_TTL_MIN', '120') or 120)
except Exception:
    EDICT_FAST_TTL_MIN = 120.0
# 🐍🔥🆕2026-10-12 火印 ED-20261012-1041 腾蛇执火印·加敏（老板令「给腾蛇执火印加敏，增强灵敏度，确保链路通畅无阻」）
#   加敏(不碰择向精准·只动开仓咽喉的"放行灵敏度"):
#     ① 手谕同向 ⇒ 放行时加"信度门槛" EDICT_FAST_MIN(默认0=不限; 户设0.80即只放高信度令 ⇒ 更准不更滥)
#     ② 达标币王同向 ⇒ 放行不再强制 BWL_STRONG(EDICT_SENS_ON=1 即认"币王令"本身为凭 ⇒ 更灵敏)
#     ③ 防脱令: EDICT_FAST_TTL_MIN 由120放宽(帝设180) ⇒ 令未刷新期间不脱令
#   边界: 只改"火速开"放行判据·不碰择向/_pick/圣裁/天眼/风控/止损/硬闸。回退: env EDICT_SENS_ON=0 且删 EDICT_FAST_FIRE_ON。
EDICT_SENS_ON = os.environ.get('EDICT_SENS_ON', '1') != '0'
try:
    EDICT_FAST_MIN = float(os.environ.get('EDICT_FAST_MIN', '0') or 0)   # 手谕信度门槛(0=不限)
except Exception:
    EDICT_FAST_MIN = 0.0
_WANG_HAND_FILE = os.path.join(_UD, 'data_v2', 'mtsim', '_王上手谕.json')
_WANG_HAND_CACHE = [0.0, {}]


def 币王令(coin):
    """👑 读币王令（达标者）→ dict | None（缺/超龄/异常 ⇒ None ⇒ 放行）"""
    if not (BWL_ON and coin):
        return None
    try:
        import json as _json, time as _time
        p = os.path.join(_UD, 'data_v2', 'mtsim', '_币王令.json')
        if _time.time() - os.path.getmtime(p) > BWL_MAX_AGE:
            return None
        d = _json.load(open(p, encoding='utf-8'))
        for _k in ('多单币王', '空单币王'):
            _v = d.get(_k) or {}
            if _v.get('币') == coin and (_v.get('四源共振') or {}).get('达标'):
                return {'向': _v.get('向'), '标': _k, '共振': (_v.get('四源共振') or {}).get('同向'),
                        '敏感': _v.get('敏感度'), '级': _v.get('敏感度级'),
                        '授权': _v.get('授权'), '定位': _v.get('精准定位')}
        return None
    except Exception:
        return None


def 手谕(coin):
    """👑🔥 读《_王上手谕.json》火印手谕 → dict | None（缺/超龄/异常 ⇒ None ⇒ 不拦·交其余闸）"""
    if not coin:
        return None
    try:
        import json as _json, time as _time
        _mt = os.path.getmtime(_WANG_HAND_FILE)
        if _mt != _WANG_HAND_CACHE[0]:
            try:
                _d = _json.load(open(_WANG_HAND_FILE, encoding='utf-8'))
            except Exception:
                _d = {}
            _mp = {}
            for _it in (_d.get('手谕') or []):
                _mp[str(_it.get('币') or '').upper()] = _it
            _WANG_HAND_CACHE[0] = _mt; _WANG_HAND_CACHE[1] = _mp
        _it = _WANG_HAND_CACHE[1].get(str(coin).upper())
        if not _it:
            return None
        _ts = str(_it.get('时刻') or '')
        if _ts:
            try:
                _age = (_time.time() - _time.mktime(_time.strptime(_ts[:19], '%Y-%m-%d %H:%M:%S'))) / 60.0
                if _age > EDICT_FAST_TTL_MIN:
                    return None
            except Exception:
                pass
        return {'向': _it.get('向'), '信': _it.get('信'), '印': _it.get('火印')}
    except Exception:
        return None


def 脑判(coin):
    """🧠 读主神大脑逐币判（向/信度/神经网络）→ dict | None（超龄/缺币/异常 ⇒ None ⇒ 放行）"""
    if not (B_ON and coin):
        return None
    try:
        import json as _json, time as _time
        p = os.path.join(_UD, '烛龙大脑', '_脑_判断.json')
        if _time.time() - os.path.getmtime(p) > B_MAX_AGE:
            return None
        d = _json.load(open(p, encoding='utf-8'))
        return (d.get('逐币') or {}).get(coin) or None
    except Exception:
        return None


def 眼级(coin, side):
    """👁 逐向读辨伪天眼判级 → (级|None, 真伪度|None, 判词)
       None = 不可用/超龄/异常 ⇒ 调用方**放行**(失败开门)"""
    if not TY_ON:
        return (None, None, '眼闸=关')
    try:
        import importlib.util as _u, json, time
        p = os.path.join(_UD, '烛龙大脑', '_天眼_真伪.json')
        age = time.time() - os.path.getmtime(p)
        if age > TY_MAX_AGE:
            return (None, None, '天眼产物超龄%.0f秒 ⇒ 放行' % age)
        S = _u.spec_from_file_location('ty_gate_%d' % (int(time.time() * 1000) % 100000), os.path.join(_UD, '_天眼_辨真伪.py'))
        ty = _u.module_from_spec(S); S.loader.exec_module(ty)
        r = ty.判(coin, side) or {}
        g = r.get('分级') or ty.级(r.get('真伪度'))
        return (g, r.get('真伪度'), r.get('判词') or '')
    except Exception as _e:
        return (None, None, '眼闸异常放行:%s' % str(_e)[:40])


def banner():
    return '🐉👑 烛龙至尊·天下一统 | 王=[烛龙] 唯一决断 | 其余(八神兽+择向诸门)=参谋·无决策权'


if SUPREME_ON:
    try:
        print('👑[开仓咽喉]' + banner(), flush=True)
    except Exception:
        pass


def _stamp(E, sig):
    """王令留痕: 读内核圣裁(E.ZHU_EDICT) → 记「王(烛龙)准 + 参谋团意见」· 参谋无决策权。纯只读"""
    try:
        ze = getattr(E, 'ZHU_EDICT', None) or {}
        _votes = ze.get('votes') or {}
        _ros = ' '.join('%s%s' % (k, '+' if v > 0 else ('-' if v < 0 else '0')) for k, v in _votes.items())
        print('👑[王令·烛龙]准：%s %s → 圣裁=%s 信%.2f | 参谋团[%s]' % (
            (sig or {}).get('coin'), (sig or {}).get('side'), ze.get('verdict'),
            float(ze.get('conf') or 0), _ros), flush=True)
    except Exception:
        pass


def sizing_half(coin, side):
    """🧠👁 降权（指挥链：大脑为准·眼为凭）：大脑降权 或 疑 或 与大脑反向 ⇒ 名义减半 → (是否减半, 因由)"""
    _rs = []
    _b = 脑判(coin) if (B_ON and B_HALF) else None
    if _b:
        try:
            if bool(_b.get('降权')):
                _rs.append('大脑降权(眼级%s 真伪%.2f)' % (_b.get('天眼分级'), float(_b.get('真伪度') or 0)))
            _bw = str(_b.get('向') or '')
            if _bw and _bw != 'hold' and side and _bw != side:
                _rs.append('大脑反向(大脑%s 信%.2f)' % (_bw, float(_b.get('信度') or 0)))
        except Exception:
            pass
    if TY_ON and TY_YELLOW_HALF:
        try:
            g, d, w = 眼级(coin, side)
            if g == '🟡疑' and not _rs:
                _rs.append('🟡疑(真伪%.2f %s)' % (float(d or 0), w))
        except Exception:
            pass
    return (True, ' + '.join(_rs)) if _rs else (False, '非疑·非反·非降')


# ══ 🔒 九户同币锁（老板令 2026-10-25 04:29「确认，可执行。急急如律令。」· 火印 ED-20261025-2030）══
#   一中心分片治理·撞币同币开仓：某币已被别户开仓 ⇒ 本户「不可开仓」；平仓即自动恢复。
#   边界：只加开仓前一道查锁；不碰止损/离场/量程/择向算式/风控闸；锁器异常一律放行。
#   开关：COIN_LOCK_ON=1(默认) / =0 回旧行为。
_ME = {'v': ''}
_CL = {'m': None}


def 设户(n):
    try:
        _ME['v'] = str(n or '').lower()
        _m = _锁器()
        if _m and _m.on():
            print('🔒[%s] 九户同币锁已挂 · %s' % (_ME['v'], _m.报盘()), flush=True)
    except Exception:
        pass


def _锁器():
    if _CL['m'] is not None:
        return _CL['m']
    try:
        import importlib.util as _iu
        _s = _iu.spec_from_file_location('coinlock', os.path.join(_UD, '_器_同币锁.py'))
        _m = _iu.module_from_spec(_s)
        _s.loader.exec_module(_m)
        _CL['m'] = _m
    except Exception:
        _CL['m'] = False
    return _CL['m']


def on():
    return os.environ.get('OPEN_ORDER_GATE_ON', '1') != '0'


def _五行无独立开仓权(E, sig):
    """☯ 五行只作参谋·无开仓权（ED-20261025-2030·乙）
    规则：五行同向但**其余诸路无一背书** ⇒ 不得独自开仓。五行不同向/读数缺失 ⇒ 交既有关，不拦。
    """
    try:
        import json as _js
        if os.environ.get('WUXING_ADVISORY_ONLY', '1') == '0':
            return (True, '')
        _sd = str((sig or {}).get('side') or '')
        if not _sd:
            return (True, '')
        v = None
        ze = getattr(E, 'ZHU_EDICT', None) or {}
        if isinstance(ze, dict):
            for _k in ('逐路', 'votes', '票'):
                if isinstance(ze.get(_k), dict) and ze.get(_k):
                    v = ze.get(_k); break
        if not isinstance(v, dict) or not v:
            try:
                with open(os.path.join(_UD, 'data_v2/mtsim/_烛龙圣裁.json'), encoding='utf-8') as _f:
                    v = (_js.load(_f) or {}).get('逐路') or {}
            except Exception:
                v = {}
        if not isinstance(v, dict) or not v:
            return (True, '')

        def _num(x):
            try:
                return float(x)
            except Exception:
                s = str(x)
                return 1.0 if ('多' in s or s in ('up', 'long', '+1')) else (-1.0 if ('空' in s or s in ('dn', 'short', '-1')) else 0.0)
        wy = _num(v.get('阴阳五行', 0))
        want = 1.0 if _sd == 'long' else -1.0
        if wy == 0 or wy != want:
            return (True, '')
        others = [k for k in v if k != '阴阳五行' and _num(v.get(k)) == want]
        if not others:
            return (False, '☯五行只作参谋: 仅五行同向、其余诸路无一背书 ⇒ 无开仓权(不开)')
        return (True, '')
    except Exception:
        return (True, '')


def _环境不适(sig):
    """🌀 顶底中段震荡 / 死水微澜·无肉 ⇒ 环境不适·不开（ED-20261025-2030·丙·机变）
    只看 sig 已有的 pos4(区间位0~100)/amp6(6根振幅%)/score(择向分)：
      ①死水：振幅<0.8% 且 非强信号(|score|<2.0)
      ②中段：区间位在22~78(中段非顶非底) 且 非强信号 且 振幅<1.5%
    强信号(|score|≥2.0)或读数缺失 ⇒ 一律放行（不憋死交易）。
    """
    try:
        if os.environ.get('ENV_ADAPT_ON', '1') == '0':
            return (True, '')
        _p4 = float((sig or {}).get('pos4') or 50.0)
        _amp = float((sig or {}).get('amp6') or 0.0)
        _sc = abs(float((sig or {}).get('score') or 0.0))
        _strong = _sc >= float(os.environ.get('ENV_STRONG_SCORE', '2.0') or 2.0)
        _dead = float(os.environ.get('ENV_DEAD_AMP', '0.8') or 0.8)
        _mid = float(os.environ.get('ENV_MID_AMP', '1.5') or 1.5)
        if _strong:
            return (True, '')
        if _amp > 0 and _amp < _dead:
            return (False, '🌀死水微澜: 振幅%.2f%%<%.2f%% · 弱信号(%.1f) ⇒ 环境不适·不开' % (_amp, _dead, _sc))
        if 22.0 <= _p4 <= 78.0 and 0 < _amp < _mid:
            return (False, '🌀中段震荡: 区间位%.0f(中段) 振幅%.2f%% · 弱信号(%.1f) ⇒ 环境不适·不开' % (_p4, _amp, _sc))
        return (True, '')
    except Exception:
        return (True, '')


def _最佳位置拦(sig):
    """🎯 顶底最佳位置（ED-20261025-2030·丙之补）
    做多不在区间顶追高（pos4≥85）· 做空不在区间底追低（pos4≤15）；
    强突破（|score|≥3.0）豁免；读数缺失放行。开关 ENTRY_ZONE_ON。
    """
    try:
        if os.environ.get('ENTRY_ZONE_ON', '1') == '0':
            return (True, '')
        sg = sig or {}
        if sg.get('pos4') is None:
            return (True, '')
        _p4 = float(sg.get('pos4'))
        _sd = str(sg.get('side') or '')
        try:
            _sc = abs(float(sg.get('score') or 0.0))
        except Exception:
            _sc = 0.0
        _hi = float(os.environ.get('ENTRY_ZONE_HI', '85') or 85)
        _lo = float(os.environ.get('ENTRY_ZONE_LO', '15') or 15)
        _strong = float(os.environ.get('ENTRY_ZONE_STRONG', '3.0') or 3.0)
        if _sc >= _strong:
            return (True, '')
        if _sd == 'long' and _p4 >= _hi:
            return (False, '🎯位置不佳: 做多在区间顶(位%.0f≥%.0f) ⇒ 追高不开' % (_p4, _hi))
        if _sd == 'short' and _p4 <= _lo:
            return (False, '🎯位置不佳: 做空在区间底(位%.0f≤%.0f) ⇒ 追低不开' % (_p4, _lo))
        return (True, '')
    except Exception:
        return (True, '')


def _时段闸(E, sig):
    """🕰 时段闸（ED-20261025-2030·戊之自校准产出）"""
    try:
        import time as _t
        if os.environ.get('HOUR_GATE_ON', '1') == '0':
            return (True, '')
        p = os.path.join(_UD, 'data_v2/mtsim/_时段闸.json')
        if not os.path.exists(p):
            return (True, '')
        with open(p, encoding='utf-8') as f:
            d = json.load(f) or {}
        hrs = d.get('不开时段') or []
        if not hrs:
            return (True, '')
        h = int(_t.strftime('%H'))
        if h in [int(x) for x in hrs]:
            return (False, '🕰时段闸: %02d点档历史命中偏低 ⇒ 本档不开' % h)
        return (True, '')
    except Exception:
        return (True, '')


def judge(E, st, sig):
    """开仓归序判据 → (是否放行, 因由)。纯只读·不改任何状态。"""
    if not on():
        return (True, '开仓归序=关(旧行为)')
    # 🔒 九户同币锁（ED-20261025-2030）: 一币一户，先到先得，平仓自动恢复
    _lkm = _锁器()
    if _lkm and _lkm.on():
        try:
            _me = str(getattr(E, 'NODE', None) or _ME['v'] or '').lower()
            _ck = (sig or {}).get('coin')
            if _me and _ck:
                _lok, _lwhy = _lkm.判开(_ck, _me, (sig or {}).get('side'))
                if not _lok:
                    print('[开仓咽喉]' + _lwhy, flush=True)
                    return (False, _lwhy)
        except Exception:
            pass
    # ☯ 五行只作参谋·无开仓权（ED-20261025-2030·乙）
    _wok, _wwhy = _五行无独立开仓权(E, sig)
    if not _wok:
        print('[开仓咽喉]' + _wwhy, flush=True)
        return (False, _wwhy)
    # 🌀 环境不适（ED-20261025-2030·丙）: 中段震荡/死水微澜·非强信号 ⇒ 不开（机变）
    # 🧹2026-10-25 08:2x 老板令「别玩乱七八糟的花样，一招就可以搞定」
    #   ⇒ 旗在：只留「开错就扭」（乾坤扭转），环境/位置/时段三道新拦全停。
    _简 = os.path.exists(os.path.join(_UD, 'data_v2/mtsim/_简化_只管扭转.flag'))
    _eok, _ewhy = (True, '') if _简 else _环境不适(sig)
    if not _eok:
        print('[开仓咽喉]' + _ewhy, flush=True)
        return (False, _ewhy)
    # 🎯 顶底最佳位置（ED-20261025-2030·丙补）
    _zok, _zwhy = (True, '') if _简 else _最佳位置拦(sig)
    if not _zok:
        print('[开仓咽喉]' + _zwhy, flush=True)
        return (False, _zwhy)
    # 🕰 时段闸（ED-20261025-2030·戊之校准产出）
    _hok, _hwhy = (True, '') if _简 else _时段闸(E, sig)
    if not _hok:
        print('[开仓咽喉]' + _hwhy, flush=True)
        return (False, _hwhy)
    # 👑🔥2026-10-12 火印 ED-20261012-1000 令出火速开（老板令「币王令出即火速开仓·不能延误时机」）
    #   王上手谕 同向 或 达标币王 同向 ⇒ **即刻放行**（免起势关/大脑锁向/相位/总裁裁决·风控在跑器侧另守）
    if EDICT_FAST_FIRE_ON:
        try:
            _fc = (sig or {}).get('coin'); _fs = (sig or {}).get('side')
            _hd = 手谕(_fc)
            if _hd and _hd.get('向') and _fs and _hd.get('向') == _fs and float(_hd.get('信') or 0) >= EDICT_FAST_MIN:
                print('👑🔥 令出火速开(王上手谕同向): %s %s 信%.2f 印%s ⇒ 咽喉即放行'
                      % (_fc, _fs, float(_hd.get('信') or 0), _hd.get('印') or ''), flush=True)
                return (True, '👑🔥令出火速开(手谕同向)')
            _bfw = 币王令(_fc)
            if _bfw and _bfw.get('向') and _fs and _bfw.get('向') == _fs and (BWL_STRONG or EDICT_SENS_ON):
                print('👑🔥 令出火速开(达标币王同向): %s %s 共振%s 敏感%s ⇒ 咽喉即放行' % (
                    _fc, _fs, _bfw.get('共振'), _bfw.get('敏感')), flush=True)
                return (True, '👑🔥令出火速开(币王令同向)')
        except Exception:
            pass
    # 🐍👑🆕2026-10-12 火印 ED-20261012-1041 乙·无王从圣裁（老板令「无王从圣裁」）
    #   无达标币王且无手谕 ⇒ 显式回落烛龙圣裁(下接 起势关/大脑锁向/总裁裁决)·只通报不设闸(零行为变化·链路有据)。
    if EDICT_SENS_ON:
        try:
            _fc2 = (sig or {}).get('coin')
            if _fc2 and not 币王令(_fc2) and not 手谕(_fc2):
                _ze = getattr(E, 'ZHU_EDICT', None) or {}
                print('[开仓咽喉]👑 无王之地·从圣裁: %s 圣裁=%s 信%.2f ⇒ 交烛龙起势/总裁裁决' % (
                    _fc2, _ze.get('verdict'), float(_ze.get('conf') or 0)), flush=True)
        except Exception:
            pass
    if DIR_FIX_ON:
        try:
            _rg = str((sig or {}).get('regime') or '')
            _t4l = float((sig or {}).get('t4l') or 0)
            _p4 = (sig or {}).get('pos4')
            _p4 = float(_p4) if _p4 is not None else 50.0
            _sd = (sig or {}).get('side')
            if _sd == 'short' and not (_rg == 'dn' or _t4l <= -0.3):
                print('[择向修] ⛔ 逆势不做空: %s regime=%s t4l=%.2f' % ((sig or {}).get('coin'), _rg, _t4l), flush=True)
                return (False, '择向修·逆势不做空(regime=%s t4l=%.2f)' % (_rg, _t4l))
            if _sd == 'long' and _rg == 'dn':
                print('[择向修] ⛔ 跌势不做多: %s' % (sig or {}).get('coin'), flush=True)
                return (False, '择向修·跌势不做多')
            if _sd == 'long' and _p4 >= DIR_FIX_CHASE_POS:
                print('[择向修] ⛔ 不追高: %s pos=%.0f' % ((sig or {}).get('coin'), _p4), flush=True)
                return (False, '择向修·不追高(pos=%.0f)' % _p4)
        except Exception:
            pass
    # 🧭 指南针校准（磁偏角 + 过度自信）—— 只校准，不改方向
    if COMPASS_ON:
        _cc = str((sig or {}).get('coin') or '').upper()
        _ccf = 0.0
        try:
            _ccf = float((sig or {}).get('conf') or 0) or 0.0
        except Exception:
            _ccf = 0.0
        if not _ccf:
            try:
                _ze0 = getattr(E, 'ZHU_EDICT', None) or {}
                # 只在圣裁就是本币时取它的信心（防拿别币的信心错杀）
                if str(_ze0.get('coin') or '').upper() == _cc:
                    _ccf = float(_ze0.get('conf') or 0)
            except Exception:
                _ccf = 0.0
        if _ccf > 1.0:
            _ccf = _ccf / 100.0
        _cok, _cwhy = 指南针判(_cc, _ccf)
        if not _cok and _cc and (_cc in COMPASS_WEAK or _ccf > 0):
            print('[指南针] 🧭 拦: %s %s | %s' % (_cc, (sig or {}).get('side'), _cwhy), flush=True)
            return (False, '指南针·%s' % _cwhy)

    if ZHONG_SHU_GATE_ON:
        _zc = (sig or {}).get('coin')
        _zs = (sig or {}).get('side')
        _zv = 中枢判(_zc)
        if not _zv:
            print('[中枢] 🚫 无声·不开: %s %s' % (_zc, _zs), flush=True)
            return (False, '中枢无声·不开')
        if str(_zv.get('向') or '') != str(_zs or ''):
            print('[中枢] 🚫 逆中枢·不开: %s 将开=%s 中枢=%s(%s)' % (
                _zc, _zs, _zv.get('向'), str(_zv.get('裁决') or '')[:24]), flush=True)
            return (False, '中枢之向=%s·逆者不开' % _zv.get('向'))
        print('[中枢] ✅ 同声: %s %s 强%.2f' % (_zc, _zs, float(_zv.get('强') or 0)), flush=True)
        try:
            _ev = 演化判(_zc, _zs, _zv.get('四态'))
            if _ev:
                print('[演化] ⛔ 避雷·不开: %s %s 命中「%s」' % (_zc, _zs, _ev), flush=True)
                return (False, '自演化忌开·%s' % _ev)
        except Exception:
            pass
    try:
        _zg = E._zhulong_gate(st, sig)
    except Exception:
        _zg = None                      # 门异常 → 不拦(与内核风格一致: 异常放行, 交其余闸)
    if _zg:
        return (False, '烛龙起势关·%s' % _zg)
    # 🧠👁🔥2026-10-08 10:38 老板令「**大脑(烛龙)指挥眼，指挥系统，指挥全部**」(火印 ED-20261008-622)
    #   指挥链: **眼 → 大脑 → 系统** —— 以**大脑判定为准**（锁向⇒禁开·降权⇒减半）；大脑无该币/超龄 ⇒ 眼判为后备。
    _b = 脑判((sig or {}).get('coin'))
    _side = (sig or {}).get('side')
    if _b:
        if bool(_b.get('锁向')) and TY_RED_LOCK:
            return (False, '🧠👁大脑锁向(眼级%s 真伪%.2f) ⇒ 禁开' % (_b.get('天眼分级'), float(_b.get('真伪度') or 0)))
        _bw = str(_b.get('向') or '')
        try:
            _nn = float(_b.get('神经网络') or 0.5)
        except Exception:
            _nn = 0.5
        if _bw and _bw != 'hold' and _side and _bw != _side and _nn < B_NN_BLOCK:
            return (False, '🧠👁双否·大脑反向(大脑%s 信%.2f)且神经网络%.2f<%.2f ⇒ 禁开' % (_bw, float(_b.get('信度') or 0), _nn, B_NN_BLOCK))
    else:
        # 后备（大脑无该币）: 用眼判
        _g, _d, _w = 眼级((sig or {}).get('coin'), _side)
        if _g == '🔴伪' and TY_RED_LOCK:
            return (False, '👁🔴天眼锁向·伪(真伪%.2f %s) ⇒ 禁开' % (float(_d or 0), _w))
    # 🌀🔥2026-10-07 火印 ED-20261007-551 相位刀豁免（老板令「急急如律令，赋予相位刀豁免权」）
    #   反币已由相位刀翻正 ⇒ 刀向为尊；『与圣裁相左』不再构成拦截（起势门之制动/否决仍守·风控一字不动）。
    try:
        if int(os.environ.get('SIGN_PHASE_ADAPT_ON', '0') or 0) == 1:
            _phc = (sig or {}).get('coin')
            if _phc and ((E._phase_of(_phc) or {}).get('相位') == '反'):
                return (True, '🔥相位刀豁免(王火令): %s 反币已翻正 ⇒ 不以『与圣裁相左』为拦' % _phc)
    except Exception:
        pass
    # 👑2026-10-11 火印 ED-20261011-905: 币王令门（四源共振·精准定位·敏感度·待火印）
    try:
        _bw = 币王令((sig or {}).get('coin'))
        if _bw:
            _sd = (sig or {}).get('side')
            _same = (_bw.get('向') == _sd)
            _msg = '👑币王令·%s %s(%s) 共振%d/4 敏感%s%s' % (
                '准行' if _same else '逆王', _bw.get('标'), _bw.get('授权'),
                _bw.get('共振') or 0, _bw.get('敏感') or 0, _bw.get('级') or '')
            try:
                print('[开仓咽喉]' + _msg, flush=True)
            except Exception:
                pass
            if _same and BWL_STRONG:
                return (True, _msg + ' ⇒ 币王令授权放行')
            if (not _same) and BWL_BLOCK_OPP:
                return (False, _msg + ' ⇒ 禁逆王开仓')
    except Exception:
        pass
    # 👑🆕2026-10-12 火印 ED-20261012-992 开仓必选币王（xwu/zls 置 BWL_REQUIRE_ON=1）
    #   非达标币王 ⇒ 不开(宁缺毋滥); 币王向相左 ⇒ 不开。默认关=零行为变化。⚠此闸与 ED-767 相左·老板明令·留痕。
    try:
        if BWL_REQUIRE and BWL_ON:
            _bwq = 币王令((sig or {}).get('coin'))
            _sdq = (sig or {}).get('side')
            if not _bwq:
                return (False, '👑币王必选: %s 非达标币王(四源共振未达标) ⇒ 不开(宁缺毋滥)' % ((sig or {}).get('coin')))
            if _bwq.get('向') != _sdq:
                return (False, '👑币王必选: %s 拟开%s 与币王向%s 相左 ⇒ 不开' % ((sig or {}).get('coin'), _sdq, _bwq.get('向')))
    except Exception:
        pass
    try:
        _tv, _tw = E._teng_she_verdict(None, sig, st, 0.0, (sig or {}).get('side'))
    except Exception as _e2:
        return (True, '总裁裁决异常放行:%s' % str(_e2)[:40])
    if str(_tv) != '准':
        return (False, '总裁裁决·%s(%s)' % (_tv, _tw))
    if SUPREME_ON:
        _stamp(E, sig)
    return (True, '烛龙起势+总裁准')
