#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 🎯 择向密钥（2026-10-04 · 火印 ED-20261004-434）
#  老板令：「你自己安排，你是工程师…好好读经典，肯定能找到解开的密钥。方向错选错币，肯定就是择向问题」
#
#  经典取法（华夏经典知识库）：
#   · 《阴符经》「绝利一源，用师十倍」—— 去掉亏钱的源，火力才集中 ⇒ **剔劣**
#   · 《易经》「君子藏器于身，待时而动」—— 不是好时辰不出手 ⇒ **避时**
#   · 《孙子兵法》「先胜而后求战」—— 先算胜，再开仓；判多失准(42.6%) ⇒ **多单加严**
#   · 《道德经》「少则得，多则惑」—— 少而精，优中选优 ⇒ **取优**
#
#  只**拦新开**、绝不砍现有仓；任何异常一律**放行**（fail-open）；默认关。
#  env（全部可选）：
#   ZX_ON=1                  总开关（默认 0 = 关，一字不变）
#   ZX_BAN_COINS=NEAR,ARB    禁开币（信号准确率过低的劣币）
#   ZX_BAN_HRS=5,6,22        禁开时段（本地小时·信号最差时段）
#   ZX_LONG_MIN=0            多单最低分（>0 才启用；判多失准 ⇒ 抬高门槛）
#   ZX_PHASE_ON=0            相位校验（1=开：相位「反」不开多、「顺」不开空）
#   ZX_WANGWANG_PASS=0       观望放行（1=相位观望也放行·默认0=静默）
import json
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))


def _lst(v):
    return [x.strip().upper() for x in (v or '').replace('，', ',').split(',') if x.strip()]


def _hrs(v):
    out = []
    for x in (v or '').replace('，', ',').split(','):
        x = x.strip().rstrip('点')
        if x.isdigit():
            out.append(int(x) % 24)
    return out


ON = (os.environ.get('ZX_ON', '0') == '1')
BAN_COINS = _lst(os.environ.get('ZX_BAN_COINS') or '')
BAN_HRS = _hrs(os.environ.get('ZX_BAN_HRS') or '')
LONG_MIN = float(os.environ.get('ZX_LONG_MIN') or 0)
PHASE_ON = (os.environ.get('ZX_PHASE_ON', '0') == '1')
# 🕊2026-10-05 老板令「准」(火印 ED-20261005-457): 观望放行开关 ——
#   回测(1493笔)证实「观望静默」误伤赢单(106笔·胜56.6%·净+3375) ⇒
#   默认 0 = 旧行为(观望=静默); 置 1 = 观望(无势)也放行(只拦「反」向硬顶)。真钱六户不置此值 ⇒ 不受影响。
WW_PASS = (os.environ.get('ZX_WANGWANG_PASS', '0') == '1')
# 🕊2026-10-04 19:13 老板令「准。」(火印 ED-20261004-447): 同声门
#   两个声音相左者不出手 —— 净分(多源票数·即「四态」之源) 与 判向(道统) 反向 ⇒ 静默不出手。
#   证据: 全史 一致 203 笔 53.2% ｜ 打架 8 笔 25.0%（当日打架 6 笔 0%）⇒ 相左者不可信。
#   只拦新开·不砍现有·异常放行·默认关(TONG_SHENG_ON=0 时零行为变化)
TS_ON = (os.environ.get('TONG_SHENG_ON', '0') == '1')
TS_MIN = float(os.environ.get('TONG_SHENG_MIN') or 0.4)


def _phase(coin):
    try:
        p = json.load(open(os.path.join(HERE, 'data_v2', 'mtsim', '_相位表.json'), encoding='utf-8'))
        return str(((p.get('币') or {}).get(coin) or {}).get('相位') or '')
    except Exception:
        return ''


def check(coin, side, hour=None, score=None):
    """→ (可开:bool, 说明:str)。异常一律放行。"""
    try:
        coin = (coin or '').upper()
        side = (side or '').lower()
        if not ON:
            return True, '密钥关'
        if hour is None:
            hour = time.localtime().tm_hour
        hour = int(hour) % 24
        if BAN_COINS and coin in BAN_COINS:
            return False, '劣币(信号失准)不开: %s' % coin
        if BAN_HRS and hour in BAN_HRS:
            return False, '劣时(判势最差时段)不开: %d点' % hour
        if LONG_MIN > 0 and side == 'long' and score is not None:
            try:
                if float(score) < LONG_MIN:
                    return False, '多单分%.2f < 门%.2f(判多失准·加严)' % (float(score), LONG_MIN)
            except Exception:
                pass
        if TS_ON and score is not None:
            # 🕊同声门: 净分方向 ≠ 拟开方向 ⇒ 静默（票数与判向相左 = 两个声音打架）
            try:
                _s = float(score)
                if abs(_s) >= TS_MIN:
                    _want = 'long' if _s > 0 else 'short'
                    if _want != side:
                        return False, '道统·异声(净分%+.2f 与判向%s 相左=两个声音打架) → 静默' % (_s, side)
            except Exception:
                pass
        if PHASE_ON:
            # ✦ 道统（2026-10-04 17:09 老板令·火印 ED-20261004-440）:
            #   有所为(顺势而为) · 有所不为(无势不开)
            #   「大起势向多开多 · 大起势转空开空 · 无势不为·不做·伺机而动·静默」
            #   唯一不可为而为之的: 起势明明为多却开空(反着干) = 该死的
            _p = _phase(coin)
            if _p == '顺':                       # 势为多
                if side == 'short':
                    return False, '道统·势为多(顺) 却开空=逆势反干(该死) → 拦'
                return True, '✅顺势·势为多 → 开多(%s)' % coin
            if _p == '反':                       # 势为空
                if side == 'long':
                    return False, '道统·势为空(反) 却开多=逆势反干 → 拦'
                return True, '✅顺势·势为空 → 开空(%s)' % coin
            # 观望 = 无势
            if WW_PASS:
                return True, '道统·观望(无势)·放行(ZX_WANGWANG_PASS=1·回测证静默误伤赢单) → 开(%s)' % coin
            return False, '道统·无势不作为(观望) → 静默·伺机而动(%s)' % coin
        return True, '密钥过(币%s·%d点·方向%s)' % (coin, hour, side)
    except Exception as e:
        return True, '密钥异常→放行(%s)' % str(e)[:50]


if __name__ == '__main__':
    print('🎯 择向密钥(含道统) 自检  ON=%s BAN_COINS=%s BAN_HRS=%s LONG_MIN=%s PHASE_ON=%s 同声=%s(门%.2f)' % (ON, BAN_COINS, BAN_HRS, LONG_MIN, PHASE_ON, TS_ON, TS_MIN))
    print('   相位表现况: 顺=%s 反=%s' % (
        [c for c, v in (json.load(open(os.path.join(HERE, 'data_v2', 'mtsim', '_相位表.json'), encoding='utf-8')).get('币') or {}).items() if v.get('相位') == '顺'],
        [c for c, v in (json.load(open(os.path.join(HERE, 'data_v2', 'mtsim', '_相位表.json'), encoding='utf-8')).get('币') or {}).items() if v.get('相位') == '反']))
    for c, s, h, sc in (('NEAR', 'short', 9, -2.7), ('DOGE', 'short', 9, -2.7), ('DOGE', 'long', 9, 1.5),
                        ('FIL', 'long', 9, 1.5), ('FIL', 'short', 9, -2.7), ('BTC', 'long', 9, 1.5),
                        # 🕊同声门三例: 净分与判向相左 ⇒ 静默; 同向 ⇒ 照旧
                        ('SUI', 'short', 9, 0.8), ('LTC', 'long', 9, -0.8), ('SUI', 'short', 9, -0.8)):
        ok, why = check(c, s, h, sc)
        print('  %-5s %-5s %2d点 分%+.2f → %s  %s' % (c, s, h, sc, '✅放行' if ok else '🛑拦下', why))
