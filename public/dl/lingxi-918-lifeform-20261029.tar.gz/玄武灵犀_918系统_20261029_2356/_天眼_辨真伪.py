#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""👁🐉 烛龙·仿生辨真伪天眼 v2（高感知）（火印 ED-20261006-522 立 · ED-20261007-580 升高感知）
主人: 🐉烛龙 ｜ 造物: 🛠小奈 ｜ 纪律: 只读·只判·不改器（伪 ⇒ 该向废/削，但不下单不动仓）

v2 升维（老板令「具备高感知识别真伪信号能力」）:
  证据 7 类 → **13 类**：①相位 ②相位样本 ③相位顺期望 ④每笔期望 ⑤分歧 ⑥劫夺
  ⑦**位置(追高/接刀)** ⑧**近端反向(末根15m)** ⑨**大势冲突(24h t96)** ⑩**效率比弱(纯噪音)**
  ⑪**共识逆向** ⑫**王袍一票否决** ⑬**五行受抑** ⑭系统(网关/准确率/巡检)
  输出: 真伪度(0..1) + 判词 + **证据链(带严重度)** + **分项** + 置信
  · 高感知 = 逐证据取真源（信号源观测/五贼观星/相位表/每笔期望/多空信号源五行/烛龙判决）
  · 铁律: 不改判定链、不下单、不动仓；仅供烛龙大脑与门户「看得见」
用法:
  python3 _天眼_辨真伪.py            # 全判并写 烛龙大脑/_天眼_真伪.json
  python3 _天眼_辨真伪.py WLD        # 单币
  python3 _天眼_辨真伪.py --json     # 输出 JSON
"""
import json, os, sys, time

B = os.path.dirname(os.path.abspath(__file__))
MB = os.path.join(B, '烛龙大脑')
os.chdir(B)
OUT = os.path.join(MB, '_天眼_真伪.json')
# 🔓2026-10-08 火印 ED-20261008-625+ 调优·甲·天眼放阈（老板令「全上」）
#   据校准(31配对): 🔴伪实际命中 0.667 ＞ 🟢真 0.50 ⇒ 眼过严·误杀 ⇒ 降「伪」阈
_TRUE_TH = float(os.environ.get('TIANYAN_TRUE_TH', '0.75'))
_DOUBT_TH = float(os.environ.get('TIANYAN_DOUBT_TH', '0.30'))   # 原 0.45 ⇒ 0.30(放阈·减误杀)
_RED_LOCK = os.environ.get('TIANYAN_RED_LOCK', '1') != '0'


def L(p, d=None):
    try:
        return json.load(open(p, encoding='utf-8'))
    except Exception:
        return d


def _phase():
    return (L('data_v2/mtsim/_相位表.json') or {}).get('币') or {}


def _ev():
    return (L('data_v2/mtsim/_择向_每笔期望.json') or {}).get('币') or {}


def _wu():
    w = (L('data_v2/mtsim/_五贼观星.json') or {}).get('器一_五贼') or {}
    return {r.get('币'): r for r in (w.get('逐币') or []) if isinstance(r, dict)}


def _obs():
    o = L('data_v2/mtsim/_信号源观测.json') or {}
    return {r.get('币'): r for r in (o.get('逐币') or []) if isinstance(r, dict)}, o


def _sig5():
    d = L('data_v2/mtsim/_多空信号源_五行.json') or {}
    return {n.get('coin'): n for n in (d.get('nodes') or []) if isinstance(n, dict)}


def _jdg():
    d = L('data_v2/mtsim/_烛龙判决.json') or {}
    return {(n.get('币') or n.get('coin')): n for n in (d.get('nodes') or []) if isinstance(n, dict)}


def _sys_level():
    """系统级真伪: 网关级别 + 巡检告警 + 信号准确率"""
    gw = '未知'
    try:
        _gl = L('data_v2/mtsim/_巡检_点亮.json') or {}
        gw = (_gl.get('网关通道') or {}).get('级别') or gw
    except Exception:
        pass
    acc = L('data_v2/mtsim/_信号活跃准确.json') or {}
    alert = os.path.exists('data_v2/logs/_巡点异常.alert')
    return {'网关': gw, '巡检告警': alert,
            '近20准确率': acc.get('近20准确率'), '近50准确率': acc.get('近50准确率')}


def 判(coin, 向=None):
    """辨真伪 v2: 返回 {币,向,真伪度,判词,证据(链),分项,置信}"""
    ph = _phase().get(coin) or {}
    ev = (_ev().get(coin) or {})
    wu = _wu().get(coin) or {}
    ob = _obs()[0].get(coin) or {}
    n5 = _sig5().get(coin) or {}
    jg = _jdg().get(coin) or {}
    sy = _sys_level()
    sg = 1 if 向 == 'long' else (-1 if 向 == 'short' else 0)
    d = 1.0
    why = []
    分项 = {}

    def cut(k, v, tag):
        nonlocal d
        d -= v
        分项[k] = round(分项.get(k, 0.0) - v, 3)
        why.append('%s(−%.2f)' % (tag, v))

    # ①相位
    p = ph.get('相位')
    if p == '反':
        cut('相位', 0.45, '相位=反(该向逆相位)')
    elif p == '观望':
        cut('相位', 0.10, '相位=观望(无凭)')
    # ②相位样本
    try:
        if int(ph.get('样本') or 0) < 120:
            cut('相位样本', 0.10, '相位样本<120')
    except Exception:
        pass
    # ③相位顺期望
    try:
        if ph.get('顺期望') is not None and float(ph.get('顺期望')) < 0:
            cut('相位顺期望', 0.15, '顺期望<0')
    except Exception:
        pass
    # ④每笔期望
    try:
        e = float(ev.get('每笔期望'))
        if e < 0:
            cut('每笔期望', 0.20, '每笔期望%.2f<0(该币历史负期望)' % e)
        elif e < 0.5:
            cut('每笔期望', 0.08, '每笔期望%.2f(薄)' % e)
    except Exception:
        pass
    # ⑤分歧 ⑥劫夺
    try:
        fx = float(wu.get('分歧') or 0.0)
        if fx >= 0.8:
            cut('分歧', 0.15, '分歧≥0.8(参谋打架)')
        elif fx >= 0.6:
            cut('分歧', 0.08, '分歧≥0.6')
    except Exception:
        pass
    try:
        jd = float(wu.get('劫夺') or 0.0)
        if jd >= 0.5:
            cut('劫夺', 0.15, '劫夺≥0.5(势被夺)')
    except Exception:
        pass
    # ⑦位置（追高/接刀）—— v2 新
    try:
        pos = float(ob.get('pos')) if ob.get('pos') is not None else None
        if pos is not None and sg:
            if sg > 0 and pos >= 85:
                cut('位置', 0.18, '追高(位置%.0f≥85)高风险' % pos)
            elif sg < 0 and pos <= 15:
                cut('位置', 0.18, '接刀(位置%.0f≤15)高风险' % pos)
            elif sg > 0 and pos >= 70:
                cut('位置', 0.08, '位置偏高%.0f' % pos)
            elif sg < 0 and pos <= 30:
                cut('位置', 0.08, '位置偏低%.0f' % pos)
    except Exception:
        pass
    # ⑧近端反向（末根15m 与拟向相反）—— v2 新
    try:
        m1 = float(ob.get('m1') or 0.0)
        if sg and m1 * sg <= -0.30:
            cut('近端', 0.12, '末根15m %+.2f%% 与拟向相反' % m1)
        elif sg and m1 * sg <= -0.10:
            cut('近端', 0.05, '末根15m %+.2f%% 略逆' % m1)
    except Exception:
        pass
    # ⑨大势冲突（24h t96 与拟向相反）—— v2 新
    try:
        t96 = float(ob.get('t96') or 0.0)
        if sg and t96 * sg < 0:
            cut('大势', 0.15, '24h大势 %+.2f%% 与拟向相反' % t96)
    except Exception:
        pass
    # ⑩效率比弱（纯噪音·er 太小）—— v2 新（★仅在真读到 er 时扣·缺数不冤杀）
    try:
        if ob.get('er') is not None:
            er = abs(float(ob.get('er') or 0.0))
            if er < 0.03:
                cut('效率比', 0.10, '效率比%.3f 近噪音' % er)
    except Exception:
        pass
    # ⑪共识逆向 —— v2 新
    try:
        cs = (n5.get('源共识') or {})
        nd = cs.get('净向')
        if nd and sg and ((nd == 'long' and sg < 0) or (nd == 'short' and sg > 0)):
            cut('源共识', 0.15, '源共识净向%s 与拟向相左' % nd)
    except Exception:
        pass
    # ⑫王袍一票否决 —— v2 新
    try:
        wp = (jg.get('王袍') or {})
        if wp.get('一票否决'):
            cut('王袍', 0.35, '王袍一票否决')
    except Exception:
        pass
    # ⑬五行受抑 —— v2 新
    try:
        _sk = str(n5.get('生克') or '')
        if '(本命抑)' in _sk:
            cut('五行', 0.12, '五行受抑(本命被克)')
        elif '(态势顺)' in _sk:
            d = min(1.0, d + 0.05)
            分项['五行'] = round(分项.get('五行', 0.0) + 0.05, 3)
            why.append('五行得助(+0.05)')
    except Exception:
        pass
    # ⑭系统级
    try:
        if float(sy.get('近20准确率') or 100) < 50:
            cut('系统', 0.10, '系统近20准确率<50%')
    except Exception:
        pass
    if sy.get('网关') and str(sy['网关']).find('甲') < 0:
        cut('系统', 0.15, '网关非甲(%s)' % sy['网关'])
    if sy.get('巡检告警'):
        why.append('巡检有告警(系统级·未扣分)')
    # 信号源观测向与拟向相左
    if 向 and ob.get('向') in ('long', 'short') and ob.get('向') != 向:
        cut('信号源', 0.20, '信号源观测向(%s)与拟向(%s)相左' % (ob.get('向'), 向))

    d = max(0.0, min(1.0, d))
    判词 = ('真·可' if d >= 0.75 else ('疑' if d >= 0.5 else '伪·废'))
    证据条数 = len([x for x in why if '−' in x or '+' in x])
    置信 = round(min(1.0, 0.35 + 0.15 * 证据条数 + (0.2 if ph.get('样本') else 0.0)), 2)
    return {'币': coin, '向': 向, '真伪度': round(d, 3), '判词': 判词,
            '分级': 级(d), '锁向': (级(d) == '🔴伪'),
            '证据': why or ['无异象'], '证据条数': 证据条数, '分项': 分项, '置信': 置信,
            '相位': p, '近20准确率': sy.get('近20准确率'), '网关': sy.get('网关')}


def 级(d):
    """👁 三级判（2026-10-08 老板规格书「身眼脑一体化」· 火印 ED-20261008-591）
       🟢真 ≥ 0.75 · 🟡疑 0.45~0.75 · 🔴伪 < 0.45（🔴⇒锁向·禁发印）"""
    try:
        d = float(d or 0)
    except Exception:
        d = 0.0
    if d >= _TRUE_TH:
        return '🟢真'
    if d >= _DOUBT_TH:
        return '🟡疑'
    return '🔴伪'


def 全判():
    obs, o = _obs()
    coins = sorted(set(list(_phase().keys()) + list(obs.keys())))
    res = {}
    for c in coins:
        res[c] = 判(c, (obs.get(c) or {}).get('向'))
    rep = {'时刻': time.strftime('%F %T'), '火印': 'ED-20261006-522/ED-20261007-580', '版本': 'v2-高感知',
           '系统级': _sys_level(), '覆盖币数': len(res), '逐币': res,
           '真': [c for c, v in res.items() if v['真伪度'] >= _TRUE_TH],
           '疑': [c for c, v in res.items() if _DOUBT_TH <= v['真伪度'] < _TRUE_TH],
           '伪': [c for c, v in res.items() if v['真伪度'] < _DOUBT_TH]}
    os.makedirs(MB, exist_ok=True)
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(rep, f, ensure_ascii=False, indent=1)
    return rep


if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == '--json':
        print(json.dumps(全判(), ensure_ascii=False, indent=1))
    elif a and a[0].isalpha():
        print(json.dumps(判(a[0].upper()), ensure_ascii=False, indent=1))
    else:
        r = 全判()
        print('👁 天眼·辨真伪 %s（%s）' % (r['时刻'], r['版本']))
        print('  系统级: 网关%s 近20准确率%s 巡检告警%s' % (r['系统级'].get('网关'), r['系统级'].get('近20准确率'), r['系统级'].get('巡检告警')))
        for c, v in sorted(r['逐币'].items(), key=lambda x: -x[1]['真伪度']):
            print('  %-6s %-5s 真伪%.3f 信%s  %s' % (c, v['向'] or '-', v['真伪度'], v['置信'], ' ; '.join(v['证据'][:3])))
        print('  真: %s ｜ 伪: %s' % (','.join(r['真']) or '无', ','.join(r['伪']) or '无'))
        print('  产物 → 烛龙大脑/_天眼_真伪.json')
