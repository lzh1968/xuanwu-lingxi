#!/data/data/com.termux/files/usr/bin/bash
# 🔁 独立子系统·自巡守护(自包含·单实例·每 60 秒点卯): 引擎掉了就拉起来; 幂等。
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" || exit 1
NODE="${LINGXI_NODE:-zxy}"
mkdir -p data_v2/logs
_LD="data_v2/logs/.self_$(printf '%s' "$(basename -- "$0")" | md5sum | cut -c1-10).lock"
if mkdir "$_LD" 2>/dev/null; then echo $$ > "$_LD/pid"; else
  _op=$(cat "$_LD/pid" 2>/dev/null); _alive=0
  [ -n "$_op" ] && [ -d "/proc/$_op" ] && { _c=$(tr '\0' '\n' < "/proc/$_op/cmdline" 2>/dev/null | sed -n '2p'); case "$(basename -- "${_c:-}")" in "$(basename -- "$0")") _alive=1;; esac; }
  if [ "$_alive" = "1" ]; then echo "[$(date '+%F %T')] ⚠️自巡已有实例(PID $_op) → 退出" >> data_v2/logs/guard_self.log; exit 0; fi
  rm -rf "$_LD"; mkdir "$_LD" 2>/dev/null && echo $$ > "$_LD/pid"
fi
echo "[$(date '+%F %T')] 🔁 独立子系统自巡上线 (NODE=$NODE)" >> data_v2/logs/guard_self.log
while true; do
  if ! pgrep -f "python3 .*_子引擎\.py $NODE --mode paper" >/dev/null 2>&1; then
    echo "[$(date '+%F %T')] 🔧 引擎不在 → 拉起 $NODE" >> data_v2/logs/guard_self.log
    setsid nohup python3 -u _子引擎.py "$NODE" --mode paper >> "data_v2/logs/sub_${NODE}_paper.log" 2>&1 < /dev/null &
  fi
  sleep 60
done
