# -*- coding: utf-8 -*-
"""🧬 子引擎 runner (独立分身·2026-09-12 老板令"分身演化测试课程")
每个 ZH 分身 = 独立子引擎(自己的内核副本) + 独立账户(自己的API Key) + 资金自适应仓位管理.
与母体完全分离: 独立内核/账本/日志/锁/密钥.

用法:
  python3 _子引擎.py zh1                                  # 模拟(默认·绝不真单)
  python3 _子引擎.py zh1 --mode live --consent "<同意码>"  # 实盘(需同意码 + 该zh已配API Key)

账户配置: 子引擎/accounts.json
  { "zh1": {"key":"...", "secret":"...", "exchange":"gate"}, "zh2": {...}, "zxy": {...} }
  缺失 → 该分身只能跑模拟(拒绝真单).
"""
import os, sys, json, time, importlib.util as _u

HERE = os.path.dirname(os.path.abspath(__file__))
SUB = os.path.join(HERE, '子引擎')
NODE = (sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else 'zh1').strip()
os.makedirs(SUB, exist_ok=True)
MT = os.path.join(HERE, 'data_v2', 'mtsim')
MT_SUB = os.path.join(MT, 'sub')
os.makedirs(MT_SUB, exist_ok=True)

# ── 档位 ──
TIERS = {
    'paper': {'POOL': 5000, 'LEVER': 10, 'live': False},
    'live':  {'POOL': 0,    'LEVER': 10, 'live': True, 'note': '资金自适应(读账户真实权益)'},
}
CONSENT = {'live': '奈工复开实盘·分身独立测试(2026-09-12)'}
MODE = 'paper'
if '--mode' in sys.argv:
    MODE = sys.argv[sys.argv.index('--mode') + 1]
CONSENT_OK = None
if '--consent' in sys.argv:
    CONSENT_OK = sys.argv[sys.argv.index('--consent') + 1]
T = TIERS.get(MODE) or TIERS['paper']

# ── 加载独立内核(该分身专属副本) ──
KERNEL = os.path.join(SUB, f'_内核_{NODE}.py')
if not os.path.exists(KERNEL):
    print(f'❌ 子引擎内核不存在: {KERNEL} (需先复制 _内核_{NODE}.py)', flush=True)
    sys.exit(1)
E = _u.module_from_spec((s := _u.spec_from_file_location('m', KERNEL)))
s.loader.exec_module(E)

# ── 账户配置(该分身专属API Key) ──
ACCTS_FILE = os.path.join(SUB, 'accounts.json')
_acct = {}
try:
    _all = json.load(open(ACCTS_FILE, encoding='utf-8'))
    _acct = _all.get(NODE, {}) or {}
except Exception:
    _acct = {}

LIVE = T['live']
if LIVE:
    if CONSENT_OK != CONSENT['live']:
        print(f'❌ 实盘需同意码: --consent "{CONSENT["live"]}" (真钱第一)', flush=True)
        sys.exit(1)
    if not _acct.get('key') or not _acct.get('secret'):
        print(f'❌ {NODE} 未配置API Key(子引擎/accounts.json) → 拒绝真单, 请仅跑模拟', flush=True)
        sys.exit(1)

# ── 池: 🩸2026-09-16 老板令"换血分池"·一系统一专属池(零重叠·防同向撞车) ──
#   18子分家·基因一致·性格不尽相同: 内核逻辑同一, 各自专属币池。
#   (旧: _ALL7 全局7币三子同池 → 择向雷同撞车·根因已诊2026-09-16)
_NODE_POOLS = {
    # 🩸2026-09-16 老板令"融入原来七币·别死板·不再为重叠做无用功": 全系统恢复统一7币
    #   (换血差异化方案作废: 自讨苦吃·吃力不讨好)
}
_known_q = {'ETH':0.01,'SOL':1,'DOGE':10,'LINK':1,'XRP':10,'ADA':10,'BTC':0.0001,
            'BNB':0.001,'SUI':1,'AVAX':1,'HYPE':0.1,'ONDO':1,'LTC':0.1,
            'TAO':0.01,'NEAR':1,'DOT':1,'BCH':0.01,'FIL':0.01,'AAVE':0.01,'FET':1,'APT':0.1,'ETC':0.1}
_ALL7 = _NODE_POOLS.get(NODE, ['BTC','ETH','SOL','DOGE','LINK','XRP','ADA'])   # 兼容未分池节点
for c in _ALL7:
    if c not in E.WATCH_COINS:
        E.WATCH_COINS[c] = {'gate': f'{c}_USDT', 'quanto': _known_q.get(c, 1)}
E.WATCH_COINS = {k: v for k, v in E.WATCH_COINS.items() if k in _ALL7}

# ── 资金自适应(POOL按真实权益; 模拟用档位POOL) ──
if LIVE:
    E.POOL = 0    # 运行时 _recalibrate 读真实权益
else:
    E.POOL = float(T['POOL'])
E.LEVER = T['LEVER']
E.NOTIONAL = (E.POOL or 0) * E.LEVER

# ── 独立账本/日志(与母体/实盘完全隔离) ──
E.STATE_FILE = os.path.join(MT_SUB, f'_sub_{NODE}_state.json')
E.LOG_FILE = os.path.join(MT_SUB, f'_{NODE}_run.log')
E.PAPER = not LIVE

# 🛡 隔离防护墙(2026-09-12 老板令"必须完成·预防相互影响"): 取锁+账本白名单自检
import importlib.util as _u2
_wall = _u2.module_from_spec((_sw := _u2.spec_from_file_location('wall', os.path.join(HERE, '_隔离防护墙.py'))))
_sw.loader.exec_module(_wall)
if not _wall.install(entity=f'sub_{NODE}', state_file=E.STATE_FILE):
    sys.exit(1)

import json as _json

def load():
    f = E.STATE_FILE
    if os.path.exists(f):
        try:
            return _json.load(open(f, encoding='utf-8'))
        except Exception:
            pass
    return {'pos': None, 'realized': 0.0, 'trades': [], 'cooldown': 0}

def save(st):
    tmp = E.STATE_FILE + '.tmp'
    _json.dump(st, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False)
    os.replace(tmp, E.STATE_FILE)

def log(m):
    line = f"[{time.strftime('%m-%d %H:%M:%S')}] {m}"
    print(line, flush=True)
    try:
        open(E.LOG_FILE, 'a', encoding='utf-8').write('\n' + line)
    except Exception:
        pass

E.log = log

print(f'🧬 子引擎[{NODE}] 内核={os.path.basename(KERNEL)} | {"实盘" if LIVE else "模拟"} | 池={"/".join(sorted(E.WATCH_COINS))}', flush=True)
print(f'   账本={E.STATE_FILE}', flush=True)
print(f'   账户={"已配Key("+_acct.get("exchange","gate")+")" if _acct.get("key") else "未配Key(仅模拟)"}', flush=True)

# ── 实盘: 注入真单/真反手外壳(照 _母体实盘.py 基因·用本分身专属Key·含限价单治碎单药) ──
if LIVE:
    import gate_api
    from gate_api import Configuration
    gl = _u.module_from_spec((sp := _u.spec_from_file_location('gl', os.path.join(HERE, 'gate_live.py'))))
    sp.loader.exec_module(gl)
    _conf = Configuration(key=_acct['key'], secret=_acct['secret'], host='https://api.gateio.ws/api/v4')
    _conf.timeout = 10
    from gate_api import ApiClient, FuturesApi, FuturesOrder
    _api = FuturesApi(ApiClient(_conf))
    E._gate_api = _api

    # 💊 限价单治碎单(2026-09-12 与母体实盘同口径·保持一致性)
    LIMIT_ORDER = (os.environ.get('LIMIT_ORDER', '1') != '0')
    SLIP_PCT = float(os.environ.get('SLIP_PCT', '0.05'))

    def _px_now(gg):
        try:
            t = _api.list_futures_tickers('usdt', contract=gg)
            if t:
                return float(getattr(t[0], 'last', '0') or 0)
        except Exception:
            pass
        return 0.0

    def _place_smart(gg, signed, reduce_only=False):
        """智能下单: 限价单(整单·免碎单)优先, 失败回退市价IOC(保成交).
        ⚠️2026-09-15 17:20 纠错: close=true是【dual模式专用】! single模式传close=true→400! 保持close=False(原正确).
          真正病根: ZLS账户曾为dual(与GTAE的single不一致) → 已切回single. 启动模式自检防复发.
        """
        if not LIMIT_ORDER:
            _api.create_futures_order('usdt', FuturesOrder(contract=gg, size=str(signed), price='0', tif='ioc', reduce_only=reduce_only, close=False))
            return True
        px = _px_now(gg)
        if px <= 0:
            _api.create_futures_order('usdt', FuturesOrder(contract=gg, size=str(signed), price='0', tif='ioc', reduce_only=reduce_only, close=False))
            return True
        slip = px * SLIP_PCT / 100.0
        limit_px = round((px + slip) if signed > 0 else (px - slip), 8)
        try:
            _api.create_futures_order('usdt', FuturesOrder(contract=gg, size=str(signed), price=str(limit_px), tif='gtc', reduce_only=reduce_only, close=False))
            return True
        except Exception as e:
            print(f'⚠️子引擎[{NODE}]限价单失败({str(e)[:60]})→回退市价IOC', flush=True)
            _api.create_futures_order('usdt', FuturesOrder(contract=gg, size=str(signed), price='0', tif='ioc', reduce_only=reduce_only, close=False))
            return True

    def _futures():
        return _api

    E._place_smart = _place_smart
    E._futures = _futures
    print(f'   ✅ 实盘API就绪({NODE}·独立Key) | 💊限价单治碎单={"开" if LIMIT_ORDER else "关"}', flush=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # 🎚 自适应调仓(照 _母体实盘.py 基因移植·老板令"zls接实盘真人陪跑")
    #   小钱办大事: 火力按把握度自适应分配; 量程随真实权益自动标定(cap-adaptive).
    # ═══════════════════════════════════════════════════════════════════════════
    EQUITY_FALLBACK = 108.98   # zls 账户兼底(2026-09-12)
    _SUB_EQ_TOTAL = __import__('os').environ.get('SUB_EQUITY_TOTAL','1') != '0'  # 💠总权益口径(含占用·默认开)
    RISK_FULL = 1.0            # 满仓单: 保证金=权益×RISK_FULL
    WEAK_RATIO = 0.40          # 弱单: 名义=BASE_MAX×WEAK_RATIO
    # 💰2026-09-15 17:26 老板令"与GTAE实盘仓位管理一致": B2分级抬档(照搬GTAE参数)
    SUB_SIZING_B2 = __import__('os').environ.get('SUB_SIZING_B2','1') != '0'  # B2分级(默认开·=0回旧)
    B2_MIN_RATIO = float(__import__('os').environ.get('B2_MIN_RATIO','0.40'))
    B2_STRONG_RATIO = float(__import__('os').environ.get('B2_STRONG_RATIO','0.95'))
    B2_WEAK_FLOOR = float(__import__('os').environ.get('B2_WEAK_FLOOR','0.50'))
    B2_HARD_CAP = float(__import__('os').environ.get('B2_HARD_CAP','0.95'))
    # 🛡2026-09-21 06:35 老板令「收紧令·量程压到 0.65」(火印 ED-20260921-119): 硬封顶开关
    #   病: 子引擎只把 B2_HARD_CAP 用在“自检”，中信号档(sc 1.5~2.5)自然插值可到 ~0.9×BASE_MAX → 量程没真压住
    #   药: 与 `_母体实盘.py` 同口径补上硬封顶(可用×杠杆×B2_HARD_CAP) · **默认关=旧行为不变**
    #   回退: 删本段 或 env 去掉 B2_HARD_CAP_ON
    B2_HARD_CLAMP = __import__('os').environ.get('B2_HARD_CAP_ON','0') != '0'
    LEVER = int(E.LEVER)
    BASE_MAX = EQUITY_FALLBACK * RISK_FULL * LEVER
    BASE_MIN = BASE_MAX * WEAK_RATIO

    def _live_equity():
        """💠2026-09-15 17:16 修复(同母体13:16 bug): 返回【总权益】而非仅available.
           病: available($20)漏了占用保证金($58) → 权益低估4倍 → 量程偏小.
           药: total = available + cross_initial_margin + cross_unrealised_pnl. 回旧: SUB_EQUITY_TOTAL=0"""
        try:
            b = _api.list_futures_accounts('usdt')
            av = float(getattr(b, 'available', 0) or 0)
            if _SUB_EQ_TOTAL:
                imr = float(getattr(b, 'cross_initial_margin', 0) or 0)
                upnl = float(getattr(b, 'cross_unrealised_pnl', 0) or 0)
                tot = av + imr + upnl
                # 交叉校验: total 字段
                _t = float(getattr(b, 'total', 0) or 0)
                if _t > 1.0:
                    tot = max(tot, _t)
                return tot if tot > 1.0 else EQUITY_FALLBACK
            return av if av > 1.0 else EQUITY_FALLBACK
        except Exception:
            return EQUITY_FALLBACK

    def _live_available():
        """可用余额(供硬封顶用·与总权益区分)"""
        try:
            b = _api.list_futures_accounts('usdt')
            return float(getattr(b, 'available', 0) or 0)
        except Exception:
            return EQUITY_FALLBACK

    def _recalibrate_sizing():
        global BASE_MIN, BASE_MAX
        _eq = _live_equity()
        BASE_MAX = round(_eq * RISK_FULL * LEVER, 2)
        # 💰2026-09-15 17:26 与GTAE对齐: B2开时名义底用B2_MIN_RATIO
        _wr = B2_MIN_RATIO if SUB_SIZING_B2 else WEAK_RATIO
        BASE_MIN = round(BASE_MAX * _wr, 2)
        return BASE_MIN, BASE_MAX

    def _adaptive_notional(sig):
        try:
            sc = abs(float(sig.get('score', 0) or 0))
            reg = sig.get('regime'); side = sig.get('side'); tp = sig.get('tp')
            # 💰2026-09-15 17:26 与GTAE对齐: B2分级抬档(强信号整体上移)
            if SUB_SIZING_B2:
                if sc >= 3.5: f_score = 1.00
                elif sc >= 2.5: f_score = 0.95
                elif sc >= 2.0: f_score = 0.85
                elif sc >= 1.5: f_score = 0.70
                else: f_score = 0.55
            else:
                if sc >= 3.5: f_score = 1.0
                elif sc >= 2.5: f_score = 0.85
                elif sc >= 1.5: f_score = 0.65
                else: f_score = 0.50
            agree = (reg == 'up' and side == 'long') or (reg == 'dn' and side == 'short')
            f_reg = 1.0 if agree else (0.55 if reg in ('chop', None, '') else 0.7)
            f_tp = 1.0 if ((tp == 'UP' and side == 'long') or (tp == 'DOWN' and side == 'short')) else 0.85
            f = max(0.0, min(1.0, f_score * f_reg * f_tp))
            nt = BASE_MIN + (BASE_MAX - BASE_MIN) * f
            if SUB_SIZING_B2:
                # 💰B2: 强信号(sc≥2.5)贴MAX×0.95(保证金~90%); 弱单(sc<1.5)保底MAX×0.50
                if sc >= 2.5:
                    _nt = round(BASE_MAX * B2_STRONG_RATIO, 2)
                elif sc < 1.5:
                    _nt = round(min(nt, BASE_MAX * B2_WEAK_FLOOR), 2)
                else:
                    _nt = round(nt, 2)
            else:
                cap = 1.0 if sc >= 1.5 else 0.40
                _nt = round(min(nt, BASE_MAX * cap), 2)
            # 🛡收紧令硬封顶(默认关): 中信号档也按 可用×杠杆×B2_HARD_CAP 封顶(同母体口径)
            if SUB_SIZING_B2 and B2_HARD_CLAMP:
                try:
                    _hard = _live_available() * LEVER * B2_HARD_CAP
                    if _nt > _hard:
                        _nt = round(max(BASE_MIN * 0.5, _hard), 2)
                except Exception:
                    pass
            return _nt, f
        except Exception:
            return BASE_MIN, 0.0

    def _sz_dyn(coin, price, notional):
        q = E.WATCH_COINS[coin]['quanto']
        return max(1, int(round(notional / price / q)))

    def _gate_positions():
        if E.PAPER: return []
        try:
            ps = _api.list_positions('usdt') or []
            return [{'gate': p.contract, 'size': int(p.size)} for p in ps if int(p.size) != 0]
        except Exception:
            return []

    _gate_got = {'bad': False}
    def _gate_ok():
        if E.PAPER: return True
        try:
            _api.list_positions('usdt'); _gate_got['bad'] = False; return True
        except Exception:
            _gate_got['bad'] = True; return False

    def _selfcheck_sizing():
        try:
            mx = {'score': 4.0, 'side': 'short', 'regime': 'dn', 'tp': 'DOWN'}
            wk = {'score': 0.5, 'side': 'long', 'regime': 'chop', 'tp': 'UP'}
            nt_max, _ = _adaptive_notional(mx); nt_wk, _ = _adaptive_notional(wk)
            # 💰2026-09-15 17:27 对齐GTAE: B2满分单=BASE_MAX×B2_STRONG_RATIO → 达标线相应调整
            _top = BASE_MAX * (B2_STRONG_RATIO if SUB_SIZING_B2 else 1.0)
            _hard_now = _live_available() * LEVER * (B2_HARD_CAP if SUB_SIZING_B2 else 0.90)
            _capped = _top > _hard_now * 1.05   # 目标超真实可开能力(占用保证金致available受限)=正常
            ok = ((nt_max >= _top * 0.98) or _capped) and (nt_wk <= nt_max)
            print(f"🛡 [{NODE}]调仓量程自检: 满分顺势→${nt_max:.0f} / 弱单→${nt_wk:.0f} | {'✅通过' if ok else '❌未达标(档位可能错配)'}", flush=True)
            return ok
        except Exception as e:
            print(f'⚠️ 调仓量程自检异常: {str(e)[:80]}', flush=True); return False

    _selfcheck_sizing()
    # 🛡🆕2026-09-15 加固: 启动自检Gate持仓模式(须single·防dual模式致刷单)
    def _selfcheck_mode():
        if E.PAPER: return True
        try:
            _b = _api.list_futures_accounts('usdt')
            _m = getattr(_b, 'position_mode', '?'); _d = getattr(_b, 'in_dual_mode', None)
            if _m != 'single':
                print(f"🚨 [{NODE}]持仓模式异常: {_m}(dual={_d})! 必须为single → 平仓会失效/刷单! 请立即切回single!", flush=True)
                return False
            print(f"🛡 [{NODE}]持仓模式自检: {_m} ✅", flush=True)
            return True
        except Exception as _e:
            print(f"⚠️ [{NODE}]模式自检异常: {str(_e)[:80]}", flush=True); return False
    _selfcheck_mode()
    try:
        _bm, _bM = _recalibrate_sizing()
        print(f"💠 [{NODE}]量程按真实权益标定: BASE_MIN=${_bm:.0f} / BASE_MAX=${_bM:.0f} (权益${_live_equity():.2f}×{LEVER}x)", flush=True)
        _selfcheck_sizing()
    except Exception as _e:
        print(f"⚠️ 量程标定异常(用兼底): {str(_e)[:80]}", flush=True)

    # ═══════════ 覆盖 开/平 → 真单(照母体基因) ═══════════
    def _open_paper(st, sig, pr):
        # 🔒单仓强锁: live下若Gate真有非零仓(非本次要开的), 绝不再开新币
        if not E.PAPER and _gate_ok():
            real = _gate_positions()
            if real:
                # 🩹2026-09-23 丙药·锁见真仓(老板令上线): 查出「真仓但账本不认」→ 落告警旗(供账实巡检/人看)
                try:
                    _lonly = [x for x in real if isinstance(x, dict) and not (
                        st.get('pos') and
                        (E.WATCH_COINS.get(st['pos']['coin']) or {}).get('gate') == x.get('gate') and
                        st['pos'].get('side') == ('long' if (x.get('size') or 0) > 0 else 'short'))]
                    if _lonly:
                        open(os.path.join(HERE, 'data_v2', 'logs', '.alert_单仓锁见真仓_%s.flag' % NODE), 'a').write(
                            '%s 交易所真仓%s·账本不认 → 请核账(补记接管或平掉落账)\n' % (time.strftime('%F %T'), _lonly))
                except Exception:
                    pass
                print(f'🛑 [{NODE}]单仓锁: Gate仍有真仓{real}→拒开新币', flush=True); return False
        coin = sig['coin']; gg = E.WATCH_COINS[coin]['gate']
        _nt, _conf = _adaptive_notional(sig)
        # 🛡收紧令·开仓前硬校验 (2026-09-21 07:0x 老板问「持仓跑完空仓自适应立刻生效不会」· 火印 ED-119 续)
        #   第三道锁(双保险): 不论哪条路径算出名义, 开单前再对一次"可用×杠杆×B2_HARD_CAP" → 超了当场收回
        if (not E.PAPER) and B2_HARD_CLAMP:
            try:
                _hd = _live_available() * LEVER * B2_HARD_CAP
                if _hd > 1.0 and _nt > _hd * 1.02:
                    print(f'🛡 [{NODE}]收紧闸: 名义${_nt:.0f} 超硬顶${_hd:.0f} → 收回到硬顶(不超量)', flush=True)
                    _nt = round(max(BASE_MIN * 0.5, _hd), 2)
            except Exception:
                pass
        ct = _sz_dyn(coin, pr, _nt); signed = ct if sig['side'] == 'long' else -ct
        print(f"🎚 [{NODE}]自适应调仓: {coin} 把握{_conf*100:.0f}% → 名义${_nt:.0f}(保证金≈${_nt/E.LEVER:.0f}) score{abs(float(sig.get('score',0) or 0)):.0f} regime={sig.get('regime')}", flush=True)
        if not E.PAPER:
            try:
                from gate_api import FuturesOrder
                try:
                    _api.update_contract_position_leverage('usdt', gg, LEVER, 'cross')
                except Exception as _le:
                    print(f'⚠️ 设杠杆失败{coin}:{str(_le)[:80]}', flush=True)
                _place_smart(gg, signed, reduce_only=False)
                try:
                    _gpos = [x for x in _api.list_positions('usdt') if x.contract == gg and abs(int(x.size)) > 0]
                    if _gpos: pr = float(_gpos[0].entry_price)
                except Exception: pass
                print(f"📈[{NODE}真实开]{coin} {sig['side']} {ct}张 nominal${_nt:.0f}@ {gg} ({LEVER}x) 成交价{pr:.4f}", flush=True)
                if not _confirm_opened(gg):
                    print(f'❌开仓未成交(丢单·已多轮核验){coin}: Gate无仓→不记账本(防幽灵)', flush=True); return False
                try:
                    _nw2 = [x for x in _api.list_positions('usdt') if x.contract == gg and abs(int(x.size)) > 0]
                    if _nw2: pr = float(_nw2[0].entry_price)
                except Exception: pass
            except Exception as e:
                print(f'❌[{NODE}]真实开失败{coin}:{str(e)[:90]}', flush=True); return False
        st['pos'] = {'coin': coin, 'side': sig['side'], 'entry': pr, 'notional': _nt,
                     'peak': 0.0, 'peak_pct': 0.0, 'floor_pct': 0.0, 'size_ct': ct,
                     'big_meat': False, 'tier': 0, 'open_ts': time.time(), 'conf': round(_conf, 3),
                     '_ctx': {'score': sig.get('score'), 'regime': sig.get('regime'), 't4': sig.get('t4'),
                              't4l': sig.get('t4l'), 'gck': sig.get('gck'), 'tp': sig.get('tp'),
                              'last15': sig.get('last15'), 'regime_at_open': sig.get('regime')}}
        return True
    E._open_paper = _open_paper

    # 🛡2026-09-19 幽灵仓护栏 (老板令「执行」· 火印 ED-20260919-060)
    #   起因: 09-18 21:41 ZLS 平ADA单交易所已成交, 但睡1.2s后自查持仓仍读到338张(读取竞态)
    #        → 账本保留pos → 此后每9秒再平一次 → 交易所400(无仓可平) → 死循环刷屏 + 面板假浮盈
    _close_fail = {}

    def _confirm_closed(gg, tries=4):
        """平仓确认(治竞态): 多轮重试(≈1.2/2.7/4.2/5.7s); 查询失败继续试·不误判; 交易所确无此仓=已平"""
        for i in range(tries):
            time.sleep(1.2 + i * 1.5)
            try:
                ps = _api.list_positions('usdt') or []
            except Exception:
                continue
            if not [p for p in ps if p.contract == gg and int(p.size) != 0]:
                return True
        return False

    def _confirm_opened(gg, tries=4):
        """🩹2026-09-23 甲药·下单回执校验(老板令「立刻上线·勿误」): 开仓后**多轮**确认(≈1.2/2.7/4.2/5.7s)
           缘起: ZLS 09-22 21:59:44 真单已成交, 但**单次**自查撞上读取竞态 → 误判「丢单」→ 不落账
                → 无主仓裸奔 2.4 小时(带仓无兜底)。照平仓侧 `_confirm_closed` 同法。
           返回 True=确已开仓 / False=核验多轮仍无仓(真丢单)"""
        for i in range(tries):
            time.sleep(1.2 + i * 1.5)
            try:
                ps = _api.list_positions('usdt') or []
            except Exception:
                continue
            if [p for p in ps if p.contract == gg and int(p.size) != 0]:
                return True
        return False

    def _exchange_has(gg):
        """>0=有仓 / 0=确无仓 / None=查不通(不敢判)"""
        try:
            ps = _api.list_positions('usdt') or []
        except Exception:
            return None
        hit = [p for p in ps if p.contract == gg and int(p.size) != 0]
        return int(hit[0].size) if hit else 0

    def _close_here(st, pos, pr, pnl_pct, pnl_usd, why):
        # 🔧🆕2026-09-16 健壮化: 持仓币不在观察池时不再直接崩(同母体实盘修法)
        coin = pos['coin']; _wc = E.WATCH_COINS.get(coin) or {}; gg = _wc.get('gate'); sz = pos.get('size_ct', 1)
        closed_ok = True
        if not E.PAPER and gg:
            signed = -sz if pos['side'] == 'long' else sz
            try:
                from gate_api import FuturesOrder
                _place_smart(gg, signed, reduce_only=True)
                print(f"🔄[{NODE}真实平]{coin} {pos['side']} {sz}张 WHY={why}", flush=True)
                if not _confirm_closed(gg):     # 🛡多轮重试+交易所真相(原: 睡1.2s只查一次)
                    print(f'❌[{NODE}]真实平未清(仍持{gg})→账本保留pos', flush=True); closed_ok = False
            except Exception as e:
                print(f'❌[{NODE}]真实平失败{coin}:{str(e)[:90]}→账本保留pos', flush=True); closed_ok = False
        if not closed_ok:
            # 🛡护栏: 同仓连续≥3轮平不掉 → 核对交易所; 确无仓=幽灵仓 → 清pos+告警, 杜绝无限400重试
            _close_fail[coin] = _close_fail.get(coin, 0) + 1
            if _close_fail[coin] >= 3:
                _has = _exchange_has(gg)
                if _has == 0:
                    print(f'🛡[{NODE}]幽灵仓清理: 交易所已无{gg} → 账本清pos(盈亏待对账·连击{_close_fail[coin]})', flush=True)
                    try:
                        open(os.path.join(HERE, 'data_v2', 'logs', '.alert_幽灵仓_%s.flag' % NODE), 'a').write(
                            '%s %s 账本曾持%s张@%s·交易所已无仓 → 已清pos, 请对账真实盈亏\n' % (
                                time.strftime('%F %T'), gg, sz, pos.get('entry')))
                    except Exception: pass
                    st.setdefault('trades', []).append({'coin': coin, 'side': pos['side'],
                        'entry': round(float(pos.get('entry', 0)), 4), 'exit': None, 'pnl': 0.0, 'pnl_pct': 0.0,
                        'why': '幽灵仓自动清理(交易所已无仓)·盈亏待对账',
                        'peak_pct': round(pos.get('peak_pct', 0) * 100, 3),
                        'ts': round(time.time(), 1), 'day': time.strftime('%Y-%m-%d')})
                    st['pos'] = None
                    _close_fail[coin] = 0
                    return
                elif _has is None:
                    print(f'⚠️[{NODE}]平仓确认: 交易所查询不通·不妄判(连击{_close_fail[coin]})', flush=True)
            return
        _close_fail[coin] = 0
        st['realized'] = st.get('realized', 0) + pnl_usd
        # 🕐2026-09-15 17:21 老板令: 补时间戳(门户"最近交易"显示时间) — 原缺ts/day致门户无时间
        _now_ts = time.time()
        st.setdefault('trades', []).append({'coin': coin, 'side': pos['side'], 'entry': round(pos['entry'], 4),
            'exit': round(pr, 4), 'pnl': round(pnl_usd, 2), 'pnl_pct': round(pnl_pct * 100, 3), 'why': why,
            'peak_pct': round(pos.get('peak_pct', 0) * 100, 3),
            'ts': round(_now_ts, 1), 'day': time.strftime('%Y-%m-%d', time.localtime(_now_ts))})
        E._note_close(st, pnl_usd, why)
        st['pos'] = None
    E._close_here = _close_here

    def _flip(st, pos, pr, ppct, pnl_usd, why, sig, nw):
        st['cooldown'] = E.REOPEN_COOLDOWN
        _close_here(st, pos, pr, ppct, pnl_usd, why)
        if st.get('pos'):
            print(f"⚠️ [{NODE}]麒麟摆尾中止: {pos['coin']} 旧仓未平净 → 不反手", flush=True)
            return 'flip_fail'
        nsig = dict(sig); nsig['side'] = nw
        _ok = _open_paper(st, nsig, pr)
        if _ok is not False and st.get('pos'):
            st['pos']['_fandou'] = pos.get('_fandou', 0) + 1
            print(f"☯️ [{NODE}]一键换向(真反手): {pos['coin']} {pos['side']}→{nw} 拿肉{pnl_usd:+.2f}$后反手", flush=True)
            return 'flip'
        st['pos'] = None
        print(f"⚠️ [{NODE}]麒麟摆尾反手开失败: {pos['coin']}→{nw} → 账本置空(防幽灵)", flush=True)
        return 'flip_fail'
    E._FLIP_HOOK = _flip
    E._flip = _flip
    print(f'   ✅ [{NODE}]真单钩子就绪(开/平/反手·单仓强锁+真仓确认+平仓校验)', flush=True)

# ── 主循环(照母体口径) ──
_sleep = int(os.environ.get('FAST_HOLD_SLEEP', '8'))
st = load()
log(f"🧬 子引擎[{NODE}]启: 独立内核{'实盘' if LIVE else '模拟'} | 池{'/'.join(sorted(E.WATCH_COINS))} | 已实现{st.get('realized',0):+.2f}$ | 持仓 {st.get('pos') and (st['pos']['coin']+' '+st['pos']['side']) or '空'}")
print(f'   循环间隔: {_sleep}s', flush=True)

# 🛟2026-09-23 乙药·启动自检对账(老板令「立刻上线·勿误」)
#   病: 引擎重启时只读账本、不问交易所 → 「交易所真仓 / 账本空」时会一直空转(单仓锁拒开新币)且带仓无兜底
#      (ZLS 09-22 21:59 丢单事件即此病; 实盘四户共同缺口)
#   药: 启动时→交易所持仓 vs 账本对一遍:
#      a) 账本空 但 交易所恰有 1 笔池内真仓 → **补记接管**(带 real性止损), 告警留痕
#      b) 账本有空外的多余真仓(池外) → 只告警, 不擅动(待人工)
#      c) 账本有仓但交易所无此仓 → 交循环里的 GHOST_RECON 连续 3 轮确认后清(不在此处砸实)
#   关: env RECON_ON_START=0(=旧行为)
if LIVE and os.environ.get('RECON_ON_START', '1') != '0':
    try:
        _rps = [x for x in (_api.list_positions('usdt') or []) if int(x.size) != 0]
    except Exception:
        _rps = None
    if _rps is not None:
        _g2c = {}
        for _k, _v in E.WATCH_COINS.items():
            try: _g2c[_v.get('gate')] = _k
            except Exception: pass
        _myp = (E.WATCH_COINS.get(st['pos']['coin']) or {}).get('gate') if st.get('pos') else None
        _extra = [x for x in _rps if x.contract != _myp]
        if st.get('pos') is None and _extra:
            _p1 = _extra[0]; _c1 = _g2c.get(_p1.contract)
            if _c1:
                _szv = abs(int(_p1.size))
                _env = float(_p1.entry_price)
                _ntv = float(getattr(_p1, 'value', 0) or 0) or round(_szv * _env * 10, 2)
                st['pos'] = {'coin': _c1, 'side': 'long' if int(_p1.size) > 0 else 'short', 'entry': _env,
                             'notional': _ntv, 'peak': 0.0, 'peak_pct': 0.0, 'floor_pct': 0.0, 'size_ct': _szv,
                             'big_meat': False, 'tier': 0, 'open_ts': time.time(), 'conf': 1.0,
                             '_ctx': {'regime_at_open': None},
                             '_补记': {'原因': '启动自检对账: 交易所真仓·账本不认 → 补记接管', '源头': 'RECON_ON_START'}}
                save(st)
                print(f'🛟 [{NODE}]启动对账·补记接管: {_c1} {st["pos"]["side"]} {_szv}张 @{_env} (账本原为空)', flush=True)
                log(f'🛟 启动对账·补记接管 {_c1} {st["pos"]["side"]} {_szv}张 @{_env}')
            else:
                print(f'🛟 [{NODE}]启动对账·告警: 交易所真仓{[(x.contract, int(x.size)) for x in _extra]} 不在池内 → 不擅动, 待人工', flush=True)
                try:
                    open(os.path.join(HERE, 'data_v2', 'logs', '.alert_启动对账_池外真仓_%s.flag' % NODE), 'a').write(
                        '%s 交易所真仓%s 不在池内·账本不认 → 待人工处置\n' % (time.strftime('%F %T'), [(x.contract, int(x.size)) for x in _extra]))
                except Exception: pass
        elif st.get('pos') and _myp and [x for x in _rps if x.contract == _myp]:
            _rp1 = [x for x in _rps if x.contract == _myp][0]
            _bsz = abs(int(_rp1.size))
            if _bsz != int(st['pos'].get('size_ct', 0)):
                print(f'🛟 [{NODE}]启动对账·张数修正: {st["pos"]["coin"]} 账本{st["pos"].get("size_ct")}张 → 交易所{_bsz}张(按真相改)', flush=True)
                st['pos']['size_ct'] = _bsz
                st['pos']['entry'] = float(_rp1.entry_price)
                save(st)
        elif st.get('pos') and _myp and not [x for x in _rps if x.contract == _myp]:
            print(f'🛟 [{NODE}]启动对账·提醒: 账本有{st["pos"]["coin"]}但交易所无此仓 → 交循环 GHOST_RECON 连续确认后清', flush=True)
# 🛟2026-09-22 14:3x 老板令「通过」(体检·P0-②): 四子引擎补「账实对账」(照母体 `_gate_flat` 基因)
#   病: 交易所侧成交(预挂触发/手平/强平)平掉仓后引擎不知 → 账本假持仓 · 盈亏不入账 · 挡开新仓(今日已实证一次)
#   药: 账本有仓时每轮核交易所; **连续 GHOST_CONFIRM 轮**都确无此仓才判幽灵(防单次查询抖动误清真仓)
#       → 注 external_flat 走内核既有 ghost_cleared 路径(只清账本·不动钱)
#   关: env GHOST_RECON_ON=0(=旧行为) · 轮数 env GHOST_CONFIRM 默认 3
GHOST_RECON_ON = os.environ.get('GHOST_RECON_ON', '1') != '0'
GHOST_CONFIRM = int(os.environ.get('GHOST_CONFIRM', '3'))
_ghost_hits = {}
while True:
    try:
        _ext = False
        if LIVE and GHOST_RECON_ON and st.get('pos'):
            _c2 = st['pos'].get('coin')
            _gg2 = (E.WATCH_COINS.get(_c2) or {}).get('gate')
            if _gg2:
                _flat = None
                try:
                    _ps2 = _api.list_positions('usdt') or []
                    _flat = not [x for x in _ps2 if x.contract == _gg2 and int(x.size) != 0]
                except Exception:
                    _flat = None                 # 查不通 → 不敢判
                if _flat is True:
                    _ghost_hits[_c2] = _ghost_hits.get(_c2, 0) + 1
                elif _flat is False:
                    _ghost_hits[_c2] = 0
                _ext = _ghost_hits.get(_c2, 0) >= GHOST_CONFIRM
                if _ext:
                    print(f'🛟[{NODE}]账实对账: 账本有{_c2}但交易所连续{GHOST_CONFIRM}轮确无仓 → 清幽灵(内核自愈)', flush=True)
                    _ghost_hits[_c2] = 0
        r = E.cycle_once(st, external_flat=_ext)
        save(st)
        if r not in ('hold', 'idle', 'cooldown'):
            log(f"动作[{r}] 已实现{st.get('realized',0):+.2f}$")
    except KeyboardInterrupt:
        break
    except Exception as e:
        log(f'⚠️ 子引擎[{NODE}]异常: {str(e)[:120]}')
    time.sleep(_sleep)
