# -*- coding: utf-8 -*-
"""
☯️ 多币母体·进化2  SIM(模拟修行版)  —— 脱胎换骨·凤凰涅槃
=============================================================
🏛 内核重中之重纲要·五脏目标(2026-09-11 老板令固化·最高准则·一切改动须服务此纲):
   ①🥇金蟾(出纳)——吞小利: 区间小肉咬进肚(阶梯), 峰≥1.0%让位貔貅;
   ②🦁貔貅(财务官)——啃大肉: 大肉≥1.5%, 自适应回撤锁(锁位紧跟峰), 不撒嘴啃到底;
   ③🐉烛龙(董事长)——决策择向: regime大势+区间位pos4+衰竭闸, 只放方向不矛盾的;
   ④🐍腾蛇(总经理)——执行择强: _pick择强+自适应名义+弱信号封顶, 挑方向最清的币开;
   ⑤🛡保卫科(应急止损)——兜底护盘·应急回转正向: 方向对顺势赚/方向错麒麟摆尾反手(不止一招止损走人).
   道器尊严 = 盈利能力; 使命 = 稳健持续能赚钱(非保证不亏); 数字必对Gate真实流水.
-------------------------------------------------------------
把旧母体的"两块肉"(金蟾美元阶梯锁 + 貔貅大肉让跑)熔进新生多币择强骨架,
成为接替原单ETH引擎的新母体主系统雏形。 本文件 = SIM/纸面, 绝不下真实单。

架构(浑然一体·一决策轮):
  · 内脏-多币自切换(继承$200节点已验健康): _coin_score/_pick 三币(ETH/SOL/DOGE)择强
  · 骨架-旧母体盈利双兽(继承金蟾貔貅精华, 按名义归一化 scale-free 移植):
       💵金蟾区间美元阶梯锁(吃区间小利阶梯, 横盘虹吸当断)
       💵貔貅 $大肉让跑(真趋势≥大盘交棒让跑, 趋势瓦解/确无发展才收官; 抬地板续吃)
       💸貔貅$保底锁利(保底TRAIL挡, 让小利不吐回)  ⚡盈利急速回吐保护(防插针回吐)

关键纪律(防旧体半山腰病复发):
  · 旧母体通用顺势门"15m虚弹当趋势太松"→ 新母体开仓要走 _pick 择强(|净分|≥PICK_ABS_MIN)
    且大势不逆(下跌日中位虚弹的多: 4H动量显著为负仍开多→拦截), 宁缺毋滥。
  · 金蟾/貔貅美元档一律按 notional 比例归一化(scale-free, 不失真)。

用法: python3 _多币母体进化2_SIM.py                  # SIM 实时轮(默认PAPER)
      python3 data_v2/mtsim/_回放_母体进化2.py        # 离线历史回放(观判)
"""
import os, time, json, urllib.request
BASE = os.path.dirname(os.path.abspath(__file__))
# ─── 池与杠杆(继承$200节点参数) ───
POOL = 200.0
LEVER = 10
NOTIONAL = POOL * LEVER
PICK_ABS_MIN = 1.0          # 方向净分|≥1 才开(宁缺毋滥)
# ⚫🆕2026-09-15 10:16 老板令"执行A: 清择向精准闸残留":
#   该闸(方A1)已于 09-13 老板令"解困仙绳"默认关(DIR_PRECISE_ON=0); 且半月沙箱实证为伪解(对齐3/3反而差-0.086%).
#   现状=死代码空转. 老板令"精准择向雷达"取代之 → 本闸彻底封存(DIR_PRECISE_LEGACY=0 永久).
#   保留常量仅为兼容旧账本/日志引用; 不再参与任何决策.
DIR_PRECISE_LEGACY = False   # 🪦已封存(2026-09-15 A) · 择向交"雷达"接管
DIR_PRECISE_MIN = int(os.environ.get('DIR_PRECISE_MIN','2'))   # (保留·未用)
# 📡🆕2026-09-15 10:16 C·精准择向雷达(老板令"照亮2/3启动点·避3/3共识点"):
#   理念: 不用"闸拦截"(B复核发现半山腰闸严重误伤: 拦下的单胜率53.2%/均+0.122% > 放行单),
#         而用"雷达照亮" — 用"方向胚胎度"评分择优, 优选2/3对齐(将成未成)启动点.
DIR_RADAR_ON = __import__('os').environ.get('DIR_RADAR_ON','1') != '0'   # 雷达择优(默认开)
RADAR_W_ALIGN = 0.25   # 对齐度细权(与base叠加)
# 2026-09-15 15:06 A方案(老板令): 雷达胚胎度偏好3/3(全周期共振=真趋势). 数据铁证: 3/3均+0.053~0.060%唯一正期望;
#   旧_embryo给2/3加分(base2.0)/3/3降权(base0.0) → 打压唯一赚钱格子! 新:3/3=2.0/2/3=1.0/0-1=负. 回旧:RADAR_EMBRYO_V2=0
RADAR_EMBRYO_V2 = __import__('os').environ.get('RADAR_EMBRYO_V2','1') != '0'   # A: 胚胎度偏好3/3(默认开)
# 2026-09-15 15:06 B方案(老板令): 时段闸 — 美欧(北京8-22)噪音大, 只接强信号. 数据:亚洲/深夜正,美欧负;
#   美欧只接score>=SEG_MIN_SCORE → 净亏-50.5%→-15.7%(减亏69%). 回旧:SEG_GATE_ON=0
SEG_GATE_ON = __import__('os').environ.get('SEG_GATE_ON','1') != '0'   # B: 时段闸(默认开)
SEG_STRONG_HOURS = (8, 22)   # 美欧时段(北京8-22点)
SEG_MIN_SCORE = float(__import__('os').environ.get('SEG_MIN_SCORE','3.0'))  # 美欧时段最低|score|
# 🌟2026-09-15 17:10 B加权(老板令): 黄金窗口加权 — 北京时间0-1点(美股收盘后+亚洲盘前·流动性最低噪音最少)
#   有超额正期望(仅0-1点开仓: 62笔·胜率66.1%·净均+0.186%). 只放大_embryo得分(不新增模块). 回旧:SEG_GOLD_ON=0
SEG_GOLD_ON = __import__('os').environ.get('SEG_GOLD_ON','1') != '0'   # B加权: 黄金窗口加权(默认开)
SEG_GOLD_HOURS = (0, 2)   # 黄金窗口(北京0-2点·不含2点)
SEG_GOLD_BOOST = float(__import__('os').environ.get('SEG_GOLD_BOOST','1.5'))  # 黄金窗口得分乘数
# 📡🆕2026-09-15 老板令: 雷达=开明兽情报体系智能工具(信号增强), 按原有链路给白虎前哨之眼→烛龙/腾蛇裁决.
#   做法: 雷达照亮结果 写 _雷达情报.json → 哨兵(白虎)合并进 _触突军情.json → 烛龙/腾蛇读.
DIR_RADAR_FEED = __import__('os').environ.get('DIR_RADAR_FEED','1') != '0'   # 雷达情报化(默认开·0=只在本轮择强不入总线)
HALFMOUNTAIN_RADAR_TAKEOVER = __import__('os').environ.get('HALFMOUNTAIN_RADAR_TAKEOVER','1') != '0'  # 半山腰闸交雷达接管(默认开)
# 🎯🆕2026-09-12 方A1·开仓后方向自检(老板"择向精准度直接关联最终胜率"):
#   ⚫2026-09-15 A: 同属死代码(DIRCHK_ON默认关·老板09-13令"开仓90秒自检砍单=亏小钱元凶") → 封存.
DIRCHK_LEGACY = False   # 🪦已封存(2026-09-15 A)
DIRCHK_WINDOW = float(os.environ.get('DIRCHK_WINDOW','90'))    # 开仓后自检窗(秒): 头90s
DIRCHK_CERT   = float(os.environ.get('DIRCHK_CERT','0.5'))     # 信号矛盾/背离certify门槛
DIRCHK_REV    = float(os.environ.get('DIRCHK_REV','0.15'))     # 近端反向幅度阈值(%)
SL = 0.025                  # 硬止损 2.5% (≈$50@2000名义, 在可承受$200池内)
CERTIFY_SENSE_ON = float(__import__('os').environ.get('CERTIFY_SENSE_ON','1'))  # 🆕2026-09-11 保卫科·高感知证伪(1开/0关)
TACTILE_ON = float(__import__('os').environ.get('TACTILE_ON','1'))   # 🆕2026-09-11 触觉融入开关(1开/0关·一键回退)
TACTILE_W = 0.5           # 触觉共振加权幅度(score±, 沙箱验5-10min前瞻60%; 温和不激进)
# 🧬🆕 时空梭顶底基因(2026-09-11 融入): 24h分位顶底反转加权(路演综合胜率66%)
SK_GENE_ON = os.environ.get('SK_GENE_ON','1') != '0'
SK_GENE_W  = 0.6          # 识顶/识底加权幅度(与触觉同量级, 温和)
def _tactile_read(coin):
    """🧬 读触觉总线最新帧该币信号(纯只读·零侵入): 返回 (side, strength) 或 (None,0). 文件不存在/异常→None."""
    if not TACTILE_ON: return None, 0.0
    try:
        import json as _j, os as _o
        _bp=_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),'data_v2','mtsim','_tactile_bus.json')
        d=_j.load(open(_bp,encoding='utf-8'))
        fr=(d.get('bus') or [])[-1].get('samples') or []
        for s in fr:
            if s.get('coin')==coin: return s.get('tactile_side'), float(s.get('strength',0) or 0)
    except Exception:
        pass
    return None, 0.0

QUALITY_GATE_ON = float(__import__('os').environ.get('QUALITY_GATE_ON','1'))  # 🧬🆕2026-09-14 22:57 老板令"B方案: 母体/GTAE并入ZH严格基因": 默认改1(与ZH1/2/3/ZLS同基因·避死水窄市)
QUALITY_AMP6_MIN = 1.2    # 近6h振幅下限(%): <此=窄市没肉(手续费吃利润)→不硬做

FEEDBACK_ON = float(__import__('os').environ.get('FEEDBACK_ON','1'))  # 🆕2026-09-11 药④触突→保卫科反馈(1开/0关)
def _certify_of(sig):
    """🧬 药②快链: 综合该币伪信号高危度 = max(引擎certify, 触突军情certify). 纯只读.
       🆕2026-09-11 防抖(治'拦了又开'): certify是瞬时值会抖动(ADA曾0.7→0.2→溜过阈值被开)
         → 记近N轮峰值: 若近CERTIFY_HIST_N轮内曾≥CERTIFY_HOT, 仍视为高危(防抖动漏网)."""
    try:
        _e=float(sig.get('certify',0) or 0) if CERTIFY_SENSE_ON else 0.0
        _n=_nerve_read(sig.get('coin')) if FEEDBACK_ON else 0.0
        _now=max(_e,_n)
        # 🆕防抖: 记该币近N轮峰值certify
        _c=sig.get('coin')
        if _c:
            _h=_CERTIFY_HIST.setdefault(_c,[])
            _h.append(_now)
            if len(_h)>CERTIFY_HIST_N: _h.pop(0)
            _peak=max(_h)
            return max(_now,_peak if _peak>=CERTIFY_HOT else 0.0)
        return _now
    except Exception:
        return 0.0

# 🆕2026-09-11 防抖参数(治'拦了又开'): certify瞬抖漏洞
CERTIFY_HOT   = float(__import__('os').environ.get('CERTIFY_HOT','0.5'))   # 伪信号高危阈值
CERTIFY_HIST_N= int(__import__('os').environ.get('CERTIFY_HIST_N','12'))   # 记忆近N轮(约24min)峰值
# ☯🀄 母子系统融合(2026-09-11 老板令·确认): 母体写共识→三标读共识(避伪/对齐); 不合并账户, 只共享"认知"
FUSION_ON = float(__import__('os').environ.get('FUSION_ON','1'))  # 母子融合开关(1开/0关)
FUSION_BUS = 'data_v2/mtsim/_母体共识.json'
_LAST_SIGS = {}   # 🆕2026-09-11 母子融合: 缓存本轮各币 sig(供 _write_consensus 复用, 避重复拉行情4min/轮)
_LAST_CHOSEN = ['']   # 🆕2026-09-11 母子融合: _pick 本轮择强结论(供共识)
_CERTIFY_HIST = {}   # 🆕2026-09-11 防抖: 各币近N轮certify历史(治'拦了又开'瞬抖漏网)
def _fusion_write(consensus):
    """☯ 母体写全池共识(只读广播): {ts, picks:{coin:{side,score,certify,regime}}, hot:{coin:certify}}"""
    if not FUSION_ON: return
    try:
        import json as _j, os as _o
        _bp=_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),FUSION_BUS)
        _j.dump(consensus, open(_bp,'w',encoding='utf-8'), ensure_ascii=False, indent=1)
    except Exception: pass
def _fusion_read(coin):
    """🀄 三标读母体共识(纯只读): 返回该币 {side,score,certify} 或 None."""
    if not FUSION_ON: return None
    try:
        import json as _j, os as _o
        _bp=_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),FUSION_BUS)
        d=_j.load(open(_bp,encoding='utf-8'))
        return (d.get('picks') or {}).get(coin)
    except Exception:
        return None
def _nerve_read(coin):
    """🧬 读触突军情总线(哨兵写的 _触突军情.json)该币高危度(纯只读·零侵入): 返回 certify(0~1).
       药④·反馈保卫科: 触突感知→保卫科提前收紧. 文件不存在/异常→0."""
    if not FEEDBACK_ON: return 0.0
    try:
        import json as _j, os as _o
        _bp=_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),'data_v2','mtsim','_触突军情.json')
        d=_j.load(open(_bp,encoding='utf-8'))
        for n in (d.get('nodes') or []):
            if n.get('coin')==coin: return float(n.get('certify',0) or 0)
    except Exception:
        pass
    return 0.0
def _radar_read(coin):
    """📡🆕2026-09-15 老板令: 读雷达情报(_雷达情报.json)该币"方向胚胎度"(纯只读·零侵入).
       定位: 雷达=开明兽情报工具(信号增强) → 白虎前哨之眼 → 烛龙/腾蛇裁决. 返回(dict|None)."""
    if not DIR_RADAR_FEED: return None
    try:
        import json as _j, os as _o
        _bdir=_o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir)=='子引擎': _bdir=_o.path.dirname(_bdir)   # 子引擎内核副本→回主目录
        _fp=_o.path.join(_bdir,'data_v2','mtsim','_雷达情报.json')
        d=_j.load(open(_fp,encoding='utf-8'))
        for n in (d.get('nodes') or []):
            if n.get('coin')==coin: return n
    except Exception:
        pass
    return None
SLOW_BLEED_ON = float(__import__('os').environ.get('SLOW_BLEED_ON','0'))  # 🆕2026-09-11 慢阴保护 · 💊2026-09-17火印令CUT-04: 默认改0(停用·与已拆反手族同族·真钱2笔0%胜-50.67·全样本6笔0%胜-1623.64)
SLOW_BLEED_DEPTH = -0.017   # 慢阴保护触发深水线(💊2026-09-17白泽处方·火印通过: -0.015→-0.017·实证慢阴保护6笔净-1623且近3日均-761在恶化→加深触发线·可 env SLOW_BLEED_DEPTH 回旧)
SLOW_BLEED_BARS  = 3        # 该币近3根15m 持续对持仓向缓反向(累积) → 认慢阴
# 🧠🆕 智能阴跌分辨(2026-09-12 00:2x 老板令"自适应给药·同向行情给宽幅空间·增强智能识别"):
#   病根: 旧慢阴保护只看'最近3根15m下跌'=45min走势 → 把'大涨后的正常回踩'误当'趋势反转'→砍在半山腰/回踩低点.
#   药: 深水+缓反向时, 先"辨"是健康回踩还是真反转 → 健康回踩给宽幅(不砍), 真反转才砍. 自适应(按波动/趋势强度动态).
SMART_BLEED_ON = __import__('os').environ.get('SMART_BLEED_ON','1') != '0'  # 智能分辨开关(0=回旧糙判定)
SMART_BLEED_TREND = 0.25    # 大趋势仍顺持仓向的判据(|t4l|≥该值且同向)
SMART_BLEED_RETRACE = 0.5   # 回踩幅度<近段涨幅×该值 → 健康回踩(给宽幅)
# 🎯🆕 区间顶底麒麟摆尾(2026-09-12 01:0x 老板令"上行后回撤幅度大→顶部麒麟摆尾做空; 空单到底没劲→做多; 区间有利可图·随机应变"):
#   病案(ETH): 2457→2628(急涨)→2558(大幅回撤)→回抽. 大趋势仍在却大幅上下→该顶底麒麟摆尾吃区间利, 非干平走人.
#   药: 辨"大幅区间震荡"(振幅大+上下扫) → 顶区麒麟摆尾做空 / 底区麒麟摆尾做多 / "没劲了"(动量衰竭)触顶底翻.
RANGE_FLIP_ON = __import__('os').environ.get('RANGE_FLIP_ON','1') != '0'  # 区间顶底麒麟摆尾(1开/0关)
RANGE_AMP = 5.0        # 区间振幅阈值: 近6h振幅≥5% → 认"大幅上下"(可麒麟摆尾)
RANGE_POS_HI = 85.0    # 区间高位区(≥85%) → 顶部麒麟摆尾做空
RANGE_POS_LO = 15.0    # 区间低位区(≤15%) → 底部麒麟摆尾做多
RANGE_EXHAUST = 0.15   # "没劲了"判据: 近3根动量<该值% → 动量衰竭(触顶底)
# 🎯🆕 见顶见底加敏 + 反转识别加敏(2026-09-12 00:3x 老板令"赋予见顶见底信号加敏·反转识别加敏"):
#   病根: ①母体无"见顶/见底"预警(pos4只作参考) ②contra太糙→急涨换挡(15m小回踩)被误当信号矛盾→真突破被拦.
#   药A: 顶底极值预警(_topbot_alert): 接近24h高/低 + 近端转弱/强 + 量能 → 警示见顶/见底(融入score).
#   药B: contra急涨豁免(_pulse): 近3根单边急动(>某幅)时, 15m小回踩不算"矛盾"(是换挡) → 真突破不被拦.
TOPBOT_SENS = float(__import__('os').environ.get('TOPBOT_SENS','1'))  # 顶底加敏(1开/0关)
TOPBOT_ZONE = 0.90   # 顶/底区: 24h分位≥90%认顶区 / ≤10%认底区(比时空梭75/25更敏)
PULSE_AMP = 2.0      # 急涨/急跌判据: 近3根15m单边幅度≥2% → 脉冲中(contra豁免)
# 💊2026-09-24 00:4x 老板令「治疗早断问题」·火印 ED-20260924-155
#   病: 早断带 -1.2% 太紧 → 实盘多笔在水下 0.43%/1.31% 就被砍(震荡里必被扫·把能赚的单子砍在半路)
#   药: 放宽到 -2.2% · **且支持 env 回退**(原版写死不读 env → 药下不进)
EARLY_CUT_ON = float(__import__('os').environ.get('EARLY_CUT_ON', '-0.022'))
# 🧭🆕2026-09-17 老板令(白泽复盘"砍早诊断"·P1): 早断·大周期顺势豁免
#   病案(实证): 24笔反手类平仓中 12笔"砍早了"(现价反而对我们有利); **其中全是空单** —— 行情一路跌,
#   系统做空方向本来就是对的, 却被"近端反弹触发的早断"砍在半路, 砍完行情继续往下。实亏约-109, 若持有约+60~100。
#   药: 水下但"大周期大势仍顺持仓向且够强"(|t4l|≥BIG_TREND_EXEMPT) → 不因近端反弹早断, 掰住等趋势。
#   守: 仍保留"深水急冲"(deep)与"单币快崩"两条真应急腿; 可 BIG_TREND_EXEMPT_ON=0 一键回旧。
BIG_TREND_EXEMPT_ON = __import__('os').environ.get('BIG_TREND_EXEMPT_ON','1') != '0'
BIG_TREND_EXEMPT = float(__import__('os').environ.get('BIG_TREND_EXEMPT','0.8'))   # 大势阈值(%·近3.3日窗)
# 🐍💊C 早断·certify分流(2026-09-11 20:5x 老板选C·治母体25%胜率): certify≥0.5真伪信号高危→麒麟摆尾(反手扭亏); <0.5疑假证伪/噪声→扛住不砍.
EARLY_CERTIFY_SPLIT = os.environ.get('EARLY_CERTIFY_SPLIT','1') != '0'
# 🤸🆕2026-09-11 20:0x 老板令"麒麟摆尾最高级别是不亏·不是亏到半山腰才翻(翻个屁)":
#   病: 旧麒麟摆尾①无次数限制→可反复翻(翻一翻亏一亏) ②触发在-1.0%→半山腰才翻(越翻越亏).
#   药: ①只翻一次(_fandou计数·翻过就认小亏不再翻) ②及早翻(淺亏FANDOU_MAX_LOSS内才允许翻, 半山腰禁翻)
#      ③必须"近端新鲜证伪"才翻(翻是扭亏机会, 非套牢补救). 可由 FLIP_FANDOU_SMART=0 回旧行为.
FLIP_FANDOU_SMART = __import__('os').environ.get('FLIP_FANDOU_SMART','1') != '0'   # 智能麒麟摆尾(及早翻+翻一次)
FANDOU_MAX_LOSS  = -0.006  # 麒麟摆尾允许的最深承压: 仅浅亏(≥-0.6%)才翻; 超过=已半山腰→禁翻(认赔早走)
# 💊🆕2026-09-12 方A1·麒麟兜底转向灵敏度(老板令"确保麒麟兜底转向灵敏度"):
#   病: 摆尾"及早"门槛仍是 ppct<=-0.004(-0.4%)+certify>=0.5 → 窄市里等确认已滑到-0.5%~-0.6%, 又撞半山腰禁翻线.
#   药: 及早摆尾"浅亏线"提前到 -0.25%(QILIN_SENS_LOSS), 且certify门槛降到0.45(QILIN_SENS_CERT), 让"及早"真早(半山腰前).
#   守: 仍只摆一次(_fandou)+仍需火印+仍需非半山腰. 可 QILIN_SENS_ON=0 一键回旧.
QILIN_SENS_ON    = os.environ.get('QILIN_SENS_ON','1') != '0'
QILIN_SENS_LOSS  = float(os.environ.get('QILIN_SENS_LOSS','-0.0035')) if QILIN_SENS_ON else -0.004   # 及早摆尾浅亏提前线(-0.35%·均衡档)
# 🦄🆕2026-09-15 12:48 老板令"A+B同整理·治麒麟越权·管理好现在向好治理":
#   病(实证): 麒麟60笔胜率11.7%亏-9319$; 金蟾100%/貔貅100%胜率 → 麒麟越权干了金蟾貔貅的活(有肉时乱刹车).
#   A: 麒麟撤出"有肉时半山腰刹车"(把退出权交还金蟾貔貅·它们按阶梯/回撤锁管).
#   B: 麒麟只留"深套+证伪确证+火印"的最后摆尾兜底(终极保险·极少用).
#   开关: QILIN_RETREAT_ON=1(默认·撤越权) / =0(回旧·照旧刹车).
#   🦄🆕2026-09-16 老板令"三兽分片治理·均衡档": 浅套-0.35% / 深套-1.0% / cert0.40 (麒麟治理水下, 水上归金蟾貔貅)
QILIN_RETREAT_ON = os.environ.get('QILIN_RETREAT_ON','1') != '0'
QILIN_LAST_DEFENSE = float(os.environ.get('QILIN_LAST_DEFENSE','-0.013'))

# 💊🔌2026-09-23 老板令(「同意以上计划」·修「旋钮失接」): 貔貅让吐四旋钮接线
#   背景: 白泽在研专题发现这四只旋钮**内核不读**(LOCK_START_PCT/GIVE_CAP_PCT/GIVE_FLOOR_PCT/DEEPWATER_CUT_PCT)
#         → 09-18 药方实验基准=处理组, 结论无效(丙级·退回重推演)。
#   纪律: **默认值 = 旧硬编码值** ⇒ env 未设时真钱行为逐字不变；只有显式设 env 才动。
LOCK_START_PCT    = float(os.environ.get('LOCK_START_PCT',   '0.010'))    # 锁盈启动门槛(峰≥此值才启动回撤锁)
GIVE_CAP_PCT      = float(os.environ.get('GIVE_CAP_PCT',     '0.0080'))   # 允许回吐·上限
GIVE_FLOOR_PCT    = float(os.environ.get('GIVE_FLOOR_PCT',   '0.0020'))   # 允许回吐·下限
DEEPWATER_CUT_PCT = float(os.environ.get('DEEPWATER_CUT_PCT','0.013'))    # 深水急冲腿阀(ppct≤-此值 且 近端反向急冲 → 早走)
# 🧠🆕2026-09-21 老板令「把兜底守护做成自我识别·自我分析·自我判断的自适应能力；同时为麒麟加一个紧急行情兜底固定止损闸」
#   (火印 ED-20260921-120) · **默认全关 = 旧行为不变** · 实盘启用须走 env + 老板点头
QILIN_ADAPT_ON       = os.environ.get('QILIN_ADAPT_ON','1') != '0'   # 🧬2026-09-21 入母体内核: 默认开        # 自适应兜底总开关
QILIN_ADAPT_MIN      = float(os.environ.get('QILIN_ADAPT_MIN','-0.006'))  # 最紧兜底(正常市况收紧到这)
QILIN_ADAPT_MAX      = float(os.environ.get('QILIN_ADAPT_MAX','-0.030'))  # 最松兜底(剧烈市况放宽到这)
QILIN_ADAPT_NEAR     = float(os.environ.get('QILIN_ADAPT_NEAR','0.60'))   # 接近度: 兜底线×此值内才做分析(省行情拉取)
# 🌊QILIN_ADAPT_RANGE 🆕2026-09-21 老板令「兜底区间设置成具备高感知性自适应灵活调控」
QILIN_ADAPT_RANGE_ON = os.environ.get('QILIN_ADAPT_RANGE_ON','0') != '0'   # 区间自适应总开关(默认0=旧行为: 固定[-0.6%,-3%])
QILIN_RANGE_VOL_CALM= float(os.environ.get('QILIN_RANGE_VOL_CALM','0.30'))   # 波动基准(1分钟σ%): 以此为 k=1
QILIN_RANGE_K_MIN    = float(os.environ.get('QILIN_RANGE_K_MIN','0.60'))      # 缩放下限(平静市况)
QILIN_RANGE_K_MAX    = float(os.environ.get('QILIN_RANGE_K_MAX','2.20'))      # 缩放上限(剧烈市况)
QILIN_RANGE_TIGHT_HI = float(os.environ.get('QILIN_RANGE_TIGHT_HI','-0.012')) # 紧端最松(剧烈时也不早砍)
QILIN_RANGE_TIGHT_LO = float(os.environ.get('QILIN_RANGE_TIGHT_LO','-0.0035'))# 紧端最紧(静水时早认赔)
QILIN_RANGE_LOOSE_HI = float(os.environ.get('QILIN_RANGE_LOOSE_HI','-0.035')) # 松端最松(剧烈时给足空间)
QILIN_RANGE_LOOSE_LO = float(os.environ.get('QILIN_RANGE_LOOSE_LO','-0.012')) # 松端最紧(平静时不深扛)
QILIN_RANGE_PIN_BOOST= float(os.environ.get('QILIN_RANGE_PIN_BOOST','1.30'))  # 插针回抽(假摔): 松端再放宽倍
QILIN_EMERGENCY_STOP = float(os.environ.get('QILIN_EMERGENCY_STOP','-0.02'))  # 🧬默认开(-2%硬底)  # 🚨紧急行情固定止损闸(0=关·建议-0.02)

# 🚨2026-09-22 14:3x 老板令「通过」(体检·P0-①·硬止损不得宽于紧急闸):
#   病: SL(2.5%) 是 cycle 最优先判定 → 8秒空窗插针越过 −2% 直穿 −2.5% 时先命中 SL → 单笔≈11.3%权益, 破 9% 红线
#   药: 二者取更紧者 → 兜底距 ≤ |QILIN_EMERGENCY_STOP| (紧急闸即真天花板)
if QILIN_EMERGENCY_STOP < 0 and SL > abs(QILIN_EMERGENCY_STOP):
    SL = abs(QILIN_EMERGENCY_STOP)

# 🪜🆕2026-09-21 07:22 老板令「给麒麟一个下阶梯吞吐(仿金蟾上阶梯的反向阶梯)· 回撤扭转辨识·镇守区间自适应」
#   仿: 金蟾=向上阶梯吞吐小利; 麒麟=**向下阶梯吞吐亏损**(回撤越深→档位越下→动作越硬) · **默认关=旧行为**
QILIN_LADDER_ON    = os.environ.get('QILIN_LADDER_ON','1') != '0'    # 🧬入母体内核: 默认开          # 🪜下阶梯总开关
QILIN_LADDER       = os.environ.get('QILIN_LADDER','0.0034,0.0051,0.0069,0.0093,0.0129,0.0193,0.025')  # 🧬实测标定档
QILIN_LADDER_ADAPT = os.environ.get('QILIN_LADDER_ADAPT','1') != '0'       # 阶梯随波动自适应缩放
QILIN_LADDER_REFV  = float(os.environ.get('QILIN_LADDER_REFV','0.30'))     # 基准波动(1分钟σ%)
QILIN_LADDER_KMIN  = float(os.environ.get('QILIN_LADDER_KMIN','0.60'))
QILIN_LADDER_KMAX  = float(os.environ.get('QILIN_LADDER_KMAX','2.00'))
#   🗡 扭转档若「可扭转」: 默认 **不认赔(给回抽机会)**; 真·摆尾反手须显式开(=1, 待纸面样本授权)
QILIN_TURN_FLIP_ON = os.environ.get('QILIN_TURN_FLIP_ON','0') != '0'

def _qilin_ladder_rungs():
    """解析阶梯档位(亏损%绝对值·升序)"""
    try:
        _v = [abs(float(x)) for x in str(QILIN_LADDER).split(',') if x.strip()]
        return sorted(_v) if len(_v) >= 3 else [0.0045, 0.0065, 0.0085, 0.012, 0.015, 0.02]
    except Exception:
        return [0.0045, 0.0065, 0.0085, 0.012, 0.015, 0.02]

def _qilin_ladder_stage(ppct, vol):
    """🪜 麒麟下阶梯·自我识别驻哪一档(仿金蟾上阶梯的反向)
    回撤越深→档位越下→动作越硬; 阶梯边界随波动缩放(镇守区间自适应)
    返回 (档号, 档名, 动作, 缩放系数)
    动作: watch(只警觉) / judge(判识可否扭转) / turn(扭亏优先·可摆尾) / cut(认赔) / hard(硬底)"""
    _r = _qilin_ladder_rungs()
    _k = 1.0
    if QILIN_LADDER_ADAPT and vol > 0:
        try:
            _k = max(QILIN_LADDER_KMIN, min(QILIN_LADDER_KMAX, vol / max(1e-9, QILIN_LADDER_REFV)))
        except Exception:
            _k = 1.0
    _d = -ppct if ppct < 0 else 0.0
    _hit = 0
    for _i, _rr in enumerate(_r):
        if _d >= _rr * _k:
            _hit = _i + 1
    if _hit == 0:
        return (0, '水上观察', 'watch', _k)
    _names = ['观察', '判识', '扭转', '护本', '急认赔', '硬底', '超硬底', '极硬底']
    _acts = ['watch', 'judge', 'turn', 'cut', 'cut', 'hard', 'hard', 'hard']
    _i = min(_hit - 1, len(_names) - 1)   # 🔧档名与档号对齐(第1档=观察)
    return (_hit, _names[_i], _acts[_i], _k)

def _qilin_can_turn(coin, side, reg, last15):
    """🔮 辨识: 这波回撤能不能"扭转乾坤"(假摔/结构未坏) → (可否, 依据)"""
    try:
        _t, _vol, _spur, _pulled = _qilin_market_type(coin, side, reg, last15)
    except Exception:
        return (False, 'unknown')
    if _t == '插针回抽':
        return (True, '插针回抽(假摔·已抽回)')
    if _t == '急冲未回':
        return (False, '急冲未回(还在冲)')
    if _t == '崩坏':
        return (False, '崩坏(大周期已反转)')
    if _t in ('阴跌', '静水'):
        return (False, _t + '(温水走坏)')
    return (False, 'unknown')


def _qilin_market_type(coin, side, reg, last15):
    """🧠 麒麟·自我识别 —— 看近端 1 分钟K线判"这是什么行情":
    返回 (类型, 波动率%, 逆势急冲%, 是否已回抽)
    类型: 崩坏(大周期已反向) / 插针回抽(急冲但已回抽) / 急冲未回 / 静水(波动极小) / 阴跌(温和持续走坏) / unknown"""
    try:
        c1 = _candles(coin, '1m', 30) or []
    except Exception:
        return ('unknown', 0.0, 0.0, False)
    if len(c1) < 8:
        return ('unknown', 0.0, 0.0, False)
    _r = []
    for _i in range(1, len(c1)):
        if c1[_i-1]:
            _r.append((c1[_i]-c1[_i-1])/c1[_i-1]*100)
    _n = len(_r) or 1
    _vol = (sum(x*x for x in _r)/_n)**0.5
    _spur = (c1[-1]-c1[-4])/c1[-4]*100 if c1[-4] else 0.0
    if side == 'short':
        _spur = -_spur
    _lo = min(c1[-3:]); _hi = max(c1[-3:])
    _pull = (c1[-1]-_lo)/_lo*100 if _lo else 0.0
    if side == 'short':
        _pull = (_hi-c1[-1])/_hi*100 if _hi else 0.0
    _t8 = (c1[-1]-c1[-8])/c1[-8]*100 if c1[-8] else 0.0
    _net = (c1[-1]-c1[0])/c1[0]*100 if c1[0] else 0.0
    _aligned = True if reg in (None, '', 'chop') else ((_t8 > 0) if side == 'long' else (_t8 < 0))
    # 🔧2026-09-21 06:xx 单测修正: **尖峰优先** —— 先判急冲/插针, 再判结构性"崩坏"
    #   (否则任何 ≥0.4% 的插针都会被当"崩坏"提前砍 = 正是老板要治的"砍在坑里")
    _big = max(0.6, 3*_vol)
    if abs(_spur) >= _big and _pull >= 0.15:
        _t = '插针回抽'
    elif abs(_spur) >= _big:
        _t = '急冲未回'
    elif (not _aligned) and abs(_t8) >= 0.4:
        _t = '崩坏'
    elif _vol <= 0.12 and abs(_net) <= 0.35:
        _t = '静水'
    else:
        _t = '阴跌'
    return (_t, _vol, _spur, _pull >= 0.15)

# 🌊QILIN_ADAPT_RANGE 兜底区间「高感知」自适应
def _qilin_adapt_band(_vol, _pulled):
    """兜底区间两端(紧端/松端)随 1 分钟波动率伸缩 —— 高感知灵活调控
    · 平静(σ≈0.1%) → 区间收窄 [-0.35%,-1.2%]: 死水里没回抽空间, 早认赔
    · 常态(σ≈0.30%)→ 区间 [-0.60%,-3.00%]: 与旧口径一致
    · 剧烈(σ≥0.66%)→ 区间放宽 [-1.20%,-3.50%]: 给足空间, 别砍在坑里
    · 插针回抽(假摔) → 松端再放宽 ×QILIN_RANGE_PIN_BOOST
    · 🚨紧急固定闸永远最外层: 自适应绝不放宽到闸外"""
    if not QILIN_ADAPT_RANGE_ON:
        return (QILIN_ADAPT_MIN, QILIN_ADAPT_MAX)          # 默认=旧行为(固定区间)
    _k = _vol / (QILIN_RANGE_VOL_CALM or 0.30)
    _k = max(QILIN_RANGE_K_MIN, min(QILIN_RANGE_K_MAX, _k))
    _t = QILIN_ADAPT_MIN * _k                               # 紧端(随波动放宽)
    if _t < QILIN_RANGE_TIGHT_HI:
        _t = QILIN_RANGE_TIGHT_HI
    if _t > QILIN_RANGE_TIGHT_LO:
        _t = QILIN_RANGE_TIGHT_LO
    _l = QILIN_ADAPT_MAX * _k                               # 松端(随波动放宽)
    if _pulled:
        _l = _l * QILIN_RANGE_PIN_BOOST
    if _l < QILIN_RANGE_LOOSE_HI:
        _l = QILIN_RANGE_LOOSE_HI
    if _l > QILIN_RANGE_LOOSE_LO:
        _l = QILIN_RANGE_LOOSE_LO
    if QILIN_EMERGENCY_STOP < 0 and _l < QILIN_EMERGENCY_STOP:
        _l = QILIN_EMERGENCY_STOP                           # 🚨硬底优先
    if _l > _t:
        _l = _t                                             # 防两端交错
    return (_t, _l)


def _qilin_adapt_line(coin, side, ppct, last15, cert, reg, base):
    """🧠 麒麟·自适应兜底线 —— 按市况类型给不同容忍度(调的是"跌多少才认赔")
    · 崩坏→收紧(早认赔) · 阴跌→收紧 · 静水→收紧
    · 急冲未回→放宽(别砍在针尖上) · 插针回抽→最宽(等它回来, 说不定是假摔)
    · 有紧急固定闸时绝不放宽到闸外(硬底优先)"""
    if not QILIN_ADAPT_ON:
        return (base, 'fixed')
    _t, _vol, _spur, _pulled = _qilin_market_type(coin, side, reg, last15)
    _f = {'崩坏': 0.60, '阴跌': 0.90, '静水': 0.85, '急冲未回': 1.80, '插针回抽': 2.30}.get(_t, 1.0)
    _ln = base * _f
    _rmin, _rmax = _qilin_adapt_band(_vol, _pulled)     # 🌊QILIN_ADAPT_RANGE 兜底区间(自适应或固定)
    if _ln > _rmin:
        _ln = _rmin                    # 最紧不放更紧(防自伤)
    if _ln < _rmax:
        _ln = _rmax                    # 最松不放更松
    if QILIN_EMERGENCY_STOP < 0 and _ln < QILIN_EMERGENCY_STOP:
        _ln = QILIN_EMERGENCY_STOP     # 🚨硬底优先: 不放宽到固定闸之外
    return (_ln, '%s(vol%.2f%%/冲%+.2f%%/区间%+.2f~%+.2f%%)' % (_t, _vol, _spur, _rmin*100, _rmax*100))


# 🗡💊2026-09-17 老板令"整治割肉族"·白泽处方实证: 及早摆尾 **11战11败·0胜**·净-1475.67
#   (统计上0.36%概率是运气→真钝刃)。它"浅亏就翻"不但没扭亏, 反而多付一个来回。→ **停用**
#   可 QILIN_EARLY_FLIP_ON=1 回旧(恢复及早摆尾)。好刃"近端证伪摆尾"(真钱胜67%)不受影响。
QILIN_EARLY_FLIP_ON = __import__('os').environ.get('QILIN_EARLY_FLIP_ON','0') != '0'
# 🗡💊2026-09-17 内核审计(275笔全样本): "反手族"全线负期望 —— 证伪确诊+近端证伪 **71战5.6胜·净-5365.44**
#   (同族: 半山腰0%-9622已禁 / 及早0%-2394已禁)。**区间顶底摆尾例外(94.3胜+2654)=好刃保留**。
#   → 停用①证伪确诊反向 + ④保卫科近端证伪。可 QILIN_CERTAIN_FLIP_ON=1 回旧。
QILIN_CERTAIN_FLIP_ON = __import__('os').environ.get('QILIN_CERTAIN_FLIP_ON','0') != '0'
QILIN_SENS_CERT  = float(os.environ.get('QILIN_SENS_CERT','0.45')) if QILIN_SENS_ON else 0.5        # 摆尾certify门槛(💊2026-09-17白泽处方·火印通过: 0.40→0.45收紧·实证摆尾84笔胜6%净-13248且近3日均-305在恶化→只翻真证伪·可 env QILIN_SENS_CERT 回旧)
FAST_CRASH_ON = -0.003   # 🚨单币快崩守护·水下触发带: ≤-0.3%且该币近端单根对持仓爆冲→应急护(不等满损/不归辨向, 归行情快崩护栏)
FAST_CRASH_BAR= 1.1      # 🚨单币快崩守护·近端单根反向爆幅阈值(%: 该币自己15m对持仓暴冲≥1.1%即认单币快崩应急)
# ─── 🛡 实盘护栏(由老母体/节点实盘四层风控·老板2026-09-08回实盘前先做·纯逻辑可单测) ───
DAY_STOP_MAX   = 3        # 单日止损次数上限(≥即锁当日新开)
DAY_LOSS_MAX   = 0.04     # 单日已实现亏损≥池4%(=日亏熔断·空仓休当日)
CONSEC_LOSS_K  = 3        # 连亏次数≥(同刀砍≥3)即触发冷却锁
# 🗄 2026-09-11 16:28 老板令"暂时封存全域熔断功能待启用": 全域锁死类护栏(日亏熔断/单日止损超限/连亏冷却)整体开关
#   GLOBAL_CIRCUIT_ON=0(默认封存) → 暂不"整机锁死", 全力以赴; =1 → 恢复全域熔断. 单笔护本(黑天鹅/防闪崩)不受此开关影响, 仍守.
GLOBAL_CIRCUIT_ON = float(__import__('os').environ.get('GLOBAL_CIRCUIT_ON','0'))
CONSEC_COOL_N  = 9        # 连亏冷却轮(9轮≈4.5h, 呼应防连亏同刀砍≥3绝不挨)
FLASH_PCT      = 0.035    # 防闪崩: 单币近端15m单根|幅|≥3.5%→拒开(不追闪崩插针)
BLACK_SWAN_PCT = 0.06     # 防黑天鹅: 参考(单币/大盘)短窗|幅|≥6%→清仓拒开(护本第一)
REOPEN_COOLDOWN = 6         # 平后冷却轮
# 🛡🆕2026-09-12 麒麟摆尾统一开关(老板令"取消麒麟摆尾名·统一麒麟摆尾"): =0回旧(无摆尾)
QILIN_TAIL_ON = __import__('os').environ.get('QILIN_TAIL_ON','1') != '0'
# 🔥🆕2026-09-12 烛龙火印(老板令"无火中枢印不得擅自行动·火印=烛龙统御/统一调度令"):
#   铁律: 开明(探)+白虎(哨)报送证伪军情 → 烛龙中枢终审 → 盖火印 → 麒麟才准摆尾.
#   麒麟无权自主触发摆尾; 无火印=只守只兜(按兵不动). ZHULONG_SEAL_ON=0 可关(回旧无印).
ZHULONG_SEAL_ON = __import__('os').environ.get('ZHULONG_SEAL_ON','1') != '0'
ZHULONG_SEAL_CERT = 0.5   # 火印门槛: certify/军情置信≥此(开明/白虎证伪军情强度) 且 regime明确(非chop)
CHOP_FLIP_OFF = __import__('os').environ.get('CHOP_FLIP_OFF','1') != '0'   # 🧬🆕2026-09-14 22:57 老板令"B方案: 并入ZH严格基因": 默认改1(死水禁摆·与ZH1/2/3/ZLS同基因)
ZHULONG_SEAL_STRONG = 0.7 # 🔧2026-09-12 保健: chop松绑门槛——chop但certify≥此(或开明+白虎双证)仍发印, 治"该变不变"
# 🦄🆕2026-09-14 22:29 老板令"中段震荡豁免·麒麟不得越权掐死":
#   病: 34笔刹车亏-6,238(76%贴-0.6%半山腰线成交) = 中段震荡正常回踩被当证伪误杀, 抹平全部止盈.
#   药: regime=chop(震荡)+非极强证伪(certify<CHOP_EXEMPT_CERT 且 非开明+白虎双证) → 麒麟按兵不动(态一).
QILIN_CHOP_EXEMPT = __import__('os').environ.get('QILIN_CHOP_EXEMPT','1') != '0'
CHOP_EXEMPT_CERT  = float(__import__('os').environ.get('CHOP_EXEMPT_CERT','0.7'))  # 震荡豁免上限: certify≥此=极强证伪→仍可动
# 🌟🆕2026-09-15 09:11 老板令"C方案加敏(A方案治本+三参数)":
#   病: DOGE 04:32开多(chop·把握47%) → 05:30刹车(-1.19%) → 07:06反手空 = 同币反复+白送手续费.
#   药①(A方案治本): chop区+低把握(score<CHOP_OPEN_MIN_SCORE) → 不开(管住开仓源头·避免开在模糊区)
#   药②(自适应收紧): chop+certify≥0.5 → 半山腰刹车线提前(-0.6%→QILIN_TIGHT_LOSS) 早收少亏
#   药③(防同币反复): 麒麟刹车平仓后该币冷却加长(QILIN_CUT_COOLDOWN轮) 防"刚杀又开"
#   药④(开明监督): 豁免条件用融合强度adms(开明flock+白虎sfk+触觉nerve) 任一强→豁免失效(更灵敏)
#   一键回旧: 任一开关=0.
QILIN_SENS_ADM   = __import__('os').environ.get('QILIN_SENS_ADM','1') != '0'      # 开明监督融合强度(默认开)
CHOP_OPEN_MIN_SCORE = float(__import__('os').environ.get('CHOP_OPEN_MIN_SCORE','2.5'))  # A方案: chop区开仓最低|score|(2.5=中把握)
QILIN_TIGHT_ON   = __import__('os').environ.get('QILIN_TIGHT_ON','0') != '0'      # 自适应收紧刹车线(默认开->💊火印令ED-20260917-012 默认0停用·与母体同口径)
QILIN_TIGHT_LOSS = float(__import__('os').environ.get('QILIN_TIGHT_LOSS','-0.0035'))  # chop区半山腰刹车线提前((-0.35% vs -0.6%))
QILIN_CUT_COOLDOWN = int(__import__('os').environ.get('QILIN_CUT_COOLDOWN','30'))  # 麒麟刹车后同币冷却轮数(30轮≈15min 防刚杀又开)
# 🔧2026-09-13 00:1x 老板令"死水一潭翻个毛线·频繁交易=机械亏损(白送手续费)": 死水行情禁摆尾.
#   病: chop松绑让死水期(certify虚高≥0.7)也发火印→麒麟白摆尾→价格回摆→亏+双向手续费.
#   药: regime=chop 且 该币近6h振幅<QUALITY_AMP6_MIN(死水判定) → 不发火印(麒麟只守只兜).
#   有振幅的chop(非死水)不动; 手工干预不受影响. CHOP_FLIP_OFF=0 可一键回退.
# 🛡🆕2026-09-12 麒麟摆尾真实化钩子(实盘注入真反手; 纸面=None) — 治"麒麟摆尾在实盘形同虚设"
_FLIP_HOOK = None
PAPER = True                # ⚠️ 模拟修行·绝不下真实单
CYCLE_SLEEP = 30
STATE_FILE = os.path.join(BASE, 'data_v2', 'mtsim', '_jinhua2_sim_state.json')
LOG_FILE   = os.path.join(BASE, 'data_v2', 'mtsim', '_jinhua2_sim.log')

WATCH_COINS = {  # gate永续+quant  (quanto仅真实下单用; SIM用开平纸面)
 'BTC': {'gate':'BTC_USDT','quanto':0.0001},  # 🆕2026-09-13 老板令加BTC(优选主流)
 'ETH': {'gate':'ETH_USDT','quanto':0.01},
 'SOL': {'gate':'SOL_USDT','quanto':1},
 'DOGE':{'gate':'DOGE_USDT','quanto':10},
 # 6币轮值扩展(老板2026-09-08批): LINK/XRP/ADA 优质主流·与三币低相关·Gate永续已核实
 'LINK':{'gate':'LINK_USDT','quanto':1},
 'XRP': {'gate':'XRP_USDT','quanto':10},
 'ADA': {'gate':'ADA_USDT','quanto':10},
}

# ─── 金蟾/貔貅盈利档(归一化为 notional %) ───
# 旧母体在(保证金MARGIN×杠杆)名义上跑: 金蟾美元档20/40/60/80/100(≈0.26%~1.31%名义)
# 新母体名义NOTIONAL=$2000: 对应美元档 = 名义应取%来算(scale-free)。
# 💊🆕2026-09-12 方A1(老板令"增强智能识别判断·给予灵活性管理·确保择向为正"):
#   病: 金蟾第一档0.3%太低→赢单刚浮盈0.3%就被剪走(实测赢单仅+0.35%/持20min), 而亏单-0.65%/持105min → 赢小输大(比0.54).
#   药: ①首档0.3%→0.6%(让赢单多跑一点) ②大趋势让位更积极 ③择向精准(A1择向) ④麒麟兜底灵敏度.
#   可 env JCH_FIRST_PCT 覆盖首档; FLEX_ON=0 一键回旧.
FLEX_ON = os.environ.get('FLEX_ON','1') != '0'
# 💊🆕2026-09-12 老板令"金蟾首档调整为0.6%-1.6%·资金额度小盈利0.3%太小":
#   病: 小资金下0.3%名义利≈$7.8@$2600, 扣两腿手续费几乎白干. 金蟾阶梯整体上移到 0.6%~1.6% 带.
#   阶梯: 0.6 / 0.85 / 1.1 / 1.35 / 1.6 % (均匀布在0.6~1.6带); 首档0.6%起咬, 顶档1.6%让位貔貅.
# 💊🆕2026-09-15 12:27 老板令"金蟾首档改0.45起(太低易生交易费)·加自适应吞金能力":
#   病(望闻问切铁证): 刹车笔40笔胜率0%亏-7427$; 其中39笔峰值<0.6%(够不到旧首档) → 0.3~0.6%肉被真空放弃 → 全亏成刹车.
#   药: ①首档0.6%→0.45%(覆盖部分死区·但保持"有尊严的肉") ②阶梯重排 0.45/0.70/0.95/1.20/1.45/1.60
#       ③自适应: 首档随行情/把握度活(趋势强→抬首档让肉跑; 震荡弱→降首档快咬落袋).
#   实测成本: 费率0.048%/边×2 + 滑点≈0.20%保本 → 0.45%净赚0.25%(余量充足).
JCH_FIRST_PCT = float(os.environ.get('JCH_FIRST_PCT','0.0045')) if FLEX_ON else 0.003   # 🆕首档0.45%(老板令)
JCH_TIER_PCT = ((JCH_FIRST_PCT,0.0070,0.0095,0.0120,0.0145,0.0160) if FLEX_ON else (0.003,0.006,0.009,0.012,0.015))  # 金蟾阶梯: 0.45/0.70/0.95/1.20/1.45/1.60%
# 🥇🆕2026-09-15 自适应吞金(老板令"金蟾吞金能力自适应"):
#   义: 首档不写死——趋势强(大势旺+趋势度强)=有肉可等→抬首档(多让肉跑); 震荡弱=肉薄易回吐→降首档(快咬落袋).
#   范围 [JCH_ADAPT_LO, JCH_ADAPT_HI]; 开关 JCH_ADAPT_ON=0 回写死0.45.
JCH_ADAPT_ON = os.environ.get('JCH_ADAPT_ON','1') != '0'   # 自适应吞金(默认开)
JCH_ADAPT_LO = 0.0040   # 震荡弱市首档下限(0.40%·快咬)
JCH_ADAPT_HI = 0.0055   # 强趋势首档上限(0.55%·让肉跑)
JCH_ADAPT_T4 = 0.35     # 大势强度阈值(|4H动量|≥此=大势旺)
JCH_ADAPT_PW = 1.0      # 趋势度阈值(≥此=趋势真强)
BIG_MEAT_PCT = 0.015                                 # 貔貅大肉分界(pct名义): ≥1.5%名义净=真趋势交貔貅
TRAIL_FLOOR_PCT = 0.008                              # 貔貅保底/抬地板(pct名义): 0.8%起锁
FAST_RETRACE_START = 0.01                            # 盈利急吐保护启动: 浮盈≥1%名义
GIVE_BACK_FRAC = 0.5                                 # 台阶回吐: 从峰值回吐一半即按该级锁走
HI_STEP_LOCK = True                                  # 貔貅递增台阶锁(只赚不吐·对称)
# ─── 貔貅抬地板/递增阶梯·移动让肉(scale-free %, 移植旧母体) ───
TRAIL_START    = 0.007        # 貔貅启动: 峰值浮盈≥0.7%才激活地板(让young小利不被剪)
TRAIL_LEG_FLOOR = 0.016       # 🦁貔貅利锁地板: 回吐保底线最低不高过此(1.6%)只进不出爬高
TARGET_PCT      = 0.05        # 目标止盈5%(双链终局收割)
DAYI_T4        = 0.35         # 大义闸: |4H动量|≥0.35%即大势仍旺(金蟾吐微利交貔貅)
# 💊🆕2026-09-12 方A1: 大义闸放宽——只要大势稍旺(DAYI_T4*0.6)且趋势非弱, 就让位貔貅多跑, 不剪赢单.
DAYI_T4_LOOSE  = 0.21         # 宽松大义闸(0.35*0.6): |t4|≥此+趋势不弱 → 也让位
FLIP_TRAIL_ON  = 0.007        # 一键换向仅对曾持大肉(peak≥此)触发, 防小利反复反手
FLIP_PACO      = 0.8          # 换向需趋势度<0.8(转弱)

def _trend_strength(pos, sig):
    """趋势强度 multi / pw(1.5强顺势~0.6逆势), 由4H动量顺向度定(供貔貅/大义/换向共用)"""
    try:
        t4=sig.get('t4',0) or 0
        if pos['side']=='long':  pw = t4/1.5
        else:                    pw = -t4/1.5
        pw=max(-2,min(2,pw))
        multi = 1.5 if pw>=1.5 else (1.15 if pw>=0.5 else (1.0 if pw>=-0.5 else (0.8 if pw>=-1.5 else 0.6)))
        return multi,pw
    except Exception:
        return 1.0, 0.0


def _target_pct_from_pw(pw):
    """🎯🆕2026-09-12 目标止盈%(门户展示/终局收割同口径): TARGET_PCT×倍率(强趋势远/弱趋势近).
       与主循环 _tg=TARGET_PCT*(1.6 if pw>=1.5 else (1.2 if pw>=1.15 else 1.0)) 同口径.
       返回 (目标pct小数, 倍率)."""
    try:
        _pw = float(pw or 0)
        mult = 1.6 if _pw>=1.5 else (1.2 if _pw>=1.15 else 1.0)
        return TARGET_PCT*mult, mult
    except Exception:
        return TARGET_PCT, 1.0


def _target_price(pos):
    """🎯🆕目标止盈价(供门户一目了然): 由持仓期认向t4(pw)算目标%, 换算目标价.
       长: 目标价=entry×(1+目标%); 空: entry×(1-目标%)."""
    try:
        ctx = pos.get('_ctx', {}) or {}
        t4 = float(ctx.get('t4', 0) or 0)
        side = pos.get('side'); entry = float(pos.get('entry', 0) or 0)
        pw = (t4/1.5) if side=='long' else (-t4/1.5)
        tpct, mult = _target_pct_from_pw(pw)
        tprice = entry*(1+tpct) if side=='long' else entry*(1-tpct)
        return {'tprice': tprice, 'tpct': tpct, 'mult': mult, 'pw': pw}
    except Exception:
        return {'tprice': 0.0, 'tpct': TARGET_PCT, 'mult': 1.0, 'pw': 0.0}

def _rise_pace(sig, side):
    """涨速节奏(缓涨放宽多吃/急拉收紧快锁): 简化1倍返回 + 末根冲幅判"""
    try:
        last15=sig.get('last15',0) or 0
        if abs(last15)>=0.5: return 0.85, 'alert'   # 急性大跳
        if abs(last15)<=0.08: return 1.15, 'buffer' # 缓行
    except Exception:
        pass
    return 1.0,'neutral'

def log(msg):
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, 'a') as f: f.write(line + '\n')
    except Exception: pass

# ─── 行情(OKX 免费; 与$200节点同源) ───
def _okx(path):
    try:
        # 🆕 2026-09-11: 超时 8s→3s. OKX挂时若每调用等8s, 一轮要数分钟(引擎发木); 3s无应即快回Gate.
        r = urllib.request.urlopen(urllib.request.Request('https://www.okx.com'+path,
            headers={'User-Agent':'M'}), timeout=3)
        return json.loads(r.read().decode())
    except Exception:
        return None

# 🌐🆕2026-09-16 事件一·网络自愈「跨层第三源」: OKX(境外云)→Gate(交易所) 同层伪冗余(VPN断一起瞎).
#   药: 加 Binance(不同境外线路) 作第三源. 三源跨线路 → VPN断掉一条, 仍有另两条可达.
#   只补数据源·不改任何交易逻辑. BINANCE_FALLBACK_ON=0 可关(回纯OKX+Gate).
BINANCE_FALLBACK_ON = __import__('os').environ.get('BINANCE_FALLBACK_ON','1') != '0'
def _binance_fallback(path):
    """OKX/Gate 都不可达时, 用 Binance 取行情(同构 OKX data 结构)."""
    if not BINANCE_FALLBACK_ON: return None
    try:
        _BN = 'https://fapi.binance.com'
        if '/market/ticker?' in path:
            _inst = path.split('instId=')[1].split('&')[0]        # 例 ADA-USDT-SWAP
            _sym = _inst.replace('-USDT-SWAP','').replace('-USDT','') + 'USDT'
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_BN}/fapi/v1/ticker/price?symbol={_sym}', headers={'User-Agent':'M'}), timeout=6)
            d = json.loads(r.read().decode())
            if d and d.get('price'):
                return {'data': [{'last': str(d['price'])}]}
        elif '/market/candles?' in path:
            _inst = path.split('instId=')[1].split('&')[0]
            _sym = _inst.replace('-USDT-SWAP','').replace('-USDT','') + 'USDT'
            _bar = path.split('bar=')[1].split('&')[0]
            _lim = int(path.split('limit=')[1].split('&')[0]) if 'limit=' in path else 50
            _iv = {'1m':'1m','3m':'3m','5m':'5m','15m':'15m','30m':'30m','1H':'1h','2H':'2h','4H':'4h','1D':'1d'}.get(_bar, _bar)
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_BN}/fapi/v1/klines?symbol={_sym}&interval={_iv}&limit={_lim}', headers={'User-Agent':'M'}), timeout=6)
            d = json.loads(r.read().decode())
            if d and isinstance(d, list):
                # Binance: [openTime,o,h,l,c,vol,...] 正序(t升) → 倒序成OKX样(最新在前)
                rows = sorted(d, key=lambda x: int(x[0]), reverse=True)
                return {'data': [[str(r2[0]), str(r2[1]), str(r2[2]), str(r2[3]), str(r2[4]), str(r2[5])] for r2 in rows]}
    except Exception:
        return None
    return None

def _gate_fallback(path):
    # 🆕 2026-09-11 00:5x 治病根: OKX超时不可达(实测0/5)时, 引擎"睛瞎"→net_err→看不见价/管不了仓/锁不了肉
    #   (老板实盘ADA空到过+2.56%肉, 但引擎peak只冻在0.526%→貔貅不触发→肉裸奔, 只靠人手工平).
    #   药: OKX失败时回退Gate(交易所本身, 实测稳0.5s). 只补数据源, 不改任何交易逻辑. 关: 置None即回纯OKX.
    #   把 OKX 路径 → Gate 路径, 返回同构 dict(模拟OKX的 data 结构): ticker加'data':[{'last':..}] / candles加'data':[[ts,o,h,l,c,vol],...]
    try:
        _GATE = 'https://api.gateio.ws/api/v4/futures/usdt'
        if '/market/ticker?' in path:
            _inst = path.split('instId=')[1].split('&')[0]      # 例 ADA-USDT-SWAP
            _c = _inst.replace('-USDT-SWAP','').replace('-USDT','')
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_GATE}/tickers?contract={_c}_USDT', headers={'User-Agent':'M'}), timeout=8)
            d = json.loads(r.read().decode())
            if d and isinstance(d, list) and d[0].get('last'):
                return {'data': [{'last': str(d[0]['last'])}]}
        elif '/market/candles?' in path:
            _inst = path.split('instId=')[1].split('&')[0]
            _c = _inst.replace('-USDT-SWAP','').replace('-USDT','')
            _bar = path.split('bar=')[1].split('&')[0]
            _lim = int(path.split('limit=')[1].split('&')[0]) if 'limit=' in path else 50
            _iv = {'1m':'1m','3m':'3m','5m':'5m','15m':'15m','30m':'30m','1H':'1h','2H':'2h','4H':'4h','1D':'1d'}.get(_bar, _bar)
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_GATE}/candlesticks?contract={_c}_USDT&interval={_iv}&limit={_lim}', headers={'User-Agent':'M'}), timeout=8)
            d = json.loads(r.read().decode())
            if d and isinstance(d, list):
                # Gate正序(t升)→倒序成OKX样(最新在前), [ts,o,h,l,c,vol]
                rows = sorted(d, key=lambda x: int(x['t']), reverse=True)
                return {'data': [[str(r2['t']), str(r2['o']), str(r2['h']), str(r2['l']), str(r2['c']), str(r2['v'])] for r2 in rows]}
    except Exception:
        return None
    return None

# 🌐🆕2026-09-16 事件一·网络自愈「断网侦测」: 三源全不可达 → 置网络断标志 → 引擎冻结开仓/记账.
_NET_STATE = {'down': False, 'since': 0, 'last_ok': 0, 'fail_streak': 0}
def _net_is_down():
    """读当前网络状态(供引擎决策: 断网→冻结开仓)."""
    return _NET_STATE.get('down', False)
def _net_mark_ok():
    _NET_STATE['fail_streak'] = 0
    _NET_STATE['last_ok'] = __import__('time').time()
    if _NET_STATE.get('down'):
        _down_sec = __import__('time').time() - _NET_STATE.get('since', 0)
        _NET_STATE['down'] = False
        try: log(f"🌐 网络自愈: 行情源恢复(断网{_down_sec:.0f}秒) → 解冻, 恢复开仓/正常管理")
        except Exception: pass
def _net_mark_fail():
    _NET_STATE['fail_streak'] = _NET_STATE.get('fail_streak', 0) + 1
    _thr = int(__import__('os').environ.get('NET_FREEZE_FAILS','3'))   # 连续N轮全源失败→判定断网
    if not _NET_STATE.get('down') and _NET_STATE['fail_streak'] >= _thr:
        _NET_STATE['down'] = True
        _NET_STATE['since'] = __import__('time').time()
        try: log(f"🌐 网络断线侦测: 三源(OKX/Gate/Binance)连续{_thr}轮全不可达 → 冻结开仓(保命), 持仓转纯守")
        except Exception: pass

def _okx2(path):
    """先OKX, 失败回退Gate, 再失败回退Binance(跨层三源冗余). 只读行情, 同构返回."""
    d = _okx(path)
    if d:
        _net_mark_ok(); return d
    d = _gate_fallback(path)
    if d:
        _net_mark_ok(); return d
    d = _binance_fallback(path)
    if d:
        _net_mark_ok(); return d
    _net_mark_fail()   # 三源全瞎 → 记一次失败(连续N次→断网冻结)
    return None

# 🔥🆕2026-09-12 行情源提速(老板令"修行情源慢·治极速命门"): _candles/_price 加短TTL缓存.
#   病: _coin_sig 单币串行拉 ~8次K线(4H/15m/1H重拉/5m/15m60…), ~2.5s/次 → ~20s/币 → 一轮~2min.
#   治: 同(币,bar,limit)在一轮内只拉一次, 复用缓存. TTL默认45s(给一轮冗余). 不改逻辑·只提速. CACHE_ON=0可关.
_CANDLE_CACHE = {}
_PRICE_CACHE = {}
CACHE_ON = __import__('os').environ.get('QUOTE_CACHE_ON','1') != '0'
CACHE_TTL = float(__import__('os').environ.get('QUOTE_CACHE_TTL','45'))
def _cache_get(_d, _k):
    if not CACHE_ON: return None
    _e=_d.get(_k)
    if _e and (__import__('time').time()-_e[0])<CACHE_TTL: return _e[1]
    return None
def _cache_put(_d, _k, _v):
    if CACHE_ON: _d[_k]=(__import__('time').time(), _v)

def _price(key):
    _ck=('px',key)
    _hit=_cache_get(_PRICE_CACHE,_ck)
    if _hit is not None: return _hit
    d = _okx2(f'/api/v5/market/ticker?instId={key}-USDT-SWAP')
    _v = float(d['data'][0]['last']) if d and d.get('data') else None
    if _v is not None: _cache_put(_PRICE_CACHE,_ck,_v)
    return _v
def _candles(key, bar, limit):
    _ck=(key,bar,limit)
    _hit=_cache_get(_CANDLE_CACHE,_ck)
    if _hit is not None: return _hit
    d = _okx2(f'/api/v5/market/candles?instId={key}-USDT-SWAP&bar={bar}&limit={limit}')
    if not d or not d.get('data'): return []
    _v=[float(r[4]) for r in sorted(d['data'], key=lambda x: x[0])]
    _cache_put(_CANDLE_CACHE,_ck,_v)
    return _v
# 🔥🆕2026-09-12 行情源并行预热(老板令"修行情源慢"): _coin_sig 需~7次不同K线(每次OKX~3.4s→串行~24s).
#   治: _prewarm 用线程池并行拉齐该币全部bar类型 → 总耗时≈单次(~3.4s), 后续_candles命中缓存.
#   同一次扫描内不重复拉; 不改逻辑只提速. PARALLEL_ON=0 可关(回串行).
def _prewarm(coin, specs):
    """并行拉齐该币全部(bar,limit)K线+price 入缓存. specs=[(bar,limit),...]"""
    if not PARALLEL_ON:
        for _b,_l in specs: _candles(coin,_b,_l)
        return
    from concurrent.futures import ThreadPoolExecutor
    def _one(s):
        if s[0]=='__px__':
            _price(coin)
        else:
            _candles(coin,s[0],s[1])
    try:
        with ThreadPoolExecutor(max_workers=min(8,len(specs)+1)) as ex:
            list(ex.map(_one, [('__px__',0)]+list(specs)))
    except Exception:
        for _b,_l in specs: _candles(coin,_b,_l)   # 并行失败→串行兼底

PARALLEL_ON = __import__('os').environ.get('QUOTE_PARALLEL_ON','1') != '0'
# _coin_sig 实际用到的全部K线规格(与函数内保持同步)
_SIG_SPECS = [('4H',20),('15m',30),('1H',60),('15m',6),('15m',60),('1H',24)]

def _ema(cs, n):
    k=2/(n+1); e=[cs[0]]
    for x in cs[1:]: e.append(x*k+e[-1]*(1-k))
    return e
def _macd_gck(c):
    try:
        c1 = _candles(c,'1H',60)
        if not c1 or len(c1)<30: return 'None',0.0
        e12=_ema(c1,12); e26=_ema(c1,26)
        dif=[a-b for a,b in zip(e12,e26)]; dea=_ema(dif,9)
        d=dif[-1]-dea[-1]; p=dif[-2]-dea[-2]
        if d>0 and p<=0: return 'golden',1.0
        if d<0 and p>=0: return 'death',1.0
        if d>0: return 'golden',0.5
        if d<0: return 'death',0.5
        return 'None',0.0
    except Exception:
        return 'None',0.0

def _coin_sig(c):
    """返回该币多信号上下文 + 净方向分(与$200节点同源评分, 多了4H大势供半山腰拦截)
    2026-09-09 21:4x 老板令·自愈方向中枢: 补‘高周期认向锚’(4H/1H EMA大势 + 真4H动量t4l)
      治老病: 方向分由 4 个短窗小特征均权拍脑袋→无大势仲裁→拿噪声当方向.
      现给每币带 regime 高层判向, 供 _pick 在下面拦‘短窗想开但大势明显顶牛’的错误方向."""
    _prewarm(c, _SIG_SPECS)   # 🔥并行预热: 一并拉齐全bar入缓存 → 后续_candles命中, 24s→~4s
    c4=_candles(c,'4H',20); c15=_candles(c,'15m',30); c1=_candles(c,'1H',60)
    pr=_price(c)
    if not c4 or len(c4)<12 or not c15 or len(c15)<10 or not pr: return None
    t4=(pr-c4[-12])/c4[-12]*100 if c4[-12] else 0      # 4H大势%(末12根≈近2日真动)
    # ── 高周期认向锚(治疗): 4H/1H EMA(8) 真趋势 + 失真多窗口径t4l ----------------------------------
    t4l=(pr-c4[-20])/c4[-20]*100 if len(c4)>=20 and c4[-20] else t4   # 更远4H窗(≈近3.3日)大势
    e4h=_ema(c4,8); e1h=_ema(c1,8)
    e4_bias = 'up' if e4h[-1]>e4h[-4]*1.002 else ('dn' if e4h[-1]<e4h[-4]*0.998 else 'flat')  # 4H EMA方向
    e1_bias = 'up' if e1h[-1]>e1h[-4]*1.001 else ('dn' if e1h[-1]<e1h[-4]*0.999 else 'flat')
    # 大势净判: 多数周期同向=顺大势(可为主方向仲裁), 冲突=chop(噪声带慎开)
    votes=sum([1 if e4_bias=='up' else (-1 if e4_bias=='dn' else 0),
               1 if e1_bias=='up' else (-1 if e1_bias=='dn' else 0),
               1 if t4l>0.25 else (-1 if t4l<-0.25 else 0)])
    regime = 'up' if votes>=2 else ('dn' if votes<=-2 else 'chop')
    # --------------------------------------------------------------------------------------------
    # 🆕2026-09-11 董事长择向·区间位(pos4): 4H近20根[最低,最高]区间中现价位置0~100 (0=区间底/超卖, 100=顶)
    # 🆕2026-09-11 行情质量: 近6h振幅(用15m近24根=6h高低)
    _h6=max(c15[-24:]) if len(c15)>=24 else max(c15); _l6=min(c15[-24:]) if len(c15)>=24 else min(c15)
    amp6=(_h6-_l6)/_l6*100 if _l6 else 0
    _hi=max(c4[-20:]) if len(c4)>=20 else max(c4); _lo=min(c4[-20:]) if len(c4)>=20 else min(c4)
    pos4=(pr-_lo)/(_hi-_lo)*100 if _hi>_lo else 50.0
    mf=sum(c15[-5:])/5; ms=sum(c15[-10:])/10
    tp='UP' if mf>ms else ('DOWN' if mf<ms else '?')
    gck,gs=_macd_gck(c)
    last15=(c15[-1]-c15[-2])/c15[-2]*100 if len(c15)>=2 and c15[-2] else 0
    s=0.0
    if t4>0.15: s+=1.0
    elif t4<-0.15: s-=1.0
    if tp=='UP': s+=1.0
    elif tp=='DOWN': s-=1.0
    if gck=='golden' and gs>0.5: s+=1.5
    elif gck=='death' and gs>0.5: s-=1.5
    elif gck=='golden': s+=0.7
    elif gck=='death': s-=0.7
    if last15>0.3: s+=0.5
    elif last15<-0.3: s-=0.5
    # 🛡 药①·保卫科高感知证伪(仅增强保卫科·不动其它): 识别"信号矛盾"与"量能背离" → 伪信号前兆
    contra = ((gck=='death' and tp=='UP') or (gck=='golden' and tp=='DOWN'))   # 信号打架=伪信号高危
    # 🎯🆕药B·反转识别加敏(2026-09-12 老板令"反转识别加敏"): 急涨/急跌中, 15m小回踩/小反弹是"换挡"不是"矛盾" → 豁免contra(真突破不被拦).
    try:
        _cp=_candles(c,'15m',6)
        if _cp and len(_cp)>=4 and _cp[-4]:
            _pi=abs(_cp[-1]-_cp[-4])/_cp[-4]*100     # 近3根15m单边幅度
            _pulse=_pi>=PULSE_AMP
            _pdir='up' if _cp[-1]>_cp[-4] else 'dn'
            # 急涨中(向上脉冲)且contra因death+UP→豁免; 急跌中(向下脉冲)且contra因golden+DOWN→豁免
            if _pulse and ((_pdir=='up' and gck=='death') or (_pdir=='dn' and gck=='golden')):
                contra=False
    except Exception:
        pass
    divg = 0
    try:
        _c15v=_candles(c,'15m',60)
        if _c15v and len(_c15v)>=25:
            _hi60=max(_c15v[:-1]); _lo60=min(_c15v[:-1])
            _at_hi = pr>=_hi60*0.998; _at_lo = pr<=_lo60*1.002
            # 量能萎缩(用15m收盘波动幅度近似量能强度, 无真实量则用ATR比)
            _tr=[abs(_c15v[i]-_c15v[i-1]) for i in range(1,len(_c15v))]
            _vshort=sum(_tr[-3:])/3 if len(_tr)>=3 else 0
            _vlong=sum(_tr[-20:])/20 if len(_tr)>=20 else _vshort
            _shrink = (_vshort < _vlong*0.8) if _vlong>0 else False
            if (_at_hi or _at_lo) and _shrink: divg = 1   # 创极值但动能萎缩=伪突破前兆
    except Exception:
        pass
    # 综合证伪置信(0~1): 矛盾(0.5) + 背离(0.3) + 近端反向(0.2)
    certify = 0.0
    if contra: certify += 0.5
    if divg:   certify += 0.3
    if len(c15)>=2 and c15[-2]:
        _l15=(c15[-1]-c15[-2])/c15[-2]*100
        if (s>=0 and _l15<-0.1) or (s<0 and _l15>0.1): certify += 0.2
    certify=min(1.0, certify)
    # 🧬 触觉融入·方案A(共振加权·守红线): 触觉向与引擎向一致→score+W; 相反→score-W; 中性/无→不动. 不改side.
    _tside,_tstr=_tactile_read(c)
    if _tside in ('long','short') and _tstr>=0.2:
        _eng_side='long' if s>=0 else 'short'
        if _tside==_eng_side: s+=TACTILE_W
        else: s-=TACTILE_W
    # 🧬🆕 时空梭顶底基因融入(2026-09-11 22:2x 老板令"融入/融合增强"·路演综合胜率66%实证):
    #   时空梭真金=用24h分位(0-100%)判顶/底 + 近端反转共振 → 加权母体择向(只加权不翻向·守触觉红线).
    #   识底(分位≤25%+近端转强)→给多向加分; 识顶(分位≥75%+近端转弱)→给空向加分. 反向弱加权.
    #   SK_GENE_ON=0 可关 (回旧无此基因). 与pos4互补: 时空梭=24h分位(自适应窗口), 母体pos4=4H近20根.
    if SK_GENE_ON:
        try:
            _c24=_candles(c,'1H',24)
            if _c24 and len(_c24)>=20:
                _sh=max(_c24); _sl=min(_c24); _sp=(pr-_sl)/(_sh-_sl)*100 if _sh>_sl else 50.0
                _samp=(_sh-_sl)/_sl*100 if _sl else 0
                _smom=(c15[-1]-c15[-4])/c15[-4]*100 if len(c15)>=4 and c15[-4] else 0
                if _samp>=2.5:   # 只在非震荡(有肉)时生效
                    if _sp<=25 and _smom>0:      # 识底→偏多
                        s += SK_GENE_W if s>=0 else SK_GENE_W*0.5
                    elif _sp>=75 and _smom<0:    # 识顶→偏空
                        s -= SK_GENE_W if s<=0 else SK_GENE_W*0.5
        except Exception:
            pass
    # 🎯🆕药A·见顶见底加敏(2026-09-12 老板令"赋予见顶见底信号加敏"·治ETH 2628顶未被识别):
    #   24h分位极值区(≥90%顶区/≤10%底区) + 近端转弱/强 → 顶/底预警. 比时空梭(75/25)更敏.
    #   顶区+近端转弱 (或顶区已滞涨) → 偏空(警示见顶); 底区+近端转强 (或底区已止跌) → 偏多(警示见底).
    _topbot=''
    if TOPBOT_SENS:
        try:
            _c24t=_candles(c,'1H',24)
            if _c24t and len(_c24t)>=20:
                _th=max(_c24t); _tl=min(_c24t); _tp=(pr-_tl)/(_th-_tl)*100 if _th>_tl else 50.0
                _tm=(c15[-1]-c15[-4])/c15[-4]*100 if len(c15)>=4 and c15[-4] else 0
                _tamp=(_th-_tl)/_tl*100 if _tl else 0
                if _tamp>=2.0:   # 非震荡
                    if _tp>=TOPBOT_ZONE*100 and _tm<0:       # 顶区+近端转弱→见顶预警(偏空)
                        s -= SK_GENE_W if s<=0 else SK_GENE_W*0.5
                        _topbot='见顶'
                    elif _tp<= (1-TOPBOT_ZONE)*100 and _tm>0: # 底区+近端转强→见底预警(偏多)
                        s += SK_GENE_W if s>=0 else SK_GENE_W*0.5
                        _topbot='见底'
        except Exception:
            pass
    return {'coin':c,'side':'long' if s>=0 else 'short','score':s,'t4':t4,'tp':tp,'gck':gck,'pr':pr,
            'last15':last15,'regime':regime,'t4l':round(t4l,3),'e4':e4_bias,'e1':e1_bias,'pos4':round(pos4,1),'amp6':round(amp6,2),
            'certify':round(certify,2),'contra':contra,'divg':divg,'topbot':_topbot,'pnl_ctx':None}

def _candles_from_hist(src, key, bar, limit):
    """离线回放注入点: 从 _3coin_hist 取bars(供回放脚本mock行情持久取)"""
    # 由回放脚本 monkeypatch _okx/_candles/_price; 此仅为默认实时
    return _candles(key, bar, limit)

# ─── 择强开仓(多币自切换内脏) ───
def _g(st):
    st.setdefault('guard',{'_dpnl':0.0,'_dstops':0,'_consec':0,'_cool':0,'_deadline':None})
    return st['guard']

# ───────── 🧬 生命体·训练数据集 (2026-09-10 老板令: 当前主力放在生命体上训练数据集) ─────────
#  定位: 纯数据记录(不改任何交易行为) —— 每次平仓把"开仓全景 + 结果"存下, 攒生命体的行为观察册/训练集.
#  字段: 币/向/开价/评分/开仓时认向regime+短窗特征/tier/持仓时长/结果pnl/pnl%/why/win/涨跌幅/时间.
import os as _os, json as _json, time as _time
LIFE_DATA_F = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'data_v2', 'mtsim', '_life_train_data.json')
def _life_sample(pos, pr, pnl_pct, pnl_usd, why):
    """平仓时落一条训练样本(开仓全景+结果). 纯追加·只保留最近5000条·失败不阻塞引擎."""
    try:
        _os.makedirs(_os.path.dirname(LIFE_DATA_F), exist_ok=True)
        arr = []
        if _os.path.exists(LIFE_DATA_F):
            try:
                arr = _json.load(open(LIFE_DATA_F, encoding='utf-8'))
                if not isinstance(arr, list): arr = []
            except Exception:
                arr = []
        ctx = pos.get('_ctx', {}) or {}
        arr.append({
            'coin': pos.get('coin'), 'side': pos.get('side'),
            'entry': round(float(pos.get('entry', 0) or 0), 6),
            'exit': round(float(pr or 0), 6),
            'tier': pos.get('tier', 0),
            'open_score': ctx.get('score'), 'open_regime': ctx.get('regime'),
            'open_t4': ctx.get('t4'), 'open_t4l': ctx.get('t4l'),
            'open_gck': ctx.get('gck'), 'open_tp': ctx.get('tp'), 'open_last15': ctx.get('last15'),
            'peak_pct': round(float(pos.get('peak_pct', 0) or 0) * 100, 3),
            'hold_h': round((_time.time() - float(pos.get('open_ts', _time.time()) or _time.time())) / 3600.0, 2),
            'pnl': round(float(pnl_usd or 0), 3), 'pnl_pct': round(float(pnl_pct or 0) * 100, 3),
            'win': bool((pnl_usd or 0) > 0), 'why': why,
            'regime_flip': bool(ctx.get('regime_at_open') and ctx.get('regime_now') and ctx.get('regime_at_open') != ctx.get('regime_now')),
            'ts': _time.time(), 'time': _time.strftime('%Y-%m-%d %H:%M:%S'),
        })
        arr = arr[-5000:]
        _json.dump(arr, open(LIFE_DATA_F, 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception as _e:
        try: log(f'⚠️ 训练样本落盘失败(不阻塞): {str(_e)[:60]}')
        except Exception: pass


def _note_close(st,pnl,why):
    """记一笔平仓计入护栏累(硬损/早断=消极单计stop+consec; 盈利/保本重置consec)"""
    g=_g(st)
    if pnl<0:
        g['_dpnl']+=pnl; g['_dstops']+=1; g['_consec']+=1
        g['_cool']=max(g['_cool'],CONSEC_COOL_N if g['_consec']>=CONSEC_LOSS_K else 0)
    else:
        g['_consec']=0

def _roll_guard(st,day=None):
    """护栏罐日翻(护栏=土行硬铁律, 不参与任何采样/观察, 也绝不被任何上层改写):
       · 只有在**真跨入新一天**(st 内已记 _day 与新 day 不同)才开新窗——重置日亏/日止损;
       · 同日(st 已记 _day==day)绝不动罐: 杜绝'重启瞬间把当日已到线的止损锁冲掉'这类自毁护栏事故;
       · 本函数只做护栏复位, 不记任何触突/混沌样本(观察层不碰护栏铁律)."""
    g=_g(st)
    if g.get('_day')==day:      # 同日: 绝对保持已建护栏窗口(不动 _dpnl/_dstops/_cool)
        return
    g['_dpnl']=0.0; g['_dstops']=0; g['_consec']=0; g['_cool']=0; g['_day']=day

# (触突微节点已按老板2026-09-09 11:47 令·全杀物理剥除→归档于 _封存_触突微节点_20260909/)
VAULT_FREEZE_ON = __import__('os').environ.get('VAULT_FREEZE_ON','1') != '0'   # 🦄2026-09-17 麒麟护仓钩子开关(可 =0 关)
# 🔪🆕2026-09-17 火印令CUT-03 逆势做空闸(默认开·可 env =0 关 / 回退)
COUNTER_SHORT_GATE_ON = float(__import__('os').environ.get('COUNTER_SHORT_GATE_ON','1'))
COUNTER_SHORT_TREND = 0.20   # t4l(4H大势)超此值=上升势
COUNTER_SHORT_MIN   = float(__import__('os').environ.get('COUNTER_SHORT_MIN','90'))  # 逆势开空的质量分下限
# ⚖️2026-09-23 19:4x 救阴·本闸对称化(老板令「搞，做完比沙箱」· 火印 ED-151): CUT-03 只拦逆势空(实测拒空703次/拒多0次) → 补对称腿(下降势拦逆势多)
COUNTER_GATE_SYM = float(__import__('os').environ.get('COUNTER_GATE_SYM','1'))  # 1=对称(默认) 0=仅旧拦空


def _vault_frozen():
    """🦄 麒麟护仓: L3冻结旗标 → **只冻结新开仓, 平仓通道永远保留**(老板令 COMMAND_QILIN_VAULTGUARD_ENHANCE)."""
    try:
        import os as _o
        _d = _o.path.dirname(_o.path.abspath(__file__))
        for _p in (_o.path.join(_d, '..', 'vault', 'freeze.flag'),
                   _o.path.join(_d, 'vault', 'freeze.flag')):
            if _o.path.exists(_p):
                return True
    except Exception:
        pass
    return False


def _guard_block(st, macro=None, pick=None):
    """护栏总闸: 返回 拦因 or None(放). 顺序: 冷却(连亏) > 日损熔断 > 日止损超限 > 黑天鹅 > 闪崩.
       macro: 可选短窗大盘|幅|; pick.sig 含 last15/flash 判. 硬护栏=护本金第一原则.
       🆕2026-09-11 自愈: 日亏 _dpnl 按'当日 trades'重算(防旧账残留锁死今天)。"""
    g=_g(st)
    # 🦄🆕2026-09-17 麒麟护仓(L3冻结): 旗标在 → 拒绝新开仓(平仓通道不受影响)
    if VAULT_FREEZE_ON and _vault_frozen():
        return '麒麟护仓·L3冻结开仓入口(只保留平仓通道): vault/freeze.flag 在 → 拒新开(护本)'
    # 🔪🆕2026-09-17 火印令CUT-03 逆势做空闸: 上升势(t4l>+0.20)要开空 → 质量分<90 则拒
    #    铁证: 真钱 short 41笔 胜39.0% 净-115.80 vs long 21笔 胜47.6% 净+11.91; 单笔最亏TOP8七笔是空单
    #    ⚠ 只拦'逆势开空'(不做逆势摸顶); 逆势做多不动(50%胜·免得误伤低吸)
    if COUNTER_SHORT_GATE_ON and pick:
        _sd=str(pick.get('side') or '').lower()
        _t4=float(pick.get('t4l') or 0)
        _sc=float(pick.get('score') or 0)
        if _sd.startswith('s') and _t4 > COUNTER_SHORT_TREND and _sc < COUNTER_SHORT_MIN:
            return (f'逆势做空闸: {pick.get("coin")}上升势(t4l={_t4:+.2f}>+{COUNTER_SHORT_TREND})'
                    f'且质量分{_sc:.0f}<{COUNTER_SHORT_MIN:.0f} → 拒开空(不做逆势摸顶·护本)')
        # ⚖️救阴·对称腿(ED-151): 下降势要开多 → 质量分<90 则拒(治'升势只多·降势无多'的单边)
        if COUNTER_GATE_SYM and _sd.startswith('l') and _t4 < -COUNTER_SHORT_TREND and _sc < COUNTER_SHORT_MIN:
            return (f'逆势做多闸: {pick.get("coin")}下降势(t4l={_t4:+.2f}<-{COUNTER_SHORT_TREND})'
                    f'且质量分{_sc:.0f}<{COUNTER_SHORT_MIN:.0f} → 拒开多(不做逆势摸底·护本)')
    if GLOBAL_CIRCUIT_ON:   # 🗄 2026-09-11 封存开关: 关时跳过全域锁死类护栏(日亏/日止损/连亏), 只留单笔护本
        if g['_cool']>0:
            g['_cool']-=1
            if g['_consec']>=CONSEC_LOSS_K:
                return f'连亏冷却锁: 连亏{g["_consec"]}单≥{CONSEC_LOSS_K}·自动冷却·防同刀砍(休{g['_cool']}轮后再试)'
        if g['_dpnl']<=-DAY_LOSS_MAX*2000:
            return f'日亏熔断: 今日已实现亏{g["_dpnl"]:+.1f}≤池{DAY_LOSS_MAX*100}%→空仓休·暂停今日新开(护本)'
        if g['_dstops']>=DAY_STOP_MAX:
            return f'单日止损超限: 今日止损{g["_dstops"]}次≥{DAY_STOP_MAX}→锁当日新开'
    m=0 if macro is None else abs(macro)
    if m>=BLACK_SWAN_PCT:
        return f'防黑天鹅: 大盘短窗|动|{m*100:.1f}%≥{BLACK_SWAN_PCT*100}%→拒开(护本第一)'
    if pick and abs(pick.get('last15',0) or 0)>=FLASH_PCT*100:   # last15=%×100; FLASH_PCT分数0.035=3.5%→乘100对齐(修真连测发现的live真实last15误拦 2026-09-08)
        return f'防闪崩: {pick["coin"]}15m单根|{pick["last15"]:.2f}%|≥{FLASH_PCT*100:.1f}%→不追闪崩插针'
    return None

def _radar_feed(pool, chosen):
    """📡 雷达情报化(2026-09-15 老板令): 照见结果写 _雷达情报.json → 供哨兵(白虎)合并进军情总线.
       定位: 雷达=开明兽情报工具(信号增强)·只报军情·不决策. 纯写盘·零侵入交易逻辑."""
    try:
        import json as _j, os as _o, time as _t
        _bdir=_o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir)=='子引擎': _bdir=_o.path.dirname(_bdir)   # 子引擎内核副本→回主目录(雷达情报统一总线)
        _fp=_o.path.join(_bdir,'data_v2','mtsim','_雷达情报.json')
        _items=[]
        for s in (pool or []):
            sd=s.get('side')
            _al=sum([
                1 if (sd=='long' and s.get('e4')=='up') or (sd=='short' and s.get('e4')=='dn') else 0,
                1 if (sd=='long' and s.get('e1')=='up') or (sd=='short' and s.get('e1')=='dn') else 0,
                1 if (sd=='long' and (s.get('t4l',0) or 0)>0.15) or (sd=='short' and (s.get('t4l',0) or 0)<-0.15) else 0,
            ])
            _items.append({'coin':s.get('coin'),'side':sd,'align':_al,
                           'embryo':round(abs(float(s.get('score',0) or 0)) + (2.0 if _al==2 else (1.0 if _al==1 else (0.0 if _al==3 else -1.0))),2)})
        _d={'updated':_t.strftime('%Y-%m-%d %H:%M:%S'),'chosen':(chosen.get('coin')+' '+chosen.get('side')) if chosen else '','nodes':_items}
        _tmp=_fp+'.tmp'; _j.dump(_d,open(_tmp,'w',encoding='utf-8'),ensure_ascii=False); _o.replace(_tmp,_fp)
    except Exception:
        pass


def _pick():
    """腾蛇·择强(辨向增强·老板23:33选A): 不只挑|score|最大, 更要挑'方向最清'的币开——
       同一币多周期(4H大势4H / 15m趋势tp / MACD金死叉)一致=方向清=优先; 强冲突(想开的就是跟4H大势顶牛→逆势隐患)=弃.
       这样腾蛇做方向(块1)时, 从'看谁冲就开谁'升级为'挑方向不矛盾的那个开', 治那2类'被我错塞进门闸'的逆势摸.
       规则: ①只放 |score|≥阀 的候选; ②在候选里先筛掉'重逆势'(4H对持仓向明显相反+15m急反抽顶牛)币; ③剩下按|score|取最强(同清度的优先清)."""
    cands=[]
    _LAST_SIGS.clear()
    for c in WATCH_COINS:
        s=_coin_sig(c)
        if s: _LAST_SIGS[c]=s
        if s and abs(s.get('score',0))>=PICK_ABS_MIN:
            cands.append(s)
    if not cands: return None
    # ②先剔除 重逆势摸 币: 想开方向但4H大势明显反向反对(t4符号与side相反)且已是急动量顶牛(last15强反向)
    clean=[]
    for s in cands:
        t4=s.get('t4',0) or 0; last15=s.get('last15',0) or 0; tp=s.get('tp')
        side=s.get('side')
        macro_against = (side=='long' and t4<=-0.8) or (side=='short' and t4>=0.8)
        loud_conflict = ((side=='long' and tp=='DOWN' and last15<-0.3) or (side=='short' and tp=='UP' and last15>0.3))
        if macro_against and loud_conflict:
            continue   # 重逆势·弃(腾蛇不选逆4H大势又要摸的币)
        # 🆕2026-09-09 高周期认向闸(治方向中枢噪声病): 短窗想开的方向 vs 高层regime('up'/'dn') 明显顶牛→弃
        #   例: 短窗想 long 但 4H/1H 大势 regime='dn'(更高层一致向下)→ 逆大势摸多, 掐; 反之亦然.
        #   只弃“高层有一致反向”; regime='chop'(高层无同向)不在此弃(留给下面的宁缺毋滥判定).
        reg=s.get('regime')
        reg_against = (side=='long' and reg=='dn') or (side=='short' and reg=='up')
        if reg_against:
            continue   # 高层一致反对短方向→弃(不逆更高大势开)
        # ⚫🆕2026-09-15 10:16 A: 择向精准闸已封存(死代码移除) → 交"精准择向雷达"接管择向(见 _coin_sig 提质).
        clean.append(s)
    if not clean:
        return None   # 全部重逆势/无方向清→宁缺毋滥(腾蛇不硬开矛盾币)
    # 🔗🆕 药②·与腾蛇双链路(2026-09-11 老板令): 快链(感知)+稳链(确认)并行
    #   快链(感知): 高certify(信号矛盾/量能背离=伪信号前兆)的币 → 稳链执行前先剔除/降级
    #   稳链(确认): 原4H大势+15m+MACD一致性链照旧执行
    #   腾蛇双腿并行: 快链预警伪信号, 稳链只在'方向清且非伪'时才执行开仓
    _dual = os.environ.get('DUAL_CHAIN_ON','1') != '0'
    if _dual:
        _clean2=[]
        for s in clean:
            _ce=_certify_of(s)   # 🧬快链: 引擎certify + 触突军情certify 取大
            if _ce>=0.5:   # 伪信号高危 → 快链拦下
                log(f"🔗 快链感知: {s['coin']} 伪信号高危(certify{_ce}) → 腾蛇稳链不开(避伪信号小亏)")
                continue
            # ☯🀄 母子融合(2026-09-11): 读母体共识, 母体判伪信号高危(certify≥0.5)的币 → 三标也不开(避伪同步)
            _fc=_fusion_read(s['coin'])
            if _fc and float(_fc.get('certify',0) or 0)>=0.5:
                log(f"☯ 母子融合: {s['coin']} 母体共识判伪信号高危(certify{_fc.get('certify')}) → 三标同步不开")
                continue
            _clean2.append(s)
        if _clean2:
            clean=_clean2            # 有存活候选 → 用过滤后的
        else:
            # 🔴2026-09-11 治“拦了又开”死病(老板令): 若全部候选均被快链/母子融合拦下(伪信号高危)
            #   → 绝不回退到被拦候选(那等于白拦·ADA实盘被拦了却照样开).
            # 🛡🆕2026-09-11 21:4x 老板令“放开宁缺毋滥·给麒麟兽兜底”
            # 🔧🆕2026-09-12 06:5x 老板"睡一觉漏光光"纠错(恢复"宁缺毋滥"本意):
            #   全候选伪信号+无肉(振幅不足)→真空仓; 仅当"有肉"(至少一个候选振幅≥RANGE_AMP)才择强开.
            if os.environ.get('OPEN_WHEN_ALLHOT','1') != '0':
                _meaty=[s for s in clean if float(s.get('amp6',0) or 0)>=RANGE_AMP]
                if _meaty:
                    _best=max(_meaty, key=lambda s:abs(s.get('score',0)))
                    log(f"🤸 放开宁缺毋滥(有肉): 全{len(clean)}候选certify高危·{len(_meaty)}个有肉 → 择最强开({_best['coin']} {_best.get('side')} |{_best.get('score'):+.1f}|振幅{_best.get('amp6')}%) + 麒麟兜底")
                    return _best
                log(f"🛑 快链/融合: 全{len(clean)}候选均伪信号高危且无肉(振幅<{RANGE_AMP}%) → 腾蛇不开(宁缺毋滥·真空仓)")
                return None
            log(f"🛑 快链/融合: 全{len(clean)}候选均伪信号高危 → 腾蛇不开(宁缺毋滥·不硬凑)")
            return None
    # 🆕 优先挑“短窗方向与高层大势同向”的那一个(顺大势的强于只凭短窗蒙的); 其余按旧|score|取强
    # 🆕 优先挑“短窗方向与高层大势同向”的那一个(顺大势的强于只凭短窗蒙的); 其余按旧|score|取强
    agree=[s for s in clean if s.get('side')==('long' if s.get('regime')=='up' else 'short') and s.get('regime') in ('up','dn')]
    pool = agree if agree else clean
    # 📡🆕2026-09-15 10:16 C(老板令"精准择向雷达·照亮2/3启动点"): 雷达择优接管"防追高".
    #   理念: 不用"闸拦截", 而用"雷达照亮" — 用"方向胚胎度"评分, 优选"将成未成(2/3对齐)"启动点.
    #   沙箱实证: 对齐2/3最佳(均-0.011%) > 3/3(均-0.055%,共识点=追高陷阱) > 0/3(最差).
    #   DIR_RADAR_ON=0 一键回旧(纯|score|择强).
    if DIR_RADAR_ON:
        def _embryo(s):
            """方向胚胎度: 越高=越接近"启动点(将成未成)"""
            sd=s.get('side')
            _al=sum([
                1 if (sd=='long' and s.get('e4')=='up') or (sd=='short' and s.get('e4')=='dn') else 0,
                1 if (sd=='long' and s.get('e1')=='up') or (sd=='short' and s.get('e1')=='dn') else 0,
                1 if (sd=='long' and (s.get('t4l',0) or 0)>0.15) or (sd=='short' and (s.get('t4l',0) or 0)<-0.15) else 0,
            ])
            sc=abs(float(s.get('score',0) or 0))
            if RADAR_EMBRYO_V2:  # 🎯2026-09-15 A方案: 3/3全共振最优(数据铁证)
                base = 2.0 if _al==3 else (1.0 if _al==2 else (-0.5 if _al==1 else -1.0))
            else:  # 旧(回退)
                base = 2.0 if _al==2 else (1.0 if _al==1 else (0.0 if _al==3 else -1.0))
            _v = sc + base + RADAR_W_ALIGN*_al
            # 🌟2026-09-15 B加权: 黄金窗口(北京0-2点)得分乘权 → 同分下优先选黄金窗口的信号
            if SEG_GOLD_ON:
                try:
                    import time as _gt
                    _h = _gt.localtime().tm_hour
                    if SEG_GOLD_HOURS[0] <= _h < SEG_GOLD_HOURS[1]:
                        _v *= SEG_GOLD_BOOST
                except Exception:
                    pass
            return _v
        _res = max(pool, key=_embryo)
        log(f"📡 雷达照亮: {_res['coin']} {_res.get('side')} 胚胎度择优(|分|{abs(_res.get('score',0)):.1f}·照辉2/3启动点·避3/3共识)")
        if DIR_RADAR_FEED:
            _radar_feed(pool, _res)   # 📡 情报化: 照见结果 写总线 → 白虎→烛龙/腾蛇
        _LAST_CHOSEN[0]=(_res['coin']+' '+_res['side']) if _res else ''
        return _res
    _res = max(pool, key=lambda s:abs(s['score']))
    _LAST_CHOSEN[0]=(_res['coin']+' '+_res['side']) if _res else ''
    return _res

def _halfmountain_block(sig):
    """🚦 半山腰守门(治旧母体通用门松): 想顺势开多但4H大势显著向下 + 中位虚弹 → 拦.
       下跌日(4H动量<-0.3%)里 15m反向弹一下就当多开=旧病复发 → 不给开."
    多向: t4<-0.3(大势下)+score由弱转多(recent) → 拦(不在下跌中段虚弹抄多).
    对称: 上涨日4H>+0.3 里 15m回弹想开空也不给(不在上升中段逆势摸顶)."""
    try:
        t4=sig.get('t4',0); score=sig.get('score',0); tp=sig.get('tp')
        # 📡🆕2026-09-15 C(老板令): 雷达接管→只拦极端逆大势(|t4|≥1.0%); 缓区(0.3~1.0)放行交雷达择优.
        _thr = 1.0 if HALFMOUNTAIN_RADAR_TAKEOVER else 0.3
        if score>0 and t4<-_thr and tp=='UP':
            return f"半山腰守门: 4H大势{t4:+.2f}%还在跌,仅15m{tp}虚弹想开多→不在下跌中段抄多(等真反转/破位)"
        if score<0 and t4>_thr and tp=='DOWN':
            return f"半山腰守门: 4H大势{t4:+.2f}%还在涨,仅15m{tp}回弹想开空→不在上升中段逆势摸顶"
    except Exception:
        pass
    return None

def _quality_block(sig):
    """🆕2026-09-11 道器行情质量闸(治"窄市硬做→手续费吃利润"):
       实证: 今日fee $5.43吃已实现利润33%; 窄市(SOL/XRP 6h振幅1.5-2%/趋势~0)反复进出.
       规则: 该币近6h振幅<QUALITY_AMP6_MIN(1.2%) 且 4H净趋势|t4|<0.3%(纯震荡) → 不硬做(宁缺毋滥).
       有肉行情(振幅够 或 有真趋势)不受影响. 可 QUALITY_GATE_ON=0 整关."""
    if not QUALITY_GATE_ON: return None
    try:
        amp6=sig.get('amp6'); t4=abs(sig.get('t4',0) or 0)
        if amp6 is None: return None
        if amp6 < QUALITY_AMP6_MIN and t4 < 0.3:
            return f"行情质量不足: {sig.get('coin')}近6h振幅{amp6:.2f}%<{QUALITY_AMP6_MIN}%且4H趋势{t4:.2f}%≈0(窄市没肉)→不硬做(手续费吃利润)"
        # 🌟🆕2026-09-15 09:11 A方案治本(老板令): chop区(震荡)+低把握(|score|<CHOP_OPEN_MIN_SCORE) → 不开.
        #   病: DOGE 04:32在chop区(把握47%)开多 → 行情转势后被刹车(-1.19%) → 反复买卖白送手续费.
        #   药: 开仓源头把关 — chop模糊区只接中高把握(score≥2.5), 低把握宁缺毋滥.
        _reg=sig.get('regime'); _sc=abs(float(sig.get('score',0) or 0))
        if _reg=='chop' and _sc < CHOP_OPEN_MIN_SCORE:
            return f"chop区把握不足: {sig.get('coin')} regime=chop且|score|{_sc:.1f}<{CHOP_OPEN_MIN_SCORE}(模糊区不开)→宁缺毋滥(避反复买卖)"
        # 🕐2026-09-15 B方案(老板令): 时段闸 — 美欧时段(北京8-22)噪音大, 只接强信号.
        if SEG_GATE_ON:
            try:
                import time as _seg_t
                _seg_hr=_seg_t.localtime().tm_hour
                if SEG_STRONG_HOURS[0] <= _seg_hr < SEG_STRONG_HOURS[1] and _sc < SEG_MIN_SCORE:
                    return f"时段闸: {sig.get('coin')} 当前{_seg_hr}点美欧时段·|score|{_sc:.1f}<{SEG_MIN_SCORE}→只做强信号(避欧美噪音)"
            except Exception:
                pass
    except Exception:
        pass
    return None

def _exhaust_rechase_block(sig):
    """🚻 高位衰竭禁再追(与半山腰对称·治'该歇时追'): 币已大涨到高位(4H涨幅大)却还想开多买回 →
       若非真破新高续涨(15m强推/创新高)而是高位衰竭(近端走弱/tp反向) → 拦, 等回落企稳或真破位续涨。
       多向(对称): 想开多 且 4H已大涨(≥~2.5%) 但 15m已不主导推(非UP/tp停/score回落) → 高位衰竭禁裸追;
       空向: 想开空 且 4H已深跌(≤~-2.5%) 但 15m已不主导跌 → 地板禁追空。
       只在此二重(4H高位&15m不续推)同真时拦; 强刚破位/续推不受影响(真突破照开)。"""
    try:
        t4=sig.get('t4',0); score=sig.get('score',0); tp=sig.get('tp'); gck=sig.get('gck')
        # 现净分含15m/末根分量: 若score已不强烈同向说明近端在衰减
        if score>0 and t4>=2.5 and tp!='UP':
            return f"高位衰竭禁再追: {sig.get('coin')}4H已涨{t4:+.2f}%至高位,15m{tp}不再主导推→非真破位裸追多(等企稳或破新高)"
        if score>0 and t4>=2.5 and gck=='death':
            return f"高位衰竭禁再追: {sig.get('coin')}4H已涨{t4:+.2f}%但MACD死叉→高位衰竭不追多"
        if score<0 and t4<=-2.5 and tp!='DOWN':
            return f"高位衰竭禁再空: {sig.get('coin')}4H已跌{t4:+.2f}%至深位,15m{tp}不再主导跌→地板不追空"
        if score<0 and t4<=-2.5 and gck=='golden':
            return f"高位衰竭禁再空: {sig.get('coin')}4H已跌{t4:+.2f}%但MACD金叉→深位衰竭不追空"
        # 🆕2026-09-11 董事长择向·区间位维度(治"接飞刀"): 想开空但已跌到4H区间底(pos4≤20, 超卖) 且15m不主导跌
        #   → 地板裸追空=接飞刀(实盘SOL/XRP/LINK/NEAR全在pos2~19%仍被追空→反弹即早断).
        #   真破位续跌(15m仍DOWN/创新低)不受影响; 镜像防高位追多(pos4≥80 & 15m不UP).
        _p4=sig.get('pos4')
        if _p4 is not None:
            if score<0 and _p4<=20 and tp!='DOWN':
                return f"深位禁裸追空: {sig.get('coin')}已跌至4H区间底(pos{_p4:.0f}%≤20)15m{tp}不续跌→接飞刀(等反弹/真破位)"
            if score>0 and _p4>=80 and tp!='UP':
                return f"高位禁裸追多: {sig.get('coin')}已涨至4H区间顶(pos{_p4:.0f}%≥80)15m{tp}不续涨→追高(等回踩/真破位)"
    except Exception:
        pass
    return None

# ─── 账本(SIM隔离) ───
def load():
    if os.path.exists(STATE_FILE):
        try: return json.load(open(STATE_FILE))
        except Exception: pass
    return {'pos':None,'realized':0.0,'trades':[]}
def save(st):
    tmp=STATE_FILE+'.tmp'; json.dump(st,open(tmp,'w')); os.replace(tmp,STATE_FILE)

# ── 🎚 自适应智能调仓 (2026-09-10 老板令: 为模拟母子系统增加·“小钱办大事”) ──
#   把握度 = 信号强度|score| × 认向共振(顺高层大势regime) × 趋势顺应(tp同向)
#   名义 = NOTIONAL × (0.35 + 0.65×f)  → 把握大接近满仓·把握小收缩(下限0.35×). 保证金=名义/LEVER.
#   ⚠量程铁律(2026-09-10 22:52 老板"固化成常态·不容重复"): score真实量程=±4(t4±1 tp±1 macd±1.5 last15±0.5).
#     档位必须按真实量程校准, 绝非0-100! 曾因档位写95/90/88/84(0-100量程)→满分顺势单被打入末档→保证金偏小事故.
#     本函数与实盘层 _母体实盘.py 的 _adaptive_notional 同口径(改动须两侧一起改).
def _adaptive_notional(sig):
    try:
        sc=abs(float(sig.get('score',0) or 0)); reg=sig.get('regime'); side=sig.get('side'); tp=sig.get('tp')
        # 按真实量程±4校准: 3.5+→1.0 / 2.5+→0.85 / 1.5+→0.65 / 其余→0.5
        f_score = 1.0 if sc>=3.5 else (0.85 if sc>=2.5 else (0.65 if sc>=1.5 else 0.5))
        agree = (reg=='up' and side=='long') or (reg=='dn' and side=='short')
        f_reg = 1.0 if agree else (0.55 if reg in ('chop',None,'') else 0.7)
        f_tp = 1.0 if ((tp=='UP' and side=='long') or (tp=='DOWN' and side=='short')) else 0.85
        f=max(0.0,min(1.0, f_score*f_reg*f_tp))
        # 🆕2026-09-11 结果导向·弱信号封顶(治"方向不清却开大仓"): sc<1.5→名义≤40%仓; 与"空仓休不硬开"同源
        cap=1.0 if sc>=1.5 else 0.40
        return min(NOTIONAL*(0.35+0.65*f), NOTIONAL*cap), f
    except Exception:
        return NOTIONAL, 0.0

def _open_paper(st, sig, pr):
    q=WATCH_COINS[sig['coin']]['quanto']
    _nt,_conf=_adaptive_notional(sig)   # 🎚 自适应名义(把握度)
    size_ct=max(1,int(round(_nt/pr/q)))
    st['pos']={'coin':sig['coin'],'side':sig['side'],'entry':pr,'notional':_nt,
               'peak':0.0,'peak_pct':0.0,'floor_pct':0.0,'size_ct':size_ct,
               'big_meat':False,'tier':0,'open_ts':_time.time(),'_opened_ts':_time.time(),'conf':round(_conf,3),   # 🆕_opened_ts供方向自检
               '_ctx':{'score':sig.get('score'),'regime':sig.get('regime'),'t4':sig.get('t4'),
                       't4l':sig.get('t4l'),'gck':sig.get('gck'),'tp':sig.get('tp'),
                       'last15':sig.get('last15'),'regime_at_open':sig.get('regime')}}
    log(f"🚀[SIM开] {sig['coin']} {sig['side']} score{sig['score']:+.1f}(t4{sig.get('t4',0):+.2f}%/{sig.get('gck')})"+(f" 🎯{sig.get('topbot')}" if sig.get('topbot') else "")+f" {size_ct}张@{pr:.4f} 名义${_nt:.0f}(把握{_conf*100:.0f}%)")
    return True

def _smart_bleed(pos, sig):
    """🧠🆕2026-09-12 智能阴跌分辨(老板令"同向行情给宽幅空间·增强智能识别")
    深水+缓反向时: 辨"健康回踩"vs"真反转" → 健康回踩给宽幅(不砍), 真反转才砍.
    5维智辨(自适应): ①大趋势向 ②回踩幅度vs涨幅 ③量能收缩 ④急涨后回踩 ⑤近端反向强度.
    返回 ('retrace',原因) 或 ('real',原因). 自适应: 强度按该币真实波动动态调.
    """
    try:
        coin=pos['coin']; side=pos['side']
        cl=_candles(coin,'15m',16)
        c1h=_candles(coin,'1H',8)
        if not cl or len(cl)<8: return ('real','无数据')
        # ① 大趋势方向: 1H近4根斜率是否仍顺持仓向(自适应: 看近4根净变化)
        _tr=0.0
        if c1h and len(c1h)>=4 and c1h[-4]:
            _tr=(c1h[-1]-c1h[-4])/c1h[-4]*100
        _tr_ok = (_tr>=SMART_BLEED_TREND) if side=='long' else (_tr<=-SMART_BLEED_TREND)
        # ② 回踩幅度 vs 近段涨幅(15m近16根): 回踩<涨幅×0.5 → 健康
        _seg=cl[-16:]; _hi=max(_seg); _lo=min(_seg); _cur=cl[-1]
        if side=='long':
            _rise=(_hi-min(_seg[:8]))/(min(_seg[:8]) or 1)*100  # 近段涨(前半低点到高点)
            _retr=(_hi-_cur)/(_hi or 1)*100                      # 从高点回踩
        else:
            _rise=(max(_seg[:8])-_lo)/(max(_seg[:8]) or 1)*100
            _retr=(_cur-_lo)/(_lo or 1)*100
        _retr_ok = _retr < _rise*SMART_BLEED_RETRACE if _rise>0.3 else False
        # ③ 量能/波动收缩(缩量回踩=健康): 近3根波动 < 前10根均幅 → 缩量
        _tr3=[abs(cl[i]-cl[i-1]) for i in range(len(cl)-3,len(cl))]
        _tr10=[abs(cl[i]-cl[i-1]) for i in range(len(cl)-12,len(cl)-2)]
        _shrink = (sum(_tr3)/max(1,len(_tr3)) < sum(_tr10)/max(1,len(_tr10))*0.85) if _tr10 else False
        # ④ 急涨/急跌后回踩(近6根有过大动 → 回踩正常)
        _bigmove = (max(_seg[-8:])-min(_seg[-8:]))/(min(_seg[-8:]) or 1)*100 > 3.0
        # ⑤ 近端反向强度(不能太猛): 近2根累计反向幅度
        _rev2=abs(cl[-1]-cl[-3])/(cl[-3] or 1)*100 if len(cl)>=3 else 0
        _soft_rev = _rev2 < 1.2   # 缓反向(<1.2%)
        # ── 综合判定: 多指标指向"健康回踩" → retrace; 否则 real ──
        _health = sum([_tr_ok, _retr_ok, _shrink, _bigmove, _soft_rev])
        _why=f"趋势{'顺' if _tr_ok else '逆'}(1H{_tr:+.2f}%) 回踩{_retr:.1f}%<涨{_rise:.1f}%{'✓' if _retr_ok else '✗'} {'缩量' if _shrink else '放量'} {'急动后' if _bigmove else ''} {'缓反' if _soft_rev else '猛反'}"
        if _health>=3 and not (not _soft_rev and _shrink==False):
            return ('retrace', _why)
        return ('real', _why)
    except Exception as e:
        return ('real', f'分辨异常{str(e)[:20]}')

def _close_here(st, pos, pr, pnl_pct, pnl_usd, why):
    st['realized']=st.get('realized',0)+pnl_usd
    # 🆕2026-09-11 老板令"三标分台账·注明当日胜率": 加 ts(平仓时刻) + day(当日) 供面板算当日胜率
    _now=_time.time()
    st.setdefault('trades',[]).append({'coin':pos['coin'],'side':pos['side'],
        'entry':round(pos['entry'],4),'exit':round(pr,4),'pnl':round(pnl_usd,2),
        'pnl_pct':round(pnl_pct*100,3),'why':why,'peak_pct':round(pos.get('peak_pct',0)*100,3),
        'ts':round(_now,1),'day':_time.strftime('%Y-%m-%d',_time.localtime(_now))})
    _note_close(st,pnl_usd,why)   # 🛡护栏: 计日亏/止损/连亏(供熔断闸)
    _life_sample(pos, pr, pnl_pct, pnl_usd, why)   # 🧬 生命体训练数据集(开仓全景+结果)
    log(f"🔒[SIM平] {pos['coin']} {pos['side']} {why} pnl{pnl_usd:+.2f}$({pnl_pct*100:+.2f}%) 累计{st.get('realized',0):+.2f}$ 峰{pos.get('peak_pct',0)*100:.2f}%")
    st['pos']=None

def _weak_signal(pos, sig):
    """近端转弱(供金蟾判伪/大肉确无发展): 反持仓向的15m/MACD/末根短下破"""
    if pos['side']=='long':
        if sig.get('tp')=='DOWN': return True,'15m转跌'
        if sig.get('gck')=='death': return True,'MACD死叉'
    else:
        if sig.get('tp')=='UP': return True,'15m转涨'
        if sig.get('gck')=='golden': return True,'MACD金叉'
    return False,''

def cycle_once(st, now_price=None, now_sig=None, external_flat=False):
    pos=st.get('pos')
    if pos:
        # 🛟 幽灵仓即时恢复(继承母体基因·2026-B): 账本说有仓但真实(Gate/外挂在器)已无 → 该仓已被外部手平/紧急平
        #   = 若当"实盘网关为判据"运行时(由驱动传 external_flat=True)立即清幽灵、记恢复轨迹、回干净空仓继续
        #   (防: 引擎误当"尚在持仓"继续管一个不存在的仓: 误判盈亏/错触发却平不到/空仓却不开新)
        if external_flat:
            st.setdefault('trades',[]).append({'coin':pos['coin'],'side':pos['side'],
                'entry':round(pos.get('entry',0),4),'exit':0.0,'pnl':0.0,'pnl_pct':0.0,'why':'manual_rec_ghost',
                'note':'手工平仓即时恢复: 账本有仓但网关已空 → 清幽灵, 现金已在网关'})
            # 不在账本落地盈亏(外部已收, 盈亏只在网关), 只记恢复轨迹
            log(f"🛟 手工平仓即时恢复: 账本有{pos['coin']} {pos['side']}但网关已空 → 清幽灵仓, 回干净空仓继续")
            st['pos']=None; return 'ghost_cleared'
        # ── 持仓管理: 择强节点持某币某向, 用金蟾/貔貅躯体管退出 ──
        sig = now_sig or _coin_sig(pos['coin'])
        if not sig: return 'net_err'
        pr = now_price or sig.get('pr') or _price(pos['coin'])
        if not pr: return 'net_err'
        ppct = (pr-pos['entry'])/pos['entry'] if pos['side']=='long' else (pos['entry']-pr)/pos['entry']
        pnl_usd = ppct*pos['notional']
        peak_pct = max(pos.get('peak_pct',0), ppct)
        pos['peak_pct']=peak_pct; pos['peak']=pos['notional']*peak_pct
        # 硬止损(2.5%)最优先护本金
        if ppct <= -SL:
            return _finish(st,pos,pr,ppct,pnl_usd,'硬止损',sig)
        # 🎯🆕2026-09-12 方A1·开仓后方向自检(老板"择向精准度直接关联最终胜率"):
        #   病: 开仓后方向错(逆势/信号矛盾)时, 旧逻辑要等到浅浅亏(-0.25%)或早断线才反应 → 已损一节.
        #   药: 开仓后头 DIRCHK_WINDOW 秒内(刚开), 若"信号自证伪"(certify高=信号矛盾/背离 + 近端反向 + 逆大势) → 极速自检砍(承认选错, 不硬扛).
        #   只动"刚开仓窗", 不影响已持仓的靠鳄鱼/麒麟正常管. ⚫2026-09-15 A: 已封存(DIRCHK_LEGACY) → 移除死代码.
        # ── 融入貔貅抬地板/递增阶梯 + 大义闸 + 一键换向 (更细的肉) ──
        wk,wkty=_weak_signal(pos,sig)
        pt=pos['peak_pct']; pp=ppct; m,pw=_trend_strength(pos,sig)
        tp=sig.get('tp'); gck=sig.get('gck'); t4=sig.get('t4',0) or 0
        last15=sig.get('last15',0) or 0
        # 🐍 早断(腾蛇断尾·铁律'小亏早走/防连亏同刀砍'在退出侧实证补): 水下尚小(>-2.5%未满损)
        #   但近端已真证伪转反(MACD对向死叉或15m反向+末根反向) → 不等满止损, 先小亏 -EARLY_CUT_ON 断早走.
        #   只断"近端确已反方", 健康回踩/持平/水下未证伪 一律不杀(保貔貅大肉不受误伤).
        #   2026-09-09 11:52 老板"全杀"A(病毒清理): 早断分两腿——
        #     腿1(gck+tp 对向, 1H-MACD确认)= 慢可信信号, 反向即断(保留原快速真反转保护, 不砍++921真早断);
        #     腿2(仅 tp+last15 无gck, 纯15m快腿)= 实盘30s读未收bar噪声主源(~14%d期误读, 真实1m实证) →
        #       需**连续2周期同向**才准断(pos['_fl2']/_fs2计数), 单根噪声颤不再独自触发误断.
        #       不重带不饿死: 仅这一快腿加计数, 腿1不动;
        #       _finish会清pos, 故计数随仓自然重归(不存在跨仓脏计数).
        flock_g=(pos['side']=='long'  and gck=='death' and tp=='DOWN')
        flock_l=(pos['side']=='long'  and tp=='DOWN' and last15<-0.1)
        flock = flock_g or (flock_l and pos.get('_fl2',0)>=1)   # 快腿需连2; gck腿即时
        if flock_l: pos['_fl2']=pos.get('_fl2',0)+1
        else:       pos['_fl2']=0
        sfk_g=(pos['side']=='short' and gck=='golden' and tp=='UP')
        sfk_l=(pos['side']=='short' and tp=='UP' and last15>0.1)
        sfk = sfk_g or (sfk_l and pos.get('_fs2',0)>=1)
        if sfk_l: pos['_fs2']=pos.get('_fs2',0)+1
        else:     pos['_fs2']=0
        # 🐍🆕早断·深水急冲腿(2026-09-10 老板“下猛药治慢断”·自适应治疗):
        #   病案: 早断线在-0.6%, 但实测多笔在-1.2~-1.58%才断(等MACD/15m死叉确认出来, 价已滑近硬止损2.5%) → “早断”沦为“慢断”,
        #   均亏-567极高. 药: 仓位已滑到较深水(≤-0.9%)且该币近端单根对持仓急冲(≥0.5%)→ 属近端已真转坏,
        #   不再等均线确认(等出来就晚了)→ 立即小亏早走, 把“-567慢断”压向“-200~300”. 只对“先跌后急冲”双条件(避浅水噪声误断).
        deep_long  = (pos['side']=='long'  and ppct<=-DEEPWATER_CUT_PCT and last15<=-0.5)   # 🔌20260923 接线
        deep_short = (pos['side']=='short' and ppct<=-DEEPWATER_CUT_PCT and last15>=0.5)   # 🔌20260923 接线
        # 🆕2026-09-11 P3·慢阴保护(治"SOL两笔扛-6.5%"): 已深水(≤-1.5%)且近3根持续缓反向 → 不等急证伪, 小亏走
        if SLOW_BLEED_ON and ppct<=SLOW_BLEED_DEPTH:
            _c15=_candles(pos['coin'],'15m',6)
            if _c15 and len(_c15)>=4:
                _last3=_c15[-3:]
                if pos['side']=='long':
                    _nfade=sum(1 for i in range(1,len(_last3)) if _last3[i]<_last3[i-1])
                else:
                    _nfade=sum(1 for i in range(1,len(_last3)) if _last3[i]>_last3[i-1])
                if _nfade>=2 and not (flock or sfk):
                    # 🧠🆕2026-09-12 智能分辨(老板"同向行情给宽幅空间·增强智能识别"):
                    #   深水+缓反向时先辨"健康回踩"vs"真反转"; 健康回踩→给宽幅(不砍), 真反转→砍.
                    _verdict, _vreason = _smart_bleed(pos, sig) if SMART_BLEED_ON else ('real','(药关)')
                    if _verdict=='retrace':
                        log(f"🫁 智能阴跌辨认: {pos['coin']} {pos['side']} 深水{ppct*100:+.2f}%但{_vreason} → 健康回踩·给宽幅空间不砍")
                    else:
                        log(f"🐌 慢阴保护: {pos['coin']} {pos['side']} 已深水{ppct*100:+.2f}% 近3根缓反向{_nfade}/2 {_vreason} → 真反转·小亏走(治扛单)")
                        return _finish(st,pos,pr,ppct,pnl_usd,f'慢阴保护(深水{ppct*100:.2f}%+缓反向{_nfade}/2·{_vreason})',sig)
        # 🐉🆕 证伪确诊反向 (2026-09-10 老板令·赋予系统“证伪确诊反向”: 发现方向错→广播警报→烛龙令腾蛇执行→于最早区间扭亏为盈)
        # 🦄🆕 麒麟摆尾(2026-09-12 07:1x 老板令"以后不要有麒麟摆尾这个名,统一'麒麟摆尾',麒麟兽天生神通"):
        #   收权归麒麟: 原散落的"证伪确诊反向/智能麒麟摆尾/保卫科麒麟摆尾/区间顶底麒麟摆尾"四门 → 融合为麒麟一盘"摆尾"统一决策.
        #   麒麟摆尾 = 镇守/守护/兜底 (守之职·唯一执刃者), 一刀判"该摆不摆" → 该摆则反手扭亏, 不该摆则按兵不动.
        _why=''  # 🩹2026-09-17 22:12 心跳自愈修: 原缺默认值→下方早断分支用 _why 时 NameError(21:39-21:42 dss/lbh/zls 连续异常·整轮cycle中断)
        _qt=_qilin_baiwei(pos, sig, st, ppct, pt, gck, tp, t4, last15, flock, sfk, deep_long, deep_short)
        if _qt:
            _act, _nw, _why = _qt[0], _qt[1], _qt[2]
            if _act=='flip':
                return _flip(st,pos,pr,ppct,pnl_usd,_why,sig,_nw)
            elif _act=='cut':
                return _finish(st,pos,pr,ppct,pnl_usd,_why,sig)
        # 🐍🆕💊C 早断·certify分流(2026-09-11 20:5x 老板选C·保留为麒麟摆尾之外的低危抰住腿):
        #   麒麟摆尾已覆盖"高危→反手/认小亏"; 此处只留"certify低=假证伪→抰住不砍".
        # 🧭🆕2026-09-17 P1(白泽复盘): 早断前先看大周期大势是否仍顺持仓向 → 顺则豁免(近端反弹不改趋势)
        _bigtrend_hold = False
        if BIG_TREND_EXEMPT_ON and ppct<=EARLY_CUT_ON:
            try:
                _t4lv = float(sig.get('t4l',0) or 0)
                _bigtrend_hold = (not (deep_long or deep_short)) and (
                    (pos['side']=='long'  and _t4lv>= BIG_TREND_EXEMPT) or
                    (pos['side']=='short' and _t4lv<=-BIG_TREND_EXEMPT))
                if _bigtrend_hold and not pos.get('_bt_log'):
                    pos['_bt_log']=1   # 每笔仓只报一次(防日志刷屏)
                    log(f"🧭 早断·大周期豁免: {pos['coin']} {pos['side']} 水下{ppct*100:+.2f}% 但大势t4l={_t4lv:+.2f}%仍顺持仓向 → 掰住不砍(等趋势)")
            except Exception:
                _bigtrend_hold = False
        if ppct<=EARLY_CUT_ON and (flock or sfk or deep_long or deep_short) and not _bigtrend_hold:
            if EARLY_CERTIFY_SPLIT and not deep_long and not deep_short:
                _certC=sig.get('certify',0) if CERTIFY_SENSE_ON else 0
                _nerveC=_nerve_read(pos['coin']) if FEEDBACK_ON else 0.0
                if _nerveC>_certC: _certC=_nerveC
                if _certC<0.5:
                    log(f"⏳ 早断分流·低危(certify{_certC}<0.5疑假证伪/噪声) → {pos['coin']} 抰住不砍(等真证伪)")
                    return 'hold_lowcert'
            _why='早断·近端证伪早走' if (flock or sfk) else '早断·深水急冲(治慢断·不等确认早走)'
            return _finish(st,pos,pr,ppct,pnl_usd,f'{_why}(水下{ppct*100:.2f}%/{gck}+{tp}/未等满损)',sig)
        # 🚨单币快崩守护(护栏·行情侧·老板23:48归位): 持仓币自己近端单根对持仓惨冲(非大盘联动才叫单币快崩)→ 应急信号,
        #   不等满损/不等辨向证伪, 小亏早护走—— 专兜那类'被单币拉起/自己崩'到-2.5%硬止损的单(ADA空被拉飞/LINK多自己崩).
        #   只对[已小幅水下(<=-0.3%) 且 单币近端一根对持仓爆冲>=1.1%]触发; 健康的浅回踩/水上波动不误杀.
        crash_long  = (pos['side']=='long'  and ppct<=FAST_CRASH_ON and (last15<=-FAST_CRASH_BAR))
        crash_short = (pos['side']=='short' and ppct<=FAST_CRASH_ON and (last15>=FAST_CRASH_BAR))
        if crash_long or crash_short:
            _cc=pos['coin']
            return _finish(st,pos,pr,ppct,pnl_usd,f'单币快崩应急护(水下{ppct*100:.2f}%/{_cc}近端|{last15:+.2f}%|惨冲→不等满损早走·护本金)',sig)
        # 0) 一键换向(已归入🦄麒麟摆尾·⓪获利转向): 此处不再单独处理(防两处重复)
        # 🐸金蟾·区间小肉(含大义闸识大体 + 微势衰减咬): 只对"未达貔貅大肉带"的区间利负责
        # 💊🆕2026-09-12 老板令"金蟾首档0.6%-1.6%": 金蟾负责 0.6%~1.6% 带(峰<1.6%=未到大肉带); 峰≥1.6%→貔貅接手.
        #   (旧: 峰<1.0%就交貔貅→0.6~1.6%带无人管; 现统一为峰<BIG_MEAT_PCT=1.6% 金蟾管)
        # 💊🆕2026-09-12 自查纠错(老板"做事不仔细"): 旧代码只在 pp≥tier[0] 咬 → 5档阶梯形同虚设(tier只初始化不递增).
        #   真阶梯: 金蟾按"当前已到档位"逐步抬升——峰刚过0.6%咬0.6档价; 峰上到0.85%→锁位抬到0.85档(不吐回); 逐级向上.
        #   这样"阶梯"才真起到"只赚不吐·逐步爬高"的作用(而非一刀0.6%剪).
        _jch_cap = max(BIG_MEAT_PCT, JCH_TIER_PCT[-1]) if FLEX_ON else 0.010   # 金蟾上界=大肉带与顶档取大(1.6%·避免顶档被截)
        # 🥇🆕2026-09-15 自适应吞金(老板令): 首档随"大势+趋势度"活——强趋势抬首档(让肉跑)·震荡弱降首档(快咬落袋).
        #   阶梯整体随首档平移(相对间距不变), 保持"只赚不吐·逐级抬升"的阶梯义.
        _tiers = JCH_TIER_PCT
        if JCH_ADAPT_ON:
            _strong = ((pos['side']=='long' and t4>=JCH_ADAPT_T4) or (pos['side']=='short' and t4<=-JCH_ADAPT_T4))
            _wk_tsig = _weak_signal(pos, sig)[0]
            if _strong and pw>=JCH_ADAPT_PW:
                _first = JCH_ADAPT_HI        # 强趋势 → 抬首档0.55(让肉跑)
            elif (not _strong) and _wk_tsig:
                _first = JCH_ADAPT_LO        # 震荡弱+近端转弱 → 降首档0.40(快咬)
            else:
                _first = JCH_FIRST_PCT       # 常态0.45
            _delta = _first - JCH_TIER_PCT[0]
            _tiers = tuple(max(0.0015, round(x+_delta,4)) for x in JCH_TIER_PCT)
        # 🐸 计算当前已到档位(按峰值 pt 定): 峰≥档位值 → 该档已达成
        _cur_tier = 0
        for _i, _tv in enumerate(_tiers):
            if pt >= _tv:
                _cur_tier = _i + 1
        pos['tier'] = max(int(pos.get('tier', 0) or 0), _cur_tier)   # 档位只升不降(已锁定)
        # 阶梯锁位: 已达某档 → 锁该档价位(回落跌破即锁走·只赚不吐); 未达首档→按首档
        _jch_lock = _tiers[_cur_tier - 1] if _cur_tier > 0 else _tiers[0]
        pos['_jch_first'] = _tiers[0]   # 供日志/面板显化
        if pp>0 and pp>=_tiers[0] and pt< BIG_MEAT_PCT*2 and pt<_jch_cap:
            _dayi = (pos['side']=='long' and t4>=DAYI_T4) or (pos['side']=='short' and t4<=-DAYI_T4)
            # 💊🆕2026-09-12 方A1: 大义闸放宽(让赢单多跑)——大势稍旺(≥DAYI_T4_LOOSE)且趋势不弱 → 也让位貔貅.
            _dayi_loose = (pos['side']=='long' and t4>=DAYI_T4_LOOSE) or (pos['side']=='short' and t4<=-DAYI_T4_LOOSE)
            # 大义闸(不剪顺大势winner): 大势仍旺顺持仓向 & 趋势度真强(pw>=1.0 顺势) → 让貔貅/阶梯接力吃整羊,
            #   即今日回放抓到的"金蟾见强趋势一根15m回落就咬走小winner→付双费重开更贵"的病(该让勿乱让)
            #   咬的两个正当理由: 大势不在(弱市区间咬小利) 或 (大势在但趋势度不强(<1.0)且近端真转弱→伪突破小咬)
            if (_dayi and pw>=1.0) or (_dayi and not wk) or (FLEX_ON and _dayi_loose and pw>=0.5):
                pass  # 让位貔貅 顺大势 / 未真弱 / (方A1)大势稍旺且趋势不弱: 不截
            elif FLEX_ON:
                # 💊真阶梯: 峰已爬到某档(峰≥该档)后, 回落到该档锁位以下→按该档锁走(只赚不吐·逐级抬).
                if pp <= _jch_lock and _cur_tier > 0:
                    return _finish(st,pos,pr,pp,pnl_usd,f'金蟾阶梯锁(到{_jch_lock*100:.2f}%档·回吐至{pp*100:.2f}%·峰{pt*100:.2f}%·{('近端'+wkty if wk else '弱市')})',sig)
            else:
                return _finish(st,pos,pr,pp,pnl_usd,f'金蟾咬区间小利(带{pw:+.2f}/{('近端'+wkty if wk else '弱市')}/峰{pt*100:.2f}%)',sig)
        # 🦁貔貅·抬地板/递增阶梯锁定(旧母体核心 只在这档启动: 峰值已真爬到>1.6%利锁地板才锁, 0.7~1.6%young利不剪)
        #   语义: TRAIL_LEG_FLOOR=1.6% 是锁位只在峰值真上到≥1.6%后才参与的一级地板(回吐跌破即保该级);
        #   1.6%以下小利归金蟾区间(吃或让貔貅), 貔貅不在此截young利。
        # 🦁🆕 貔貅·自适应回撤锁(2026-09-11 老板令"自适应最优·确保正向把钱收进肚子·滴水不漏"):
        #   病: 旧"递增阶梯"(step1%/1.5%/2%)在峰1.6~2.7%段锁位全卡1.6%不动(漏0.4~1.1%), 且峰<1.6%根本不锁(裸奔).
        #   药: 锁位**紧跟峰**(锁=峰-允许回吐), 允许回吐随(趋势度×涨速)自适应, 上下限夹紧(0.2%~0.8%)→ 滴水不漏.
        #   自适应: 强顺势(pw高/缓涨)给稍宽(防噪声甩下车); 逆势/急涨给紧(快锁防插针吐肉). GIVE_BACK_FRAC 由此复活.
        _LOCK_START = LOCK_START_PCT   # 🔌20260923 接线(默认0.010=旧值)
        if pt>=_LOCK_START and pp>0:
            _fr = 0.35 if pw>=1.30 else (0.30 if pw>=0.9 else 0.25)   # 越顺势越给宽
            _pace_rc,_pc = _rise_pace(sig,pos['side'])
            if _pc=='alert':  _fr=0.25
            if _pc=='buffer': _fr=0.40
            _give = max(GIVE_FLOOR_PCT, min(pt*_fr, GIVE_CAP_PCT))   # 🔌20260923 接线(默认0.20%~0.80%=旧值)
            _lock = max(0.0, pt-_give)
            if pp<=_lock:
                return _finish(st,pos,pr,pp,pnl_usd,f'貔貅自适应回撤锁(锁{_lock*100:.2f}%·峰{pt*100:.2f}%·让吐{_give*100:.2f}%·{_pc})',sig)
        # 🦁→🐸 盈利回落·退返金蟾肚(块2滴水不漏·老板图纸): 曾养出貔貅大肉(big_meat)后自峰值大回吐,
        #   且近端已真转弱(不愿再往大肉续跑)→ 不再让肉滑剩到$10/无兜, 立刻把这只大肉单退返金蟾肚子,
        #   金蟾按当前仍在正盈利的档位逐档兑住(最大退返$100带内, 最小$20/0.3%档不死漏).
        #   🐉烛龙大趋势闸(老板23:13精化·防误伤极强趋势单): 先问"这是真大趋势的回踩、还是无趋势回吐":
        #     短回踩但烛龙仍判持仓向强趋势仍在(强顺势量能/高位微势同向/近端未反方)→ 不兑付, 放赊貁续跑吃大肉;
        #     仅当烛龙也判趋势真断(此处近端真转弱 wk) + 回踩已深到金蟾带才由金蟾肚兑付滴滤守住.
        #     净效果: 纯回吐仍滴水不漏; 少数极强趋势单不再被腰在边缘提前止盈.
        if pos.get('big_meat') and wk and 0<pp<=BIG_MEAT_PCT*3.33 and pt>=BIG_MEAT_PCT:
            # 蜡烛·仍强趋势闸: 回踩淺但烛龙判持仓向强趋势仍续(pw高顺势 / 高位微势同向) → 不兑, 让赊貁续跑
            still_up = (pos['side']=='long'  and (pw>=0.9 or t4>=DAYI_T4*0.3) and tp!='DOWN')
            still_dn = (pos['side']=='short' and (pw<=-0.9 or t4<=-DAYI_T4*0.3) and tp!='UP')
            if (still_up or still_dn) and pp>=BIG_MEAT_PCT:   # 仍强趋势且只回踩到还保大肉带→不兑付让跑
                pass  # 🐉烛龙闸: 不动(本轮续让赊貅吃, 防强趋势单被提前止盈)
            else:
                if pp>=JCH_TIER_PCT[0]:
                    return _finish(st,pos,pr,pp,pnl_usd,f'金蟾肚·大肉回落退返兑付(峰{pt*100:.2f}%→现{pp*100:.2f}%, 没让肉漏剩无兜)',sig)
        # 🦁貔貅·目标止盈终点收割(双链终局)
        # 🎯🆕2026-09-12 方A1: 改用共享 _target_pct_from_pw(门户与引擎同口径)
        _tg,_tmult=_target_pct_from_pw(pw)
        if pp>=_tg:
            return _finish(st,pos,pr,pp,pnl_usd,f'貔貅目标盈禾·终点收割({pp*100:.2f}%≥{_tg*100:.2f}%·倍率{_tmult})',sig)
        # 🦁貔貅·确无发展收官(曾达大肉带被拖回且近端转弱→不裸赌续肉)
        if pos.get('big_meat') and wk and pp<=BIG_MEAT_PCT:
            return _finish(st,pos,pr,pp,pnl_usd,'貔貅大肉无发展收官',sig)
        # 大肉带判定(供下轮":让跑): 曾↑史≥BIG_MEAT
        if pt>=BIG_MEAT_PCT: pos['big_meat']=True
        return 'hold'
    # ── 空仓择强(多币自切换: 关一单→重选最强) ──
    cooldown=st.get('cooldown',0)
    if cooldown>0:
        st['cooldown']=cooldown-1; return 'cooldown'
    # 🛡护栏闸(先拦: 连亏冷却/日亏熔断/日止损超限/黑天鹅; 硬护栏优先于择强)
    # 🔧 2026-09-10 修复: 跨日复位(此前 _roll_guard 定义了却从未调用→日锁跨天不消·护栏窗口卡死) → 每日自愈
    _roll_guard(st, _time.strftime('%Y-%m-%d'))
    gb=_guard_block(st, macro=None, pick=None)
    if gb:
        log(f"🛡 {gb} → 空仓休(护栏优先, 不下单)"); return 'blocked_guard'
    pick=_pick()
    if pick:
        hm=_halfmountain_block(pick)
        if hm:
            log(f"🚦 {hm} → 空仓守(宁缺毋滥)"); return 'blocked_halfmountain'
        _qb=_quality_block(pick)
        if _qb:
            log(f"💤 {_qb}"); return 'blocked_quality'
        ex=_exhaust_rechase_block(pick)
        if ex:
            log(f"🚦 {ex} → 高位衰竭守(非真破位不追)"); return 'blocked_exhaust'
        # 🛡护栏·闪崩闸(选定币近端单根爆幅→不追插针)
        gb2=_guard_block(st, macro=None, pick=pick)
        if gb2:
            log(f"🛡 {gb2} → 闪崩拒开"); return 'blocked_flash'
        pr=pick.get('pr') or _price(pick['coin'])
        if not pr: return 'net_err'
        # 🔴🆕2026-09-11 开仓前双保险(治“拦了又开”): 快链/母子融合任一判该币伪信号高危(certify≥0.5)→不开.
        #   (即使 _pick 漏过, 此处也兵底; 守住“伪信号绝不开仓”铁律)
        try:
            _ce2=_certify_of(pick) if os.environ.get('DUAL_CHAIN_ON','1')!='0' else 0.0
            _fc2=_fusion_read(pick['coin']) if (os.environ.get('FUSION_ON','1')!='0') else None
            _fcv=float((_fc2 or {}).get('certify',0) or 0)
            if _ce2>=0.5 or _fcv>=0.5:
                # 🛡🆕2026-09-11 21:4x 老板令"放开宁缺毋滥·给麒麟兽兜底"
                # 🔧🆕2026-09-12 06:5x 老板"睡一觉漏光光"纠错·恢复"宁缺毋滥"本意:
                #   病: 全伪信号(无肉)也硬开 → 开了就往麒麟摆尾跑 → 麒麟摆尾沦为"变相止损" → 小亏+手续费累积(隔夜漏-$55.5).
                #   药: "放开宁缺毋滥"仅在**有肉**(该币振幅够·值得博)时生效; 无肉(震荡死水/振幅不足)→真宁缺毋滥空仓.
                #   OPEN_WHEN_ALLHOT=0 整关; 有肉阈值 RANGE_AMP(5%). 无肉=该币近6h振幅< RANGE_AMP.
                _meat=float(pick.get('amp6',0) or 0)   # 该币近6h振幅
                if os.environ.get('OPEN_WHEN_ALLHOT','1') == '0' or _meat < RANGE_AMP:
                    log(f"🛑 开仓前二次校验: {pick['coin']} 伪信号高危(certify{max(_ce2,_fcv)}) 且无肉(振幅{_meat:.1f}%<{RANGE_AMP}%) → 真空仓(守宁缺毋滥)")
                    return 'blocked_certify'
                log(f"🤸 放开宁缺毋滥: {pick['coin']} 伪信号高危但**有肉**(振幅{_meat:.1f}%≥{RANGE_AMP}%) → 仍开(交麒麟兜底: 麒麟摆尾/早断分流)")
        except Exception:
            pass
        # 🌟🆕2026-09-15 09:11 药③(老板令): 麒麟刹车后同币冷却 — 防"刚杀又开"(减同向多频次交易+手续费)
        _cc = st.get('_coin_cool',{}).get(pick['coin'],0)
        if _cc > _time.time():
            _left=(_cc-_time.time())/60.0
            log(f"❄️ 同币冷却: {pick['coin']} 平仓后冷却中(剩{_left:.1f}min) → 不开(治反复开)")
            return 'coin_cooldown'
        _qc=st.get('_qilin_cut',{}).get(pick['coin'],0)
        if QILIN_CUT_COOLDOWN>0 and _qc>_time.time():
            _left=(_qc-_time.time())/60.0
            log(f"❄️ 刹车冷却: {pick['coin']} 麒麟刹车后冷却中(剩{_left:.1f}min) → 不开(防反复)")
            return 'qilin_cooldown'
        # 🌐🆕2026-09-16 事件一·网络自愈「断网冻结开仓」: 三源全不可达→不瞎开(保命)
        if _net_is_down():
            log(f"🌐 网络断线冻结: 行情三源(OKX/Gate/Binance)全不可达 → 拒开仓(保命·不瞎开)")
            return 'blocked_netdown'
        _ok=_open_paper(st,pick,pr)
        # 🛡🆕2026-09-11 修"开仓失败未回滚"(老板令): 开仓返回False(如Gate 400重复/保证金不足)→
        #   绝不当'open'成功, 不写幽灵仓(账本与Gate脱节) → 返回'open_fail'让上游知实情.
        if _ok is False:
            return 'open_fail'
        return 'open'
    log(f"⚾ 空仓休: 方向不够清(|分|<{PICK_ABS_MIN}) 不硬开")
    return 'idle'

def _zhulong_fire_seal(pos, sig, ppct, pt, gck, tp, last15, flock, sfk, _cert):
    """🔥 烛龙火印 — 烛龙中枢终审许可(2026-09-12 老板令"无火中枢印不得擅自行动")
    铁律: 开明(探)+白虎(哨)报证伪军情 → 烛龙终审 → 盖火印 → 麒麟才准摆尾.
    火印条件(三者齐备):
      ①烛龙大势明朗: regime非chop(烛龙已定大势方向)
      ②开明/白虎证伪军情: certify≥ZHULONG_SEAL_CERT 或 白虎近端证伪(flock/sfk)
      ③军情与持仓矛盾: 持仓方向已不被大势支持
    🔧2026-09-12 保健(老板令"给予保健到最优状态"): chop松绑——regime=chop不放一票否决:
      当chop但极强证伪(certify≥ZHULONG_SEAL_STRONG=0.7 或 开明+白虎双证 flock&&sfk) → 仍发印.
      治"该变不变": chop是常态(噪声带), 若chop永不摆尾 → 麒麟形同虚设, 又回病根.
    返回: True(盖印可摆) / False(无印→只守只兜)
    """
    if not ZHULONG_SEAL_ON:
        return True   # 关印→回旧行为(不走火印闸)
    _reg=sig.get('regime')
    # ② 开明/白虎证伪军情齐备
    _have_intel = (_cert>=ZHULONG_SEAL_CERT) or flock or sfk
    if not _have_intel:
        return False
    # ① 烛龙大势明朗(非chop = 中枢已定大势). chop松绑: 极强证伪/双证时仍发印.
    if _reg not in ('up','dn'):
        # 🆕2026-09-13 00:1x 老板令"死水一潭翻个毛线": 死水闸——chop+窄市没肉(振幅<AMP6_MIN) → 不发印.
        #   死水期 certify 易虚高 → 白摆尾(价格回摆) → 机械亏损+双向手续费. 静观其变即可, 除非手工干预.
        if CHOP_FLIP_OFF:
            _amp = sig.get('amp6')
            try:
                _amp = float(_amp) if _amp is not None else None
            except Exception:
                _amp = None
            if _amp is not None and _amp < QUALITY_AMP6_MIN:
                return False   # 死水(窄市没肉) → 不发火印 → 麒麟只守只兜(不白摆尾)
        _strong = (_cert>=ZHULONG_SEAL_STRONG) or (flock and sfk)
        if not _strong:
            return False
        # chop但军情极强 → 放行(需③矛盾性检查用"非混沌"处理: 既无大势支持则视为背离)
    else:
        # ③ 军情与持仓矛盾(大势已不支持现持仓; 若大势仍顺持仓=态一→不发印)
        _reg_supports=(pos['side']=='long' and _reg=='up') or (pos['side']=='short' and _reg=='dn')
        if _reg_supports:
            return False
    # 🔧2026-09-12 降噪: 不在盖印处刷日志(每轮都盖但未必摆→刷屏). 改由消费处(摆尾/刹车)打印.
    return True

def _qilin_baiwei(pos, sig, st, ppct, pt, gck, tp, t4, last15, flock, sfk, deep_long, deep_short):
    """🦄 麒麟摆尾 — 麒麟兽天生神通·统一摆尾决策(2026-09-12 老板令: 取消"麒麟摆尾"名, 四门合一)
    收权: 镇守/守护/兜底 (守之职·唯一执刃者). 一刀判"该摆不摆".
    返回: ('flip',反手向,原因) 或 ('cut',原因) 或 None(按兵不动).
    开关: QILIN_TAIL_ON=0 整关(回旧: 无摆尾).
    融合原四门(按优先级): ①证伪确诊 ②智能及早 ③区间顶底 ④保卫科高感知/证伪
    """
    if not QILIN_TAIL_ON:
        return None
    _reg=sig.get('regime')
    _nw='short' if pos['side']=='long' else 'long'
    _blk=(_nw=='long' and _reg=='dn') or (_nw=='short' and _reg=='up')   # 反手向逆高层大势→不摆
    _reg_still_ok=(pos['side']=='long' and _reg=='up') or (pos['side']=='short' and _reg=='dn')
    _deep=(pos['side']=='long' and last15<=-0.5) or (pos['side']=='short' and last15>=0.5)
    # 🔧2026-09-12 保健(老板令): 深水闸精修——不是所有深水急冲都不摆.
    #   逆大势深水急冲(行情突发·易插针) → 不摆(护本不赌);
    #   但若急冲方向与"高层大势"一致(真反转确认) → 该摆(拿准方向不放过).
    if _deep:
        _rip_dir = 'long' if (pos['side']=='short' and last15>=0.5) else 'short'   # 急冲方向(=反手向)
        _rip_align = (_rip_dir=='long' and _reg=='up') or (_rip_dir=='short' and _reg=='dn')
        if _rip_align:
            _deep = False   # 急冲与大势同向=真反转 → 解锁可摆(不护本放弃)
            log(f"🦄🔥 麒麟摆尾·深水解锁: {pos['coin']} 急冲{last15:+.2f}%与大势{_reg}同向(真反转) → 解锁不护本")
    _already=pos.get('_fandou',0)>0
    # 🚨🆕2026-09-21 老板令「为麒麟加一个紧急行情兜底固定止损闸」(火印 ED-20260921-120)
    #   定位: 最外层硬底 —— 不看把握度/证伪/火印/震荡豁免, 价格触线即认赔(防崩盘与插针穿透)
    #   默认 0=关(旧行为). 建议 -0.02. 优先级高于"震荡豁免"与一切"等确认"逻辑.
    if QILIN_EMERGENCY_STOP < 0 and ppct <= QILIN_EMERGENCY_STOP:
        st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
        return ('cut',None,f'麒麟紧急兜底固定闸({ppct*100:+.2f}%≤{QILIN_EMERGENCY_STOP*100:.2f}%)(护本)')
    # 🪜🆕2026-09-21 07:22 老板令「麒麟下阶梯吞吐+回撤扭转辨识」(默认关·只守只兜)
    if QILIN_LADDER_ON:
        try:
            _lv = _qilin_market_type(pos['coin'], pos['side'], _reg, last15)[1]
            _stage, _sname, _sact, _lk = _qilin_ladder_stage(ppct, _lv)
            if _sact in ('cut', 'hard'):
                log(f"🪜 麒麟下阶梯[{_stage}·{_sname}]: {pos['coin']} {ppct*100:+.2f}% (σ{_lv:.2f}%/缩放×{_lk:.2f}) → 认赔护本")
                st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
                return ('cut',None,f'麒麟下阶梯·{_sname}({ppct*100:+.2f}%·第{_stage}档)')
            if _sact == 'turn':
                _can, _why = _qilin_can_turn(pos['coin'], pos['side'], _reg, last15)
                if _can and not _blk:
                    if QILIN_TURN_FLIP_ON:
                        log(f"🪜 麒麟下阶梯[{_stage}·扭转]: {pos['coin']} {ppct*100:+.2f}% → 辨识[{_why}]可扭转 → 摆尾{_nw}(扭亏·已授权)")
                        return ('flip',_nw,f'麒麟下阶梯·扭转乾坤({_why}·第{_stage}档)')
                    log(f"🪜 麒麟下阶梯[{_stage}·扭转]: {pos['coin']} {ppct*100:+.2f}% → 辨识[{_why}]可扭转 → 暂不认赔(给回抽机会·摆尾待样本授权)")
                    return None
                log(f"🪜 麒麟下阶梯[{_stage}·{_sname}]: {pos['coin']} {ppct*100:+.2f}% → 辨识[{_why}]不可扭转 → 认赔护本")
                st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
                return ('cut',None,f'麒麟下阶梯·{_sname}(不可扭转·第{_stage}档)')
        except Exception as _le:
            log(f"⚠️ 麒麟下阶梯异常(本次跳过·不影响旧逻辑): {str(_le)[:70]}")
    # 已摆过→不再摆二
    _cert=sig.get('certify',0) if CERTIFY_SENSE_ON else 0
    if FEEDBACK_ON:
        _nerve=_nerve_read(pos['coin'])
        if _nerve>_cert: _cert=_nerve
    # 🦄🆕2026-09-14 22:29 老板令"中段震荡豁免": regime=chop(震荡)+非极强证伪 → 麒麟按兵不动(态一).
    # 🌟🆕2026-09-15 09:11 加敏(药④): 豁免用"开明监督融合强度" adms — 开明(flock)+白虎(sfk)+触觉(_nerve)任一强→豁免失效(更灵敏).
    # 🔧2026-09-15 09:27 体检修复: 单flock/sfk原只抦0.5<7门槛=监督未生效 → 改flock/sfk为"确证级"(各搟0.7·命中即豁免失效).
    _adms = _cert
    if QILIN_SENS_ADM:
        _sup = (0.7 if flock else 0.0)
        _sup += (0.7 if sfk else 0.0)
        _sup += 0.3*(_nerve if 'FEEDBACK_ON' in dir() and FEEDBACK_ON else 0.0)
        _adms = max(_cert, _sup, _cert)
    if QILIN_CHOP_EXEMPT and _reg=='chop' and _adms<CHOP_EXEMPT_CERT and not (flock and sfk):
        return None   # 震荡+非极强证伪 → 不干预(随多空自动上下)
    # 🔥 烛龙火印校验(老板铁律: 无火印不得擅自摆尾 → 只守只兜)
    _fire=_zhulong_fire_seal(pos, sig, ppct, pt, gck, tp, last15, flock, sfk, _cert)
    _seal_tag=('🔥印' if _fire else '🚫无印')
    # 🌟🆕2026-09-15 加敏(药②): 自适应收紧刹车线 — chop区(震荡)且certify≥0.5 → 提前到QILIN_TIGHT_LOSS(早收少亏)
    _cut_line = -0.004
    if QILIN_TIGHT_ON and _reg=='chop' and _cert>=0.5:
        _cut_line = max(_cut_line, QILIN_TIGHT_LOSS)   # chop+证伪→收紧(-0.35%> -0.4%·更浅=早收)
    if not _fire:
        # 无火印: 麒麟不得自主摆尾. 但"已摆过/半山腰+伪信号"的刹车(认小亏)仍可(那是守本非摆尾).
        _already0=pos.get('_fandou',0)>0
        _deep0=(pos['side']=='long' and last15<=-0.5) or (pos['side']=='short' and last15>=0.5)
        # 🦄🆕2026-09-15 A+B: 撤权后 → 麒麟不再"有肉时半山腰刹车"(交金蟾貔貅按阶梯管);
        #   只在"深套≥QILIN_LAST_DEFENSE(1.2%)"才做最后兜底(终极保险). 可 QILIN_RETREAT_ON=0 回旧.
        if QILIN_RETREAT_ON:
            if _cert>=0.5 and not _deep0 and ppct<=QILIN_LAST_DEFENSE*QILIN_ADAPT_NEAR:
                _qln,_qty=_qilin_adapt_line(pos['coin'],pos['side'],ppct,last15,_cert,_reg,QILIN_LAST_DEFENSE)
                if ppct<=_qln:
                    log(f"🛡 麒麟自适应兜底({_qty}): {pos['coin']} {ppct*100:+.2f}%≤{_qln*100:.2f}% → 认赔护本")
                    st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
                    return ('cut',None,f'麒麟自适应兜底·{_qty}({ppct*100:+.2f}%≤{_qln*100:.2f}%)(护本)')
            return None   # 有肉/浅亏 → 交金蟾貔貅管(麒麟不插手)
        # 🦄🆕2026-09-16 老板令"半山腰只许反手或扛住, 绝不许止损": 半山腰刹车(割肉)已剥夺.
        #   半山腰(-0.6%~-1.2%) → 扛住不动(等真证伪/等回本); 深套兜底仍保留(守底仓).
        #   可 QILIN_HALFMOUNT_CUT=1 回旧(恢复半山腰刹车).
        if os.environ.get('QILIN_HALFMOUNT_CUT','0') == '1':
            if _cert>=0.5 and ppct<=_cut_line and (_already0 or ppct<FANDOU_MAX_LOSS) and not _deep0:
                _rsn='已摆过(不再摆二)' if _already0 else f'已半山腰({ppct*100:+.2f}%<{_cut_line*100:.2f}%)'
                log(f"🦄🛑 麒麟摆尾刹车(回旧·半山腰): {pos['coin']} {_rsn}")
                st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
                return ('cut',None,f'麒麟摆尾刹车·{_rsn}(护本)')
        return None   # 无火印 → 只守只兜(不动)·半山腰扛住不割
    # ── ⓪ 获利转向摆尾(曾持大肉转弱+MACD反向): 锁肉翻向 ──
    _pw=0.0
    try:
        _m2,_pw=_trend_strength(pos,sig)
    except Exception:
        pass
    if pt>=FLIP_TRAIL_ON and _pw<=FLIP_PACO and not _deep:
        _f_long=(pos['side']=='long' and gck=='death' and tp=='DOWN')
        _f_short=(pos['side']=='short' and gck=='golden' and tp=='UP')
        if _f_long or _f_short:
            log(f"🦄 麒麟摆尾(获利转向): {pos['coin']} {pos['side']} 峰{pt*100:.2f}%转弱(pw{_pw:+.2f}) → 拿肉换{_nw}")
            return ('flip',_nw,f'{_seal_tag}麒麟摆尾·获利转向({gck}+{tp}/峰{pt*100:.2f}%锁肉换向)')
    # ── ① 证伪确诊反向(逆大势+双确认): 最笃, 已承压→摆尾 (深水急冲例外:守本不赌) ──
    if QILIN_CERTAIN_FLIP_ON and not _blk and not _deep and ((pos['side']=='long' and _reg=='dn' and tp=='DOWN' and last15<=-0.1 and ppct<=-0.002) or
                     (pos['side']=='short' and _reg=='up' and tp=='UP' and last15>=0.1 and ppct<=-0.002)):
        log(f"🦄 麒麟摆尾(证伪确诊): {pos['coin']} {pos['side']} 逆高层大势regime={_reg}+近端双确认 → 反手{_nw}(扭亏)")
        return ('flip',_nw,f'{_seal_tag}麒麟摆尾·证伪确诊(逆regime{_reg}/{gck}/{tp}/{last15:+.2f}·最早区间扭亏)')
    # ── ② 智能及早摆尾(certify≥0.5浅亏+未摆过+大势不支): 半山腰前就摆 ──
    # 💊🆕2026-09-12 方A1: 灵敏度增强(浅亏线-0.4%→-0.25%, certify闸0.5→0.45), 让及早真早(半山腰前).
    if QILIN_EARLY_FLIP_ON and _cert>=QILIN_SENS_CERT and QILIN_SENS_LOSS<=ppct<=-0.0015 and not _already and not _reg_still_ok and not _blk and not _deep:
        log(f"🦄 麒麟摆尾(及早·灵敏): {pos['coin']} {pos['side']} 浅亏{ppct*100:+.2f}%+伪信号certify{_cert} → 半山腰前摆尾{_nw}(扭亏)")
        return ('flip',_nw,f'{_seal_tag}麒麟摆尾·及早(浅亏{ppct*100:+.2f}%/certify{_cert}·半山腰前扭亏)')
    # ── ③ 区间顶底摆尾(大幅区间+顶底区+动量衰竭): 上下吃利 ──
    if RANGE_FLIP_ON and not _already:
        try:
            _rc=_candles(pos['coin'],'15m',24)
            if _rc and len(_rc)>=20:
                _rhi=max(_rc); _rlo=min(_rc); _rcur=_rc[-1]
                _ramp=(_rhi-_rlo)/_rlo*100 if _rlo else 0
                _rpos=(_rcur-_rlo)/(_rhi-_rlo)*100 if _rhi>_rlo else 50
                _rmom=(_rc[-1]-_rc[-4])/_rc[-4]*100 if _rc[-4] else 0
                _rexh=abs(_rmom)<RANGE_EXHAUST
                if _ramp>=RANGE_AMP and pos['side']=='long' and _rpos>=RANGE_POS_HI and (_rexh or pt>=BIG_MEAT_PCT*0.5):
                    log(f"🦄🔝 麒麟摆尾(区间顶): {pos['coin']} long 达顶{_rpos:.0f}%(振幅{_ramp:.1f}%)+动量{_rmom:+.2f}%衰竭 → 摆尾空(吃回撤利)")
                    return ('flip','short',f'{_seal_tag}麒麟摆尾·区间顶(顶{_rpos:.0f}%/振幅{_ramp:.1f}%/衰竭{_rmom:+.2f}%)')
                if _ramp>=RANGE_AMP and pos['side']=='short' and _rpos<=RANGE_POS_LO and (_rexh or pt>=BIG_MEAT_PCT*0.5):
                    log(f"🦄🔻 麒麟摆尾(区间底): {pos['coin']} short 达底{_rpos:.0f}%(振幅{_ramp:.1f}%)+动量{_rmom:+.2f}%衰竭 → 摆尾多(吃反弹利)")
                    return ('flip','long',f'{_seal_tag}麒麟摆尾·区间底(底{_rpos:.0f}%/振幅{_ramp:.1f}%/衰竭{_rmom:+.2f}%)')
        except Exception:
            pass
    # ── ④ 保卫科摆尾(近端证伪 flock/sfk + 承压): 只摆非深水急冲(护本不赌) ──
    if QILIN_CERTAIN_FLIP_ON and (flock or sfk) and not _already and not _deep and not _blk:
        if ppct<=-0.004 or _cert>=0.5:
            log(f"🦄 麒麟摆尾(近端证伪): {pos['coin']} {pos['side']} {gck}+{tp}承压{ppct*100:+.2f}% → 摆尾{_nw}(扭亏非止损)")
            return ('flip',_nw,f'{_seal_tag}麒麟摆尾·近端证伪({gck}/{tp}·反手{_nw}扭亏)')
    # ── 刹车: 已摆过/已半山腰 + 确有伪信号 → 认小亏走(不自相残杀) ──
    # 🦄🆕2026-09-15 A+B: 有火印也不"有肉刹车"(交金蟾貔貅); 仅深套≥QILIN_LAST_DEFENSE 兜底.
    if QILIN_RETREAT_ON:
        if _cert>=0.5 and not _deep and ppct<=QILIN_LAST_DEFENSE*QILIN_ADAPT_NEAR:
            _qln2,_qty2=_qilin_adapt_line(pos['coin'],pos['side'],ppct,last15,_cert,_reg,QILIN_LAST_DEFENSE)
            if ppct<=_qln2:
                log(f"🛡 麒麟自适应兜底({_qty2}·持火印): {pos['coin']} {ppct*100:+.2f}%≤{_qln2*100:.2f}% → 认赔护本")
                return ('cut',None,f'麒麟自适应兜底·{_qty2}({ppct*100:+.2f}%)(护本)')
        _cut_skip=True
    else:
        _cut_skip=False
    # 🦄🆕2026-09-16 老板令: 半山腰刹车已剥夺(只许反手/扛住); 深套兜底在上方保留. 可 QILIN_HALFMOUNT_CUT=1 回旧.
    if os.environ.get('QILIN_HALFMOUNT_CUT','0') == '1':
        if (not _cut_skip) and _cert>=0.5 and ppct<=_cut_line and (_already or ppct<FANDOU_MAX_LOSS) and not _deep:
            _rsn='已摆过(不再摆二)' if _already else f'已半山腰({ppct*100:+.2f}%<{_cut_line*100:.2f}%)'
            log(f"🦄🛑 麒麟摆尾刹车(回旧): {pos['coin']} {_rsn}")
            st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
            return ('cut',None,f'麒麟摆尾刹车·{_rsn}(护本)')
    return None

def _flip(st,pos,pr,ppct,pnl_usd,why,sig,nw):
    # 🛡🆕2026-09-12 06:5x 麒麟摆尾真实化钩子(老板"睡一觉漏光光"彻查): 若实盘注入 _FLIP_HOOK → 交给它真反手(真开Gate单);
    #   否则纸面默认(仅改账本). 治"麒麟摆尾在实盘形同虚设(账本反了Gate没动→判外部手平)".
    if _FLIP_HOOK is not None:
        return _FLIP_HOOK(st,pos,pr,ppct,pnl_usd,why,sig,nw)
    st['cooldown']=REOPEN_COOLDOWN
    _close_here(st,pos,pr,ppct,pnl_usd,why)
    # 立即反手开新方向(纸面)
    nsig=dict(sig); nsig['side']=nw
    st['pos']={'coin':pos['coin'],'side':nw,'entry':pr,'notional':pos['notional'],
               'peak':0.0,'peak_pct':0.0,'floor_pct':0.0,'size_ct':pos.get('size_ct',0),
               'big_meat':False,'tier':0,'open_ts':_time.time(),
               '_fandou':pos.get('_fandou',0)+1,   # 🤸🆕麒麟摆尾计数+1(翻过来的孪生仓: 已翻过1次→不再翻二)
               '_ctx':{'score':sig.get('score'),'regime':sig.get('regime'),'t4':sig.get('t4'),
                       't4l':sig.get('t4l'),'gck':sig.get('gck'),'tp':sig.get('tp'),
                       'last15':sig.get('last15'),'regime_at_open':sig.get('regime'),'flipped_from':pos['side']}}
    log(f"☯️ 一键换向: {pos['coin']} {pos['side']}→{nw} 拿肉{pnl_usd:+.2f}$后反手(麒麟摆尾第{pos.get('_fandou',0)+1}次·已锁定不再翻)")
    return 'flip'

def _finish(st,pos,pr,ppct,pnl_usd,why,sig):
    st['cooldown']=REOPEN_COOLDOWN
    # 🩸🆕2026-09-16 老板令"同币连续开仓·亏损再开又开止住": 任何平仓都设"同币冷却"
    try:
        _cc = int(os.environ.get('COIN_REOPEN_COOLDOWN','60'))
        if _cc > 0:
            st.setdefault('_coin_cool',{})[pos['coin']] = _time.time() + _cc*CYCLE_SLEEP
    except Exception:
        pass
    _close_here(st,pos,pr,ppct,pnl_usd,why)
    return 'close'

def main():
    log("☯️ 多币母体·进化2 [SIM模拟修行·绝不下真实单] | 三币择强×金蟾貔貅阶梯 | PAPER")
    st=load()
    log(f"  已实现{st.get('realized',0):+.2f}$ | 持仓: {st.get('pos')}")
    while True:
        try:
            cycle_once(st); save(st)
        except Exception as e:
            log(f"⚠️ 轮异常: {str(e)[:100]}")
        # 🛡🆕2026-09-11 20:1x 提速(漏点4·救命速度): 持仓时用"快巡"短隔(持仓管理只需1币),
        #   方向不对→快速麒麟摆尾=扭亏重中之重; 空仓时用常规隔(需扫全池择强·慢).
        #   FAST_HOLD_SLEEP 可由 env 调; =0 则关提速(回常规).
        _fast = int(os.environ.get('FAST_HOLD_SLEEP','8'))
        time.sleep(_fast if (st.get('pos') and _fast>0) else CYCLE_SLEEP)

if __name__=='__main__':
    main()
