# -*- coding: utf-8 -*-
"""🛡 隔离防护墙 (2026-09-12 老板令"必须完成·预防相互影响")
五实体(母体5k/实盘/ZH1/ZH2/ZXY)相互隔离的公共守卫:
  ① 实例锁  — 每实体独立锁, 防双开(撞单/孤儿仓)
  ② 账本白名单 — 只允许写自己的账本(state file), 防串账
  ③ 启动自检 — 锁+账本+身份三者一致才放行

用法(在每实体runner启动时):
    import _隔离防护墙 as wall
    wall.install(entity='sub_dss', state_file=E.STATE_FILE, lock='._sub_dss.lock')
"""
import os, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))

# 六实体白名单: entity → 合法账本(只允许这一个) [zh2→lbh改名 2026-09-15]
_ENTITY_STATE = {
    'mother_5k':  'data_v2/mtsim/_jinhua2_sim_state_5k.json',
    'live':       'data_v2/mtsim/_jinhua2_livelive_test100_state.json',
    'sub_dss':    'data_v2/mtsim/sub/_sub_dss_state.json',
    'sub_lbh':    'data_v2/mtsim/sub/_sub_lbh_state.json',
    'sub_zxy':    'data_v2/mtsim/sub/_sub_zxy_state.json',
    'sub_zls':    'data_v2/mtsim/sub/_sub_zls_state.json',
}
_ENTITY_LOCK = {
    'mother_5k':  '._mother_5k.lock',
    'live':       '._mother_paper_mid.lock',
    'sub_dss':    '._sub_dss.lock',
    'sub_lbh':    '._sub_lbh.lock',
    'sub_zxy':    '._sub_zxy.lock',
    'sub_zls':    '._sub_zls.lock',
}


def _pid_alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def acquire_lock(entity, lock=None):
    """获取实例锁; 已有活实例→False(拒双开). 返回锁路径 or None.
    鲁棒性: ①自己重入不拦(同PID) ②死PID→清陈旧锁 ③写后回读验真.
    🔒2026-09-21 18:4x 老板令「给予整编干净」锁名归一: 一实体一锁 ——
      优先级: 显式 lock 参数 → _ENTITY_LOCK 名单 → 环境 GATELOCK → 兵底 ._iso_<entity>.lock
      (旧病: 名单外实体一律另建 ._iso_*锁 → 与守护/GATELOCK 撞成双锁)"""
    lock = (lock or _ENTITY_LOCK.get(entity) or os.environ.get('GATELOCK')
            or f'._iso_{entity}.lock')
    if not os.path.isabs(lock):
        lock = os.path.join(HERE, lock)
    if os.path.exists(lock):
        try:
            old = int(open(lock).read().strip())
            if old == os.getpid():
                return lock  # 同进程重入
            if _pid_alive(old):
                print(f'❌ [隔离墙] {entity} 已有实例PID{old}在跑 → 退出(防双开)', flush=True)
                return None
            # 死PID → 清陈旧锁
            print(f'🧹 [隔离墙] {entity} 陈旧锁PID{old}(已死) → 清除重取', flush=True)
            os.remove(lock)
        except Exception:
            pass
    try:
        open(lock, 'w').write(str(os.getpid()))
        # 回读验真
        back = int(open(lock).read().strip())
        if back != os.getpid():
            print(f'⚠️ [隔离墙] {entity} 锁写后回读不符({back}!={os.getpid()}) → 拒', flush=True)
            return None
        return lock
    except Exception as e:
        print(f'⚠️ [隔离墙] {entity} 取锁失败: {e}', flush=True)
        return None


def check_state_whitelist(entity, state_file):
    """自检: 该实体只能写自己白名单内的账本, 否则拒跑(防串账)."""
    allowed = _ENTITY_STATE.get(entity)
    if not allowed:
        print(f'⚠️ [隔离墙] 未知实体 {entity}, 跳过账本白名单校验', flush=True)
        return True
    want = os.path.abspath(os.path.join(HERE, allowed))
    got = os.path.abspath(state_file)
    if want != got:
        print(f'❌ [隔离墙] {entity} 账本越界! 期望={allowed} 实得={got} → 拒跑', flush=True)
        return False
    return True


def install(entity, state_file=None, lock=None):
    """一键装墙: 取锁 + 账本白名单校验. 返回 True=放行."""
    ok = True
    if state_file is not None:
        if not check_state_whitelist(entity, state_file):
            ok = False
    lk = acquire_lock(entity, lock)
    if lk is None:
        ok = False
    if ok:
        print(f'🛡 [隔离墙] {entity} 就位(锁={os.path.basename(lk)} 账本={_ENTITY_STATE.get(entity, "(自由)")})', flush=True)
    return ok
