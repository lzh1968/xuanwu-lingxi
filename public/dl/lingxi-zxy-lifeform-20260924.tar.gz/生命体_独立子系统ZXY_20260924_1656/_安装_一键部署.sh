#!/data/data/com.termux/files/usr/bin/bash
# 🐢 玄武灵犀 · 生命体独立子系统 —— 一键部署 (在**新机**上运行)
# 用法:  bash _安装_一键部署.sh [--dir 目标目录] [--名 zxy] [--起] [--带自巡]
#   默认只"校验+就位"(不启动·安全); --起 = 就位后拉起引擎; --带自巡 = 引擎 + 常驻自巡守护(推荐)
#   默认目标: $HOME/.openclaw/workspace/skills/sniper-engine  (与本源同款布局; 可用 --dir 改)
set -u
SRC="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEST="$HOME/.openclaw/workspace/skills/sniper-engine"
NODE="zxy"; DO_START=0; DO_GUARD=0
while [ $# -gt 0 ]; do
  case "$1" in
    --dir) DEST="$2"; shift 2;;
    --名|--node) NODE="$2"; shift 2;;
    --起) DO_START=1; shift;;
    --带自巡) DO_START=1; DO_GUARD=1; shift;;
    *) shift;;
  esac
done
echo "🐢 生命体·独立子系统 一键部署"
echo "  源: $SRC"
echo "  目标: $DEST"
echo "──────────────────────────────"
echo "▸ ① 环境自检"
command -v python3 >/dev/null 2>&1 || { echo "  ❌ 未找到 python3 —— 请先装好 Termux 环境(同款 NextFlowOSAi)"; exit 1; }
python3 -c "import sys,json,urllib.request,hashlib;print('  ✅ python3', sys.version.split()[0], '基础库齐全')"
echo "▸ ② 清单校验"
if [ -f "$SRC/清单.md5" ]; then (cd "$SRC" && md5sum -c 清单.md5 --quiet) && echo "  ✅ 清单校验通过" || echo "  ⚠️ 清单有出入(继续, 请人工看一眼)"; fi
echo "▸ ③ 就位文件"
mkdir -p "$DEST/子引擎/data_v2/mtsim" "$DEST/data_v2/mtsim/sub" "$DEST/data_v2/logs"
for f in _子引擎.py _隔离防护墙.py _自巡_独立子系统.sh; do
  [ -f "$SRC/$f" ] && cp -f "$SRC/$f" "$DEST/" && echo "   + $f"
done
[ -f "$SRC/子引擎/_内核_zxy.py" ] && cp -f "$SRC/子引擎/_内核_zxy.py" "$DEST/子引擎/" && echo "   + 子引擎/_内核_zxy.py"
for f in _life_train_data.json _雷达情报.json; do
  [ -f "$SRC/子引擎/data_v2/mtsim/$f" ] && cp -f "$SRC/子引擎/data_v2/mtsim/$f" "$DEST/子引擎/data_v2/mtsim/" && echo "   + 子引擎/data_v2/mtsim/$f"
done
if [ ! -f "$DEST/data_v2/mtsim/sub/_sub_${NODE}_state.json" ]; then
  cp -f "$SRC/data_v2/mtsim/sub/_sub_zxy_state.json" "$DEST/data_v2/mtsim/sub/_sub_${NODE}_state.json" && echo "   + 空账本(起始 \$5000) _sub_${NODE}_state.json"
else
  echo "   · 已有账本, 保留不动(不覆盖历史)"
fi
chmod +x "$DEST/_自巡_独立子系统.sh"
echo "▸ ④ 试跑自检(10 秒)"
( cd "$DEST" && timeout 10 python3 -u _子引擎.py "$NODE" --mode paper > "data_v2/logs/_试跑.log" 2>&1 ) || true
if grep -q "空仓休\|开仓\|扫描\|轮" "data_v2/logs/_试跑.log" 2>/dev/null || [ -s "$DEST/data_v2/logs/_试跑.log" ]; then
  echo "  ✅ 引擎可跑(样例输出下行)"
  tail -2 "$DEST/data_v2/logs/_试跑.log" | sed 's/^/     /'
else
  echo "  ⚠️ 试跑无输出 —— 请看 $DEST/data_v2/logs/_试跑.log"
fi
if [ "$DO_START" = "1" ]; then
  echo "▸ ⑤ 启动"
  ( cd "$DEST" && setsid nohup python3 -u _子引擎.py "$NODE" --mode paper >> "data_v2/logs/sub_${NODE}_paper.log" 2>&1 < /dev/null & )
  echo "   ✅ 引擎已起(模拟档·$NODE)"
  if [ "$DO_GUARD" = "1" ]; then
    ( cd "$DEST" && LINGXI_NODE="$NODE" setsid nohup bash _自巡_独立子系统.sh >/dev/null 2>&1 & )
    echo "   ✅ 常驻自巡已起(掉线自愈)"
  fi
else
  echo "▸ ⑤ 未启动"
  echo "   要起: cd $DEST && bash _安装_一键部署.sh --起   (或 --带自巡 连守护一起)"
fi
echo "──────────────────────────────"
echo "✅ 部署完成。看活: tail -f $DEST/data_v2/logs/sub_${NODE}_paper.log"
echo "⚠️ 只跑模拟: 本包含**没有任何密钥**; 若要接真钱 → 新机自配自家 Key + 同意码, 且**旧机必须先停**(同一账户严禁双开)"
