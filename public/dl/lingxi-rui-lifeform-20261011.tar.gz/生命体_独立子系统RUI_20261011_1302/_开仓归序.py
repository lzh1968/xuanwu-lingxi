# -*- coding: utf-8 -*-
"""👑🐍 开仓归序（ED-20260929-325 · 老板令 2026-09-29 08:00）

老板原话：「抑制金蟾开仓，判起势烛龙统御，开仓归总裁」。

**病(实证)**: 内核本有「烛龙门(一票之闸)」 `_zhulong_gate`(子引擎/_内核_*.py 内、原在 `_open_paper` 里)，
但跑器 `_子引擎.py` **覆盖了 `E._open_paper`** ⇒ 内核那道门**从未执行**(死码) ⇒
金蟾费率腿以 `FUND_LEG_BYPASS_GATE/BYPASS_TREND/NO_HUIZHU` **绕过一切闸自行开仓**
(实证: 09-29 07:59:03 老板手工平仓后 40 秒, LINK 空 178 张@15.421 又被金蟾开出来)。

**药**: 在**开仓咽喉**把门立起来 ——
  关一 · **烛龙起势(统御)**: `E._zhulong_gate(st,sig)` → 制动/否决 ⇒ 禁新开; 逆大势 ⇒ 拦; 顺势 ⇒ 主动放行; 无势 ⇒ 交圣裁相左判。
  关二 · **总裁裁决(开仓归总裁)**: `E._teng_she_verdict(None,sig,st,0.0,side)` → 止(连亏/冷却)·缓(逆圣裁/逆大势) ⇒ 不开。
金蟾抑制在**源头**: 基因 `FUND_LEG_ON=0`(费率腿不再成为候选) —— 本件只负责"门"。

开关: `OPEN_ORDER_GATE_ON`(默认 1) · `=0` 回旧行为。回退: `_补_开仓归序_20260929.py --revert`。
"""
import os

# 👑🆕2026-10-06 火印 ED-20261006-487（承 ED-486《烛龙至尊·黄袍加身·天下一统令》）：
#   开仓咽喉立「烛龙至尊」横幅 + 参谋意见书 —— 王(烛龙)为准否唯一决断者；
#   大势门/择强/开明/白虎/触觉军情/顶底半山等诸路一律记「参谋」(无决策权)。
#   只增可见性与留痕·不改一字判定链·不动风控/择向参数·异常一律放行。回退: SUPREME_ON=0（本件零行为变化）。
SUPREME_ON = os.environ.get('SUPREME_ON', '1') != '0'

# 👁🔥2026-10-08 09:47 老板令「眼睛接进真钱的闸（🔴伪锁向/🟡疑减仓）—— 让烛龙身脑👁感知一切」(火印 ED-20261008-616)
#   职: 开仓前读**辨伪天眼判定级** —— 🔴伪⇒**锁向不开**; 🟡疑⇒**名义减半**; 🟢真⇒放行。
#   边界: **只加"开仓前的一道门"** —— 不动止损/紧急闸/兜底/量程/风控闸/相位/择向算式。
#   失败开门: 天眼产物超龄/异常 ⇒ **放行**(不因眼睛瞎了而憋死交易——承「加闸易憋死系统」之训)。
#   开关: TIANYAN_GATE_ON(默认1) · TIANYAN_RED_LOCK(默认1) · TIANYAN_YELLOW_HALF(默认1) · TIANYAN_MAX_AGE(默认900秒)
TY_ON = os.environ.get('TIANYAN_GATE_ON', '1') != '0'
TY_RED_LOCK = os.environ.get('TIANYAN_RED_LOCK', '1') != '0'
TY_YELLOW_HALF = os.environ.get('TIANYAN_YELLOW_HALF', '1') != '0'
try:
    TY_MAX_AGE = float(os.environ.get('TIANYAN_MAX_AGE', '900') or 900)
except Exception:
    TY_MAX_AGE = 900.0
_UD = os.path.dirname(os.path.abspath(__file__))

# 🧠🔥2026-10-08 10:24 老板令「完成并完善系统之王烛龙主神大脑和眼睛的工程…直接开启真钱交易测试」(火印 ED-20261008-619)
#   大脑门: 读主神大脑产物 `烛龙大脑/_脑_判断.json`（逐币: 向/信度/神经网络 拟合分）
#   规则(三步同向律): 双否(大脑反向 且 NN<阈) ⇒ 禁开; 单否(大脑反向) ⇒ 减半; 同向 ⇒ 放行。
#   开关: ZHU_BRAIN_GATE_ON(默认1) · ZHU_BRAIN_HALF(默认1) · ZHU_BRAIN_NN_BLOCK(默认0.50) · ZHU_BRAIN_MAX_AGE(默认900秒)
#   失败开门: 产物超龄/缺该币/异常 ⇒ 放行(不刷日志不拦)。
B_ON = os.environ.get('ZHU_BRAIN_GATE_ON', '1') != '0'
B_HALF = os.environ.get('ZHU_BRAIN_HALF', '1') != '0'
try:
    B_NN_BLOCK = float(os.environ.get('ZHU_BRAIN_NN_BLOCK', '0.50') or 0.50)
except Exception:
    B_NN_BLOCK = 0.50
try:
    B_MAX_AGE = float(os.environ.get('ZHU_BRAIN_MAX_AGE', '900') or 900)
except Exception:
    B_MAX_AGE = 900.0


# 👑🔥2026-10-11 老板令「每轮币王荐向必须达到四源共振要求、接入判定链、真钱、内核…
#   加上精准定位、敏感度，直接可应用于烛龙火印下发腾蛇执行开仓」(火印 ED-20261011-905)
#   币王令门: 读《_币王令.json》(由 _核_币王令.py 产: 四源共振 + 精准定位 + 敏感度 + 授权待火印)
#   · 默认(只读留痕·零行为变化): 该币为**达标币王** ⇒ 咽喉打「👑币王令·准行」；引擎欲开之向与令相反 ⇒ 打「👑币王令·逆王(警示)」
#   · BWL_STRONG_ON=1(须火印+老板点头): 达标币王·同向 ⇒ 主动放行(越软拦；硬闸/风控/止损一字不动)
#   · BWL_BLOCK_OPP=1(须火印+老板点头): 与达标币王反向 ⇒ 拦(禁逆王开仓)
#   失败开门: 令缺/超龄/异常 ⇒ 放行。回退: 删本段 + 删 judge() 内币王令段。
BWL_ON = os.environ.get('BWL_GATE_ON', '1') != '0'
BWL_STRONG = os.environ.get('BWL_STRONG_ON', '0') != '0'
BWL_BLOCK_OPP = os.environ.get('BWL_BLOCK_OPP', '0') != '0'
try:
    BWL_MAX_AGE = float(os.environ.get('BWL_MAX_AGE', '900') or 900)
except Exception:
    BWL_MAX_AGE = 900.0


def 币王令(coin):
    """👑 读币王令（达标者）→ dict | None（缺/超龄/异常 ⇒ None ⇒ 放行）"""
    if not (BWL_ON and coin):
        return None
    try:
        import json as _json, time as _time
        p = os.path.join(_UD, 'data_v2', 'mtsim', '_币王令.json')
        if _time.time() - os.path.getmtime(p) > BWL_MAX_AGE:
            return None
        d = _json.load(open(p, encoding='utf-8'))
        for _k in ('多单币王', '空单币王'):
            _v = d.get(_k) or {}
            if _v.get('币') == coin and (_v.get('四源共振') or {}).get('达标'):
                return {'向': _v.get('向'), '标': _k, '共振': (_v.get('四源共振') or {}).get('同向'),
                        '敏感': _v.get('敏感度'), '级': _v.get('敏感度级'),
                        '授权': _v.get('授权'), '定位': _v.get('精准定位')}
        return None
    except Exception:
        return None


def 脑判(coin):
    """🧠 读主神大脑逐币判（向/信度/神经网络）→ dict | None（超龄/缺币/异常 ⇒ None ⇒ 放行）"""
    if not (B_ON and coin):
        return None
    try:
        import json as _json, time as _time
        p = os.path.join(_UD, '烛龙大脑', '_脑_判断.json')
        if _time.time() - os.path.getmtime(p) > B_MAX_AGE:
            return None
        d = _json.load(open(p, encoding='utf-8'))
        return (d.get('逐币') or {}).get(coin) or None
    except Exception:
        return None


def 眼级(coin, side):
    """👁 逐向读辨伪天眼判级 → (级|None, 真伪度|None, 判词)
       None = 不可用/超龄/异常 ⇒ 调用方**放行**(失败开门)"""
    if not TY_ON:
        return (None, None, '眼闸=关')
    try:
        import importlib.util as _u, json, time
        p = os.path.join(_UD, '烛龙大脑', '_天眼_真伪.json')
        age = time.time() - os.path.getmtime(p)
        if age > TY_MAX_AGE:
            return (None, None, '天眼产物超龄%.0f秒 ⇒ 放行' % age)
        S = _u.spec_from_file_location('ty_gate_%d' % (int(time.time() * 1000) % 100000), os.path.join(_UD, '_天眼_辨真伪.py'))
        ty = _u.module_from_spec(S); S.loader.exec_module(ty)
        r = ty.判(coin, side) or {}
        g = r.get('分级') or ty.级(r.get('真伪度'))
        return (g, r.get('真伪度'), r.get('判词') or '')
    except Exception as _e:
        return (None, None, '眼闸异常放行:%s' % str(_e)[:40])


def banner():
    return '🐉👑 烛龙至尊·天下一统 | 王=[烛龙] 唯一决断 | 其余(八神兽+择向诸门)=参谋·无决策权'


if SUPREME_ON:
    try:
        print('👑[开仓咽喉]' + banner(), flush=True)
    except Exception:
        pass


def _stamp(E, sig):
    """王令留痕: 读内核圣裁(E.ZHU_EDICT) → 记「王(烛龙)准 + 参谋团意见」· 参谋无决策权。纯只读"""
    try:
        ze = getattr(E, 'ZHU_EDICT', None) or {}
        _votes = ze.get('votes') or {}
        _ros = ' '.join('%s%s' % (k, '+' if v > 0 else ('-' if v < 0 else '0')) for k, v in _votes.items())
        print('👑[王令·烛龙]准：%s %s → 圣裁=%s 信%.2f | 参谋团[%s]' % (
            (sig or {}).get('coin'), (sig or {}).get('side'), ze.get('verdict'),
            float(ze.get('conf') or 0), _ros), flush=True)
    except Exception:
        pass


def sizing_half(coin, side):
    """🧠👁 降权（指挥链：大脑为准·眼为凭）：大脑降权 或 疑 或 与大脑反向 ⇒ 名义减半 → (是否减半, 因由)"""
    _rs = []
    _b = 脑判(coin) if (B_ON and B_HALF) else None
    if _b:
        try:
            if bool(_b.get('降权')):
                _rs.append('大脑降权(眼级%s 真伪%.2f)' % (_b.get('天眼分级'), float(_b.get('真伪度') or 0)))
            _bw = str(_b.get('向') or '')
            if _bw and _bw != 'hold' and side and _bw != side:
                _rs.append('大脑反向(大脑%s 信%.2f)' % (_bw, float(_b.get('信度') or 0)))
        except Exception:
            pass
    if TY_ON and TY_YELLOW_HALF:
        try:
            g, d, w = 眼级(coin, side)
            if g == '🟡疑' and not _rs:
                _rs.append('🟡疑(真伪%.2f %s)' % (float(d or 0), w))
        except Exception:
            pass
    return (True, ' + '.join(_rs)) if _rs else (False, '非疑·非反·非降')


def on():
    return os.environ.get('OPEN_ORDER_GATE_ON', '1') != '0'


def judge(E, st, sig):
    """开仓归序判据 → (是否放行, 因由)。纯只读·不改任何状态。"""
    if not on():
        return (True, '开仓归序=关(旧行为)')
    try:
        _zg = E._zhulong_gate(st, sig)
    except Exception:
        _zg = None                      # 门异常 → 不拦(与内核风格一致: 异常放行, 交其余闸)
    if _zg:
        return (False, '烛龙起势关·%s' % _zg)
    # 🧠👁🔥2026-10-08 10:38 老板令「**大脑(烛龙)指挥眼，指挥系统，指挥全部**」(火印 ED-20261008-622)
    #   指挥链: **眼 → 大脑 → 系统** —— 以**大脑判定为准**（锁向⇒禁开·降权⇒减半）；大脑无该币/超龄 ⇒ 眼判为后备。
    _b = 脑判((sig or {}).get('coin'))
    _side = (sig or {}).get('side')
    if _b:
        if bool(_b.get('锁向')) and TY_RED_LOCK:
            return (False, '🧠👁大脑锁向(眼级%s 真伪%.2f) ⇒ 禁开' % (_b.get('天眼分级'), float(_b.get('真伪度') or 0)))
        _bw = str(_b.get('向') or '')
        try:
            _nn = float(_b.get('神经网络') or 0.5)
        except Exception:
            _nn = 0.5
        if _bw and _bw != 'hold' and _side and _bw != _side and _nn < B_NN_BLOCK:
            return (False, '🧠👁双否·大脑反向(大脑%s 信%.2f)且神经网络%.2f<%.2f ⇒ 禁开' % (_bw, float(_b.get('信度') or 0), _nn, B_NN_BLOCK))
    else:
        # 后备（大脑无该币）: 用眼判
        _g, _d, _w = 眼级((sig or {}).get('coin'), _side)
        if _g == '🔴伪' and TY_RED_LOCK:
            return (False, '👁🔴天眼锁向·伪(真伪%.2f %s) ⇒ 禁开' % (float(_d or 0), _w))
    # 🌀🔥2026-10-07 火印 ED-20261007-551 相位刀豁免（老板令「急急如律令，赋予相位刀豁免权」）
    #   反币已由相位刀翻正 ⇒ 刀向为尊；『与圣裁相左』不再构成拦截（起势门之制动/否决仍守·风控一字不动）。
    try:
        if int(os.environ.get('SIGN_PHASE_ADAPT_ON', '0') or 0) == 1:
            _phc = (sig or {}).get('coin')
            if _phc and ((E._phase_of(_phc) or {}).get('相位') == '反'):
                return (True, '🔥相位刀豁免(王火令): %s 反币已翻正 ⇒ 不以『与圣裁相左』为拦' % _phc)
    except Exception:
        pass
    # 👑2026-10-11 火印 ED-20261011-905: 币王令门（四源共振·精准定位·敏感度·待火印）
    try:
        _bw = 币王令((sig or {}).get('coin'))
        if _bw:
            _sd = (sig or {}).get('side')
            _same = (_bw.get('向') == _sd)
            _msg = '👑币王令·%s %s(%s) 共振%d/4 敏感%s%s' % (
                '准行' if _same else '逆王', _bw.get('标'), _bw.get('授权'),
                _bw.get('共振') or 0, _bw.get('敏感') or 0, _bw.get('级') or '')
            try:
                print('[开仓咽喉]' + _msg, flush=True)
            except Exception:
                pass
            if _same and BWL_STRONG:
                return (True, _msg + ' ⇒ 币王令授权放行')
            if (not _same) and BWL_BLOCK_OPP:
                return (False, _msg + ' ⇒ 禁逆王开仓')
    except Exception:
        pass
    try:
        _tv, _tw = E._teng_she_verdict(None, sig, st, 0.0, (sig or {}).get('side'))
    except Exception as _e2:
        return (True, '总裁裁决异常放行:%s' % str(_e2)[:40])
    if str(_tv) != '准':
        return (False, '总裁裁决·%s(%s)' % (_tv, _tw))
    if SUPREME_ON:
        _stamp(E, sig)
    return (True, '烛龙起势+总裁准')
