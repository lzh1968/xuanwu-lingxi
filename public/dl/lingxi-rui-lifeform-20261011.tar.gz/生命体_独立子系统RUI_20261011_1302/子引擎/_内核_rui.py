# -*- coding: utf-8 -*-
"""
☯️ 多币母体·进化2  SIM(模拟修行版)  —— 脱胎换骨·凤凰涅槃
=============================================================
🏛 内核重中之重纲要·五脏目标(2026-09-11 老板令固化·最高准则·一切改动须服务此纲):
   ①🥇金蟾(出纳)——吞小利: 区间小肉咬进肚(阶梯), 峰≥1.0%让位貔貅;
   ②🦁貔貅(财务官)——啃大肉: 大肉≥1.5%, 自适应回撤锁(锁位紧跟峰), 不撒嘴啃到底;
   ③🐉烛龙(董事长)——决策择向: regime大势+区间位pos4+衰竭闸, 只放方向不矛盾的;
   ④🐍腾蛇(总经理)——执行择强: _pick择强+自适应名义+弱信号封顶, 挑方向最清的币开;
   ⑤🛡保卫科(应急止损)——兜底护盘·应急回转正向: 方向对顺势赚/方向错麒麟摆尾反手(不止一招止损走人).
   道器尊严 = 盈利能力; 使命 = 稳健持续能赚钱(非保证不亏); 数字必对Gate真实流水.
-------------------------------------------------------------
把旧母体的"两块肉"(金蟾美元阶梯锁 + 貔貅大肉让跑)熔进新生多币择强骨架,
成为接替原单ETH引擎的新母体主系统雏形。 本文件 = SIM/纸面, 绝不下真实单。

架构(浑然一体·一决策轮):
  · 内脏-多币自切换(继承$200节点已验健康): _coin_score/_pick 三币(ETH/SOL/DOGE)择强
  · 骨架-旧母体盈利双兽(继承金蟾貔貅精华, 按名义归一化 scale-free 移植):
       💵金蟾区间美元阶梯锁(吃区间小利阶梯, 横盘虹吸当断)
       💵貔貅 $大肉让跑(真趋势≥大盘交棒让跑, 趋势瓦解/确无发展才收官; 抬地板续吃)
       💸貔貅$保底锁利(保底TRAIL挡, 让小利不吐回)  ⚡盈利急速回吐保护(防插针回吐)

关键纪律(防旧体半山腰病复发):
  · 旧母体通用顺势门"15m虚弹当趋势太松"→ 新母体开仓要走 _pick 择强(|净分|≥PICK_ABS_MIN)
    且大势不逆(下跌日中位虚弹的多: 4H动量显著为负仍开多→拦截), 宁缺毋滥。
  · 金蟾/貔貅美元档一律按 notional 比例归一化(scale-free, 不失真)。

用法: python3 _多币母体进化2_SIM.py                  # SIM 实时轮(默认PAPER)
      python3 data_v2/mtsim/_回放_母体进化2.py        # 离线历史回放(观判)
"""
import os, time, json, urllib.request
BASE = os.path.dirname(os.path.abspath(__file__))
# ─── 池与杠杆(继承$200节点参数) ───
POOL = 200.0
LEVER = 10
NOTIONAL = POOL * LEVER
PICK_ABS_MIN = 1.0          # 方向净分|≥1 才开(宁缺毋滥)

# ═══ 🐉 无为纪律三条铁律 (2026-09-25 火印 ED-20260925-138 · 固化·不可行情内篡改) ═══
#   ①规则触发不得人为绕行  ②条件未达不因情绪强行生成信号  ③因子/阈值仅允许版本制度流程修改
WUWEI_RULES = {
    'rule1_no_bypass': True,       # 规则触发不得绕行
    'rule2_no_force': True,        # 条件未达不强生成信号
    'rule3_version_only': True,    # 因子/阈值仅版本流程可改
}
def _wuwei_guard(name, val, expect):
    '''无为铁律·启动自检: 核心阈值必须等于定版值, 否则报警(防行情内临时篡改)'''
    if val != expect:
        _L = globals().get('log')
        if _L: _L(f"🚫 无为铁律告警: {name}={val} 与定版{expect}不符 → 疑遭临时篡改")
        return False
    return True
# 定版阈值(改这些值必须走版本流程·重新铸火印)
WUWEI_PINNED = {'PICK_ABS_MIN': 1.0, 'COUNTER_SHORT_TREND': 0.20}
for _k, _v in WUWEI_PINNED.items():
    _wuwei_guard(_k, globals().get(_k), _v)
# ═══ 无为铁律结束 ═══
# ⚫🆕2026-09-15 10:16 老板令"执行A: 清择向精准闸残留":
#   该闸(方A1)已于 09-13 老板令"解困仙绳"默认关(DIR_PRECISE_ON=0); 且半月沙箱实证为伪解(对齐3/3反而差-0.086%).
#   现状=死代码空转. 老板令"精准择向雷达"取代之 → 本闸彻底封存(DIR_PRECISE_LEGACY=0 永久).
#   保留常量仅为兼容旧账本/日志引用; 不再参与任何决策.
DIR_PRECISE_LEGACY = False   # 🪦已封存(2026-09-15 A) · 择向交"雷达"接管
DIR_PRECISE_MIN = int(os.environ.get('DIR_PRECISE_MIN','2'))   # (保留·未用)
# 📡🆕2026-09-15 10:16 C·精准择向雷达(老板令"照亮2/3启动点·避3/3共识点"):
#   理念: 不用"闸拦截"(B复核发现半山腰闸严重误伤: 拦下的单胜率53.2%/均+0.122% > 放行单),
#         而用"雷达照亮" — 用"方向胚胎度"评分择优, 优选2/3对齐(将成未成)启动点.
DIR_RADAR_ON = __import__('os').environ.get('DIR_RADAR_ON','1') != '0'   # 雷达择优(默认开)
RADAR_W_ALIGN = 0.25   # 对齐度细权(与base叠加)
# 2026-09-15 15:06 A方案(老板令): 雷达胚胎度偏好3/3(全周期共振=真趋势). 数据铁证: 3/3均+0.053~0.060%唯一正期望;
#   旧_embryo给2/3加分(base2.0)/3/3降权(base0.0) → 打压唯一赚钱格子! 新:3/3=2.0/2/3=1.0/0-1=负. 回旧:RADAR_EMBRYO_V2=0
RADAR_EMBRYO_V2 = __import__('os').environ.get('RADAR_EMBRYO_V2','1') != '0'   # A: 胚胎度偏好3/3(默认开)
# 2026-09-15 15:06 B方案(老板令): 时段闸 — 美欧(北京8-22)噪音大, 只接强信号. 数据:亚洲/深夜正,美欧负;
#   美欧只接score>=SEG_MIN_SCORE → 净亏-50.5%→-15.7%(减亏69%). 回旧:SEG_GATE_ON=0
SEG_GATE_ON = __import__('os').environ.get('SEG_GATE_ON','1') != '0'   # B: 时段闸(默认开)
SEG_STRONG_HOURS = (8, 22)   # 美欧时段(北京8-22点)
SEG_MIN_SCORE = float(__import__('os').environ.get('SEG_MIN_SCORE','3.0'))  # 美欧时段最低|score|

# 💊2026-09-24 23:0x 老板令「上」: 劣时段闸 — 实测负期望时段(样本≥20笔)只接强信号
#   默认空/0 = **零影响**(与旧行为完全一致) ⇒ 真钱内核未设环境变量即不受影响
BAD_HOURS = set(x.strip() for x in __import__('os').environ.get('BAD_HOURS','').split(',') if x.strip())
BAD_HOUR_MIN_SCORE = float(__import__('os').environ.get('BAD_HOUR_MIN_SCORE','0') or 0)

# 💊2026-09-24 23:2x 老板令「一切归因于择向」: 择向确认闸 — 周期对齐不足则宁缺毋滥(等启动点)
#   默认 0 = **零影响**(与旧行为一致) ⇒ 真钱内核未设环境变量即不受影响
ENTRY_ALIGN_MIN = int(__import__('os').environ.get('ENTRY_ALIGN_MIN','0') or 0)
# 🌟2026-09-15 17:10 B加权(老板令): 黄金窗口加权 — 北京时间0-1点(美股收盘后+亚洲盘前·流动性最低噪音最少)
#   有超额正期望(仅0-1点开仓: 62笔·胜率66.1%·净均+0.186%). 只放大_embryo得分(不新增模块). 回旧:SEG_GOLD_ON=0
SEG_GOLD_ON = __import__('os').environ.get('SEG_GOLD_ON','1') != '0'   # B加权: 黄金窗口加权(默认开)
SEG_GOLD_HOURS = (0, 2)   # 黄金窗口(北京0-2点·不含2点)
SEG_GOLD_BOOST = float(__import__('os').environ.get('SEG_GOLD_BOOST','1.5'))  # 黄金窗口得分乘数
# 📡🆕2026-09-15 老板令: 雷达=开明兽情报体系智能工具(信号增强), 按原有链路给白虎前哨之眼→烛龙/腾蛇裁决.
#   做法: 雷达照亮结果 写 _雷达情报.json → 哨兵(白虎)合并进 _触突军情.json → 烛龙/腾蛇读.
DIR_RADAR_FEED = __import__('os').environ.get('DIR_RADAR_FEED','1') != '0'   # 雷达情报化(默认开·0=只在本轮择强不入总线)
HALFMOUNTAIN_RADAR_TAKEOVER = __import__('os').environ.get('HALFMOUNTAIN_RADAR_TAKEOVER','1') != '0'  # 半山腰闸交雷达接管(默认开)
# 🎯🆕2026-09-12 方A1·开仓后方向自检(老板"择向精准度直接关联最终胜率"):
#   ⚫2026-09-15 A: 同属死代码(DIRCHK_ON默认关·老板09-13令"开仓90秒自检砍单=亏小钱元凶") → 封存.
DIRCHK_LEGACY = False   # 🪦已封存(2026-09-15 A)
DIRCHK_WINDOW = float(os.environ.get('DIRCHK_WINDOW','90'))    # 开仓后自检窗(秒): 头90s
DIRCHK_CERT   = float(os.environ.get('DIRCHK_CERT','0.5'))     # 信号矛盾/背离certify门槛
DIRCHK_REV    = float(os.environ.get('DIRCHK_REV','0.15'))     # 近端反向幅度阈值(%)
SL = 0.025                  # 硬止损 2.5% (≈$50@2000名义, 在可承受$200池内)
CERTIFY_SENSE_ON = float(__import__('os').environ.get('CERTIFY_SENSE_ON','1'))  # 🆕2026-09-11 保卫科·高感知证伪(1开/0关)
TACTILE_ON = float(__import__('os').environ.get('TACTILE_ON','1'))   # 🆕2026-09-11 触觉融入开关(1开/0关·一键回退)
TACTILE_W = 0.5           # 触觉共振加权幅度(score±, 沙箱验5-10min前瞻60%; 温和不激进)
# 🧬🆕 时空梭顶底基因(2026-09-11 融入): 24h分位顶底反转加权(路演综合胜率66%)
SK_GENE_ON = os.environ.get('SK_GENE_ON','1') != '0'
SK_GENE_W  = 0.6          # 识顶/识底加权幅度(与触觉同量级, 温和)
def _tactile_read(coin):
    """🧬 读触觉总线最新帧该币信号(纯只读·零侵入): 返回 (side, strength) 或 (None,0). 文件不存在/异常→None."""
    if not TACTILE_ON: return None, 0.0
    try:
        import json as _j, os as _o
        _bp=_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),'data_v2','mtsim','_tactile_bus.json')
        d=_j.load(open(_bp,encoding='utf-8'))
        fr=(d.get('bus') or [])[-1].get('samples') or []
        for s in fr:
            if s.get('coin')==coin: return s.get('tactile_side'), float(s.get('strength',0) or 0)
    except Exception:
        pass
    return None, 0.0

QUALITY_GATE_ON = float(__import__('os').environ.get('QUALITY_GATE_ON','1'))  # 🧬🆕2026-09-14 22:57 老板令"B方案: 母体/GTAE并入ZH严格基因": 默认改1(与ZH1/2/3/ZLS同基因·避死水窄市)
QUALITY_AMP6_MIN = 1.2    # 近6h振幅下限(%): <此=窄市没肉(手续费吃利润)→不硬做

FEEDBACK_ON = float(__import__('os').environ.get('FEEDBACK_ON','1'))  # 🆕2026-09-11 药④触突→保卫科反馈(1开/0关)
def _certify_of(sig):
    """🧬 药②快链: 综合该币伪信号高危度 = max(引擎certify, 触突军情certify). 纯只读.
       🆕2026-09-11 防抖(治'拦了又开'): certify是瞬时值会抖动(ADA曾0.7→0.2→溜过阈值被开)
         → 记近N轮峰值: 若近CERTIFY_HIST_N轮内曾≥CERTIFY_HOT, 仍视为高危(防抖动漏网)."""
    try:
        _e=float(sig.get('certify',0) or 0) if CERTIFY_SENSE_ON else 0.0
        _n=_nerve_read(sig.get('coin')) if FEEDBACK_ON else 0.0
        _now=max(_e,_n)
        # 🆕防抖: 记该币近N轮峰值certify
        _c=sig.get('coin')
        if _c:
            _h=_CERTIFY_HIST.setdefault(_c,[])
            _h.append(_now)
            if len(_h)>CERTIFY_HIST_N: _h.pop(0)
            _peak=max(_h)
            return max(_now,_peak if _peak>=CERTIFY_HOT else 0.0)
        return _now
    except Exception:
        return 0.0

# 🆕2026-09-11 防抖参数(治'拦了又开'): certify瞬抖漏洞
CERTIFY_HOT   = float(__import__('os').environ.get('CERTIFY_HOT','0.5'))   # 伪信号高危阈值
CERTIFY_HIST_N= int(__import__('os').environ.get('CERTIFY_HIST_N','12'))   # 记忆近N轮(约24min)峰值
_LAST_SIGS = {}   # 🆕2026-09-11 母子融合: 缓存本轮各币 sig(供 _write_consensus 复用, 避重复拉行情4min/轮)
_LAST_CHOSEN = ['']   # 🆕2026-09-11 母子融合: _pick 本轮择强结论(供共识)
_CERTIFY_HIST = {}   # 🆕2026-09-11 防抖: 各币近N轮certify历史(治'拦了又开'瞬抖漏网)
def _nerve_read(coin):
    """🧬 读触突军情总线(哨兵写的 _触突军情.json)该币高危度(纯只读·零侵入): 返回 certify(0~1).
       药④·反馈保卫科: 触突感知→保卫科提前收紧. 文件不存在/异常→0."""
    if not FEEDBACK_ON: return 0.0
    try:
        import json as _j, os as _o
        _bp=_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),'data_v2','mtsim','_触突军情.json')
        d=_j.load(open(_bp,encoding='utf-8'))
        for n in (d.get('nodes') or []):
            if n.get('coin')==coin: return float(n.get('certify',0) or 0)
    except Exception:
        pass
    return 0.0
def _radar_read(coin):
    """📡🆕2026-09-15 老板令: 读雷达情报(_雷达情报.json)该币"方向胚胎度"(纯只读·零侵入).
       定位: 雷达=开明兽情报工具(信号增强) → 白虎前哨之眼 → 烛龙/腾蛇裁决. 返回(dict|None)."""
    if not DIR_RADAR_FEED: return None
    try:
        import json as _j, os as _o
        _bdir=_o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir)=='子引擎': _bdir=_o.path.dirname(_bdir)   # 子引擎内核副本→回主目录
        _fp=_o.path.join(_bdir,'data_v2','mtsim','_雷达情报.json')
        d=_j.load(open(_fp,encoding='utf-8'))
        for n in (d.get('nodes') or []):
            if n.get('coin')==coin: return n
    except Exception:
        pass
    return None
# 🚌🆕2026-09-30 老板令《三兽图谱·三兽成三才》(火印 ED-20260930-338): **三兽巴士总闸**
#   三兽: 🥇金蟾(出纳·吞小利) → 🦁貔貅(财务官·啃大肉) → 🛡麒麟(保卫科·扭转乾坤)
#   三路连边: ②金蟾→貔貅(让吐/退返) · ①金蟾→麒麟(摆尾/知会) · ③貔貅→麒麟(转弱/承接)
#   BEASTBUS_ON=1(默认·**现行为逐字不变**) / =0(**一键回滚**三路连边·三兽各归各=旧行为)
#   回滚法: 基因此键置 0 → 重启两守护（无需逐项关）
BEASTBUS_ON = __import__('os').environ.get('BEASTBUS_ON','1') != '0'


# 🎯🆕 区间顶底麒麟摆尾(2026-09-12 01:0x 老板令"上行后回撤幅度大→顶部麒麟摆尾做空; 空单到底没劲→做多; 区间有利可图·随机应变"):
#   病案(ETH): 2457→2628(急涨)→2558(大幅回撤)→回抽. 大趋势仍在却大幅上下→该顶底麒麟摆尾吃区间利, 非干平走人.
#   药: 辨"大幅区间震荡"(振幅大+上下扫) → 顶区麒麟摆尾做空 / 底区麒麟摆尾做多 / "没劲了"(动量衰竭)触顶底翻.
RANGE_FLIP_ON = (__import__('os').environ.get('RANGE_FLIP_ON','1') != '0') and BEASTBUS_ON  # 区间顶底麒麟摆尾(1开/0关) · 🚌并入三兽巴士(①金蟾→麒麟 摆尾/知会)
RANGE_AMP = 5.0        # 区间振幅阈值: 近6h振幅≥5% → 认"大幅上下"(可麒麟摆尾)
RANGE_POS_HI = 85.0    # 区间高位区(≥85%) → 顶部麒麟摆尾做空
RANGE_POS_LO = 15.0    # 区间低位区(≤15%) → 底部麒麟摆尾做多
RANGE_EXHAUST = 0.15   # "没劲了"判据: 近3根动量<该值% → 动量衰竭(触顶底)
# 🎯🆕 见顶见底加敏 + 反转识别加敏(2026-09-12 00:3x 老板令"赋予见顶见底信号加敏·反转识别加敏"):
#   病根: ①母体无"见顶/见底"预警(pos4只作参考) ②contra太糙→急涨换挡(15m小回踩)被误当信号矛盾→真突破被拦.
#   药A: 顶底极值预警(_topbot_alert): 接近24h高/低 + 近端转弱/强 + 量能 → 警示见顶/见底(融入score).
#   药B: contra急涨豁免(_pulse): 近3根单边急动(>某幅)时, 15m小回踩不算"矛盾"(是换挡) → 真突破不被拦.
TOPBOT_SENS = float(__import__('os').environ.get('TOPBOT_SENS','1'))  # 顶底加敏(1开/0关)
TOPBOT_ZONE = 0.90   # 顶/底区: 24h分位≥90%认顶区 / ≤10%认底区(比时空梭75/25更敏)
PULSE_AMP = 2.0      # 急涨/急跌判据: 近3根15m单边幅度≥2% → 脉冲中(contra豁免)
MIN_HOLD_SEC = int(os.environ.get('MIN_HOLD_SEC','0'))   # 🛡2026-09-25 老板令「让环境变量生效」: 最小持有(照老母体ED-141③搬入)·0=关   # 🗑2026-09-25 老板令「删除掉早断功能」→ 默认 0=删; =1 恢复早断两腿
# 🤸🆕2026-09-11 20:0x 老板令"麒麟摆尾最高级别是不亏·不是亏到半山腰才翻(翻个屁)":
#   病: 旧麒麟摆尾①无次数限制→可反复翻(翻一翻亏一亏) ②触发在-1.0%→半山腰才翻(越翻越亏).
#   药: ①只翻一次(_fandou计数·翻过就认小亏不再翻) ②及早翻(淺亏FANDOU_MAX_LOSS内才允许翻, 半山腰禁翻)
#      ③必须"近端新鲜证伪"才翻(翻是扭亏机会, 非套牢补救). 可由 FLIP_FANDOU_SMART=0 回旧行为.
FLIP_FANDOU_SMART = __import__('os').environ.get('FLIP_FANDOU_SMART','1') != '0'   # 智能麒麟摆尾(及早翻+翻一次)
# 🧩🆕2026-09-30 老板令《四环闭环》**环四·只翻一次硬闸**（火印 ED-20260930-338 承 ED-336 择币三正）
#   病(实证 ED-335 摆尾营): `_fandou` **只计数**——②③④ 门都拿它当闸，唯独 **⓪获利转向门绕过**；
#     同一枚币可连翻成群(19 次摆尾实为 5 簇·**14 次空转**白送手续费)
#   药: ⓪门并入 `_fandou` 检查(只翻一次·翻过只守只兜)；QILIN_FLIP_ONCE_ON=1(默认) / =0 **逐字回旧**(允许再翻)
QILIN_FLIP_ONCE_ON = os.environ.get('QILIN_FLIP_ONCE_ON','1') != '0'
FANDOU_MAX_LOSS  = -0.006  # 麒麟摆尾允许的最深承压: 仅浅亏(≥-0.6%)才翻; 超过=已半山腰→禁翻(认赔早走)
# 💊🆕2026-09-12 方A1·麒麟兜底转向灵敏度(老板令"确保麒麟兜底转向灵敏度"):
#   病: 摆尾"及早"门槛仍是 ppct<=-0.004(-0.4%)+certify>=0.5 → 窄市里等确认已滑到-0.5%~-0.6%, 又撞半山腰禁翻线.
#   药: 及早摆尾"浅亏线"提前到 -0.25%(QILIN_SENS_LOSS), 且certify门槛降到0.45(QILIN_SENS_CERT), 让"及早"真早(半山腰前).
#   守: 仍只摆一次(_fandou)+仍需火印+仍需非半山腰. 可 QILIN_SENS_ON=0 一键回旧.
QILIN_SENS_ON    = os.environ.get('QILIN_SENS_ON','1') != '0'
QILIN_SENS_LOSS  = float(os.environ.get('QILIN_SENS_LOSS','-0.0035')) if QILIN_SENS_ON else -0.004   # 及早摆尾浅亏提前线(-0.35%·均衡档)
# 🦄🆕2026-09-15 12:48 老板令"A+B同整理·治麒麟越权·管理好现在向好治理":
#   病(实证): 麒麟60笔胜率11.7%亏-9319$; 金蟾100%/貔貅100%胜率 → 麒麟越权干了金蟾貔貅的活(有肉时乱刹车).
#   A: 麒麟撤出"有肉时半山腰刹车"(把退出权交还金蟾貔貅·它们按阶梯/回撤锁管).
#   B: 麒麟只留"深套+证伪确证+火印"的最后摆尾兜底(终极保险·极少用).
#   开关: QILIN_RETREAT_ON=1(默认·撤越权) / =0(回旧·照旧刹车).
#   🦄🆕2026-09-16 老板令"三兽分片治理·均衡档": 浅套-0.35% / 深套-1.0% / cert0.40 (麒麟治理水下, 水上归金蟾貔貅)
QILIN_RETREAT_ON = os.environ.get('QILIN_RETREAT_ON','1') != '0'
# 🔆🆕2026-10-03 老板令「准·甲+半味丙」(火印 ED-20261003-395): 兜底焊死 —— 去 certify≥0.5 门槛
#   病: 兜底带 `if _cert>=0.5` 门 ⇒ 无证伪的阴跌→兜底不咬→滑到 2.0% 硬止损(单笔 19% 权益·破 9% 红线)
#   药: env QILIN_DEFENSE_UNCOND=1 ⇒ 条件放宽为 (_cert>=0.5 or QILIN_DEFENSE_UNCOND) ⇒ −0.9% 无条件咬
#   默认 '0' = 逐字旧行为（可一键回退）
QILIN_DEFENSE_UNCOND = os.environ.get('QILIN_DEFENSE_UNCOND','0') != '0'
QILIN_LAST_DEFENSE = float(os.environ.get('QILIN_LAST_DEFENSE','-0.013'))

# 🧠🆕2026-09-27 火印 ED-20260927-239 融入「当年自适应兜底」(源自 09-21 内核 · 老板令「回归9/15-9/22择向钢」)
#   考古: 09-15~09-22 胜68%净+17369 · 09-23~今 胜28%净−9096；V47: 自适应兜底 +442.89 vs 固定96 +27.23
QILIN_ADAPT_ON   = os.environ.get('QILIN_ADAPT_ON', '0') != '0'          # 自适应兜底总开关(内核默认关·模拟/仿真基因开)
QILIN_ADAPT_MIN  = float(os.environ.get('QILIN_ADAPT_MIN', '-0.006'))   # 最紧兜底
QILIN_ADAPT_MAX  = float(os.environ.get('QILIN_ADAPT_MAX', '-0.030'))   # 最松兜底
QILIN_ADAPT_NEAR = float(os.environ.get('QILIN_ADAPT_NEAR', '0.60'))    # 接近度(省行情拉取)
QILIN_TURN_HOLD_ON = os.environ.get('QILIN_TURN_HOLD_ON', '0') != '0'   # 🔮回撤扭转辨识(近端已回抽≥0.15% → 缓一档不砍·V48实证有效)

# 🧭🆕2026-09-27 火印 ED-20260927-240《择向三刀》(老板令「急急如律令，准」·沙箱 V46 Q7 实证)
#   ①位置带 30~70(池内96根区间分位·不追高不接刀) ②池内同向≥60%(顺势共识) ③回踩到位后等一根(不抢第一根)
#   内核默认**全关**=旧行为不变；模拟/仿真基因开；真钱另请印。
SIGN_POS_BAND_ON  = os.environ.get('SIGN_POS_BAND_ON', '0') != '0'
SIGN_POS_BAND_LO  = float(os.environ.get('SIGN_POS_BAND_LO', '35'))
SIGN_POS_BAND_HI  = float(os.environ.get('SIGN_POS_BAND_HI', '65'))
# 🧭 2026-09-30 老板令「择时择位闸·三齐」→ 落地形态「必须过 + 位置定仓」(火印 ED-20260930-350)
#   老板原话: 「只在信号强加位置好加大势跌三齐时才出手，专治22%胜率的病根」
#   实测: 硬 AND「大势跌+位置高」15 天 0 次(互斥) ⇒ 位置当油门、不当刹车 ⇒ 出带减仓不拦死
SIGN_POS_THROTTLE_ON  = os.environ.get('SIGN_POS_THROTTLE_ON', '0') != '0'      # 默认 0 = 逐字回旧
SIGN_POS_THROTTLE_MIN = float(os.environ.get('SIGN_POS_THROTTLE_MIN', '0.50'))  # 出带最低量程
SIGN_SAME_DIR_MIN = float(os.environ.get('SIGN_SAME_DIR_MIN', '0'))     # 0=不启用
SIGN_WAIT_ONE     = os.environ.get('SIGN_WAIT_ONE', '0') != '0'
# 🧬🆕2026-09-27 火印 ED-20260927-243《自演化第四轮落地·择回踩深》(沙箱二/四轮铁证)
#   ①市况门: 效率比ER≥阈 · 波动vol≤阈 · 强度|t4|≥阈 · 长窗t96同向
#   ②择强口径: 由「信号最强|t4|」改「回踩最深|m1|」—— 回踩越深的顺势单·胜率与盈亏比越高
#   内核默认**全关**=旧行为不变；模拟/仿真基因开；真钱另请印(收兵中)。
SIGN_REGIME_GATE_ON = os.environ.get('SIGN_REGIME_GATE_ON', '0') != '0'
SIGN_ER_MIN    = float(os.environ.get('SIGN_ER_MIN', '0.15'))

# 🔪2026-10-02 老板令「凡是反的调为正(扭转乾坤)，凡是正的优中优又优」(火印 ED-20261002-384):
SIGN_ER_GATE_HARD_ON = int(os.environ.get('SIGN_ER_GATE_HARD_ON', '0'))   # 甲刀: 单币ER门无条件生效(修"天明代偿"漏洞)
SIGN_PHASE_SPLIT_ON  = int(os.environ.get('SIGN_PHASE_SPLIT_ON', '0'))    # 🔪ED-393 相位分门: "顺"币走趋势门, "反"币(做反转)走位置极值门
SIGN_REV_POS_HI      = float(os.environ.get('SIGN_REV_POS_HI', '75'))     #   反币: pos≥此值 ⇒ 贴顶做空
SIGN_REV_POS_LO      = float(os.environ.get('SIGN_REV_POS_LO', '25'))     #   反币: pos≤此值 ⇒ 贴底做多
SIGN_NEAR_CONFIRM_ON = int(os.environ.get('SIGN_NEAR_CONFIRM_ON', '0'))   # 乙刀: 近端(末根15m)反向则不判向(治滞后追单)
SIGN_NEAR_MIN        = float(os.environ.get('SIGN_NEAR_MIN', '0.30'))     # 乙刀阈值(%)
YIJING_CF_ER_ON      = int(os.environ.get('YIJING_CF_ER_ON', '0'))        # 丙刀: 信度计入效率比(优中优)
SIGN_TREND_ALIGN_ON = int(os.environ.get('SIGN_TREND_ALIGN_ON', '0'))  # 丁刀: 判向/选币须与长窗(24h)大势同向
SIGN_PHASE_ADAPT_ON  = int(os.environ.get('SIGN_PHASE_ADAPT_ON', '0'))   # 相位刀: 逐币顺/反(翻正)/观望



SIGN_VOL_CAP   = float(os.environ.get('SIGN_VOL_CAP', '0.70'))
SIGN_T4_MIN2   = float(os.environ.get('SIGN_T4_MIN2', '1.5'))
SIGN_T96_SAME  = os.environ.get('SIGN_T96_SAME', '1') != '0'
SIGN_RANK_PULL = os.environ.get('SIGN_RANK_PULL', '0') != '0'
SIGN_CHASE_M1_MAX = float(os.environ.get('SIGN_CHASE_M1_MAX','99.0'))   # 🧲ED-20260927-246 追高闸(|m1|上限%·99=关·旧行为)
SIGN_PULL_MIN     = float(os.environ.get('SIGN_PULL_MIN','0.0'))       # 🧲ED-20260927-246 回踩闸(顺方向回踩≥此%·0=关)
# 🧬🆕2026-09-28 火印 ED-20260928-289《补全新基因功能·大势门震荡回补》(A/B 回放铁证 ED-288)
#   病: 09-23→今 效率比 er≈0.08~0.11 ＜ SIGN_ER_MIN(0.15·震荡市) ⇒ 大势门恒 0 ⇒ G1/G2/G3/G4 的「顺势」分支空转(形同未接)。
#   治: er 不足判「无势」时, 若 大小窗同向(t96 与 t4 同号·|t96|≥阈) 且 不贴极端位 且 波动不过阈 ⇒ 回补判势 sign(t4)。
#   内核默认**关**=逐字回旧；模拟/仿真基因开；真钱另请印(收兵中)。
SIGN_TREND_FALLBACK_ON = os.environ.get('SIGN_TREND_FALLBACK_ON', '0') != '0'
SIGN_T96_FB_MIN   = float(os.environ.get('SIGN_T96_FB_MIN', '1.0'))    # 🧬回补: 长窗t96幅度门槛(%·|t96|≥此才算同向大势)
SIGN_T4_FB_MIN    = float(os.environ.get('SIGN_T4_FB_MIN', '0.30'))    # 🧬回补: 短窗t4幅度门槛(%·实测真实行情 t4≈0.03~0.4 ⇒ 1.5 不可达: 回补用 0.30)
SIGN_FB_POS_HI    = float(os.environ.get('SIGN_FB_POS_HI', '85'))      # 🧬回补: 多头位置上限(不追顶)
SIGN_FB_POS_LO    = float(os.environ.get('SIGN_FB_POS_LO', '15'))      # 🧬回补: 空头位置下限(不接刀)
# 🧭🆕2026-09-28 势位共振优先（火印 ED-20260928-300 · 老板「做势位共振优先，再推演出来结果」· 承 ED-283）--
#   势=短窗t4与长窗t96同向(大势明确) · 位=96根分位pos(贴底/贴顶) · 共振=多头(势上+贴底)/空头(势下+贴顶)
#   「优先」= 有共振候选则只从共振中择强; 无则回旧(不困死)。默认**关**=逐字回旧。
SIGN_TREND_POS_RESO_ON = os.environ.get('SIGN_TREND_POS_RESO_ON', '0') != '0'
SIGN_RESO_POS_LO = float(os.environ.get('SIGN_RESO_POS_LO', '35'))     # 多头「贴底」上限(96根分位%)
SIGN_RESO_POS_HI = float(os.environ.get('SIGN_RESO_POS_HI', '65'))     # 空头「贴顶」下限(96根分位%)
SIGN_RESO_BOOST  = float(os.environ.get('SIGN_RESO_BOOST', '1.0'))     # 共振加成倍率(1.0=不加成)
FUND_LEG_TGT      = float(os.environ.get('FUND_LEG_TGT','0.0'))        # 🪙ED-20260927-246 费率腿专属止盈(%·0=关)
FUND_LEG_STP      = float(os.environ.get('FUND_LEG_STP','0.0'))        # 🪙ED-20260927-246 费率腿专属止损(%·0=关)
HUIZHU_STREAK     = int(os.environ.get('HUIZHU_STREAK','0'))           # 🐚ED-20260927-246 白泽·逐币连亏升温(笔·0=关)
HUIZHU_HOLD_SEC   = int(os.environ.get('HUIZHU_HOLD_SEC','14400'))     #    升温时长(秒·默认4小时)
POOL_COOL_STREAK  = int(os.environ.get('POOL_COOL_STREAK','0'))        # 🦌ED-20260927-246 白鹿·池级连亏冷却(笔·0=关)
POOL_COOL_BARS    = int(os.environ.get('POOL_COOL_BARS','24'))         #    歇多少根15m(默认24根=6小时)

FUND_LEG_TAIL     = float(os.environ.get('FUND_LEG_TAIL','0.05'))      # 🪙ED-20260927-249 费率腿尾部阈值(0.05=旧行为)
FUND_LEG_NO_HUIZHU= os.environ.get('FUND_LEG_NO_HUIZHU','0') != '0'    # 🪙ED-20260927-249 费率腿免疫白泽/白鹿/同币冷却(连亏不计不拦)
FUND_LEG_BYPASS_GATE = os.environ.get('FUND_LEG_BYPASS_GATE','0') != '0'  # 🪙ED-20260927-249 费率腿豁免时段闸/劣时段闸
FUND_LEG_BYPASS_TREND = os.environ.get('FUND_LEG_BYPASS_TREND','0') != '0'  # 🪙ED-20260927-251 费率腿豁免逆势类闸(三态门/逆势空闸/半山腰/宁缺毋滥/衰竭)
# 📶🆕2026-09-27 顶底/半山腰/止损 自适应增强（火印 ED-20260927-253·老板令）
TOPBOT_ADAPT_ON = os.environ.get('TOPBOT_ADAPT_ON','1') != '0'      # 顶底识别自适应(区间位阈值随波动伸缩)
TOPBOT_GATE_ON  = os.environ.get('TOPBOT_GATE_ON','1') != '0'       # 禁顶部追多·禁底部追空
HALFM_ADAPT_ON  = os.environ.get('HALFM_ADAPT_ON','1') != '0'       # 半山腰自适应(非常规禁·常规豁免)
HALFM_TREND_THR = float(os.environ.get('HALFM_TREND_THR','0.5'))    # 4H趋势明确线%(≥=常规放行)
HALFM_IMP_THR   = float(os.environ.get('HALFM_IMP_THR','0.25'))     # 短线推进同向线%(≥=常规放行)
SL_ADAPT_ON     = os.environ.get('SL_ADAPT_ON','1') != '0'          # 止损宽幅自适应(随开仓波动率伸缩)
SL_ADAPT_MIN    = float(os.environ.get('SL_ADAPT_MIN','0.010'))     # 自适应止损下限(夹紧)
# ══ 🐉 烛龙圣裁 · 王袍加身（老板令 2026-09-27 22:56「多币择强·阴阳五行择向·凡与信号判断分析有关者全部加注进入烛龙·一个主意一个声音」·火印 ED-20260927-257）══
#   2026-09-27 23:20 老板令「归类未融入到烛龙的·找出来一并拟合进入烛龙」→ 本块新增 **归类名册 ZHU_ATTR**（逐键归 票/闸/制动/离场/选池/执行/自身 七类）
#   与 **否决闸并入** `_zhulong_veto`（既有链路闸函数只读调用：半山腰·宁缺毋滥·衰竭反追·顶底反追·知止）→ 任一触即 圣裁=hold 且禁新开
#   诸路合议为**一票之声**: 大势门 · 择强 · 阴阳五行择向 · 开明情报 · 白虎哨探 · 触觉军情 · 顶底半山 · 费率腿 · 麒麟制衡(制动)
#   唯一裁决 = long / short / hold / await · 落盘 `_烛龙圣裁.json`（系统只有一枚声音）· 麒麟制衡=制动(日亏半线)·艮8硬熔断仍最高优先
#   默认开: ZHU_EDICT_ON=1 ZHU_EDICT_ENFORCE=1（=0 回旧行为）· 不改既有择向/风控判定
ZHU_EDICT_ON = os.environ.get('ZHU_EDICT_ON', '1') != '0'
# 👑🆕2026-10-06 火印 ED-20261006-516 王上手谕（老板亲令→引擎王令）· 默认关 · 加法不删
WANG_HAND_EDICT_ON = os.environ.get('WANG_HAND_EDICT_ON', '0') != '0'   # 默认关(=0 回旧行为)
_WANG_HAND_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data_v2', 'mtsim', '_王上手谕.json')
_WANG_HAND_CACHE = [0.0, {}]

_WANG_HAND_ACK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data_v2', 'mtsim', '_王令回执.jsonl')
_WANG_HAND_ACK = set()   # 🔁ED-20261006-523: 按"印"去重

def _wang_hand_feed():
    """👑 本户名(取自内核文件名)"""
    try:
        return os.path.basename(os.path.abspath(__file__)).replace('_内核_', '').replace('.py', '')
    except Exception:
        return '?'

def _wang_hand_ack(rec):
    """📮 上行回执(双回链路之上行)"""
    try:
        rec['时刻'] = _time.strftime('%F %T'); rec['户'] = _wang_hand_feed(); rec['进程号'] = os.getpid()
        open(_WANG_HAND_ACK_FILE, 'a', encoding='utf-8').write(_json.dumps(rec, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _wang_hand_seal_ok(seal):
    """🈲 令不乱下: 校验火印是否在印链中(无印/查不到 → 令不生效)"""
    try:
        _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'supreme', '_edict_chain.jsonl')
        _t = open(_p, encoding='utf-8').read()
        return bool(seal) and (str(seal) in _t)
    except Exception:
        return False


def _wang_hand_edict(coin):
    """👑 王上手谕: **烛龙令(火印) → 腾蛇执行** · 只读文件 · **无印不生效** · 异常返回 {}"""
    if not coin:
        return {}
    try:
        _mt = os.path.getmtime(_WANG_HAND_FILE)
    except Exception:
        return {}
    if _mt != _WANG_HAND_CACHE[0]:
        try:
            _d = _json.load(open(_WANG_HAND_FILE, encoding='utf-8'))
        except Exception:
            _d = {}
        _o = {}
        for _it in (_d.get('手谕') or []):
            if isinstance(_it, dict) and _it.get('币'):
                _sk = str(_it.get('火印') or _d.get('火印') or '')
                if not _wang_hand_seal_ok(_sk):
                    continue   # 🈲 令不乱下: 无有效火印 → 令不生效
                _o[str(_it['币']).upper()] = {'verdict': str(_it.get('向') or ''),
                                             'conf': float(_it.get('信') or 0.0),
                                             'why': str(_it.get('据') or ''),
                                             'seal': _sk,
                                             'exec': str(_it.get('执行') or '腾蛇')}
        _WANG_HAND_CACHE[0] = _mt; _WANG_HAND_CACHE[1] = _o
        if _o:
            for _c, _e in _o.items():
                _sk = str((_e or {}).get('seal'))
                if _sk in _WANG_HAND_ACK:
                    continue
                _WANG_HAND_ACK.add(_sk)
                _wang_hand_ack({'类别': '受令', '令': _e['seal'], '币': _c, '向': _e['verdict'],
                                '信': _e['conf'], '执行': _e.get('exec', '腾蛇'), '结果': '已受令(待该币候选即生效)'})
    return _WANG_HAND_CACHE[1].get(str(coin).upper(), {})

ZHU_EDICT_ENFORCE = os.environ.get('ZHU_EDICT_ENFORCE', '1') != '0'
# 🐉🗡🆕ED-20260928-275 顺势而为（老板 15:19「赋予烛龙君顺势而为判断能力，闸门不禁多空大趋势…别又把自己困死」）--
#   修订 ED-274「硬前置」(大势门票==0 即禁开 ⇒ 各币多 0 ⇒ 几乎全禁 ⇒ **会困死自己**·前科可鉴) → **撤**
#   开(=1): ①大势明确且同向 ⇒ **顺势主动放行**(不被“与合议相左”所拦·积极作为) ②逆势 ⇒ 拦 ③**无明确大势 ⇒ 不拦**(交其他路线判断)
#   默认 **0 = 逐字回旧行为**
ZHU_TREND_FOLLOW_ON = os.environ.get('ZHU_TREND_FOLLOW_ON', '0') != '0'
# 🐉🆕ED-20261008-632 王令至上(老板令「天眼及雷达等一切皆无权开仓。择向烛龙」·火印 ED-20261008-632)
#   1=圣裁非「同向 long/short」即禁新开(hold/await ⇒ 无令不开)·0=逐字回旧。回退: env ZHU_EDICT_STRICT=0
#   🧬2026-10-11 火印 ED-20261011-930 定向灌顶进锐(rui·模拟母子异体) —— 此块为移植件
ZHU_EDICT_STRICT = os.environ.get('ZHU_EDICT_STRICT', '1') != '0'
# 📡🆕ED-20260928-277 三兽拟合·多向互联互通（老板 15:24「麒麟(乾坤扭转式)与开明—烛龙—麒麟 三者拟合，多向互联互通…防误伤、护仓守本」）--
#   开(=1): ①开明雷达接通(烛龙「开明情报」票吃雷达真源 side/align/embryo·缺失才回退 last15)
#            ②防误伤护仓(烛龙判**顺势**且未深套 ⇒ 麒麟**不作早断/摆尾**)
#            ③闭环回传(麒麟 flip/cut 写 `_麒麟回执.json` + 进圣裁存档·只作情报·不作新锁)
#   默认 **0 = 逐字回旧行为**
THREE_BEAST_LINK_ON = os.environ.get('THREE_BEAST_LINK_ON', '0') != '0'
# 🐉🐍🦄🆕ED-20260928-278 摆尾**双回流链路**（老板 15:49「正向决策…摆尾搞错，全盘皆输。打通烛龙和腾蛇到麒麟摆尾双回流链路。烛龙出印，腾蛇总裁，麒麟摆尾」）--
#   开(=1): 麒麟四门**反手**须『**烛龙出印**(火印闸) + **腾蛇总裁**(执行层裁决 准)』**双齐**方可摆尾；任一未回 ⇒ 不作反手
#           回流**双写**: 麒麟出手 → `_麒麟回执.json`(烛龙) + `_腾蛇回执.json`(腾蛇)·**只作情报·不作新锁**
#   默认 **0 = 逐字回旧**（只看火印）。硬闸(紧急闸/深套兜底/硬止损) **一律不受本开关影响**。
DUAL_RETURN_LINK_ON = os.environ.get('DUAL_RETURN_LINK_ON', '0') != '0'
_LAST_TS = ['', '']   # 腾蛇总裁最近一次裁决(供回执留痕)
ZHU_EDICT = {'ts': 0.0, 'cycle': 0, 'coin': '', 'verdict': 'await', 'conf': 0.0, 'votes': {}, 'why': '待候选', 'seq': 0}
ZHU_BRAKE = [False]
ZHU_VETO = [False, []]
ZHU_W = {'大势门': 3.0, '择强': 2.0, '阴阳五行': 2.0, '费率腿': 2.0,
         '开明情报': 1.5, '白虎哨探': 1.5, '触觉军情': 1.0, '顶底半山': 1.0}
# ☯🐉2026-10-01 老板令「八路合一·阴阳五行道统·100%接入主导」: 阴阳五行升为**主宰**(定方向)·其余七路降为**参谋**(只加信心·异向不抵销)
#   道统: 太极(心:阴符经/心经 · 法:阴阳五行爻相辨·势位法) ⇒ 唯一至尊义志·不可改变
#   默认 0 = 逐字回旧(八路加权投票)；置 1 = 道统主宰。回退: env 去此变量。
YIJING_YINYANG_SOVEREIGN = os.environ.get('YIJING_YINYANG_SOVEREIGN', '0') != '0'
# 👑🐉ED-20261008-636 王上独立自主择向(老板令「赋予烛龙独立自主择向权，其它一律降权为仅参谋」)
#   1=圣裁方向**只**出自王上自己的「势」; 诸臣(择强/开明/白虎/触觉/顶底/道统)**只作参谋·只加信心·不得定方向**。0=逐字回旧。
#   🧬2026-10-11 火印 ED-20261011-930 定向灌顶进锐(rui·模拟母子异体) —— 此块为移植件
ZHU_SOV_PICK    = os.environ.get('ZHU_SOVEREIGN_PICK', '0') != '0'
ZHU_SOV_PHASE_GATE = os.environ.get('ZHU_SOV_PHASE_GATE', '1') != '0'   # 相位=反 ⇒ 王上不动(与「甲·反币不入场」同向)
ZHU_SOV_ER_MIN  = float(os.environ.get('ZHU_SOV_ER_MIN', '0.06'))   # 势·效率比门槛(实测行情 er≈0.05~0.08)
ZHU_SOV_T4_MIN  = float(os.environ.get('ZHU_SOV_T4_MIN', '0.30'))   # 势·小势门槛(|t4|·16根·%)
ZHU_SOV_T96_MIN = float(os.environ.get('ZHU_SOV_T96_MIN', '0.60'))  # 势·大势门槛(|t96|·96根≈4h·%)
ZHU_SOV_POS_HI  = float(os.environ.get('ZHU_SOV_POS_HI', '85'))     # 势·多头位置上限(不追顶)
ZHU_SOV_POS_LO  = float(os.environ.get('ZHU_SOV_POS_LO', '15'))     # 势·空头位置下限(不接刀)
ZHU_SOV_VOL_CAP = float(os.environ.get('ZHU_SOV_VOL_CAP', '0.70'))  # 势·波动上限(过噪不动)
ZHU_LAST = ['']
ZHU_ATTR = {
    '票·大势门': ["SIGN_REGIME_GATE_ON", "SIGN_ER_MIN", "SIGN_VOL_CAP", "SIGN_T4_MIN2", "SIGN_T96_SAME", "SIGN_RANK_PULL", "SIGN_SAME_DIR_MIN", "SIGN_TREND_FALLBACK_ON", "SIGN_T96_FB_MIN", "SIGN_T4_FB_MIN", "SIGN_FB_POS_HI", "SIGN_FB_POS_LO", "SIGN_TREND_POS_RESO_ON", "SIGN_RESO_POS_LO", "SIGN_RESO_POS_HI", "SIGN_RESO_BOOST"],
    '票·择强': ["SIGN_WAIT_ONE", "SIGN_CHASE_M1_MAX", "SIGN_PULL_MIN", "CHASE_LONG_GATE_ON", "CHASE_LONG_T4L", "PICK_ABS_MIN", "ENTRY_SCORE100_MIN"],
    '票·阴阳五行': ["YIJING_GATE_ON", "YIJING_TIAN_EFF", "YIJING_REN_SCORE", "WUXING_SAMPLE_F", "WUXING_SNAP_F", "WUXING_STATE_F", "WUXING_COUNTER_F", "SANT_GATE_ON", "SANT_YIN_ON", "SANT_YIN_SCORE", "SANT_CERT_MIN", "SANT_DIVG_MIN", "SANT_CHAOS_ON"],
    '票·开明/白虎/触觉': ["WATCH_COINS_ONLY", "SIGN_POS_BAND_ON", "SIGN_POS_BAND_LO", "SIGN_POS_BAND_HI", "DIRCHK_CERT", "DIRCHK_REV", "DIRCHK_WINDOW", "DIRCHK_LEGACY", "DIR_PRECISE_MIN", "DIR_PRECISE_LEGACY"],
    '票·鼎与中枢关': ["ZHONGSHU_ENTRY_GATE_ON", "ZHONGSHU_PULLBACK_ON", "ZHONGSHU_PULLBACK_MIN", "ZHONGSHU_PULLBACK_PCT", "ZHONGSHU_PULLBACK_ADAPT_ON", "ZHONGSHU_POS_MAX", "ZHONGSHU_SPD_MAX", "ZHONGSHU_DIV_MAX", "REOPEN_COOLDOWN", "COIN_REOPEN_COOLDOWN"],
    '票·费率腿': ["FUND_LEG_ON", "FUND_LEG_TGT", "FUND_LEG_STP", "FUND_LEG_TAIL", "FUND_LEG_NO_HUIZHU", "FUND_LEG_BYPASS_GATE", "FUND_LEG_BYPASS_TREND"],
    '闸·顶底半山宁缺': ["TOPBOT_ADAPT_ON", "TOPBOT_GATE_ON", "TOPBOT_ZONE", "HALFM_ADAPT_ON", "HALFM_TREND_THR", "HALFM_IMP_THR", "QUALITY_AMP6_MIN", "RANGE_AMP", "RANGE_EXHAUST", "RANGE_POS_LO", "RANGE_POS_HI", "TOPBOT_ZONE_HI", "TOPBOT_ADAPT_MAX", "SIGN_HALF_BAND_LO", "SIGN_HALF_BAND_HI", "SIGN_TOP_BAN_ON", "SIGN_TOP_BAN_POS"],
    '闸·觉悟体用药五': ["JUE_AWARE_ON", "JUE_SPECTRUM_ON", "JUE_DRIFT_ON", "JUE_THROTTLE_ON", "JUE_HOLD_BASE", "JUE_THR_BASE", "JUE_RATIO_MIN", "JUE_RATIO_MAX", "JUE_GRAY_PCT", "JUE_AXIOM_LOCK", "JUE_Y5_ON", "JUE_Y5_BOOST", "JUE_Y5_CONF_MIN"],
    '闸·混沌态': ["HUNDUN_ON", "HUNDUN_SNR_MIN", "HUNDUN_PROBE_MIN_SCORE", "HUNDUN_PROBE_SCALE", "HUNDUN_TIMEOUT_SEC", "HUNDUN_EVOLVE_F", "HUNDUN_LEDGER_F", "HUNDUN_OBS_F", "HUNDUN_FLIP_N"],
    '闸·麒麟与融合': ["QILIN_ADAPT_ON", "QILIN_ADAPT_MIN", "QILIN_ADAPT_MAX", "QILIN_ADAPT_NEAR", "QILIN_SENS_ON", "QILIN_SENS_CERT", "QILIN_SENS_LOSS", "QILIN_TURN_HOLD_ON", "QILIN_RETREAT_ON", "DUAL_CHAIN_ON", "SK_GENE_ON", "FLEX_ON", "RADAR_W_ALIGN", "TACTILE_W", "THREE_BEAST_LINK_ON", "DUAL_RETURN_LINK_ON"],
    '制动·护本': ["QILIN_EMERGENCY_STOP", "QILIN_LAST_DEFENSE", "QILIN_HALFMOUNT_CUT", "DEEPWATER_CUT_PCT", "HUNDUN_FREEZE_ON", "FAST_CRASH_ON", "FAST_CRASH_BAR", "ZHULONG_SEAL_STRONG", "ZHULONG_SEAL_CERT", "SL_ADAPT_ON", "SL_ADAPT_MIN"],
    '离场·退出档': ["LOCK_START_PCT", "GIVE_BACK_FRAC", "GIVE_CAP_PCT", "GIVE_FLOOR_PCT", "BIG_MEAT_PCT", "TARGET_PCT", "TRAIL_START", "TRAIL_FLOOR_PCT", "TRAIL_LEG_FLOOR", "HI_STEP_LOCK", "MIN_HOLD_SEC", "JCH_ADAPT_ON", "JCH_ADAPT_LO", "JCH_ADAPT_HI", "JCH_ADAPT_PW", "JCH_ADAPT_T4", "JCH_FIRST_PCT", "QIAN_CAP_RATIO"],
    '选池·记忆': ["POOL_COOL_STREAK", "POOL_COOL_BARS", "HUIZHU_STREAK", "HUIZHU_HOLD_SEC"],
    '执行·系统': ["CYCLE_SLEEP", "FAST_HOLD_SLEEP", "POOL", "LEVER", "PAPER", "OPEN_WHEN_ALLHOT"],
    '自身·圣裁与方阵': ["ZHU_EDICT_ON", "ZHU_EDICT_ENFORCE", "ZHU_TREND_FOLLOW_ON", "JIU_GONG_ON", "JG_FUSE_FORCE"],
}


def _zg_bucket(k):
    """归类查询: 任一开关归入七类之一(名册唯一·零遗漏)"""
    for _b, _ks in ZHU_ATTR.items():
        if k in _ks:
            return _b
    return ''



# ─────────── 🔪相位刀(ED-387·根治) ───────────
_PHASE_CACHE = {'mt': None, 'd': {}}

# 🌀🌀2026-10-07 火印 ED-20261007-558 相位精修: 分市况相位 + 鲜度校验（**默认关·零行为变化**）
_PHASE_XT = {'mt': None, 'd': {}}
_SITAI_CACHE = {'mt': None, 'd': {}}


def _si_tai_now(coin):
    """现市况四态（读 多空源五行扫描档）"""
    try:
        _base = os.path.dirname(os.path.abspath(__file__))
        _f = ''
        for _c in (os.path.join(_base, '..', 'data_v2', 'mtsim', '_多空源五行_扫描.json'),
                   os.path.join(_base, 'data_v2', 'mtsim', '_多空源五行_扫描.json')):
            if os.path.exists(_c):
                _f = _c; break
        if not _f:
            return None
        _mt = os.path.getmtime(_f)
        if _mt != _SITAI_CACHE['mt']:
            _d = json.load(open(_f, encoding='utf-8')) or {}
            _SITAI_CACHE['d'] = {str(_r.get('币')).upper(): _r.get('四态')
                                 for _r in (_d.get('共识表') or []) if isinstance(_r, dict)}
            _SITAI_CACHE['mt'] = _mt
        return _SITAI_CACHE['d'].get(str(coin).upper())
    except Exception:
        return None


def _phase_xt(coin, _p):
    """按 分市况相位/鲜度 修正相位（开关关 ⇒ 原样返回）"""
    try:
        _reg = os.environ.get('PHASE_REGIME_ON', '0') == '1'
        _fre = os.environ.get('PHASE_FRESH_ON', '0') == '1'
        if not (_reg or _fre):
            return _p
        _base = os.path.dirname(os.path.abspath(__file__))
        _f = ''
        for _c in (os.path.join(_base, '..', 'data_v2', 'mtsim', '_相位_分市况.json'),
                   os.path.join(_base, 'data_v2', 'mtsim', '_相位_分市况.json')):
            if os.path.exists(_c):
                _f = _c; break
        if not _f:
            return _p
        _mt = os.path.getmtime(_f)
        if _mt != _PHASE_XT['mt']:
            _PHASE_XT['d'] = (json.load(open(_f, encoding='utf-8')) or {}).get('币') or {}
            _PHASE_XT['mt'] = _mt
        _x = _PHASE_XT['d'].get(str(coin).upper())
        if not _x:
            return _p
        _p = dict(_p or {})
        _src = []
        if _reg:
            _st = _si_tai_now(coin)
            _v = ((_x.get('分市况') or {}).get(_st) or {}) if _st else {}
            if _v.get('相位'):
                _p['相位'] = _v['相位']; _p['同向率'] = _v.get('同向率'); _src.append('分市况:' + str(_st))
        if _fre:
            _fr = _x.get('鲜度') or {}
            if _fr.get('疑陈旧') and _fr.get('近窗相位'):
                _p['相位'] = _fr['近窗相位']; _p['同向率'] = _fr.get('近50'); _src.append('鲜度近窗')
        if _src:
            _p['相位源'] = '·'.join(_src)
        return _p
    except Exception:
        return _p

def _phase_of(coin):
    """读相位表 → {'相位': 顺/反/观望, ...} or None(缺表)"""
    try:
        _base = os.path.dirname(os.path.abspath(__file__))
        _f = ''
        for _cand in (os.path.join(_base, 'data_v2', 'mtsim', '_相位表.json'),
                      os.path.join(_base, '..', 'data_v2', 'mtsim', '_相位表.json'),
                      os.path.join(_base, '..', '..', 'data_v2', 'mtsim', '_相位表.json')):
            if os.path.exists(_cand):
                _f = _cand; break
        if not _f:
            return None
        _mt = os.path.getmtime(_f)
        if _mt != _PHASE_CACHE.get('mt'):
            _PHASE_CACHE['d'] = (json.load(open(_f, encoding='utf-8')) or {}).get('币') or {}
            _PHASE_CACHE['mt'] = _mt
        return _phase_xt(coin, _PHASE_CACHE['d'].get(coin))
    except Exception:
        return None

def _phase_sign(coin):
    """反(翻正) ⇒ -1; 其余 ⇒ +1"""
    try:
        _p = _phase_of(coin) or {}
        return -1 if _p.get('相位') == '反' else 1
    except Exception:
        return 1

def _yinyang_sovereign(st, sig):
    """☯🐉 阴阳五行道统·主宰裁决（2026-10-01 老板令「八路合一·阴阳五行道统·100%接入主导」）
    道统=太极(心:阴符经/心经, 法:阴阳五行爻相辨·势位法) ⇒ 唯一定方向者；其余七路只能加成/制动。
    返回: (方向 long/short/await, 信心0~1, 卦象说明)
        · 阴阳五行 ON(YIJING_YINYANG_SOVEREIGN) 时：三才(天/地/人)判阴阳定乾坤
        · 关时：回旧口径(吃 tp 顶底位)· 兼容零行为变化
    回退: env 去 YIJING_YINYANG_SOVEREIGN → 逐字回旧
    """
    if not YIJING_YINYANG_SOVEREIGN:
        _tp = str((sig or {}).get('tp') or '').upper()
        _d = 'long' if _tp in ('UP', 'LONG') else ('short' if _tp in ('DOWN', 'SHORT') else 'await')
        return _d, (0.5 if _d != 'await' else 0.0), '爻相(旧)·tp=%s' % _tp
    try:
        # ㈠ 三才之象: 天(池均效率比 er) · 地(池均位) · 人(信号号 strength)
        _tian, _di, _e, _p = _yijing_tai()
        _sc = abs(float((sig or {}).get('score', 0) or 0))
        _ren = '有号' if _sc >= YIJING_REN_SCORE else '无号'
        # 🔪ED-393·乙 相位分门: "反"币靠**位置极值**定"有号"(反转要极端位置, 不要趋势强度)
        if SIGN_PHASE_SPLIT_ON and (_phase_of((sig or {}).get('coin')) or {}).get('相位') == '反':
            _pv0 = 50.0
            try:
                _po = (_sign_pool_obs() or {}).get((sig or {}).get('coin')) or {}
                _pv0 = float(_po.get('pos') or 50)
            except Exception:
                _pv0 = 50.0
            if (_pv0 >= SIGN_REV_POS_HI) or (_pv0 <= SIGN_REV_POS_LO):
                _ren = '有号'
                _rev_ext = _pv0
        # ㈡ 方向主权: 单币 t4 定乾坤(道统主币之向); 混沌/三才缺 ⇒ await(宁缺毋滥)
        _t4 = float((sig or {}).get('t4') or 0)
        _er = float((sig or {}).get('er') or 0)
        try:
            _zv = (_sign_pool_obs() or {}).get((sig or {}).get('coin')) or {}
            if _zv:
                _t4 = float(_zv.get('t4') or _t4)
                _er = float(_zv.get('er') or _er)
        except Exception:
            pass
        # 阴/阳: t4 定阴阳(阳=多/阴=空); 三才缺或混沌 ⇒ await
        if _ren == '无号':
            return 'await', 0.0, '人无号(号弱)·await'
        # 🔪甲刀(ED-384): **单币** ER 门无条件生效 —— 旧码只在「天不明」时查 er ⇒ 池均一判"天明"整段跳过
        #   ⇒ 单币 er=0.01 纯噪音也判向开仓(今日 9/9 反向单皆由此漏出) ⇒ 无趋势不做。
        # 🔪ED-393 相位分门: "反"币做的是反转 —— 要的是价格走极端, 不是趋势 ⇒ 趋势门对它不适用(改由位置极值门把关)
        _pc = ''
        try:
            _pc = (sig or {}).get('coin') if isinstance(sig, dict) else ''
        except Exception:
            _pc = ''
        _is_rev = bool(SIGN_PHASE_SPLIT_ON and (_phase_of(_pc) or {}).get('相位') == '反')
        if SIGN_ER_GATE_HARD_ON and abs(_er) < SIGN_ER_MIN and not _is_rev:
            return 'await', 0.0, '单币er%.2f<门%.2f·无趋势不做' % (abs(_er), SIGN_ER_MIN)
        if _tian != '明' and abs(_er) < (SIGN_ER_MIN):
            return 'await', 0.0, '天不明+无势·await(天地混沌)'
        _d = 'long' if _t4 > 0 else ('short' if _t4 < 0 else 'await')
        # 🔪乙刀(ED-384): 近端同向确认 —— 治"滞后动量追单"(t4 是过去4H涨跌·价格一反弹就反)。
        if SIGN_NEAR_CONFIRM_ON and _d in ('long', 'short'):
            try:
                _m1p = float((_zv or {}).get('m1') or 0.0)
            except Exception:
                _m1p = 0.0
            if (_d == 'short' and _m1p >= SIGN_NEAR_MIN) or (_d == 'long' and _m1p <= -SIGN_NEAR_MIN):
                return 'await', 0.0, '近端反向(末根15m %+.2f%% ≥ %.2f%%)·待确认' % (_m1p, SIGN_NEAR_MIN)
        # 🔪丁刀(ED-386): 长窗大势同向 —— 治"用4小时回抽逆3日主势"(SOL 3日+2.21%却被判空)。
        if SIGN_TREND_ALIGN_ON and _d in ('long', 'short'):
            try:
                _t96 = float((_zv or {}).get('t96') or 0.0)
            except Exception:
                _t96 = 0.0
            if (_d == 'short' and _t96 > 0) or (_d == 'long' and _t96 < 0):
                return 'await', 0.0, '逆大势(24h %+.2f%%)·不做' % _t96
        if _d == 'await':
            return 'await', 0.0, '爻相无向·await'
        # ㈢ 信心: 由 天(效率比) · 地(位) · 人(号) 三象合算
        _cf = 0.5
        _cf += 0.2 if _tian == '明' else 0.0                          # 天清
        _cf += 0.2 * min(1.0, _sc / max(YIJING_REN_SCORE, 0.1))
        if YIJING_CF_ER_ON:
            _cf += 0.15 * min(1.0, abs(_er) / 0.25)   # 🔪丙刀(ED-384): 趋势越清(er高)信越高 ⇒ 真趋势单优选/加码        # 人号强
        # 地: 顺势位更佳(多单在低/中位·空单在高/中位)
        _pos = float(_p if _p else 50)
        if (_d == 'long' and _pos <= 65) or (_d == 'short' and _pos >= 35):
            _cf += 0.1
        _cf = round(max(0.0, min(1.0, _cf)), 3)
        return _d, _cf, '三才 天%s/地%s/人%s · t4%.2f er%.2f' % (_tian, _di, _ren, _t4, _er)
    except Exception as _e3:
        return 'await', 0.0, '道统异常·await(%s)' % _e3


def _sovereign_first_pick(st):
    """☯🐉 道统先导择向（2026-10-01 老板令「重排架构·阴阳五行道统站第一岗」·火印 ED-20261001-366 续）
    病: 旧序「候选→择强闸(净分≥1.0)→...→道统」 ⇒ 道统坐最后岗, 前面几道门先把候选筛光 ⇒ 主宰形同虚设。
    治: SOVEREIGN=1 且 _pick() 无候选时, 由道统(三才)定乾坤 → 在**顺势币**里选最强 → 交下游闸(共振/市况/否决)把关。
    返回 sig(dict·兼容下游) 或 None。回退: YIJING_YINYANG_SOVEREIGN=0 → 本函数不参与(逐字回旧)。
    """
    if not YIJING_YINYANG_SOVEREIGN:
        return None
    try:
        _tian, _di, _e, _p = _yijing_tai()
        if _tian != '明':
            return None                      # 天不明(池均无效率) ⇒ 大势混沌, 不出手(宁缺毋滥)
        # 道统定乾坤方向: 池均 t4 定阴阳(阳=多/阴=空)
        _obs = _sign_pool_obs() or {}
        _t4s = [float((_obs.get(_c) or {}).get('t4') or 0) for _c in WATCH_COINS if _obs.get(_c)]
        if not _t4s:
            return None
        _pool_t4 = sum(_t4s) / len(_t4s)
        if _pool_t4 == 0:
            return None
        _sov_dir = 'long' if _pool_t4 > 0 else 'short'
        # 在顺势币里选最强(道统-implied bar·非死死 PICK_ABS_MIN):
        #   ①币自身 t4 与道统向同号 ②|t4|≥道统门槛(自适应·用 SIGN_T4_MIN2 的 1/2 作下限, 保证能选出) ③score 同号
        _tbar = max(0.3, float(SIGN_T4_MIN2) * 0.5)
        _best = None; _bestk = -1e9
        for _c in _wang_edict_only(list(WATCH_COINS)):   # 👑2026-10-10 王令至上(ED-20261010-827)
            _s = _LAST_SIGS.get(_c)
            if not _s:
                try: _s = _coin_sig(_c)
                except Exception: _s = None
            if not _s: continue
            _t4 = float(_s.get('t4') or 0)
            _sc = float(_s.get('score') or 0)
            _same = (_t4 > 0 and _sov_dir == 'long') or (_t4 < 0 and _sov_dir == 'short')
            if not _same: continue
            # 🔪丁刀(ED-386): 长窗大势同向 —— 逆主势的候选在**源头**剔掉(不再靠下游闸兜)。
            if SIGN_TREND_ALIGN_ON:
                _t96v = float((_obs.get(_c) or {}).get('t96') or 0.0)
                if (_sov_dir == 'long' and _t96v < 0) or (_sov_dir == 'short' and _t96v > 0):
                    continue
            if abs(_t4) < _tbar: continue
            if (_sc > 0 and _sov_dir != 'long') or (_sc < 0 and _sov_dir != 'short'):
                continue                      # 净分反号 ⇒ 近端衰减, 弃
            # 🆕2026-10-01 顺道统但避极端位(治“道统先导总选同一币→又被顶底闸拦死”):
            #   多单不在区间顶(pos4>77)、空单不在区间底(pos4<23) —— 与下游顶底闸同向, 前置避让。
            _p4 = float(_s.get('pos4') or 50)
            if _sov_dir == 'long' and _p4 > 77: continue
            if _sov_dir == 'short' and _p4 < 23: continue
            # 🆕2026-10-01 币自身 regime 不得为 chop(与三态门/混沌守无门同向·前置避让):
            #   道统天清(池均趋势)但要选的币自身不能是震荡(chop), 否则被三态门拒开 ⇒ 白选。
            _rg = str(_s.get('regime') or '')
            if _rg == 'chop': continue
            if _sov_dir == 'long' and _rg == 'dn': continue
            if _sov_dir == 'short' and _rg == 'up': continue
            _k = abs(_t4) + 0.3 * abs(_sc) + 0.5 * min(5.0, float(_s.get('amp6') or 0))   # 强度=大势动+净分+有肉(振幅)
            if _k > _bestk:
                _bestk = _k; _best = _s
        if not _best:
            return None
        _best = dict(_best)
        _best['side'] = _sov_dir
        _best['_sovereign'] = True
        # ☯2026-10-01 老板令「知止闸+顶底闸并入道统」: 道统先导单补齐离场字段(止盈向) ⇒ 过知止闸
        #   道统已定乾坤(天清·顺势) ⇒ tp 随道统方向标(UP=多/DOWN=空)·保证离场集合完整。
        _best['tp'] = 'UP' if _sov_dir == 'long' else 'DOWN'
        if abs(float(_best.get('score') or 0)) < YIJING_REN_SCORE:
            # 人号弱: 道统仍定乾坤(天清·顺势), 但补一个最低净分信号供下游识别(不造方向, 仅标识)
            _best['score'] = float(_best.get('score') or 0) or (0.1 if _sov_dir == 'long' else -0.1)
        log('☯🐉 道统先导: 天%s/地%s 池均t4%.2f → 定%s · 选 %s(混t4%.2f 号%.2f)' % (
            _tian, _di, _pool_t4, {'long': '多', 'short': '空'}[_sov_dir],
            _best.get('coin'), float(_best.get('t4') or 0), float(_best.get('score') or 0)))
        return _best
    except Exception as _e4:
        log('☯ 道统先导异常(回旧): %s' % _e4)
        return None


# ═══ 🌀 ED-20261003-398 五行相克·方向级入闸（老板令「法不显化？需治」·按奈工最优方案）═══
#   道统「阴阳五行当家」的**五行半**：相生=助攻(如ED-397沙箱实测:只乘排序分·翻不动方向⇒空转)，
#   **相克=制衡**(本令)。该方向**近端样本足够且胜率不足** ⇒ **不背书·拦新开**。
#   **自适应·自熄**: 胜率回升即自动放行(非死规则) ⇒ 自生进化。
#   **边界**: 挂 `_zhulong_veto` → 只被 `_open_paper` 调用 ⇒ **只拦新开·绝不碰持仓/止损/平仓**；
#          env 默认 0 = 旧行为；判定链其余一字不动。回退: 删/置0 本三常量。
WUXING_VETO_ON  = os.environ.get('WUXING_VETO_ON', '0') != '0'
WUXING_VETO_WIN = float(os.environ.get('WUXING_VETO_WIN', '0.45'))   # 该方向近端样本胜率下限
WUXING_VETO_N   = int(os.environ.get('WUXING_VETO_N', '24'))         # 最小样本数


def _wuxing_side_veto(sig):
    """🌀 五行相克·方向否决(ED-398): 拟开方向近端胜率不足 ⇒ 不背书。只读快照·绝不改判定链其余。"""
    if not (WUXING_VETO_ON and sig):
        return False
    try:
        _sd = str((sig or {}).get('side') or '')
        if _sd not in ('long', 'short'):
            return False
        _k = '多' if _sd == 'long' else '空'
        if not os.path.exists(WUXING_SNAP_F):
            return False
        _j = json.load(open(WUXING_SNAP_F, encoding='utf-8'))
        _n = int(_j.get('样本数_' + _k) or 0)
        _wr = float(_j.get('胜率_' + _k) or 0.0)
        if _n >= WUXING_VETO_N and _wr < WUXING_VETO_WIN:
            try:
                _wuxing_tick('相克·方向否决')
            except Exception:
                pass
            try:
                log('🌀 五行相克·方向否决: 拟%s · 该方向近%d笔胜率%.0f%%<%.0f%% ⇒ 不背书(拦新开)'
                    % (_sd, _n, _wr * 100, WUXING_VETO_WIN * 100))
            except Exception:
                pass
            return True
    except Exception:
        return False
    return False


def _zhulong_veto(st, sig):
    """🚪 并入圣裁的**否决闸**(既有链路闸函数·只读调用): 任一触发 → 圣裁=hold + 禁新开。费率腿豁免(ED-251 结构性信号另册)"""
    ZHU_VETO[0] = False
    ZHU_VETO[1] = []
    try:
        if not (ZHU_EDICT_ON and sig):
            return []
        if sig.get('_fund_leg'):
            return []
        _hits = []
        # 🧪2026-10-04 火印 ED-20261004-449（承 ED-443·三臂与六户同代）:
        #   「人有号」时 半山腰/宁缺毋滥/衰竭反追/顶底反追 四道位置类闸降为提示(不拦)；知止/五行相克照旧。
        #   开关 VETO_SOFT_ON(默认0=逐字回旧·零外溢)
        _softv = False
        if os.environ.get('VETO_SOFT_ON', '0') != '0':
            try:
                _softv = abs(float(sig.get('score') or 0)) >= float(os.environ.get('VETO_SOFT_SCORE', '1.0'))
                if not _softv and SIGN_PHASE_SPLIT_ON and (_phase_of(sig.get('coin')) or {}).get('相位') == '反':
                    _po = (_sign_pool_obs() or {}).get(sig.get('coin')) or {}
                    _pv = float(_po.get('pos') or 50)
                    if _pv >= SIGN_REV_POS_HI or _pv <= SIGN_REV_POS_LO:
                        _softv = True
            except Exception:
                _softv = False
        for _nm, _fn in (('半山腰', '_halfmountain_block'), ('宁缺毋滥', '_quality_block'),
                         ('衰竭反追', '_exhaust_rechase_block'), ('顶底反追', '_topbot_rechase_block')):
            if _softv:
                continue
            try:
                _f = globals().get(_fn)
                if _f and _f(sig):
                    _hits.append(_nm)
            except Exception:
                pass
        try:
            if _wuxing_side_veto(sig):
                _hits.append('五行相克')
        except Exception:
            pass
        try:
            if not _zhizhi_ok(sig):
                _hits.append('知止')
        except Exception:
            pass
        ZHU_VETO[0] = bool(_hits)
        ZHU_VETO[1] = _hits
    except Exception:
        pass
    return ZHU_VETO[1]


def _sovereign_pick(st, sig, _votes):
    """👑🐉 王上独立自主择向(2026-10-08 老板令「赋予烛龙独立自主择向权，其它一律降权为仅参谋」)
       方向**只**出自王上自己的「势」: 大势(96根≈4h t96) · 小势(16根 t4) · 效率比 er · 位置 pos · 波动 vol · 相位表。
       诸臣(择强/开明情报/白虎哨探/触觉军情/顶底半山/阴阳五行道统)**只加信心·不得定方向**(异向不减)。
       麒麟制衡仍只作制动。返回 (方向, 信心, 缘由)。
       🧬2026-10-11 火印 ED-20261011-930 定向灌顶进锐(rui·模拟母子异体) —— 此函数为移植件。"""
    _coin = ''
    try:
        _coin = str(sig.get('coin') or '').upper()
    except Exception:
        pass
    try:
        if ZHU_SOV_PHASE_GATE and ((_phase_of(_coin) or {}).get('相位') == '反'):
            return ('hold' if sig else 'await', 0.0, '王上独裁·相位反(不动)')
    except Exception:
        pass
    er = t4 = t96 = pos = vol = None
    try:
        _zv = (_sign_pool_obs() or {}).get(_coin) or {}
        if _zv:
            er = float(_zv.get('er') or 0); t4 = float(_zv.get('t4') or 0)
            t96 = float(_zv.get('t96') or 0); pos = float(_zv.get('pos') if _zv.get('pos') is not None else 50)
            vol = abs(float(_zv.get('vol') or 0))
    except Exception:
        pass
    if er is None:
        try:
            er = float(sig.get('er') or 0); t4 = float(sig.get('t4') or 0)
            t96 = float(sig.get('t96') or 0); pos = float(sig.get('pos4') or 50); vol = 0.0
        except Exception:
            return ('hold' if sig else 'await', 0.0, '王上独裁·势不可读')
    _sgn = 0
    _why2 = ''
    if abs(er) >= ZHU_SOV_ER_MIN and abs(t4) >= ZHU_SOV_T4_MIN and abs(t96) >= ZHU_SOV_T96_MIN:
        if (t4 > 0) == (t96 > 0):
            _sgn = 1 if t4 > 0 else -1
    else:
        # 🌊大势回补口径: er 不足(震荡) 但大小窗同向且幅度够 ⇒ 仍判势
        if (abs(t4) >= max(ZHU_SOV_T4_MIN, 0.50)) and (abs(t96) >= max(ZHU_SOV_T96_MIN, 0.80)) and ((t96 > 0) == (t4 > 0)):
            _sgn = 1 if t4 > 0 else -1
            _why2 = '·回补'
    if _sgn != 0 and ZHU_SOV_VOL_CAP > 0 and vol is not None and vol > ZHU_SOV_VOL_CAP:
        _sgn = 0
        _why2 = '·波动过噪'
    if _sgn > 0 and pos is not None and pos > ZHU_SOV_POS_HI:
        _sgn = 0
        _why2 = '·不追顶'
    if _sgn < 0 and pos is not None and pos < ZHU_SOV_POS_LO:
        _sgn = 0
        _why2 = '·不接刀'
    if _sgn == 0:
        return ('hold' if sig else 'await', 0.0,
                '王上独裁·势不足%s t96%.2f t4%.2f er%.2f 位%.0f' % (_why2, t96, t4, er, pos if pos is not None else 50))
    _cf = (0.5 + 0.3 * min(1.0, abs(er) / max(ZHU_SOV_ER_MIN, 1e-9) / 2.0)
           + 0.2 * min(1.0, abs(t96) / max(ZHU_SOV_T96_MIN, 1e-9) / 3.0))
    try:
        _ag = sum(1 for _k, _v in _votes.items() if _v['v'] != 0 and ((_v['v'] > 0) == (_sgn > 0)) and _k != '麒麟制衡')
        _tt = sum(1 for _k, _v in _votes.items() if _v['v'] != 0 and _k != '麒麟制衡')
        if _tt > 0:
            _cf += 0.1 * (_ag / float(_tt))
    except Exception:
        pass
    _cf = round(max(0.0, min(1.0, _cf)), 3)
    _vd = 'long' if _sgn > 0 else 'short'
    _cm = ' '.join('%s%s' % (_k, '+' if _v['v'] > 0 else ('-' if _v['v'] < 0 else '0'))
                   for _k, _v in _votes.items() if _k != '阴阳五行')
    _why = '王上独裁·大势%.2f/小势%.2f/效率%.2f/位%.0f%s | 参谋 %s' % (t96, t4, er, pos if pos is not None else 50, _why2, _cm)
    return (_vd, _cf, _why)


# ═══════════════════════════════════════════════════════════════════════════
# 👑🔥 王令至上 · 择向降权为奴仆（2026-10-10 老板令「令择向擎降权为奴仆，王令至上，
#   让"有王令的币"优先进入开仓候选」·火印 ED-20261010-827）· 铸印 2026-10-10 15:10
#   令意: 诸臣(择强/共振/开明/白虎/触觉/顶底/阴阳五行)一律降为奴仆·
#         **凡王已下火印手谕之币 ⇒ 直接置顶候选**；王令在册之币若未入候选 ⇒ 补入候选。
#   边界: 只改「候选取舍」·**不改方向**(方向仍出自王上自己的势) · 无王令币则逐字回旧。
#   回退: env WANG_EDICT_FIRST=0 → 逐字回旧行为(不动内核一字)。
# ═══════════════════════════════════════════════════════════════════════════
WANG_EDICT_FIRST = os.environ.get('WANG_EDICT_FIRST', '1') != '0'


def _wang_edict_first(pool):
    """👑 王令至上: 有王令之币优先进入候选(已在池者留·未入池者补) ⇒ 只从王令币中择。无王令币则原样返回。"""
    if not WANG_EDICT_FIRST:
        return pool
    try:
        _out = []; _seen = set()
        for _s in (pool or []):
            _c = str((_s or {}).get('coin') or '').upper()
            if _c and _wang_hand_edict(_c):
                _out.append(_s); _seen.add(_c)
        _add = []
        for _c in list(WATCH_COINS):
            _c = str(_c).upper()
            if _c in _seen:
                continue
            _e = _wang_hand_edict(_c)
            if not _e:
                continue
            _s = None
            try:
                _s = dict(_LAST_SIGS.get(_c) or {}) or None
            except Exception:
                _s = None
            if not _s:
                try:
                    _s = _coin_sig(_c)
                except Exception:
                    _s = None
            if not _s:
                continue
            _s = dict(_s)
            _s['side'] = str(_e.get('verdict') or _s.get('side') or '')
            _add.append(_s)
        if _out or _add:
            log('👑 王令至上(择向降权为奴仆): 王令币优先候选 · 在池%d 补入%d → %s' % (
                len(_out), len(_add), ','.join(str(x.get('coin')) for x in (_out + _add))))
            return _out + _add
        log('👑 王令至上: 候选%d 皆无王令 → 诸臣只作参谋(回旧口径)' % len(pool or []))
    except Exception as _e9:
        log('👑 王令至上异常(回旧): %s' % _e9)
    return pool


def _wang_edict_only(coins):
    """👑 王令至上: 只留有王令之币(供道统先导); 无一有令则原样返回(逐字回旧)。"""
    if not WANG_EDICT_FIRST:
        return list(coins)
    try:
        _k = [_c for _c in coins if _wang_hand_edict(str(_c).upper())]
        if _k:
            log('👑 王令至上(道统先导): 只在王令币中择 → %s' % ','.join(str(x) for x in _k))
            return _k
    except Exception:
        pass
    return list(coins)


def _zhulong_edict(st, sig=None, decide=False):
    """🐉 诸路(vote=-1/0/+1) → 加权合议 → 唯一圣裁(一个主意)。麒麟制衡=制动不投票向；否决闸并入。decide=True 只算不落盘"""
    if not ZHU_EDICT_ON:
        return ('hold', 0.0, '圣裁关')
    _votes = {}
    if sig:
        def _put(_n, _v, _w):
            _votes[_n] = {'v': int(_v), 'why': str(_w)[:22]}
        _s = float(sig.get('score') or 0)
        _t4 = float(sig.get('t4') or 0)
        _er = float(sig.get('er') or 0)
        # 🐉2026-09-28 13:43 老板令「激活烛龙已拟合兼容的择向新基因功能，增强烛龙大趋势判断」→ 裁「甲。准」(火印 ED-20260928-269)
        #   病: sig(_coin_sig) 不含 er ⇒ 旧票恒判 0(大趋势判断空转)。治: 读**池内全观测**(er/vol/t96/t4) + **已拟合择向基因**(SIGN_*)方投方向。
        #   兼容·可关: SIGN_REGIME_GATE_ON=0 → 逐字回旧口径(|er|≥0.15)。
        _ZERM = (SIGN_ER_MIN if SIGN_REGIME_GATE_ON else 0.15)
        _ZT4M = (SIGN_T4_MIN2 if SIGN_REGIME_GATE_ON else 0.0)
        _ZV, _ZT96, _ZPOS = None, None, None
        if SIGN_REGIME_GATE_ON:
            try:
                _zv = (_sign_pool_obs() or {}).get(sig.get('coin')) or {}
                if _zv:
                    _er = float(_zv.get('er') or _er)
                    _t4 = float(_zv.get('t4') or _t4)
                    _ZV, _ZT96 = _zv.get('vol'), _zv.get('t96')
                    _ZPOS = _zv.get('pos')
            except Exception:
                pass
        _zok = (abs(_er) >= _ZERM) and (abs(_t4) >= _ZT4M)
        if SIGN_REGIME_GATE_ON:
            try:
                if SIGN_VOL_CAP > 0 and abs(float(_ZV or 0)) > SIGN_VOL_CAP:
                    _zok = False
            except Exception:
                pass
            if SIGN_T96_SAME:
                try:
                    _z96 = float(_ZT96 or 0)
                    if _z96 and ((_z96 > 0) != (_t4 > 0)):
                        _zok = False
                except Exception:
                    pass
        # 🧬🆕ED-20260928-289 大势门·震荡回补(补全新基因触发链路): er 不足(震荡) 但 大小窗同向 且 不贴极端位 且 波动不过阈 ⇒ 回补判势
        if (not _zok) and SIGN_REGIME_GATE_ON and SIGN_TREND_FALLBACK_ON:
            try:
                _z96f = float(_ZT96 or 0)
                _posf = float(_ZPOS if _ZPOS is not None else 50)
                _volf = abs(float(_ZV or 0))
                _okf = ((abs(_t4) >= SIGN_T4_FB_MIN) and (abs(_z96f) >= SIGN_T96_FB_MIN)
                        and ((_z96f > 0) == (_t4 > 0))
                        and ((_t4 > 0 and _posf <= SIGN_FB_POS_HI) or (_t4 < 0 and _posf >= SIGN_FB_POS_LO))
                        and (SIGN_VOL_CAP <= 0 or _volf <= SIGN_VOL_CAP))
                if _okf:
                    _zok = True
            except Exception:
                pass
        _p4 = float(sig.get('pos4') or 50)
        _tp = str(sig.get('tp') or '').upper()
        _l15 = float(sig.get('last15') or 0)
        _put('大势门', 1 if (_t4 > 0 and _zok) else (-1 if (_t4 < 0 and _zok) else 0), 't4%.2f/er%.2f' % (_t4, _er))
        _put('择强', 1 if _s > 0.5 else (-1 if _s < -0.5 else 0), 'score%.2f' % _s)
        _put('阴阳五行', 1 if _tp in ('UP', 'LONG') else (-1 if _tp in ('DOWN', 'SHORT') else 0), _tp)
        # 📡🆕ED-20260928-277 三兽拟合①·雷达接通: 「开明情报」票吃**开明真源**(雷达方向胚胎度/对齐度)·缺失才回退旧口径(last15)
        _ki, _kwh = 0, ''
        if THREE_BEAST_LINK_ON:
            try:
                _rd = _radar_read(sig.get('coin'))
                if _rd:
                    _rsd, _ral, _rem = str(_rd.get('side') or ''), int(_rd.get('align') or 0), float(_rd.get('embryo') or 0)
                    if _rsd in ('long', 'short') and _ral >= 2:
                        _ki = 1 if _rsd == 'long' else -1
                        _kwh = '雷达%s对齐%d胚%.1f' % (_rsd, _ral, _rem)
            except Exception:
                pass
        if not _ki:
            _ki = 1 if _l15 > 0.2 else (-1 if _l15 < -0.2 else 0); _kwh = '同向%.2f' % _l15
        _put('开明情报', _ki, _kwh)
        _put('白虎哨探', 1 if _p4 <= 30 else (-1 if _p4 >= 70 else 0), '位%.0f' % _p4)
        # 🐞2026-10-02 老板令「甲和乙必须彻底根治」: 触觉军情=开明/白虎**证伪强度**(certify 0~1·高=信号可疑)
        #   旧病: 判 '真' in str(certify) —— certify 是数字(0.0/0.5/0.7)·永不成立 ⇒ 恒 0 熄火
        #   治: 达高危门槛 CERTIFY_HOT=0.5 ⇒ 投 -1(证伪军情·警示) · 否则 0
        _cfz = float(sig.get('certify') or 0)
        _put('触觉军情', -1 if _cfz >= CERTIFY_HOT else 0, '证伪%.2f' % _cfz)
        # 🐞2026-10-02 同令: 顶底半山 —— 内核实际写 '见顶'/'见底'·旧票只认 'TOP'/'顶' 全等 ⇒ 恒 0 熄火
        #   治: 见底 ⇒ +1 · 见顶 ⇒ -1 (兼容旧词)
        _tb = str(sig.get('topbot') or '').upper()
        _put('顶底半山', 1 if (_tb in ('BOTTOM', '底', '见底')) else (-1 if _tb in ('TOP', '顶', '见顶') else 0), _tb[:6])
        if sig.get('_fund_leg'):
            _put('费率腿', -1 if str(sig.get('side')) == 'short' else 1, '极端尾部反向')
    _rk = 0
    try:
        _g = st.get('guard') or {}
        if float(_g.get('_dpnl') or 0) <= -_jg_loss_line() * 0.5:
            _rk = -1
    except Exception:
        pass
    ZHU_BRAKE[0] = (_rk < 0)
    _votes['麒麟制衡'] = {'v': 0, 'why': ('制动' if _rk < 0 else '未触发')}
    _num = 0.0
    _den = 0.0
    if ZHU_SOV_PICK:
        # 👑🐉ED-20261008-636 王上独立自主择向(老板令): 方向只出自王上之「势」· 诸臣只作参谋·只加信心
        _vd, _cf, _why = _sovereign_pick(st, sig, _votes)
    elif YIJING_YINYANG_SOVEREIGN:
        # ☯🐉 道统主宰制：阴阳五行定方向·其余七路只加信心(异向不抵销)
        _yy_d, _yy_cf, _yy_why = _yinyang_sovereign(st, sig)
        if _yy_d == 'await':
            _vd, _cf = ('await' if not sig else 'hold'), 0.0
        else:
            _vd = _yy_d
            # 七路只为信心加成(同向加分·异向**不减**·不抵消方向)
            _bonus = 0.0
            _bden = 0.0
            for _k, _v in _votes.items():
                _w = ZHU_W.get(_k)
                if _w is None or _k == '阴阳五行':
                    continue
                _bden += _w
                if _v['v'] != 0 and ((_v['v'] > 0) == (_vd == 'long')):
                    _bonus += _w
            _cf = _yy_cf + (0.3 * (_bonus / _bden) if _bden > 0 else 0.0)
            _cf = round(max(0.0, min(1.0, _cf)), 3)
        _why = '道统·%s | 参谋 %s' % (_yy_why, ' '.join('%s%s' % (_k, '+' if _v['v'] > 0 else ('-' if _v['v'] < 0 else '0')) for _k, _v in _votes.items() if _k != '阴阳五行'))
    else:
        for _k, _v in _votes.items():
            _w = ZHU_W.get(_k)
            if _w is None:
                continue
            _num += _w * _v['v']
            if _v['v'] != 0:
                _den += _w
        if _den <= 0:
            _vd, _cf = ('await' if not sig else 'hold'), 0.0
        else:
            _vd = 'long' if _num > 0 else ('short' if _num < 0 else 'hold')
            _cf = round(min(1.0, abs(_num) / (3.0 * _den)), 3)
        _why = ' '.join('%s%s' % (_k, '+' if _v['v'] > 0 else ('-' if _v['v'] < 0 else '0')) for _k, _v in _votes.items())
    if ZHU_BRAKE[0]:
        _vd = 'hold'
        _why += ' ·制衡制动'
    _vt = _zhulong_veto(st, sig)
    if _vt:
        _vd = 'hold'
        _why += ' ·闸制动(%s)' % ','.join(_vt)
    ZHU_EDICT.update({'ts': _time.time(), 'cycle': JG_ST.get('周期', 0), 'coin': (sig or {}).get('coin', ''),
                      'verdict': _vd, 'conf': _cf, 'votes': {_k: _v['v'] for _k, _v in _votes.items()},
                      'why': _why, 'seq': ZHU_EDICT.get('seq', 0) + 1})
    try:
        if WANG_HAND_EDICT_ON:
            _we = _wang_hand_edict((sig or {}).get('coin', ''))
            if _we and _we.get('verdict') in ('long', 'short'):
                # 🔬 择向加严①②·王令同框 (2026-10-09 火印 ED-20261009-726 · 试验田·默认关)
                _wh_ok = True; _wr = ''
                if os.environ.get('DIR_HARDEN_ON', '0') == '1':
                    _wc = str((sig or {}).get('coin') or '').upper()
                    _wtier = {x.strip().upper() for x in (os.environ.get('DIR_LOW_TIER') or '').split(',') if x.strip()}
                    _wlow = float(os.environ.get('DIR_LOW_MIN', '2.5') or 2.5)
                    _whr = float(os.environ.get('DIR_LONG_HR_MIN', '0.50') or 0.50)
                    _wsc = abs(float((sig or {}).get('score') or 0))
                    if _wc in _wtier and _wsc < _wlow:
                        _wh_ok = False; _wr = '②低准币弱信(%s %.1f<%s)' % (_wc, _wsc, _wlow)
                    elif _we['verdict'] == 'long':
                        _wp = _phase_of((sig or {}).get('coin')) or {}
                        if _wp.get('相位') != '顺' or float(_wp.get('同向率') or 0) < _whr:
                            _wh_ok = False; _wr = '①多头不达标(相位=%s 同向率=%s)' % (_wp.get('相位'), _wp.get('同向率'))
                if not _wh_ok:
                    log('👑[王上手谕·加严拦] %s %s 不达①②(%s) → 不覆写·退回本户自裁' % (ZHU_EDICT.get('coin'), _we['verdict'], _wr))
                else:
                    _vd = _we['verdict']; _cf = _we['conf']
                    _why = _why + ' | 👑王上手谕: ' + _we['why']
                    ZHU_EDICT.update({'verdict': _vd, 'conf': _cf, 'why': _why})
                    log('👑[王上手谕·烛龙令→腾蛇执行] %s %s 信%.2f | 令出=%s 执行=%s | %s' % (ZHU_EDICT.get('coin'), _vd, _cf, _we.get('seal'), _we.get('exec'), _we['why']))
                    _wang_hand_ack({'类别': '执令', '令': _we.get('seal'), '币': ZHU_EDICT.get('coin'),
                                    '向': _vd, '信': _cf, '执行': _we.get('exec'), '结果': '已执令(王令已覆写本户该币圣裁)'})
    except Exception:
        pass
    if not decide:
        if _vd != ZHU_LAST[0]:
            ZHU_LAST[0] = _vd
            log('🐉 烛龙圣裁(一个声音): %s%s 信%.2f | %s' % ((sig or {}).get('coin', ''), _vd, _cf, _why))
        if ZHU_EDICT['seq'] % 5 == 0:
            try:
                _json.dump({'时刻': _time.strftime('%F %T'), '周期': ZHU_EDICT['cycle'], '币': ZHU_EDICT['coin'],
                            '圣裁': _vd, '信心': _cf, '制动': ZHU_BRAKE[0], '否决': ZHU_VETO[1], '逐路': ZHU_EDICT['votes'],
                            '麒麟回执': _qilin_receipt_last(),   # 📡ED-20260928-277 三兽闭环: 麒麟出手回执(只作情报·不作新锁)
                            '依据': _why, '序号': ZHU_EDICT['seq'],
                            '归类': {_b: len(_ks) for _b, _ks in ZHU_ATTR.items()}},
                           open(_jg_file('_烛龙圣裁.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            except Exception:
                pass
    return (_vd, _cf, _why)


_ZHU_OBS_SEQ = [0]

def _zhulong_observe_flat(st):
    """📻 ED-20261003-407 电台常通令（老板 2026-10-03 23:18「查。搞定他」）
    病: `_zhulong_cycle` 只在【有持仓】时取 sig ⇒ 空仓 _sig=None ⇒ 本函数所在文件里 `_zhulong_edict` 的 `if sig:`
        整块不执行 ⇒ 参谋七源全不评估 ⇒ 圣裁行只剩「参谋 麒麟制衡0」⇒ 电台整天失联(观感"信号源断掉")。
    治: 空仓时**照样**逐候选币评估信号源(decide=True·只算不落盘) → 落盘 `_信号源观测.json` + 日志一行。
    边界(铁律): 观测前后对 ZHU_EDICT/ZHU_BRAKE/ZHU_LAST/ZHU_VETO/ZHU_ATTR **快照并原地复原**
        ⇒ 开仓判定链零变化 · 绝不写 `_烛龙圣裁.json` · 绝不参与 `_zhulong_gate`。
    节流: ZHU_OBS_EVERY(默认20) 个圣裁周期一次; 一键关 ZHU_OBS_ON=0。
    """
    if os.environ.get('ZHU_OBS_ON', '1') == '0':
        return
    _ZHU_OBS_SEQ[0] += 1
    try:
        _every = int(os.environ.get('ZHU_OBS_EVERY', '20') or 20)
    except Exception:
        _every = 20
    if _every > 1 and (_ZHU_OBS_SEQ[0] % _every) != 1:
        return
    _se = dict(ZHU_EDICT)
    _sb, _sl, _sv = list(ZHU_BRAKE), list(ZHU_LAST), list(ZHU_VETO)
    _sa = {_k: (list(_v) if isinstance(_v, list) else _v) for _k, _v in ZHU_ATTR.items()}
    _rows = []
    try:
        for _c in list(WATCH_COINS.keys()):
            try:
                _s = _coin_sig(_c)
                if not _s:
                    continue
                _s = dict(_s); _s['coin'] = _c
                _d, _cf, _w = _zhulong_edict(st, _s, decide=True)
                _rows.append({'币': _c, '向': _d, '信': round(float(_cf), 3),
                              '票': dict(ZHU_EDICT.get('votes') or {}), '依据': str(_w)[:140]})
            except Exception:
                continue
    finally:
        try:
            ZHU_EDICT.clear(); ZHU_EDICT.update(_se)
            ZHU_BRAKE[:] = _sb; ZHU_LAST[:] = _sl; ZHU_VETO[:] = _sv
            for _k, _v in _sa.items():
                if isinstance(_v, list) and isinstance(ZHU_ATTR.get(_k), list):
                    ZHU_ATTR[_k][:] = _v
                else:
                    ZHU_ATTR[_k] = _v
        except Exception:
            pass
    _scnt, _nz, _dir = {}, 0, 0
    for _r in _rows:
        _has = False
        for _k, _v in (_r.get('票') or {}).items():
            try:
                if int(_v or 0) != 0:
                    _scnt[_k] = _scnt.get(_k, 0) + 1; _has = True
            except Exception:
                pass
        if _has:
            _nz += 1
        if _r.get('向') in ('long', 'short'):
            _dir += 1
    try:
        _json.dump({'时刻': _time.strftime('%F %T'), '周期': ZHU_EDICT.get('cycle', 0),
                    '覆盖币数': len(_rows), '源响应数': _nz, '有向币数': _dir,
                    '各源非零票数': _scnt, '逐币': _rows},
                   open(_jg_file('_信号源观测.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception:
        pass
    try:
        log('📻 信号源观测(空仓电台): 覆盖%d币 源响应%d 有向%d | %s' % (
            len(_rows), _nz, _dir, ' '.join('%s%d' % (_k, _v) for _k, _v in sorted(_scnt.items()))))
    except Exception:
        pass

def _zhulong_cycle(st):
    """🐉 每周期: 对当前对象(持仓币 或 空仓待候选)出唯一圣裁"""
    if not ZHU_EDICT_ON:
        return None
    _pos = st.get('pos') or {}
    _sig = None
    if _pos:
        try:
            _sig = _coin_sig(_pos.get('coin'))
        except Exception:
            _sig = None
        if not _sig:
            _sig = {'coin': _pos.get('coin'), 'side': _pos.get('side'), 'score': 0, 'pos4': 50}
    else:
        # 📻 ED-20261003-407 电台常通令: 空仓(正当选币之时)也要评估信号源(只算不落盘·观测)
        try:
            _zhulong_observe_flat(st)
        except Exception:
            pass
    return _zhulong_edict(st, _sig)


def _zhulong_gate(st, sig):
    """🚪 一票之闸: 制动/否决闸触发 → 禁新开；拟开方向与圣裁相左 → 拦。费率腿豁免(ED-251)"""
    try:
        if not (ZHU_EDICT_ON and ZHU_EDICT_ENFORCE) or not sig:
            return None
        if sig.get('_fund_leg'):
            return None
        # ☯2026-10-01 一票之闸并入道统: 道统先导单(_sovereign)本即道统自己的裁决 ⇒ 不再自相抵拦。
        # 🔒ED-20261008-632 改: 王令至上档下**不再豁免道统先导**(择向唯烛龙·天眼/雷达/道统皆不得自开)
        if sig.get('_sovereign') and not ZHU_EDICT_STRICT:
            return None
        _v, _cf, _wh = _zhulong_edict(st, sig, decide=True)
        if ZHU_VETO[0]:
            log('🐉 一票之闸: 闸制动 → 禁新开(一个声音) | %s' % ','.join(ZHU_VETO[1]))
            return 'blocked_by_zhulong'
        if ZHU_BRAKE[0]:
            log('🐉 一票之闸: 麒麟制衡制动(日亏半线) → 禁新开(一个声音)')
            return 'blocked_by_zhulong'
        _side = str(sig.get('side') or '')
        # 🐉🆕ED-20261008-632 王令至上（老板令「天眼及雷达等一切皆无权开仓。择向烛龙」）
        #   治: **圣裁非「同向 long/short」即禁新开**(hold/await ⇒ 无令不开)·删「顺势越王放行」后门。
        #   回退: env ZHU_EDICT_STRICT=0 → 逐字回旧(顺势放行 + 只拦反向)。
        #   🧬2026-10-11 火印 ED-20261011-930 定向灌顶进锐(rui·模拟母子异体)。
        if ZHU_EDICT_STRICT:
            _side0 = str(sig.get('side') or '')
            if _v in ('long', 'short') and _side0 == _v:
                log('🐉 一票之闸: 王令同向(%s·信%.2f) → 放行 | 拟%s %s' % (_v, _cf, sig.get('coin'), _side0))
                return None
            log('🐉 一票之闸: 无同向王令(圣裁=%s·信%.2f·拟%s %s) → 禁新开【无令不开】 | %s'
                % (_v, _cf, sig.get('coin'), _side0, _wh))
            return 'blocked_by_zhulong'
        # 🐉🗡🆕ED-20260928-275 顺势而为: 顺则**主动放行**(不被合议相左所阻)·逆则拦·**无势不拦**(不困死)·费率腿已在上面豁免
        if ZHU_TREND_FOLLOW_ON:
            _td = int((ZHU_EDICT.get('votes') or {}).get('大势门') or 0)
            _dr = 1 if _side == 'long' else (-1 if _side == 'short' else 0)
            if _td and _dr:
                _nm = {1: '看多', -1: '看空'}.get(_td, _td)
                if _dr != _td:
                    log('🐉 一票之闸: 逆势 → 拦(大势[%s]·拟%s %s·择势而为)' % (_nm, sig.get('coin'), _side))
                    return 'blocked_by_zhulong'
                log('🐉 一票之闸: 顺势而为·主动放行(大势[%s]·拟%s %s·不受合议相左所阻)' % (_nm, sig.get('coin'), _side))
                return None
            # ↓ 无明确大势(大势门=0) ⇒ 不拦, 交其余路线判断(不困死)
        if _v in ('long', 'short') and _side and _side != _v:
            log('🐉 一票之闸: 拟%s %s 与圣裁(%s·信%.2f)相左 → 拦(一个声音) | %s' % (sig.get('coin'), _side, _v, _cf, _wh))
            return 'blocked_by_zhulong'
    except Exception as _e:
        log('🐉 圣裁闸异常(放行): %s' % str(_e)[:60])
    return None


# ══ 🏛 九宫八卦方阵（老板载入令 HD-20260927-JG-001 · 系统火印 ED-20260927-255）══
#   太极(本心觉知·独立旁路只读) · 中5麒麟(arbitration_core) · 四正: 离9烛龙 fire·sense_infer / 坎1腾蛇 water·damp_control
#   / 震3金蟾 wood·order_execute / 兑7貔貅 metal·asset_treasury · 四维: 坤2 archive_pool / 艮8 hard_limit_fuse
#   / 巽4 explore_probe / 乾6 rhythm_scheduler · 相生闭环 震→离→中5→兑→坎→震 · 相克 震克中5·离克兑·中5克坎·兑克震·坎克离
#   **纯旁路编排层: 不改既有开平仓判定**(护择向核心)·默认开(=1)·关 JIU_GONG_ON=0 即零影响
JIU_GONG_ON = os.environ.get('JIU_GONG_ON', '1') != '0'
JG_HARD_FUSE = [False]
JG_ST = {'周期': 0, '震': 0, '离': 0, '中5': 0, '兑': 0, '坎': 0, '坤': 0, '艮': 0, '巽': 0, '乾': 0, '太极': 0, '相生轮': 0, '相克轮': 0}
JG_NODES = {'中5': ('麒麟', 'earth', 'arbitration_core'), '离9': ('烛龙', 'fire', 'sense_infer'),
            '坎1': ('腾蛇', 'water', 'damp_control'), '震3': ('金蟾', 'wood', 'order_execute'),
            '兑7': ('貔貅', 'metal', 'asset_treasury'), '坤2': ('坤', 'earth', 'archive_pool'),
            '艮8': ('艮', 'earth', 'hard_limit_fuse'), '巽4': ('巽', 'wood', 'explore_probe'),
            '乾6': ('乾', 'metal', 'rhythm_scheduler')}
JG_SHENG = [('震', '离'), ('离', '中5'), ('中5', '兑'), ('兑', '坎'), ('坎', '震')]     # 相生闭环流水线
JG_KE = [('震', '中5'), ('离', '兑'), ('中5', '坎'), ('兑', '震'), ('坎', '离')]        # 相克约束链路(常驻并行·禁互斥)


def _jg_file(name):
    _b = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(_b) == '子引擎':
        _b = os.path.dirname(_b)
    return os.path.join(_b, 'data_v2', 'mtsim', name)


def _jg_loss_line():
    """艮8 硬熔断线(美元)。
    🔄ED-20260929-321(老板令「以上最优推荐」·甲案): **按该户真实权益自适应** = DAY_LOSS_MAX(4%) × 真实权益。
    权益由跑器 `_子引擎.py` 每次量程重标写入模块变量 `_LIVE_EQ`(与量程同口径·仅真钱户)。
    取不到权益 / 开关关闭 → 回退旧口径 DAY_LOSS_MAX*2000(=$80·固定池)。**回退开关: JG_LOSS_LINE_EQ=0**"""
    try:
        if str(os.environ.get('JG_LOSS_LINE_EQ', '1')) != '0':
            _e = float(globals().get('_LIVE_EQ') or 0)
            if _e > 1.0:
                return abs(float(DAY_LOSS_MAX)) * _e
    except Exception:
        pass
    try:
        return abs(float(DAY_LOSS_MAX)) * 2000.0
    except Exception:
        return 80.0


def _taiji_sees(st):
    """#太极本体: 独立旁路·只读照见 → 识别 起执/贪相/惧相(标记送中宫制衡集合·不改交易)"""
    _m = []
    try:
        _g = st.get('guard') or {}
        _p = st.get('pos') or {}
        if float(_g.get('_consec') or 0) <= -2:
            _m.append('惧相')
        if float(_g.get('_dpnl') or 0) < 0 and float(_p.get('mae_pct') or 0) < -0.01:
            _m.append('惧相')
        if float(_p.get('peak_pct') or 0) >= 0.02 and float(_g.get('_dpnl') or 0) > 0:
            _m.append('贪相')
        if float(_p.get('peak_pct') or 0) >= 0.03 and int(_g.get('_dstops') or 0) >= 1:
            _m.append('起执')
    except Exception:
        pass
    return sorted(set(_m))


def _jiugong_cycle(st):
    """🏛 九宫八卦方阵·每一运算周期: 相生+相克**两链常驻并行**(禁模式切换) · 中宫收八方 · 艮8硬熔断最高优先
       (不受仲裁改写) · 巽4混沌微探测 · 坤2归档沉淀 · 乾6节拍 · 太极旁路照见。**不改既有开平仓判定**。"""
    if not JIU_GONG_ON:
        return None
    JG_ST['周期'] += 1
    JG_ST['乾'] += 1                                       # 乾6 时序节拍(管循环启停/复盘周期)
    for _a, _b in JG_SHENG:
        JG_ST[_a] += 1                                     # 相生闭环(常驻)
    JG_ST['相生轮'] += 1
    for _a, _b in JG_KE:
        JG_ST[_b + '_克'] = JG_ST.get(_b + '_克', 0) + 1    # 相克约束(常驻并行·不切换模式)
    JG_ST['相克轮'] += 1
    JG_ST['艮'] += 1                                       # 艮8 每周期评估硬线(埋点·可验非空壳)
    _p = st.get('pos') or {}
    _g = st.get('guard') or {}
    _in8 = {'震': JG_ST['震'], '离': JG_ST['离'], '兑': JG_ST['兑'], '坎': JG_ST['坎'],
            '坤': JG_ST['坤'], '艮': int(JG_HARD_FUSE[0]), '巽': JG_ST['巽'], '乾': JG_ST['乾']}
    _arb = 'manage' if _p else 'hunt'                       # 中5 麒麟·制衡表决(收八方全部输入)
    try:
        if float(_g.get('_dpnl') or 0) <= -_jg_loss_line() * 0.5:
            _arb = 'defend'
    except Exception:
        pass
    _chaos = 0.0
    _conf = 0.5
    try:
        if _p:
            _chaos = max(0.0, min(1.0, abs(float(_p.get('mae_pct') or 0)) * 40.0))
        _sc = abs(float((_p.get('_ctx') or {}).get('score') or 0)) if _p else 3.0
        _conf = max(0.0, min(1.0, _sc / 4.0))
    except Exception:
        pass
    if _chaos >= 0.4 or _conf < 0.35:
        JG_ST['巽'] += 1                                    # 巽4 混沌微探测(有混沌分或低置信即放行·不绝迹不妄动)
    _marks = _taiji_sees(st)
    JG_ST['太极'] += 1                                      # 太极旁路照见
    _hard = False                                           # 艮8 硬熔断(刚性底线)
    try:
        if float(_g.get('_dpnl') or 0) <= -_jg_loss_line():
            _hard = True
        if str(os.environ.get('JG_FUSE_FORCE', '0')) == '1':
            _hard = True
    except Exception:
        pass
    JG_HARD_FUSE[0] = bool(_hard)
    if JG_HARD_FUSE[0]:
        _arb = 'FUSE'                                       # 仲裁**不得覆写**硬熔断(硬闸优先)
    _mode = _arb                                        # 作业模式(hunt/manage/defend/FUSE)
    try:
        _ed = ZHU_EDICT.get('verdict')                      # 🐉 一个声音: 中5麒麟仲裁 = 烛龙圣裁(硬熔断除外)
        if not JG_HARD_FUSE[0] and _ed in ('long', 'short'):
            _arb = _ed
        elif not JG_HARD_FUSE[0] and _ed == 'hold':
            _arb = 'hold'
    except Exception:
        _mode = _arb
    if JG_ST['周期'] % 20 == 0:                             # 坤2 归档沉淀(节流)
        JG_ST['坤'] += 1
        try:
            _r = {'ts': _time.time(), '周期': JG_ST['周期'], '相生轮': JG_ST['相生轮'], '相克轮': JG_ST['相克轮'],
                  '仲裁': _arb, '艮8硬熔断': JG_HARD_FUSE[0], '太极标记': _marks,
                  '巽4混沌分': round(_chaos, 3), '离9置信': round(_conf, 3), '八方输入': _in8}
            open(_jg_file('_九宫方阵_归档.jsonl'), 'a', encoding='utf-8').write(_json.dumps(_r, ensure_ascii=False) + '\n')
        except Exception:
            pass
    if JG_ST['周期'] % 5 == 0:                              # 状态落盘(供门户/自检)
        try:
            _stt = {'时刻': _time.strftime('%F %T'), '周期': JG_ST['周期'], '相生轮': JG_ST['相生轮'], '相克轮': JG_ST['相克轮'],
                    '节点计数': {_k: JG_ST.get(_k, 0) for _k in ('震', '离', '中5', '兑', '坎', '坤', '艮', '巽', '乾', '太极')},
                    '八方输入': _in8, '八方键数': len(_in8), '仲裁': _arb, '艮8硬熔断': JG_HARD_FUSE[0], '艮8优先': True,
                    '模式': _mode, '烛龙圣裁': ZHU_EDICT.get('verdict'), '烛龙信': ZHU_EDICT.get('conf'),
                    '太极照见': True, '太极标记': _marks, '巽4混沌分': round(_chaos, 3), '离9置信': round(_conf, 3), '节点表': JG_NODES}
            _jf = _jg_file('_九宫方阵_status.json')
            os.makedirs(os.path.dirname(_jf), exist_ok=True)
            _json.dump(_stt, open(_jf, 'w', encoding='utf-8'), ensure_ascii=False)
        except Exception:
            pass
    return _arb


# 💊🆕2026-09-28 五味药·1234（老板令「先做1234·改默认值」）
#   ①顶底闸 顶阈默认75/底25（原自适应80~88）②半山腰带 35~65（让开75）③势位共振 保持 ④多单贴顶禁用带 pos≥70禁多
TOPBOT_ZONE_HI   = float(os.environ.get('TOPBOT_ZONE_HI','75'))     # ①顶底闸·顶阈%(默认75 ⇒ 底25)
TOPBOT_ADAPT_MAX = float(os.environ.get('TOPBOT_ADAPT_MAX','85'))   # ①顶底自适应上限(大波动收紧至此)
SIGN_HALF_BAND_LO = float(os.environ.get('SIGN_HALF_BAND_LO','35')) # ②半山腰带 下沿
SIGN_HALF_BAND_HI = float(os.environ.get('SIGN_HALF_BAND_HI','65')) # ②半山腰带 上沿
SIGN_TOP_BAN_ON  = os.environ.get('SIGN_TOP_BAN_ON','1') != '0'     # ④多单贴顶禁用带(开)
SIGN_TOP_BAN_POS = float(os.environ.get('SIGN_TOP_BAN_POS','70'))   # ④多单 pos≥此值 → 禁多
# 🌊🆕2026-10-02 老板令「赋予系统适应做交易权…择向为正时随行就市·该紧得紧该松就松」(火印 ED-20261002-379)
SIGN_ADAPT_TRADE_ON = os.environ.get('SIGN_ADAPT_TRADE_ON','0') != '0'  # 自适应做交易权·总闸(默认关=旧行为)
SIGN_ADAPT_T4_MIN   = float(os.environ.get('SIGN_ADAPT_T4_MIN','0.30'))  # 「有势」门槛·4根趋势(%)
SIGN_ADAPT_T96_MIN  = float(os.environ.get('SIGN_ADAPT_T96_MIN','1.0'))  # 「有势」门槛·96根趋势(%)
SIGN_ADAPT_POS_HI   = float(os.environ.get('SIGN_ADAPT_POS_HI','92'))    # 有势·多  位置带上沿放宽至
SIGN_ADAPT_POS_LO   = float(os.environ.get('SIGN_ADAPT_POS_LO','8'))     # 有势·空  位置带下沿放宽至
SIGN_ADAPT_TOPBAN   = float(os.environ.get('SIGN_ADAPT_TOPBAN','96'))    # 有势·贴顶禁多阈值放宽至
def _sign_shi_zheng(coin, side, obs):
    """「势正」? 有明确趋势且与方向同向(与「大势门」回补同口径)。→ (是否, 说明)"""
    if not SIGN_ADAPT_TRADE_ON:
        return (False, '闸关')
    _v = (obs or {}).get(coin)
    if not _v:
        return (False, '缺数')
    try:
        _t4 = float(_v.get('t4') or 0); _t96 = float(_v.get('t96') or 0)
        _er = abs(float(_v.get('er') or 0))
    except Exception:
        return (False, '数坏')
    if _er < SIGN_ER_MIN:
        return (False, 'er弱')
    if side == 'long' and _t4 >= SIGN_ADAPT_T4_MIN and _t96 >= SIGN_ADAPT_T96_MIN:
        return (True, '势上(t4%.2f/t96%.2f)' % (_t4, _t96))
    if side == 'short' and _t4 <= -SIGN_ADAPT_T4_MIN and _t96 <= -SIGN_ADAPT_T96_MIN:
        return (True, '势下(t4%.2f/t96%.2f)' % (_t4, _t96))
    return (False, '逆/无势')
def _sign_same_ratio(obs):
    """池内同向率: (同向率, 多, 空) —— 与沙箱同口径(t4 定向)"""
    if not obs:
        return (0.0, 0, 0)
    _l = sum(1 for v in obs.values() if (v or {}).get('side', 0) > 0)
    _s = len(obs) - _l
    return (max(_l, _s) / float(len(obs)), _l, _s)

def _sign_pos_ok(coin, obs, side=None):
    """位置带校验: (是否在带内, 位置值)；缺数据→(True, None) 放行(不因缺数误拦)
    🌊2026-10-02 老板令「自适应做交易权」: 带外若「势正」⇒ 放宽(多放上沿/空放下沿) = 随行就市；逆/无势 ⇒ 维持严带。"""
    _v = (obs or {}).get(coin)
    if not _v:
        return (True, None)
    _p = _v.get('pos')
    if _p is None:
        return (True, None)
    _p = float(_p)
    if SIGN_POS_BAND_LO <= _p <= SIGN_POS_BAND_HI:
        return (True, _p)
    _ok, _why = _sign_shi_zheng(coin, side, obs)
    if _ok:
        _hi = SIGN_ADAPT_POS_HI if side == 'long' else SIGN_POS_BAND_HI
        _lo = SIGN_ADAPT_POS_LO if side == 'short' else SIGN_POS_BAND_LO
        if _lo <= _p <= _hi:
            return (True, _p)
    return (False, _p)


def _reso_ok(coin, obs):
    """🧭 势位共振(ED-20260928-300): (是否共振, 说明)。势= t4/t96 同向; 位= 96根分位。缺数据→(False, 缺因)"""
    _v = (obs or {}).get(coin)
    if not _v:
        return (False, '缺数')
    _t4 = float(_v.get('t4') or 0); _t96 = float(_v.get('t96') or 0)
    _p = _v.get('pos')
    if _p is None:
        return (False, '缺位')
    _p = float(_p)
    if _t4 > 0 and _t96 > 0 and _p <= SIGN_RESO_POS_LO:
        return (True, '多·势上贴底%.0f' % _p)
    if _t4 < 0 and _t96 < 0 and _p >= SIGN_RESO_POS_HI:
        return (True, '空·势下贴顶%.0f' % _p)
    return (False, '势位不合')


def _qilin_market_type(coin, side, reg, last15=None):
    """🧠 麒麟·自我识别: 看近端 1 分钟K线判"这是什么行情"
    返回 (类型, 波动率%, 逆势急冲%, 是否已回抽)；类型: 崩坏/插针回抽/急冲未回/静水/阴跌/unknown"""
    try:
        c1 = _candles(coin, '1m', 30) or []
    except Exception:
        return ('unknown', 0.0, 0.0, False)
    if len(c1) < 8:
        return ('unknown', 0.0, 0.0, False)
    _r = []
    for _i in range(1, len(c1)):
        if c1[_i - 1]:
            _r.append((c1[_i] - c1[_i - 1]) / c1[_i - 1] * 100)
    _n = len(_r) or 1
    _vol = (sum(x * x for x in _r) / _n) ** 0.5
    _spur = (c1[-1] - c1[-4]) / c1[-4] * 100 if c1[-4] else 0.0
    if side == 'short':
        _spur = -_spur
    _lo = min(c1[-3:]); _hi = max(c1[-3:])
    _pull = (c1[-1] - _lo) / _lo * 100 if _lo else 0.0
    if side == 'short':
        _pull = (_hi - c1[-1]) / _hi * 100 if _hi else 0.0
    _t8 = (c1[-1] - c1[-8]) / c1[-8] * 100 if c1[-8] else 0.0
    _net = (c1[-1] - c1[0]) / c1[0] * 100 if c1[0] else 0.0
    _aligned = True if reg in (None, '', 'chop') else ((_t8 > 0) if side == 'long' else (_t8 < 0))
    _big = max(0.6, 3 * _vol)
    if abs(_spur) >= _big and _pull >= 0.15:
        _t = '插针回抽'
    elif abs(_spur) >= _big:
        _t = '急冲未回'
    elif (not _aligned) and abs(_t8) >= 0.4:
        _t = '崩坏'
    elif _vol <= 0.12 and abs(_net) <= 0.35:
        _t = '静水'
    else:
        _t = '阴跌'
    return (_t, _vol, _spur, _pull >= 0.15)

def _qilin_adapt_line(coin, side, ppct, last15, cert, reg, base):
    """🧠 麒麟·自适应兜底线(调"跌多少才认赔"): 崩坏/阴跌/静水→收紧 · 急冲未回/插针回抽→放宽(别砍在针尖)"""
    if not QILIN_ADAPT_ON:
        return (base, 'fixed')
    _t, _vol, _spur, _pulled = _qilin_market_type(coin, side, reg, last15)
    _f = {'崩坏': 0.60, '阴跌': 0.90, '静水': 0.85, '急冲未回': 1.80, '插针回抽': 2.30}.get(_t, 1.0)
    _ln = base * _f
    if _ln > QILIN_ADAPT_MIN:
        _ln = QILIN_ADAPT_MIN
    if _ln < QILIN_ADAPT_MAX:
        _ln = QILIN_ADAPT_MAX
    if QILIN_EMERGENCY_STOP < 0 and _ln < QILIN_EMERGENCY_STOP:
        _ln = QILIN_EMERGENCY_STOP          # 🚨硬底优先
    return (_ln, '%s(vol%.2f%%/冲%+.2f%%)' % (_t, _vol, _spur))

def _qilin_line(pos, ppct, last15, cert, reg):
    """兜底线取用口: 自适应按市况伸缩 · 否则固定线。
    🔮返回三元 (线, 缘由, 是否缓一档): 近端已回抽≥0.15%(假摔) → 缓一档不砍(V48实证: 净和 +749 vs +443)"""
    if QILIN_ADAPT_ON:
        try:
            _ln, _why = _qilin_adapt_line(pos.get('coin'), pos.get('side'), ppct, last15, cert, reg, QILIN_LAST_DEFENSE)
            _hold = False
            if QILIN_TURN_HOLD_ON:
                _t, _vol, _spur, _pulled = _qilin_market_type(pos.get('coin'), pos.get('side'), reg, last15)
                _hold = bool(_pulled) and (_t in ('插针回抽', '急冲未回'))
                if _hold:
                    _why += '·已回抽缓一档'
            return (_ln, _why, _hold)
        except Exception:
            pass
    return (QILIN_LAST_DEFENSE, 'fixed', False)


# 🚨🆕2026-09-25 紧急固定闸(自四户内核回填·老板令「实盘全部融入新武器·确保完全融入」)
#   病: 新武器缺此闸 → SL=2.5% 无夹紧 → 单笔最坏 10×0.42×2.5%=10.5% > 9% 红线
#   药(沿四户 P0-① 2026-09-22 老板令): 硬止损不得宽于紧急闸 → 二者取更紧者
QILIN_EMERGENCY_STOP = float(os.environ.get('QILIN_EMERGENCY_STOP','-0.02'))
if QILIN_EMERGENCY_STOP < 0 and SL > abs(QILIN_EMERGENCY_STOP):
    SL = abs(QILIN_EMERGENCY_STOP)   # 🚨硬底优先: SL 不得宽于紧急闸
# 📏🆕ED-20260927-253 止损宽幅自适应(老板令「赋予止损面宽幅自适应功能」)
#   口径: 以 SL(已夹紧≤|紧急闸|) 为基准, 按**开仓波动率 amp6** 伸缩 0.8~1.6 倍;
#         **夹紧**: 下限 SL_ADAPT_MIN(默认1.0%) · 上限=min(SL,|紧急闸|) ⇒ 绝不破「单笔最坏≤9%权益」红线。
def _sl_adapt_pct(amp6=None):
    """📏 自适应止损宽度(小数): 大波动放宽(防噪声扫损)/小波动收紧(早护本金)"""
    _base = SL
    if not SL_ADAPT_ON:
        return _base
    try:
        _a = float(amp6 if amp6 is not None else 2.0)
        _k = max(0.8, min(1.6, 0.7 + 0.3 * max(0.0, min(3.0, _a))))
        _cap = min(_base, abs(QILIN_EMERGENCY_STOP) or _base)
        return round(max(SL_ADAPT_MIN, min(_cap, _base * _k)), 4)
    except Exception:
        return _base
  # 💊火印令ED-20260917-012: -0.010→-0.013(与母体同口径)  # 麒麟兜底线: 仅深套≥1.0%才出手(日常退出交金蟾貔貅)

# 💊🔌2026-09-23 老板令(「同意以上计划」·修「旋钮失接」): 貔貅让吐四旋钮接线
#   背景: 白泽在研专题发现这四只旋钮**内核不读**(LOCK_START_PCT/GIVE_CAP_PCT/GIVE_FLOOR_PCT/DEEPWATER_CUT_PCT)
#         → 09-18 药方实验基准=处理组, 结论无效(丙级·退回重推演)。
#   纪律: **默认值 = 旧硬编码值** ⇒ env 未设时真钱行为逐字不变；只有显式设 env 才动。
LOCK_START_PCT    = float(os.environ.get('LOCK_START_PCT',   '0.010'))    # 锁盈启动门槛(峰≥此值才启动回撤锁)
GIVE_CAP_PCT      = float(os.environ.get('GIVE_CAP_PCT',     '0.0080'))   # 允许回吐·上限
GIVE_FLOOR_PCT    = float(os.environ.get('GIVE_FLOOR_PCT',   '0.0020'))   # 允许回吐·下限
DEEPWATER_CUT_PCT = float(os.environ.get('DEEPWATER_CUT_PCT','0.013'))    # 深水急冲腿阀(ppct≤-此值 且 近端反向急冲 → 早走)
# 🗡💊2026-09-17 老板令"整治割肉族"·白泽处方实证: 及早摆尾 **11战11败·0胜**·净-1475.67
#   (统计上0.36%概率是运气→真钝刃)。它"浅亏就翻"不但没扭亏, 反而多付一个来回。→ **停用**
#   可 QILIN_EARLY_FLIP_ON=1 回旧(恢复及早摆尾)。好刃"近端证伪摆尾"(真钱胜67%)不受影响。
QILIN_EARLY_FLIP_ON = __import__('os').environ.get('QILIN_EARLY_FLIP_ON','0') != '0'
# 🗡💊2026-09-17 内核审计(275笔全样本): "反手族"全线负期望 —— 证伪确诊+近端证伪 **71战5.6胜·净-5365.44**
#   (同族: 半山腰0%-9622已禁 / 及早0%-2394已禁)。**区间顶底摆尾例外(94.3胜+2654)=好刃保留**。
#   → 停用①证伪确诊反向 + ④保卫科近端证伪。可 QILIN_CERTAIN_FLIP_ON=1 回旧。
QILIN_CERTAIN_FLIP_ON = __import__('os').environ.get('QILIN_CERTAIN_FLIP_ON','0') != '0'
QILIN_SENS_CERT  = float(os.environ.get('QILIN_SENS_CERT','0.45')) if QILIN_SENS_ON else 0.5        # 摆尾certify门槛(💊2026-09-17白泽处方·火印通过: 0.40→0.45收紧·实证摆尾84笔胜6%净-13248且近3日均-305在恶化→只翻真证伪·可 env QILIN_SENS_CERT 回旧)
FAST_CRASH_ON = float(os.environ.get('FAST_CRASH_ON','-0.003'))  # 🔌2026-09-25 老板令「用其它功能代替，比如环境变量」: 接 env(原硬编码死值)
FAST_CRASH_BAR = float(os.environ.get('FAST_CRASH_BAR','1.1'))   # 🔌2026-09-25 同上: 接 env(原硬编码死值)
# ─── 🛡 实盘护栏(由老母体/节点实盘四层风控·老板2026-09-08回实盘前先做·纯逻辑可单测) ───
DAY_STOP_MAX   = 3        # 单日止损次数上限(≥即锁当日新开)
DAY_LOSS_MAX   = 0.04     # 单日已实现亏损≥池4%(=日亏熔断·空仓休当日)
# 🔄ED-20260929-322(老板令「准」): 开小口子供沙盘法案对照(连亏阈值=1/2)·**不设 env 时逐字回旧**
def _env_int_322(_k, _d):
    try:
        return int(float(__import__('os').environ.get(_k, _d)))
    except (TypeError, ValueError):
        return int(_d)
CONSEC_LOSS_K  = _env_int_322('CONSEC_LOSS_K', '3')   # 连亏次数≥(同刀砍≥3)即触发冷却锁
# 🗄 2026-09-11 16:28 老板令"暂时封存全域熔断功能待启用": 全域锁死类护栏(日亏熔断/单日止损超限/连亏冷却)整体开关
#   GLOBAL_CIRCUIT_ON=0(默认封存) → 暂不"整机锁死", 全力以赴; =1 → 恢复全域熔断. 单笔护本(黑天鹅/防闪崩)不受此开关影响, 仍守.
GLOBAL_CIRCUIT_ON = float(__import__('os').environ.get('GLOBAL_CIRCUIT_ON','0'))
CONSEC_COOL_N  = _env_int_322('CONSEC_COOL_N', '9')   # 连亏冷却轮(9轮≈4.5h, 呼应防连亏同刀砍≥3绝不挨)
FLASH_PCT      = 0.035    # 防闪崩: 单币近端15m单根|幅|≥3.5%→拒开(不追闪崩插针)
BLACK_SWAN_PCT = 0.06     # 防黑天鹅: 参考(单币/大盘)短窗|幅|≥6%→清仓拒开(护本第一)
REOPEN_COOLDOWN = 6         # 平后冷却轮
# 🛡🆕2026-09-12 麒麟摆尾统一开关(老板令"取消麒麟摆尾名·统一麒麟摆尾"): =0回旧(无摆尾)
QILIN_TAIL_ON = __import__('os').environ.get('QILIN_TAIL_ON','1') != '0'
# 🔥🆕2026-09-12 烛龙火印(老板令"无火中枢印不得擅自行动·火印=烛龙统御/统一调度令"):
#   铁律: 开明(探)+白虎(哨)报送证伪军情 → 烛龙中枢终审 → 盖火印 → 麒麟才准摆尾.
#   麒麟无权自主触发摆尾; 无火印=只守只兜(按兵不动). ZHULONG_SEAL_ON=0 可关(回旧无印).
ZHULONG_SEAL_ON = __import__('os').environ.get('ZHULONG_SEAL_ON','1') != '0'
ZHULONG_SEAL_CERT = 0.5   # 火印门槛: certify/军情置信≥此(开明/白虎证伪军情强度) 且 regime明确(非chop)
CHOP_FLIP_OFF = __import__('os').environ.get('CHOP_FLIP_OFF','1') != '0'   # 🧬🆕2026-09-14 22:57 老板令"B方案: 并入ZH严格基因": 默认改1(死水禁摆·与ZH1/2/3/ZLS同基因)
ZHULONG_SEAL_STRONG = 0.7 # 🔧2026-09-12 保健: chop松绑门槛——chop但certify≥此(或开明+白虎双证)仍发印, 治"该变不变"
# 🦄🆕2026-09-14 22:29 老板令"中段震荡豁免·麒麟不得越权掐死":
#   病: 34笔刹车亏-6,238(76%贴-0.6%半山腰线成交) = 中段震荡正常回踩被当证伪误杀, 抹平全部止盈.
#   药: regime=chop(震荡)+非极强证伪(certify<CHOP_EXEMPT_CERT 且 非开明+白虎双证) → 麒麟按兵不动(态一).
QILIN_CHOP_EXEMPT = __import__('os').environ.get('QILIN_CHOP_EXEMPT','1') != '0'
CHOP_EXEMPT_CERT  = float(__import__('os').environ.get('CHOP_EXEMPT_CERT','0.7'))  # 震荡豁免上限: certify≥此=极强证伪→仍可动
# 🌟🆕2026-09-15 09:11 老板令"C方案加敏(A方案治本+三参数)":
#   病: DOGE 04:32开多(chop·把握47%) → 05:30刹车(-1.19%) → 07:06反手空 = 同币反复+白送手续费.
#   药①(A方案治本): chop区+低把握(score<CHOP_OPEN_MIN_SCORE) → 不开(管住开仓源头·避免开在模糊区)
#   药②(自适应收紧): chop+certify≥0.5 → 半山腰刹车线提前(-0.6%→QILIN_TIGHT_LOSS) 早收少亏
#   药③(防同币反复): 麒麟刹车平仓后该币冷却加长(QILIN_CUT_COOLDOWN轮) 防"刚杀又开"
#   药④(开明监督): 豁免条件用融合强度adms(开明flock+白虎sfk+触觉nerve) 任一强→豁免失效(更灵敏)
#   一键回旧: 任一开关=0.
QILIN_SENS_ADM   = __import__('os').environ.get('QILIN_SENS_ADM','1') != '0'      # 开明监督融合强度(默认开)
CHOP_OPEN_MIN_SCORE = float(__import__('os').environ.get('CHOP_OPEN_MIN_SCORE','2.5'))  # A方案: chop区开仓最低|score|(2.5=中把握)
QILIN_TIGHT_ON   = __import__('os').environ.get('QILIN_TIGHT_ON','0') != '0'      # 自适应收紧刹车线(默认开->💊火印令ED-20260917-012 默认0停用·与母体同口径)
QILIN_TIGHT_LOSS = float(__import__('os').environ.get('QILIN_TIGHT_LOSS','-0.0035'))  # chop区半山腰刹车线提前((-0.35% vs -0.6%))
QILIN_CUT_COOLDOWN = int(__import__('os').environ.get('QILIN_CUT_COOLDOWN','30'))  # 麒麟刹车后同币冷却轮数(30轮≈15min 防刚杀又开)
# 🔧2026-09-13 00:1x 老板令"死水一潭翻个毛线·频繁交易=机械亏损(白送手续费)": 死水行情禁摆尾.
#   病: chop松绑让死水期(certify虚高≥0.7)也发火印→麒麟白摆尾→价格回摆→亏+双向手续费.
#   药: regime=chop 且 该币近6h振幅<QUALITY_AMP6_MIN(死水判定) → 不发火印(麒麟只守只兜).
#   有振幅的chop(非死水)不动; 手工干预不受影响. CHOP_FLIP_OFF=0 可一键回退.
# 🛡🆕2026-09-12 麒麟摆尾真实化钩子(实盘注入真反手; 纸面=None) — 治"麒麟摆尾在实盘形同虚设"
_FLIP_HOOK = None
PAPER = True                # ⚠️ 模拟修行·绝不下真实单
CYCLE_SLEEP = 30
STATE_FILE = os.path.join(BASE, 'data_v2', 'mtsim', '_jinhua2_sim_state.json')
LOG_FILE   = os.path.join(BASE, 'data_v2', 'mtsim', '_jinhua2_sim.log')

WATCH_COINS = {  # gate永续+quant  (quanto仅真实下单用; SIM用开平纸面)
 'BTC': {'gate':'BTC_USDT','quanto':0.0001},  # 🆕2026-09-13 老板令加BTC(优选主流)
 # ⛔2026-09-30 老板令「ETH 给予移出·怪币有毒」(火印 ED-20260930-344): ETH 淘汰池(−0.35%/笔) → 移出交易池
 'SOL': {'gate':'SOL_USDT','quanto':1},
 'DOGE':{'gate':'DOGE_USDT','quanto':10},
 # 6币轮值扩展(老板2026-09-08批): LINK/XRP/ADA 优质主流·与三币低相关·Gate永续已核实
 # ⛔2026-10-01 老板令「LINK 从币池踢出·各系统」(火印 ED-20261001-364): LINK 移出
 'XRP': {'gate':'XRP_USDT','quanto':10},
 'ADA': {'gate':'ADA_USDT','quanto':10},
 # 🎯🆕2026-09-30 老板令「狩猎模式·优选币池扩容」(火印 ED-20260930-343/344)
 #   口径: quanto 全部 Gate 永续实测; 24h成交额薄(<10M)者只进侦察池不下单(宁缺毋滥)
 'LTC': {'gate':'LTC_USDT','quanto':0.1},    # 24h额12.6M·老板点名
 'BNB': {'gate':'BNB_USDT','quanto':0.001},  # 24h额38.2M·老板点名
 'NEAR':{'gate':'NEAR_USDT','quanto':1},     # 24h额47.5M
 'SUI': {'gate':'SUI_USDT','quanto':1},      # 24h额32.6M
 'AVAX':{'gate':'AVAX_USDT','quanto':1},     # 24h额36.8M
 'UNI': {'gate':'UNI_USDT','quanto':1},      # 24h额28.9M
 'WLD': {'gate':'WLD_USDT','quanto':1},      # 24h额31.0M·第2批
 'FIL': {'gate':'FIL_USDT','quanto':0.01},   # 24h额12.7M·第2批
 'ARB': {'gate':'ARB_USDT','quanto':1},      # 24h额9.8M·第2批
 'DOT': {'gate':'DOT_USDT','quanto':1},      # 24h额8.3M·第2批
}

# 🧪2026-09-24 老板令「三支入场源脱钩·跑真对照」(火印 ED-20260924-158): 按户指定币池开关
#   不设环境变量 = 完全原样(真钱户/母体不受影响); 设了 = 只跑池内币种
_ONLY = os.environ.get('WATCH_COINS_ONLY', '').strip()
if _ONLY:
    _keep = {c.strip().upper() for c in _ONLY.split(',') if c.strip()}
    WATCH_COINS = {k: v for k, v in WATCH_COINS.items() if k in _keep}

# ─── 金蟾/貔貅盈利档(归一化为 notional %) ───
# 旧母体在(保证金MARGIN×杠杆)名义上跑: 金蟾美元档20/40/60/80/100(≈0.26%~1.31%名义)
# 新母体名义NOTIONAL=$2000: 对应美元档 = 名义应取%来算(scale-free)。
# 💊🆕2026-09-12 方A1(老板令"增强智能识别判断·给予灵活性管理·确保择向为正"):
#   病: 金蟾第一档0.3%太低→赢单刚浮盈0.3%就被剪走(实测赢单仅+0.35%/持20min), 而亏单-0.65%/持105min → 赢小输大(比0.54).
#   药: ①首档0.3%→0.6%(让赢单多跑一点) ②大趋势让位更积极 ③择向精准(A1择向) ④麒麟兜底灵敏度.
#   可 env JCH_FIRST_PCT 覆盖首档; FLEX_ON=0 一键回旧.
FLEX_ON = os.environ.get('FLEX_ON','1') != '0'
# 💊🆕2026-09-12 老板令"金蟾首档调整为0.6%-1.6%·资金额度小盈利0.3%太小":
#   病: 小资金下0.3%名义利≈$7.8@$2600, 扣两腿手续费几乎白干. 金蟾阶梯整体上移到 0.6%~1.6% 带.
#   阶梯: 0.6 / 0.85 / 1.1 / 1.35 / 1.6 % (均匀布在0.6~1.6带); 首档0.6%起咬, 顶档1.6%让位貔貅.
# 💊🆕2026-09-15 12:27 老板令"金蟾首档改0.45起(太低易生交易费)·加自适应吞金能力":
#   病(望闻问切铁证): 刹车笔40笔胜率0%亏-7427$; 其中39笔峰值<0.6%(够不到旧首档) → 0.3~0.6%肉被真空放弃 → 全亏成刹车.
#   药: ①首档0.6%→0.45%(覆盖部分死区·但保持"有尊严的肉") ②阶梯重排 0.45/0.70/0.95/1.20/1.45/1.60
#       ③自适应: 首档随行情/把握度活(趋势强→抬首档让肉跑; 震荡弱→降首档快咬落袋).
#   实测成本: 费率0.048%/边×2 + 滑点≈0.20%保本 → 0.45%净赚0.25%(余量充足).
JCH_FIRST_PCT = float(os.environ.get('JCH_FIRST_PCT','0.0045')) if FLEX_ON else 0.003   # 🆕首档0.45%(老板令)
JCH_TIER_PCT = ((JCH_FIRST_PCT,0.0070,0.0095,0.0120,0.0145,0.0160) if FLEX_ON else (0.003,0.006,0.009,0.012,0.015))  # 金蟾阶梯: 0.45/0.70/0.95/1.20/1.45/1.60%
# 🥇🆕2026-09-15 自适应吞金(老板令"金蟾吞金能力自适应"):
#   义: 首档不写死——趋势强(大势旺+趋势度强)=有肉可等→抬首档(多让肉跑); 震荡弱=肉薄易回吐→降首档(快咬落袋).
#   范围 [JCH_ADAPT_LO, JCH_ADAPT_HI]; 开关 JCH_ADAPT_ON=0 回写死0.45.
JCH_ADAPT_ON = os.environ.get('JCH_ADAPT_ON','1') != '0'   # 自适应吞金(默认开)
JCH_ADAPT_LO = float(os.environ.get('JCH_ADAPT_LO','0.0040'))   # 震荡弱市首档下限(0.40%·快咬) 🔌ED-20261003-400 env化(默认不变=零行为变化)
JCH_ADAPT_HI = float(os.environ.get('JCH_ADAPT_HI','0.0055'))   # 强趋势首档上限(0.55%·让肉跑) 🔌ED-20261003-400 env化(默认不变=零行为变化)
JCH_ADAPT_T4 = 0.35     # 大势强度阈值(|4H动量|≥此=大势旺)
JCH_ADAPT_PW = 1.0      # 趋势度阈值(≥此=趋势真强)
BIG_MEAT_PCT    = float(os.environ.get('BIG_MEAT_PCT','0.015'))     # 🦁ED-241 大肉分界(env化·默认=旧值)                                 # 貔貅大肉分界(pct名义): ≥1.5%名义净=真趋势交貔貅
TRAIL_FLOOR_PCT = float(os.environ.get('TRAIL_FLOOR_PCT','0.008'))   # 🦁ED-241 貔貅保底/抬地板(env化)                              # 貔貅保底/抬地板(pct名义): 0.8%起锁
FAST_RETRACE_START = 0.01                            # 盈利急吐保护启动: 浮盈≥1%名义
GIVE_BACK_FRAC  = float(os.environ.get('GIVE_BACK_FRAC','0.5'))        # 🥇ED-241 台阶回吐比(env化)                                 # 台阶回吐: 从峰值回吐一半即按该级锁走
HI_STEP_LOCK    = os.environ.get('HI_STEP_LOCK','1') != '0'             # 🥇ED-241 貔貅递增台阶锁(积沙成塔·env化)                                  # 貔貅递增台阶锁(只赚不吐·对称)
# ─── 貔貅抬地板/递增阶梯·移动让肉(scale-free %, 移植旧母体) ───
TRAIL_START     = float(os.environ.get('TRAIL_START','0.007'))        # 🦁ED-241 貔貅启动(env化)        # 貔貅启动: 峰值浮盈≥0.7%才激活地板(让young小利不被剪)
TRAIL_LEG_FLOOR = float(os.environ.get('TRAIL_LEG_FLOOR','0.016'))   # 🦁ED-241 利锁地板(只进不出·env化)       # 🦁貔貅利锁地板: 回吐保底线最低不高过此(1.6%)只进不出爬高
TARGET_PCT      = float(os.environ.get('TARGET_PCT','0.05'))        # 🦁ED-241 目标止盈(env化)        # 目标止盈5%(双链终局收割)
DAYI_T4        = 0.35         # 大义闸: |4H动量|≥0.35%即大势仍旺(金蟾吐微利交貔貅)
# 💊🆕2026-09-12 方A1: 大义闸放宽——只要大势稍旺(DAYI_T4*0.6)且趋势非弱, 就让位貔貅多跑, 不剪赢单.
DAYI_T4_LOOSE  = 0.21         # 宽松大义闸(0.35*0.6): |t4|≥此+趋势不弱 → 也让位
FLIP_TRAIL_ON  = (0.007 if BEASTBUS_ON else 9.9)   # 🚌三兽巴士(③貔貅→麒麟 转弱/承接): 关总线→9.9=永不触发(一键回滚) · 原:曾持大肉(peak≥此)才换向
FLIP_PACO      = 0.8          # 换向需趋势度<0.8(转弱)

def _trend_strength(pos, sig):
    """趋势强度 multi / pw(1.5强顺势~0.6逆势), 由4H动量顺向度定(供貔貅/大义/换向共用)"""
    try:
        t4=sig.get('t4',0) or 0
        if pos['side']=='long':  pw = t4/1.5
        else:                    pw = -t4/1.5
        pw=max(-2,min(2,pw))
        multi = 1.5 if pw>=1.5 else (1.15 if pw>=0.5 else (1.0 if pw>=-0.5 else (0.8 if pw>=-1.5 else 0.6)))
        return multi,pw
    except Exception:
        return 1.0, 0.0


def _target_pct_from_pw(pw):
    """🎯🆕2026-09-12 目标止盈%(门户展示/终局收割同口径): TARGET_PCT×倍率(强趋势远/弱趋势近).
       与主循环 _tg=TARGET_PCT*(1.6 if pw>=1.5 else (1.2 if pw>=1.15 else 1.0)) 同口径.
       返回 (目标pct小数, 倍率)."""
    try:
        _pw = float(pw or 0)
        mult = 1.6 if _pw>=1.5 else (1.2 if _pw>=1.15 else 1.0)
        return TARGET_PCT*mult, mult
    except Exception:
        return TARGET_PCT, 1.0


def _target_price(pos):
    """🎯🆕目标止盈价(供门户一目了然): 由持仓期认向t4(pw)算目标%, 换算目标价.
       长: 目标价=entry×(1+目标%); 空: entry×(1-目标%)."""
    try:
        ctx = pos.get('_ctx', {}) or {}
        t4 = float(ctx.get('t4', 0) or 0)
        side = pos.get('side'); entry = float(pos.get('entry', 0) or 0)
        pw = (t4/1.5) if side=='long' else (-t4/1.5)
        tpct, mult = _target_pct_from_pw(pw)
        tprice = entry*(1+tpct) if side=='long' else entry*(1-tpct)
        return {'tprice': tprice, 'tpct': tpct, 'mult': mult, 'pw': pw}
    except Exception:
        return {'tprice': 0.0, 'tpct': TARGET_PCT, 'mult': 1.0, 'pw': 0.0}

def _rise_pace(sig, side):
    """涨速节奏(缓涨放宽多吃/急拉收紧快锁): 简化1倍返回 + 末根冲幅判"""
    try:
        last15=sig.get('last15',0) or 0
        if abs(last15)>=0.5: return 0.85, 'alert'   # 急性大跳
        if abs(last15)<=0.08: return 1.15, 'buffer' # 缓行
    except Exception:
        pass
    return 1.0,'neutral'

def log(msg):
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, 'a') as f: f.write(line + '\n')
    except Exception: pass

# ─── 行情(OKX 免费; 与$200节点同源) ───
def _okx(path):
    try:
        # 🆕 2026-09-11: 超时 8s→3s. OKX挂时若每调用等8s, 一轮要数分钟(引擎发木); 3s无应即快回Gate.
        r = urllib.request.urlopen(urllib.request.Request('https://www.okx.com'+path,
            headers={'User-Agent':'M'}), timeout=3)
        return json.loads(r.read().decode())
    except Exception:
        return None

# 🌐🆕2026-09-16 事件一·网络自愈「跨层第三源」: OKX(境外云)→Gate(交易所) 同层伪冗余(VPN断一起瞎).
#   药: 加 Binance(不同境外线路) 作第三源. 三源跨线路 → VPN断掉一条, 仍有另两条可达.
#   只补数据源·不改任何交易逻辑. BINANCE_FALLBACK_ON=0 可关(回纯OKX+Gate).
BINANCE_FALLBACK_ON = __import__('os').environ.get('BINANCE_FALLBACK_ON','1') != '0'
def _binance_fallback(path):
    """OKX/Gate 都不可达时, 用 Binance 取行情(同构 OKX data 结构)."""
    if not BINANCE_FALLBACK_ON: return None
    try:
        _BN = 'https://fapi.binance.com'
        if '/market/ticker?' in path:
            _inst = path.split('instId=')[1].split('&')[0]        # 例 ADA-USDT-SWAP
            _sym = _inst.replace('-USDT-SWAP','').replace('-USDT','') + 'USDT'
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_BN}/fapi/v1/ticker/price?symbol={_sym}', headers={'User-Agent':'M'}), timeout=6)
            d = json.loads(r.read().decode())
            if d and d.get('price'):
                return {'data': [{'last': str(d['price'])}]}
        elif '/market/candles?' in path:
            _inst = path.split('instId=')[1].split('&')[0]
            _sym = _inst.replace('-USDT-SWAP','').replace('-USDT','') + 'USDT'
            _bar = path.split('bar=')[1].split('&')[0]
            _lim = int(path.split('limit=')[1].split('&')[0]) if 'limit=' in path else 50
            _iv = {'1m':'1m','3m':'3m','5m':'5m','15m':'15m','30m':'30m','1H':'1h','2H':'2h','4H':'4h','1D':'1d'}.get(_bar, _bar)
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_BN}/fapi/v1/klines?symbol={_sym}&interval={_iv}&limit={_lim}', headers={'User-Agent':'M'}), timeout=6)
            d = json.loads(r.read().decode())
            if d and isinstance(d, list):
                # Binance: [openTime,o,h,l,c,vol,...] 正序(t升) → 倒序成OKX样(最新在前)
                rows = sorted(d, key=lambda x: int(x[0]), reverse=True)
                return {'data': [[str(r2[0]), str(r2[1]), str(r2[2]), str(r2[3]), str(r2[4]), str(r2[5])] for r2 in rows]}
    except Exception:
        return None
    return None

def _gate_fallback(path):
    # 🆕 2026-09-11 00:5x 治病根: OKX超时不可达(实测0/5)时, 引擎"睛瞎"→net_err→看不见价/管不了仓/锁不了肉
    #   (老板实盘ADA空到过+2.56%肉, 但引擎peak只冻在0.526%→貔貅不触发→肉裸奔, 只靠人手工平).
    #   药: OKX失败时回退Gate(交易所本身, 实测稳0.5s). 只补数据源, 不改任何交易逻辑. 关: 置None即回纯OKX.
    #   把 OKX 路径 → Gate 路径, 返回同构 dict(模拟OKX的 data 结构): ticker加'data':[{'last':..}] / candles加'data':[[ts,o,h,l,c,vol],...]
    try:
        _GATE = 'https://api.gateio.ws/api/v4/futures/usdt'
        if '/market/ticker?' in path:
            _inst = path.split('instId=')[1].split('&')[0]      # 例 ADA-USDT-SWAP
            _c = _inst.replace('-USDT-SWAP','').replace('-USDT','')
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_GATE}/tickers?contract={_c}_USDT', headers={'User-Agent':'M'}), timeout=8)
            d = json.loads(r.read().decode())
            if d and isinstance(d, list) and d[0].get('last'):
                return {'data': [{'last': str(d[0]['last'])}]}
        elif '/market/candles?' in path:
            _inst = path.split('instId=')[1].split('&')[0]
            _c = _inst.replace('-USDT-SWAP','').replace('-USDT','')
            _bar = path.split('bar=')[1].split('&')[0]
            _lim = int(path.split('limit=')[1].split('&')[0]) if 'limit=' in path else 50
            _iv = {'1m':'1m','3m':'3m','5m':'5m','15m':'15m','30m':'30m','1H':'1h','2H':'2h','4H':'4h','1D':'1d'}.get(_bar, _bar)
            r = urllib.request.urlopen(urllib.request.Request(
                f'{_GATE}/candlesticks?contract={_c}_USDT&interval={_iv}&limit={_lim}', headers={'User-Agent':'M'}), timeout=8)
            d = json.loads(r.read().decode())
            if d and isinstance(d, list):
                # Gate正序(t升)→倒序成OKX样(最新在前), [ts,o,h,l,c,vol]
                rows = sorted(d, key=lambda x: int(x['t']), reverse=True)
                return {'data': [[str(r2['t']), str(r2['o']), str(r2['h']), str(r2['l']), str(r2['c']), str(r2['v'])] for r2 in rows]}
    except Exception:
        return None
    return None

# 🌐🆕2026-09-16 事件一·网络自愈「断网侦测」: 三源全不可达 → 置网络断标志 → 引擎冻结开仓/记账.
_NET_STATE = {'down': False, 'since': 0, 'last_ok': 0, 'fail_streak': 0}
def _net_is_down():
    """读当前网络状态(供引擎决策: 断网→冻结开仓)."""
    return _NET_STATE.get('down', False)
def _net_mark_ok():
    _NET_STATE['fail_streak'] = 0
    _NET_STATE['last_ok'] = __import__('time').time()
    if _NET_STATE.get('down'):
        _down_sec = __import__('time').time() - _NET_STATE.get('since', 0)
        _NET_STATE['down'] = False
        try: log(f"🌐 网络自愈: 行情源恢复(断网{_down_sec:.0f}秒) → 解冻, 恢复开仓/正常管理")
        except Exception: pass
def _net_mark_fail():
    _NET_STATE['fail_streak'] = _NET_STATE.get('fail_streak', 0) + 1
    _thr = int(__import__('os').environ.get('NET_FREEZE_FAILS','3'))   # 连续N轮全源失败→判定断网
    # 🔧🆕2026-10-06 火印 ED-20261006-536（参经修器·老板令「参经修器·让系统恢复活跃交易」）:
    #   经注明写「连续3轮全不可达」，器却按**单次取数失败**计数 ⇒ 一轮内任意3次失败即误报断网
    #   （实测一日 450 次·断线/自愈成对瞬跳）⇒ 每次冻结即「拒开仓」。治：须同时满足
    #   「连续N次失败」且「距上次成功 ≥ NET_FREEZE_GRACE 秒(默认60)」方判断网。真断网照冻·保命不减。
    _grace = float(__import__('os').environ.get('NET_FREEZE_GRACE', '60'))
    _last_ok = float(_NET_STATE.get('last_ok') or 0)
    _ok_recent = ((__import__('time').time() - _last_ok) < _grace) if _last_ok else False
    if not _NET_STATE.get('down') and _NET_STATE['fail_streak'] >= _thr and not _ok_recent:
        _NET_STATE['down'] = True
        _NET_STATE['since'] = __import__('time').time()
        try: log(f"🌐 网络断线侦测: 三源(OKX/Gate/Binance)连续{_thr}轮全不可达 → 冻结开仓(保命), 持仓转纯守")
        except Exception: pass

def _okx2(path):
    """先OKX, 失败回退Gate, 再失败回退Binance(跨层三源冗余). 只读行情, 同构返回."""
    d = _okx(path)
    if d:
        _net_mark_ok(); return d
    d = _gate_fallback(path)
    if d:
        _net_mark_ok(); return d
    d = _binance_fallback(path)
    if d:
        _net_mark_ok(); return d
    _net_mark_fail()   # 三源全瞎 → 记一次失败(连续N次→断网冻结)
    return None

# 🔥🆕2026-09-12 行情源提速(老板令"修行情源慢·治极速命门"): _candles/_price 加短TTL缓存.
#   病: _coin_sig 单币串行拉 ~8次K线(4H/15m/1H重拉/5m/15m60…), ~2.5s/次 → ~20s/币 → 一轮~2min.
#   治: 同(币,bar,limit)在一轮内只拉一次, 复用缓存. TTL默认45s(给一轮冗余). 不改逻辑·只提速. CACHE_ON=0可关.
_CANDLE_CACHE = {}
_PRICE_CACHE = {}
CACHE_ON = __import__('os').environ.get('QUOTE_CACHE_ON','1') != '0'
CACHE_TTL = float(__import__('os').environ.get('QUOTE_CACHE_TTL','45'))
def _cache_get(_d, _k):
    if not CACHE_ON: return None
    _e=_d.get(_k)
    if _e and (__import__('time').time()-_e[0])<CACHE_TTL: return _e[1]
    return None
def _cache_put(_d, _k, _v):
    if CACHE_ON: _d[_k]=(__import__('time').time(), _v)

def _price(key):
    _ck=('px',key)
    _hit=_cache_get(_PRICE_CACHE,_ck)
    if _hit is not None: return _hit
    d = _okx2(f'/api/v5/market/ticker?instId={key}-USDT-SWAP')
    _v = float(d['data'][0]['last']) if d and d.get('data') else None
    if _v is not None: _cache_put(_PRICE_CACHE,_ck,_v)
    return _v
def _candles(key, bar, limit):
    _ck=(key,bar,limit)
    _hit=_cache_get(_CANDLE_CACHE,_ck)
    if _hit is not None: return _hit
    d = _okx2(f'/api/v5/market/candles?instId={key}-USDT-SWAP&bar={bar}&limit={limit}')
    if not d or not d.get('data'): return []
    _v=[float(r[4]) for r in sorted(d['data'], key=lambda x: x[0])]
    _cache_put(_CANDLE_CACHE,_ck,_v)
    return _v
# 🔥🆕2026-09-12 行情源并行预热(老板令"修行情源慢"): _coin_sig 需~7次不同K线(每次OKX~3.4s→串行~24s).
#   治: _prewarm 用线程池并行拉齐该币全部bar类型 → 总耗时≈单次(~3.4s), 后续_candles命中缓存.
#   同一次扫描内不重复拉; 不改逻辑只提速. PARALLEL_ON=0 可关(回串行).
def _prewarm(coin, specs):
    """并行拉齐该币全部(bar,limit)K线+price 入缓存. specs=[(bar,limit),...]"""
    if not PARALLEL_ON:
        for _b,_l in specs: _candles(coin,_b,_l)
        return
    from concurrent.futures import ThreadPoolExecutor
    def _one(s):
        if s[0]=='__px__':
            _price(coin)
        else:
            _candles(coin,s[0],s[1])
    try:
        with ThreadPoolExecutor(max_workers=min(8,len(specs)+1)) as ex:
            list(ex.map(_one, [('__px__',0)]+list(specs)))
    except Exception:
        for _b,_l in specs: _candles(coin,_b,_l)   # 并行失败→串行兼底

PARALLEL_ON = __import__('os').environ.get('QUOTE_PARALLEL_ON','1') != '0'
# _coin_sig 实际用到的全部K线规格(与函数内保持同步)
_SIG_SPECS = [('4H',20),('15m',30),('1H',60),('15m',6),('15m',60),('1H',24)]

def _ema(cs, n):
    if not cs: return []   # guard-2026-10-10 hazard1: empty-data guard
    k=2/(n+1); e=[cs[0]]
    for x in cs[1:]: e.append(x*k+e[-1]*(1-k))
    return e
def _macd_gck(c):
    try:
        c1 = _candles(c,'1H',60)
        if not c1 or len(c1)<30: return 'None',0.0
        e12=_ema(c1,12); e26=_ema(c1,26)
        dif=[a-b for a,b in zip(e12,e26)]; dea=_ema(dif,9)
        d=dif[-1]-dea[-1]; p=dif[-2]-dea[-2]
        if d>0 and p<=0: return 'golden',1.0
        if d<0 and p>=0: return 'death',1.0
        if d>0: return 'golden',0.5
        if d<0: return 'death',0.5
        return 'None',0.0
    except Exception:
        return 'None',0.0

def _coin_sig(c, manage=False):   # 🔓ED-20261008-628 manage=True ⇒ 持仓管理豁免(观望不拦管仓)
    """返回该币多信号上下文 + 净方向分(与$200节点同源评分, 多了4H大势供半山腰拦截)
    2026-09-09 21:4x 老板令·自愈方向中枢: 补‘高周期认向锚’(4H/1H EMA大势 + 真4H动量t4l)
      治老病: 方向分由 4 个短窗小特征均权拍脑袋→无大势仲裁→拿噪声当方向.
      现给每币带 regime 高层判向, 供 _pick 在下面拦‘短窗想开但大势明显顶牛’的错误方向."""
    _prewarm(c, _SIG_SPECS)   # 🔥并行预热: 一并拉齐全bar入缓存 → 后续_candles命中, 24s→~4s
    c4=_candles(c,'4H',20); c15=_candles(c,'15m',30); c1=_candles(c,'1H',60)
    pr=_price(c)
    if not c4 or len(c4)<12 or not c15 or len(c15)<10 or not pr: return None
    t4=(pr-c4[-12])/c4[-12]*100 if c4[-12] else 0      # 4H大势%(末12根≈近2日真动)
    # ── 高周期认向锚(治疗): 4H/1H EMA(8) 真趋势 + 失真多窗口径t4l ----------------------------------
    t4l=(pr-c4[-20])/c4[-20]*100 if len(c4)>=20 and c4[-20] else t4   # 更远4H窗(≈近3.3日)大势
    e4h=_ema(c4,8); e1h=_ema(c1,8)
    e4_bias = 'up' if e4h[-1]>e4h[-4]*1.002 else ('dn' if e4h[-1]<e4h[-4]*0.998 else 'flat')  # 4H EMA方向
    e1_bias = 'up' if e1h[-1]>e1h[-4]*1.001 else ('dn' if e1h[-1]<e1h[-4]*0.999 else 'flat')
    # 大势净判: 多数周期同向=顺大势(可为主方向仲裁), 冲突=chop(噪声带慎开)
    votes=sum([1 if e4_bias=='up' else (-1 if e4_bias=='dn' else 0),
               1 if e1_bias=='up' else (-1 if e1_bias=='dn' else 0),
               1 if t4l>0.25 else (-1 if t4l<-0.25 else 0)])
    regime = 'up' if votes>=2 else ('dn' if votes<=-2 else 'chop')
    # --------------------------------------------------------------------------------------------
    # 🆕2026-09-11 董事长择向·区间位(pos4): 4H近20根[最低,最高]区间中现价位置0~100 (0=区间底/超卖, 100=顶)
    # 🆕2026-09-11 行情质量: 近6h振幅(用15m近24根=6h高低)
    _h6=max(c15[-24:]) if len(c15)>=24 else max(c15); _l6=min(c15[-24:]) if len(c15)>=24 else min(c15)
    amp6=(_h6-_l6)/_l6*100 if _l6 else 0
    _hi=max(c4[-20:]) if len(c4)>=20 else max(c4); _lo=min(c4[-20:]) if len(c4)>=20 else min(c4)
    pos4=(pr-_lo)/(_hi-_lo)*100 if _hi>_lo else 50.0
    mf=sum(c15[-5:])/5; ms=sum(c15[-10:])/10
    tp='UP' if mf>ms else ('DOWN' if mf<ms else '?')
    gck,gs=_macd_gck(c)
    last15=(c15[-1]-c15[-2])/c15[-2]*100 if len(c15)>=2 and c15[-2] else 0
    s=0.0
    if t4>0.15: s+=1.0
    elif t4<-0.15: s-=1.0
    if tp=='UP': s+=1.0
    elif tp=='DOWN': s-=1.0
    if gck=='golden' and gs>0.5: s+=1.5
    elif gck=='death' and gs>0.5: s-=1.5
    elif gck=='golden': s+=0.7
    elif gck=='death': s-=0.7
    if last15>0.3: s+=0.5
    elif last15<-0.3: s-=0.5
    # 🛡 药①·保卫科高感知证伪(仅增强保卫科·不动其它): 识别"信号矛盾"与"量能背离" → 伪信号前兆
    contra = ((gck=='death' and tp=='UP') or (gck=='golden' and tp=='DOWN'))   # 信号打架=伪信号高危
    # 🎯🆕药B·反转识别加敏(2026-09-12 老板令"反转识别加敏"): 急涨/急跌中, 15m小回踩/小反弹是"换挡"不是"矛盾" → 豁免contra(真突破不被拦).
    try:
        _cp=_candles(c,'15m',6)
        if _cp and len(_cp)>=4 and _cp[-4]:
            _pi=abs(_cp[-1]-_cp[-4])/_cp[-4]*100     # 近3根15m单边幅度
            _pulse=_pi>=PULSE_AMP
            _pdir='up' if _cp[-1]>_cp[-4] else 'dn'
            # 急涨中(向上脉冲)且contra因death+UP→豁免; 急跌中(向下脉冲)且contra因golden+DOWN→豁免
            if _pulse and ((_pdir=='up' and gck=='death') or (_pdir=='dn' and gck=='golden')):
                contra=False
    except Exception:
        pass
    divg = 0
    try:
        _c15v=_candles(c,'15m',60)
        if _c15v and len(_c15v)>=25:
            _hi60=max(_c15v[:-1]); _lo60=min(_c15v[:-1])
            _at_hi = pr>=_hi60*0.998; _at_lo = pr<=_lo60*1.002
            # 量能萎缩(用15m收盘波动幅度近似量能强度, 无真实量则用ATR比)
            _tr=[abs(_c15v[i]-_c15v[i-1]) for i in range(1,len(_c15v))]
            _vshort=sum(_tr[-3:])/3 if len(_tr)>=3 else 0
            _vlong=sum(_tr[-20:])/20 if len(_tr)>=20 else _vshort
            _shrink = (_vshort < _vlong*0.8) if _vlong>0 else False
            if (_at_hi or _at_lo) and _shrink: divg = 1   # 创极值但动能萎缩=伪突破前兆
    except Exception:
        pass
    # 综合证伪置信(0~1): 矛盾(0.5) + 背离(0.3) + 近端反向(0.2)
    certify = 0.0
    if contra: certify += 0.5
    if divg:   certify += 0.3
    if len(c15)>=2 and c15[-2]:
        _l15=(c15[-1]-c15[-2])/c15[-2]*100
        if (s>=0 and _l15<-0.1) or (s<0 and _l15>0.1): certify += 0.2
    certify=min(1.0, certify)
    # 🧬 触觉融入·方案A(共振加权·守红线): 触觉向与引擎向一致→score+W; 相反→score-W; 中性/无→不动. 不改side.
    _tside,_tstr=_tactile_read(c)
    if _tside in ('long','short') and _tstr>=0.2:
        _eng_side='long' if s>=0 else 'short'
        if _tside==_eng_side: s+=TACTILE_W
        else: s-=TACTILE_W
    # 🧬🆕 时空梭顶底基因融入(2026-09-11 22:2x 老板令"融入/融合增强"·路演综合胜率66%实证):
    #   时空梭真金=用24h分位(0-100%)判顶/底 + 近端反转共振 → 加权母体择向(只加权不翻向·守触觉红线).
    #   识底(分位≤25%+近端转强)→给多向加分; 识顶(分位≥75%+近端转弱)→给空向加分. 反向弱加权.
    #   SK_GENE_ON=0 可关 (回旧无此基因). 与pos4互补: 时空梭=24h分位(自适应窗口), 母体pos4=4H近20根.
    if SK_GENE_ON:
        try:
            _c24=_candles(c,'1H',24)
            if _c24 and len(_c24)>=20:
                _sh=max(_c24); _sl=min(_c24); _sp=(pr-_sl)/(_sh-_sl)*100 if _sh>_sl else 50.0
                _samp=(_sh-_sl)/_sl*100 if _sl else 0
                _smom=(c15[-1]-c15[-4])/c15[-4]*100 if len(c15)>=4 and c15[-4] else 0
                if _samp>=2.5:   # 只在非震荡(有肉)时生效
                    if _sp<=25 and _smom>0:      # 识底→偏多
                        s += SK_GENE_W if s>=0 else SK_GENE_W*0.5
                    elif _sp>=75 and _smom<0:    # 识顶→偏空
                        s -= SK_GENE_W if s<=0 else SK_GENE_W*0.5
        except Exception:
            pass
    # 🎯🆕药A·见顶见底加敏(2026-09-12 老板令"赋予见顶见底信号加敏"·治ETH 2628顶未被识别):
    #   24h分位极值区(≥90%顶区/≤10%底区) + 近端转弱/强 → 顶/底预警. 比时空梭(75/25)更敏.
    #   顶区+近端转弱 (或顶区已滞涨) → 偏空(警示见顶); 底区+近端转强 (或底区已止跌) → 偏多(警示见底).
    _topbot=''
    if TOPBOT_SENS:
        try:
            _c24t=_candles(c,'1H',24)
            if _c24t and len(_c24t)>=20:
                _th=max(_c24t); _tl=min(_c24t); _tp=(pr-_tl)/(_th-_tl)*100 if _th>_tl else 50.0
                _tm=(c15[-1]-c15[-4])/c15[-4]*100 if len(c15)>=4 and c15[-4] else 0
                _tamp=(_th-_tl)/_tl*100 if _tl else 0
                if _tamp>=2.0:   # 非震荡
                    if _tp>=TOPBOT_ZONE*100 and _tm<0:       # 顶区+近端转弱→见顶预警(偏空)
                        s -= SK_GENE_W if s<=0 else SK_GENE_W*0.5
                        _topbot='见顶'
                    elif _tp<= (1-TOPBOT_ZONE)*100 and _tm>0: # 底区+近端转强→见底预警(偏多)
                        s += SK_GENE_W if s>=0 else SK_GENE_W*0.5
                        _topbot='见底'
        except Exception:
            pass
    # 🔪相位刀(ED-387·根治): 逐币实测相位 —— 顺/反(翻正)/观望(不做)。
    #   翻正时把**方向族字段整体镜像** ⇒ 全系统一致地按"翻转后的世界"工作(不再靠单个闸兜底)。
    if SIGN_PHASE_ADAPT_ON:
        _phv = _phase_of(c)
        if _phv:
            if _phv.get('相位') == '观望':
                if not manage:
                    return None   # 仅新开仓: 观望不做
                # 🔓ED-20261008-628 持仓管理豁免: 观望不拦「管仓」(该仓须有看护)
            if _phv.get('相位') == '反':
                s = -s
                t4 = -t4
                last15 = -last15
                try:
                    t4l = -float(t4l)
                except Exception:
                    pass
                tp = {'UP': 'DOWN', 'DOWN': 'UP'}.get(tp, tp)
                gck = {'golden': 'death', 'death': 'golden'}.get(gck, gck)
                regime = {'up': 'dn', 'dn': 'up'}.get(regime, regime)
                try:
                    e4_bias = {'up': 'dn', 'dn': 'up'}.get(e4_bias, e4_bias)
                    e1_bias = {'up': 'dn', 'dn': 'up'}.get(e1_bias, e1_bias)
                    _topbot = {'见顶': '见底', '见底': '见顶'}.get(_topbot, _topbot)
                except Exception:
                    pass
    return {'coin':c,'side':'long' if s>=0 else 'short','score':s,'t4':t4,'tp':tp,'gck':gck,'pr':pr,
            'last15':last15,'regime':regime,'t4l':round(t4l,3),'e4':e4_bias,'e1':e1_bias,'pos4':round(pos4,1),'amp6':round(amp6,2),
            'certify':round(certify,2),'contra':contra,'divg':divg,'topbot':_topbot,'pnl_ctx':None}

def _candles_from_hist(src, key, bar, limit):
    """离线回放注入点: 从 _3coin_hist 取bars(供回放脚本mock行情持久取)"""
    # 由回放脚本 monkeypatch _okx/_candles/_price; 此仅为默认实时
    return _candles(key, bar, limit)

# ─── 择强开仓(多币自切换内脏) ───
def _g(st):
    st.setdefault('guard',{'_dpnl':0.0,'_dstops':0,'_consec':0,'_cool':0,'_deadline':None})
    return st['guard']

# ───────── 🧬 生命体·训练数据集 (2026-09-10 老板令: 当前主力放在生命体上训练数据集) ─────────
#  定位: 纯数据记录(不改任何交易行为) —— 每次平仓把"开仓全景 + 结果"存下, 攒生命体的行为观察册/训练集.
#  字段: 币/向/开价/评分/开仓时认向regime+短窗特征/tier/持仓时长/结果pnl/pnl%/why/win/涨跌幅/时间.
import os as _os, json as _json, time as _time
LIFE_DATA_F = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'data_v2', 'mtsim', '_life_train_data.json')
def _life_sample(pos, pr, pnl_pct, pnl_usd, why):
    """平仓时落一条训练样本(开仓全景+结果). 纯追加·只保留最近5000条·失败不阻塞引擎."""
    try:
        _os.makedirs(_os.path.dirname(LIFE_DATA_F), exist_ok=True)
        arr = []
        if _os.path.exists(LIFE_DATA_F):
            try:
                arr = _json.load(open(LIFE_DATA_F, encoding='utf-8'))
                if not isinstance(arr, list): arr = []
            except Exception:
                arr = []
        ctx = pos.get('_ctx', {}) or {}
        arr.append({
            'coin': pos.get('coin'), 'side': pos.get('side'),
            'entry': round(float(pos.get('entry', 0) or 0), 6),
            'exit': round(float(pr or 0), 6),
            'tier': pos.get('tier', 0),
            'open_score': ctx.get('score'), 'open_regime': ctx.get('regime'),
            'open_t4': ctx.get('t4'), 'open_t4l': ctx.get('t4l'),
            'open_gck': ctx.get('gck'), 'open_tp': ctx.get('tp'), 'open_last15': ctx.get('last15'),
            'peak_pct': round(float(pos.get('peak_pct', 0) or 0) * 100, 3),
            'hold_h': round((_time.time() - float(pos.get('open_ts', _time.time()) or _time.time())) / 3600.0, 2),
            'pnl': round(float(pnl_usd or 0), 3), 'pnl_pct': round(float(pnl_pct or 0) * 100, 3),
            'win': bool((pnl_usd or 0) > 0), 'why': why,
            'regime_flip': bool(ctx.get('regime_at_open') and ctx.get('regime_now') and ctx.get('regime_at_open') != ctx.get('regime_now')),
            'ts': _time.time(), 'time': _time.strftime('%Y-%m-%d %H:%M:%S'),
        })
        arr = arr[-5000:]
        _json.dump(arr, open(LIFE_DATA_F, 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception as _e:
        try: log(f'⚠️ 训练样本落盘失败(不阻塞): {str(_e)[:60]}')
        except Exception: pass


def _note_close(st,pnl,why):
    """记一笔平仓计入护栏累(硬损/早断=消极单计stop+consec; 盈利/保本重置consec)"""
    g=_g(st)
    if pnl<0:
        g['_dpnl']+=pnl; g['_dstops']+=1; g['_consec']+=1
        g['_cool']=max(g['_cool'],CONSEC_COOL_N if g['_consec']>=CONSEC_LOSS_K else 0)
    else:
        g['_consec']=0
    try:
        _jue_after_close(pnl)
    except Exception: pass

def _roll_guard(st,day=None):
    """护栏罐日翻(护栏=土行硬铁律, 不参与任何采样/观察, 也绝不被任何上层改写):
       · 只有在**真跨入新一天**(st 内已记 _day 与新 day 不同)才开新窗——重置日亏/日止损;
       · 同日(st 已记 _day==day)绝不动罐: 杜绝'重启瞬间把当日已到线的止损锁冲掉'这类自毁护栏事故;
       · 本函数只做护栏复位, 不记任何触突/混沌样本(观察层不碰护栏铁律)."""
    g=_g(st)
    if g.get('_day')==day:      # 同日: 绝对保持已建护栏窗口(不动 _dpnl/_dstops/_cool)
        return
    g['_dpnl']=0.0; g['_dstops']=0; g['_consec']=0; g['_cool']=0; g['_day']=day

# (触突微节点已按老板2026-09-09 11:47 令·全杀物理剥除→归档于 _封存_触突微节点_20260909/)
VAULT_FREEZE_ON = __import__('os').environ.get('VAULT_FREEZE_ON','1') != '0'   # 🦄2026-09-17 麒麟护仓钩子开关(可 =0 关)
# 🔪🆕2026-09-17 火印令CUT-03 逆势做空闸(默认开·可 env =0 关 / 回退)
COUNTER_SHORT_GATE_ON = float(__import__('os').environ.get('COUNTER_SHORT_GATE_ON','1'))
COUNTER_SHORT_TREND = 0.20   # t4l(4H大势)超此值=上升势
COUNTER_SHORT_MIN   = float(__import__('os').environ.get('COUNTER_SHORT_MIN','90'))
# 🔪🆕2026-09-27 火印 ED-20260927-237 追多做多闸: 做多且4H大势已冲高(t4l≥阈值) → 拒开(不追高·方向不稳不做单)
CHASE_LONG_GATE_ON = os.environ.get('CHASE_LONG_GATE_ON', '0') != '0'
CHASE_LONG_T4L     = float(os.environ.get('CHASE_LONG_T4L', '3.0'))

# 🐍🆕2026-09-27 火印 ED-20260927-238 择强·自适应等回踩（沙箱 V44/V45）: 回踩门槛随趋势强度加深
def _pull_need_adaptive(t4l):
    """自适应回踩门槛(%): |4H大势|<1% → 0.15 · 1~3% → 0.30 · ≥3% → 0.45（沙箱证门槛越深越好）"""
    try:
        _a = abs(float(t4l or 0))
    except Exception:
        _a = 0.0
    return 0.15 if _a < 1.0 else (0.30 if _a < 3.0 else 0.45)  # 逆势开空的质量分下限


def _vault_frozen():
    """🦄 麒麟护仓: L3冻结旗标 → **只冻结新开仓, 平仓通道永远保留**(老板令 COMMAND_QILIN_VAULTGUARD_ENHANCE)."""
    try:
        import os as _o
        _d = _o.path.dirname(_o.path.abspath(__file__))
        for _p in (_o.path.join(_d, '..', 'vault', 'freeze.flag'),
                   _o.path.join(_d, 'vault', 'freeze.flag')):
            if _o.path.exists(_p):
                return True
    except Exception:
        pass
    return False



# ═══ 🧪 三态门·混沌守无 + 阴阳相位 (火印 ED-20260925-140/141 · 2026-09-25 老板选甲) ═══
#   道法自然: 混沌即无 → 守在"无", 不妄造趋势; 一画开天(信噪比+共识) → 分化阴阳.
#   env 开关默认关(SANT_GATE_ON=0) → 零影响可回退; 置1启用.
SANT_GATE_ON   = os.environ.get('SANT_GATE_ON', '0') != '0'
# ══ 🈸工单 ED-20260925-143 · 三项独立软开关(互不耦合·可单项启停隔离故障·留配置快照可一键回退) ══
five_phase_generation_enable = os.environ.get('five_phase_generation_enable', '0') != '0'  # 五行相生·迭代总开关(灰度④·默认关)
five_phase_restrain_enable   = os.environ.get('five_phase_restrain_enable', '0') != '0'    # 五行相克总开关(灰度③·默认关)
zhizhi_check_enable          = os.environ.get('zhizhi_check_enable', '1') != '0'           # 知止校验总开关(灰度②·默认开)
ZHIZHI_ON = zhizhi_check_enable   # 兼容旧名(等价)
SANT_CHAOS_ON  = os.environ.get('SANT_CHAOS_ON', '1') != '0'   # 混沌守无(随总闸)
SANT_YIN_ON    = os.environ.get('SANT_YIN_ON', '0') != '0'     # 阴态提门槛(沙箱证 0 触发·默认关)
SANT_CERT_MIN  = float(os.environ.get('SANT_CERT_MIN', '3.0')) # 矛盾分阈值
SANT_DIVG_MIN  = float(os.environ.get('SANT_DIVG_MIN', '2.0')) # 背离度阈值
SANT_YIN_SCORE = float(os.environ.get('SANT_YIN_SCORE', '2.5'))# 阴态开仓门槛

# ═══ 🌫 混沌-开天演化范式 (2026-09-26 行老板一键部署令 ED-20260925-141 · 本令火印 ED-20260926-178) ═══
#   纲领: 混沌即"无"(阴阳未判) → 系统**允许常驻混沌**, 不强制落阴阳; 一画开天(信噪比抬升+多因子共识)才分化.
#   顺序固化·不可颠倒: 一生二(确立阳/阴) → 二生三(相生-相克制衡调度·三才就位) → 三生万物(多路径推演出交易方案)
#   铁律: 禁止在混沌中强行制造阴阳信号。 总闸默认 0 = 零影响(沙箱验后接入).
HUNDUN_ON          = os.environ.get('HUNDUN_ON', '0') != '0'
HUNDUN_SNR_MIN     = float(os.environ.get('HUNDUN_SNR_MIN', '0.30'))    # 信噪比(4H动量)下限·低于则疑混沌
HUNDUN_FLIP_N      = int(os.environ.get('HUNDUN_FLIP_N', '3'))          # 相位短窗翻转次数阈值
HUNDUN_PROBE_SCALE = float(os.environ.get('HUNDUN_PROBE_SCALE', '0.25'))# 混沌期探测仓比例(金蟾最低强度)
HUNDUN_TIMEOUT_SEC = int(os.environ.get('HUNDUN_TIMEOUT_SEC', '5400'))  # 混沌超时(默认90分)
HUNDUN_PROBE_MIN_SCORE = float(os.environ.get('HUNDUN_PROBE_MIN_SCORE', '1.0'))  # 探测最低质量分
HUNDUN_LEDGER_F    = os.environ.get('HUNDUN_LEDGER_F', 'data_v2/mtsim/_混沌台账.jsonl')
HUNDUN_FREEZE_ON   = os.environ.get('HUNDUN_FREEZE_ON', '1') != '0'      # 铁律③: 混沌中冻结反馈环(默认开)
HUNDUN_OBS_F       = os.environ.get('HUNDUN_OBS_F', 'data_v2/mtsim/_混沌观测台账.jsonl')     # 铁律②: 观测素材
HUNDUN_EVOLVE_F    = os.environ.get('HUNDUN_EVOLVE_F', 'data_v2/mtsim/_开天演化_六十四爻.jsonl')  # ④三生万物
_HUNDUN_RULES = {'rule1_no_force_yinyang': 1,   # 铁律①: 宁可无信号, 不可捏造信号(混沌中禁强行二分)
                 'rule2_watch_never_stop': 1}   # 铁律②: "无"≠停机 —— 博弈收敛, 观测推演不停
_HUNDUN_FROZEN = {'on': False, 'since': 0.0}    # 反馈环冻结标(跨函数·模块级)




def _hundun_ledger(rec):
    """⑥ 台账埋点: 混沌-绩效复盘台账(只追加·永不覆盖)"""
    try:
        with open(HUNDUN_LEDGER_F, 'a', encoding='utf-8') as _f:
            _f.write(json.dumps(rec, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _hundun_state(st):
    """混沌态器具(存账本 → 断点续处·重启不丢计时)"""
    if not isinstance(st, dict):
        return {}
    _d = st.get('hundun')
    if not isinstance(_d, dict):
        _d = {}
    _d.setdefault('on', False)
    _d.setdefault('since', 0.0)
    _d.setdefault('probe_scale', HUNDUN_PROBE_SCALE)
    _d.setdefault('samples', 0)
    st['hundun'] = _d
    return _d


def _hundun_judge(pick, st):
    """② 混沌判别门 + ④ 一画开天分化判据。返回 (是否混沌, 详情)"""
    reg  = str(pick.get('regime') or '').lower()
    sd   = str(pick.get('side') or '').lower()
    t4   = abs(float(pick.get('t4') or 0))
    t4l  = abs(float(pick.get('t4l') or 0))
    sc   = abs(float(pick.get('score') or 0))
    cert = float(pick.get('certify') or 0)
    divg = float(pick.get('divg') or 0)
    _d = _hundun_state(st)
    r_snr   = t4 < HUNDUN_SNR_MIN                                   # ①趋势信噪比低
    r_div   = (cert >= SANT_CERT_MIN and divg >= SANT_DIVG_MIN)     # ②多因子背离
    r_chop  = (reg == 'chop')                                       # 震荡市本体
    r_grip  = (t4l < HUNDUN_SNR_MIN) or ((t4l > 0) != (t4 > 0))     # ③两回路无一致抓手
    _ph = 1 if ((reg == 'up' and sd.startswith('l')) or (reg == 'dn' and sd.startswith('s'))) else (-1 if reg in ('up', 'dn') else 0)
    _hs = _d.get('ph_hist')
    if not isinstance(_hs, list):
        _hs = []
    _hs.append(_ph); del _hs[:-12]
    _d['ph_hist'] = _hs
    _flips = sum(1 for _i in range(1, len(_hs)) if _hs[_i] and _hs[_i - 1] and _hs[_i] != _hs[_i - 1])
    r_flip  = _flips >= HUNDUN_FLIP_N                               # ④相位短窗反复翻转
    _hits = sum([1 for _x in (r_snr, r_div, r_chop, r_grip, r_flip) if _x])
    _is_c = bool(HUNDUN_ON and (r_chop or _hits >= 2))
    _cons = bool(t4 >= HUNDUN_SNR_MIN and t4l >= HUNDUN_SNR_MIN and ((t4l > 0) == (t4 > 0)))
    _d2 = {'regime': reg, 'side': sd, 't4': round(t4, 3), 't4l': round(t4l, 3), 'score': round(sc, 2),
           'certify': cert, 'divg': divg, '命中项数': _hits, '相位翻转': _flips,
           '条件': {'信噪比低': r_snr, '因子背离': r_div, '震荡市': r_chop, '无抓手': r_grip, '相位翻转': r_flip},
           '分化共识': _cons, '距分化阈值余量': round(max(0.0, HUNDUN_SNR_MIN - t4), 3)}
    return _is_c, _d2


def _hundun_frozen():
    """铁律③: 混沌中 正反馈扩张/负反馈阻尼 两回路一律静默(不自动抬权重·不自动压频次)"""
    try:
        return bool(HUNDUN_ON and HUNDUN_FREEZE_ON and _HUNDUN_FROZEN['on'])
    except Exception:
        return False


def _hundun_no_force_guard(pick):
    """铁律① 硬闸: 禁止混沌中强行二分阴阳(抹平分歧=系统最大心魔)"""
    _mk = [k for k in ('force_phase', '_force_yinyang', 'force_yang', 'force_yin', 'FORCE_PHASE') if pick.get(k)]
    if _mk:
        _L = globals().get('log')
        if _L: _L('🧱 铁律① 拒止: 混沌中试图强行二分阴阳(%s) → 拦下(宁可无信号)' % ','.join(_mk))
        _hundun_ledger({'ts': time.time(), '时刻': time.strftime('%F %T'), '事件': '铁律①拒止·强行二分',
                        'coin': pick.get('coin'), '标记': _mk})
        return '混沌守无·铁律①: 禁止强行二分阴阳(本窗不可抹平分歧强归阳/阴) → 拦下'
    return None


def _hundun_observe(st, pick, det):
    """铁律②: 混沌中博弈收敛, 但**观测推演不停** —— 每轮采样, 持续为"无中生有"积累素材"""
    try:
        _h = _hundun_state(st)
        _h['obs'] = int(_h.get('obs') or 0) + 1
        with open(HUNDUN_OBS_F, 'a', encoding='utf-8') as _f:
            _f.write(json.dumps({'ts': time.time(), '时刻': time.strftime('%F %T'), 'coin': pick.get('coin'),
                                 'regime': det.get('regime'), 't4': det.get('t4'), 't4l': det.get('t4l'),
                                 'score': det.get('score'), 'certify': det.get('certify'), 'divg': det.get('divg'),
                                 '命中项数': det.get('命中项数'), '距分化阈值余量': det.get('距分化阈值余量'),
                                 '观测序号': _h['obs'], '探测比例': _h.get('probe_scale')}, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _kaixin_evolve(pick, st, det):
    """④ 三生万物: 三才齐备 → 四象(4)→八卦(8)→六十四爻(64) 多情景分支(择向/头寸/止盈止损)·只推演不下单"""
    try:
        _amp = abs(float(pick.get('amp6') or 0))
        _ce  = float(pick.get('certify') or det.get('certify') or 0)
        _dvg = float(pick.get('divg') or det.get('divg') or 0)
        _brn = float(pick.get('burn') or 0); _ftg = float(pick.get('fatigue') or 0)
        # 六爻: 爻1大势 爻2快势 爻3量能 爻4校验 爻5分歧 爻6能量 (阳=1/阴=0)
        _yao = [1 if float(det.get('t4') or 0) >= 0 else 0, 1 if float(det.get('t4l') or 0) >= 0 else 0,
                1 if _amp >= 0.8 else 0, 1 if _ce < 0.5 else 0, 1 if _dvg < 2.0 else 0,
                1 if (_brn < 2.5 and _ftg < 6) else 0]
        _si = lambda b: ('顺势重仓', '100%', '让吐0.8%') if b >= 5 else \
                        ('顺势中仓', '65%', '让吐0.6%') if b == 4 else \
                        ('轻仓试单', '42%', '锁盈0.4%') if b == 3 else \
                        ('等回抽限价', '25%', '锁盈0.25%') if b == 2 else ('守无·不出手', '0%', '—')
        _branches = []
        for _i in range(64):
            _b = [(_i >> _k) & 1 for _k in range(6)]
            _d1, _d2, _d3 = _si(sum(_b))
            _branches.append({'爻': ''.join(str(_x) for _x in _b), '阳爻数': sum(_b),
                              '择向': _d1, '头寸': _d2, '止盈': _d3,
                              '止损': '-1.3%' if sum(_b) >= 2 else '—'})
        _sixiang = [{'象': ''.join(str(_x) for _x in [(_i >> _k) & 1 for _k in range(2)]), '阳爻数': bin(_i).count('1')} for _i in range(4)]
        _bagua = [{'卦': ''.join(str(_x) for _x in [(_i >> _k) & 1 for _k in range(3)]), '阳爻数': bin(_i).count('1')} for _i in range(8)]
        _cur = int(''.join(str(_x) for _x in _yao), 2)
        _out = {'ts': time.time(), '时刻': time.strftime('%F %T'), 'coin': pick.get('coin'),
                '六爻(大势/快势/量能/校验/分歧/能量)': _yao, '本爻': ''.join(str(_x) for _x in _yao),
                '四象': _sixiang, '八卦': _bagua, '六十四爻': _branches, '当爻': _branches[_cur]}
        with open(HUNDUN_EVOLVE_F, 'a', encoding='utf-8') as _f:
            _f.write(json.dumps(_out, ensure_ascii=False) + '\n')
        _hundun_ledger({'ts': time.time(), '时刻': time.strftime('%F %T'), '事件': '三生万物·演化方案出',
                        'coin': pick.get('coin'), '本爻': _out['本爻'], '当爻方案': _out['当爻']})
        _L = globals().get('log')
        if _L: _L('🌟 三生万物: 四象(4)→八卦(8)→六十四爻(64) 多情景推演完成 · 本爻 %s → %s/%s/%s(只推演不下单)' % (
            _out['本爻'], _out['当爻']['择向'], _out['当爻']['头寸'], _out['当爻']['止盈']))
        return _out
    except Exception as _e:
        _L = globals().get('log')
        if _L: _L('⚠ 演化推演异常: %s' % str(_e)[:80])
        return None


def _hundun_hook(st, pick):
    """★ED-141: ②判别 → ③行为约束 → ④一画开天 → ⑤超时 → ⑥台账。返回拦因 or None(放行)"""
    try:
        _now = time.time()
        _is_c, _d = _hundun_judge(pick, st)
        _h = _hundun_state(st)
        _was = bool(_h.get('on'))
        _L = globals().get('log')
        if _is_c:
            if not _was:                                             # 入混沌(⑥)
                _h['on'] = True; _h['since'] = _now
                _h['probe_scale'] = HUNDUN_PROBE_SCALE; _h['timeout_logged'] = False
                _HUNDUN_FROZEN['on'] = True; _HUNDUN_FROZEN['since'] = _now   # 铁律③: 反馈环冻结休眠
                if _L: _L('❄ 铁律③ 反馈环冻结: 正反馈扩张/负反馈阻尼两回路静默(相生推演/相克校验/反哺权重/判别器降权 全停)')
                _hundun_ledger({'ts': _now, '时刻': time.strftime('%F %T'), '事件': '入混沌',
                                'coin': pick.get('coin'), '详情': _d})
                if _L: _L('🌫 入混沌态: %s(阴阳未判·守"无"·不妄造趋势) 命中%d项 %s' % (pick.get('coin'), _d['命中项数'], _d['条件']))
            _dur = _now - float(_h.get('since') or _now)
            if _dur > HUNDUN_TIMEOUT_SEC and not _h.get('timeout_logged'):   # ⑤ 超时守护
                _h['timeout_logged'] = True
                _h['probe_scale'] = max(0.05, float(_h.get('probe_scale') or HUNDUN_PROBE_SCALE) * 0.5)
                _hundun_ledger({'ts': _now, '时刻': time.strftime('%F %T'), '事件': '混沌超时',
                                '持续秒': round(_dur, 1),
                                '处置': '仅降探测至%.2f·提采样频次·**不强制生成阴阳**' % _h['probe_scale'],
                                '距分化余量': _d['距分化阈值余量'], '详情': _d})
                if _L: _L('🌫 混沌超时%.0f分 → 不强制分化: 探测降至%.0f%%·采样加密(守"无")' % (_dur / 60.0, _h['probe_scale'] * 100))
            _hundun_observe(st, pick, _d)                             # 铁律②: "无"非停机 → 观测推演不停·积累素材
            _nfg = _hundun_no_force_guard(pick)                       # 铁律①: 禁混沌中强行二分
            if _nfg:
                return _nfg
            _sc = abs(float(pick.get('score') or 0))
            if _sc < HUNDUN_PROBE_MIN_SCORE:                          # ③ 质量过低 → 纯观测
                return '混沌守无门: 质量分%.1f<%.1f → 仅观测推演(不出手·静候一画开天)' % (_sc, HUNDUN_PROBE_MIN_SCORE)
            pick['_hundun_probe'] = True                              # ③ 放最小探测(金蟾采样·不为收益)
            _h['samples'] = int(_h.get('samples') or 0) + 1
            if _L: _L('🌫 混沌态探测(金蟾最低强度): %s %s 分%.1f → 放最小仓%.0f%%(仅采样·不为收益)' % (
                pick.get('coin'), pick.get('side'), _sc, float(_h.get('probe_scale') or HUNDUN_PROBE_SCALE) * 100))
            return None
        if _was:                                                      # ④ 一画开天·分化(顺序固化)
            _dur = _now - float(_h.get('since') or _now)
            _rsn = '分化共识(信噪比抬升+多因子同向)' if _d.get('分化共识') else '信噪比抬升'
            _h['on'] = False; _h['since'] = 0.0; _h['timeout_logged'] = False
            _HUNDUN_FROZEN['on'] = False; _HUNDUN_FROZEN['since'] = 0.0   # 铁律③: 解冻(阴阳立·反馈环重启)
            _kaixin_evolve(pick, st, _d)                              # ④三生万物: 四象→八卦→六十四爻
            _hundun_ledger({'ts': _now, '时刻': time.strftime('%F %T'), '事件': '出一画开天·分化',
                            '持续秒': round(_dur, 1), '退出原因': _rsn, '详情': _d})
            if _L:
                _L('☯ 一画开天: 混沌%.0f分 → 分化确立(一生二·%s)' % (_dur / 60.0, _rsn))
                _L('☯ 二生三: 阴阳相位稳定 → 激活相生-相克制衡调度链路(三才就位)')
                _L('☯ 三生万物: 多路径沙盘推演(头寸/入场时机/离场集合) → 演化交易方案')
        return None
    except Exception as _e:
        _L = globals().get('log')
        if _L: _L('⚠ 混沌门异常(放行): %s' % str(_e)[:80])
        return None




def _santai_gate(pick):
    """三态门: 阳态放行 / 阴态提门槛 / 混沌守无(拒开待分化). 返回 拦因 or None"""
    if not pick:
        return None
    if pick.get('_sovereign'):
        return None          # ☯2026-10-01 三态门并入道统: 道统先导单已前置避 chop/逆势币 ⇒ 不叠拦(一个声音)
    try:
        reg  = str(pick.get('regime') or '').lower()   # up / dn / chop
        sc   = abs(float(pick.get('score') or 0))
        cert = float(pick.get('certify') or 0)          # 信号矛盾分
        divg = float(pick.get('divg') or 0)             # 背离度
        sd   = str(pick.get('side') or '').lower()
        # ① 混沌守无: regime=chop 或 多因子背离(矛盾+背离双高)
        if SANT_CHAOS_ON and (reg == 'chop' or (cert >= SANT_CERT_MIN and divg >= SANT_DIVG_MIN)):
            _w = 'regime=chop' if reg == 'chop' else '矛盾%.1f+背离%.1f' % (cert, divg)
            return '混沌守无门: %s → 拒开(守"无"·不妄造趋势·静待一画开天)' % _w
        # ② 阴阳相位: 阳态(同向)放行; 阴态(逆势)须高质量
        if SANT_YIN_ON and reg in ('up', 'dn'):
            _yang = ((reg == 'up' and sd.startswith('l')) or (reg == 'dn' and sd.startswith('s')))
            if not _yang and sc < SANT_YIN_SCORE:
                return '阴阳相位门·阴态: regime=%s但%s逆势 且 质量分%.1f<%s → 拒开(非同势)' % (reg, sd, sc, SANT_YIN_SCORE)
    except Exception:
        return None
    return None


def _guard_block(st, macro=None, pick=None):
    """护栏总闸: 返回 拦因 or None(放). 顺序: 冷却(连亏) > 日损熔断 > 日止损超限 > 黑天鹅 > 闪崩.
       macro: 可选短窗大盘|幅|; pick.sig 含 last15/flash 判. 硬护栏=护本金第一原则.
       🆕2026-09-11 自愈: 日亏 _dpnl 按'当日 trades'重算(防旧账残留锁死今天)。"""
    # 🌫 混沌-开天范式(火印 ED-20260926-178·行 ED-20260925-141): 混沌不锁死机会 → 放最小探测
    if HUNDUN_ON and pick:
        _hbm = _hundun_hook(st, pick)
        if _hbm:
            return _hbm
    # 🧪 三态门(火印 ED-140/141): 混沌守无/阴阳相位 —— 挂护栏总闸最前(nullpick 则跳过)
    if SANT_GATE_ON and pick:
        _stg = _santai_gate(pick)
        if _stg:
            return _stg

    g=_g(st)
    # 🦄🆕2026-09-17 麒麟护仓(L3冻结): 旗标在 → 拒绝新开仓(平仓通道不受影响)
    if VAULT_FREEZE_ON and _vault_frozen():
        return '麒麟护仓·L3冻结开仓入口(只保留平仓通道): vault/freeze.flag 在 → 拒新开(护本)'
    # 🔪🆕2026-09-17 火印令CUT-03 逆势做空闸: 上升势(t4l>+0.20)要开空 → 质量分<90 则拒
    #    铁证: 真钱 short 41笔 胜39.0% 净-115.80 vs long 21笔 胜47.6% 净+11.91; 单笔最亏TOP8七笔是空单
    #    ⚠ 只拦'逆势开空'(不做逆势摸顶); 逆势做多不动(50%胜·免得误伤低吸)
    if COUNTER_SHORT_GATE_ON and pick and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
        _sd=str(pick.get('side') or '').lower()
        _t4=float(pick.get('t4l') or 0)
        _sc=float(pick.get('score') or 0)
        if _sd.startswith('s') and _t4 > COUNTER_SHORT_TREND and _sc < COUNTER_SHORT_MIN:
            return (f'逆势做空闸: {pick.get("coin")}上升势(t4l={_t4:+.2f}>+{COUNTER_SHORT_TREND})'
                    f'且质量分{_sc:.0f}<{COUNTER_SHORT_MIN:.0f} → 拒开空(不做逆势摸顶·护本)')
    # 🔪🆕2026-09-27 火印 ED-20260927-237 追多做多闸（择向精准·老板三令之③）
    #   铁证(09-23至今130笔): 做多&t4l≥+3% = 70笔 胜33% 净−534.08; 拒掉后余60笔 胜62% 净+531.15
    if CHASE_LONG_GATE_ON and pick:
        try:
            _csd = str(pick.get('side') or '').lower()
            _ct4 = float(pick.get('t4l') or 0)
            _is_long = _csd.startswith('l') or _csd in ('多', 'buy', 'up')
            if _is_long and _ct4 >= CHASE_LONG_T4L:
                return (f'追多做多闸: {pick.get("coin")}4H大势已冲高(t4l={_ct4:+.2f}≥+{CHASE_LONG_T4L:.1f})'
                        f' → 拒开(不追高·方向不稳不做单)')
        except Exception:
            pass
    if GLOBAL_CIRCUIT_ON:   # 🗄 2026-09-11 封存开关: 关时跳过全域锁死类护栏(日亏/日止损/连亏), 只留单笔护本
        if g['_cool']>0:
            g['_cool']-=1
            if g['_consec']>=CONSEC_LOSS_K:
                return f'连亏冷却锁: 连亏{g["_consec"]}单≥{CONSEC_LOSS_K}·自动冷却·防同刀砍(休{g['_cool']}轮后再试)'
        if g['_dpnl']<=-_jg_loss_line():
            return f'日亏熔断: 今日已实现亏{g["_dpnl"]:+.1f}≤线{_jg_loss_line():.1f}$(权益{(globals().get("_LIVE_EQ") or 0):.0f}×{DAY_LOSS_MAX*100:.0f}%)→空仓休·暂停今日新开(护本)'
        if g['_dstops']>=DAY_STOP_MAX:
            return f'单日止损超限: 今日止损{g["_dstops"]}次≥{DAY_STOP_MAX}→锁当日新开'
    m=0 if macro is None else abs(macro)
    if m>=BLACK_SWAN_PCT:
        return f'防黑天鹅: 大盘短窗|动|{m*100:.1f}%≥{BLACK_SWAN_PCT*100}%→拒开(护本第一)'
    if pick and abs(pick.get('last15',0) or 0)>=FLASH_PCT*100:   # last15=%×100; FLASH_PCT分数0.035=3.5%→乘100对齐(修真连测发现的live真实last15误拦 2026-09-08)
        return f'防闪崩: {pick["coin"]}15m单根|{pick["last15"]:.2f}%|≥{FLASH_PCT*100:.1f}%→不追闪崩插针'
    return None

def _radar_feed(pool, chosen):
    """📡 雷达情报化(2026-09-15 老板令): 照见结果写 _雷达情报.json → 供哨兵(白虎)合并进军情总线.
       定位: 雷达=开明兽情报工具(信号增强)·只报军情·不决策. 纯写盘·零侵入交易逻辑."""
    try:
        import json as _j, os as _o, time as _t
        _bdir=_o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir)=='子引擎': _bdir=_o.path.dirname(_bdir)   # 子引擎内核副本→回主目录(雷达情报统一总线)
        _fp=_o.path.join(_bdir,'data_v2','mtsim','_雷达情报.json')
        _items=[]
        for s in (pool or []):
            sd=s.get('side')
            _al=sum([
                1 if (sd=='long' and s.get('e4')=='up') or (sd=='short' and s.get('e4')=='dn') else 0,
                1 if (sd=='long' and s.get('e1')=='up') or (sd=='short' and s.get('e1')=='dn') else 0,
                1 if (sd=='long' and (s.get('t4l',0) or 0)>0.15) or (sd=='short' and (s.get('t4l',0) or 0)<-0.15) else 0,
            ])
            _items.append({'coin':s.get('coin'),'side':sd,'align':_al,
                           'embryo':round(abs(float(s.get('score',0) or 0)) + (2.0 if _al==2 else (1.0 if _al==1 else (0.0 if _al==3 else -1.0))),2)})
        # 🔓2026-10-08 火印 ED-20261008-627 点亮·雷达情报写全池（老板令「点亮系统」）: 补齐全池未照见之币
        try:
            _have=set((_it.get('coin') for _it in _items))
            for _ck in list(WATCH_COINS.keys()):
                if _ck not in _have:
                    _items.append({'coin':_ck,'side':'','align':0,'embryo':0.0})
        except Exception:
            pass
        _d={'updated':_t.strftime('%Y-%m-%d %H:%M:%S'),'chosen':(chosen.get('coin')+' '+chosen.get('side')) if chosen else '','nodes':_items}
        _tmp=_fp+'.tmp'; _j.dump(_d,open(_tmp,'w',encoding='utf-8'),ensure_ascii=False); _o.replace(_tmp,_fp)
    except Exception:
        pass


# ═══ 🐉 五行相生相克制衡链路 (火印 ED-20260925-138 · 💊2026-09-25 老板令「认认真真完善」· 真接版) ═══
#   相生闭环(五环真接·末环反哺首环): 择向输出 → 推演 → 沉淀 → 归档 → 迭代(反哺择向)
#   相克约束(三克真接·有牙): 麒麟风控 ⟂ 择向 · 校验分 ⟂ 择向 · 沙箱 ⟂ 实盘参数
WUXING_COUNTER_F = os.environ.get('WUXING_COUNTER_F', 'data_v2/mtsim/_五行制衡_计数.json')
WUXING_STATE_F   = os.environ.get('WUXING_STATE_F', 'data_v2/mtsim/_五行制衡_状态.json')   # 🌀沙箱可隔离
WUXING_SNAP_F    = os.environ.get('WUXING_SNAP_F', 'data_v2/mtsim/_五行_权重快照.json')      # 🈸工单1-2 离线权重快照(唯一权重来源)
WUXING_SAMPLE_F  = os.environ.get('WUXING_SAMPLE_F', 'data_v2/mtsim/_五行_样本.jsonl')       # 🈸工单1-3 迭代样本质料(含相位/probe/知止/终止标记)
_WUXING_CACHE = {'t': 0.0, 'w': {'多': 1.0, '空': 1.0}, 'veto': False}


def _wuxing_read():
    try:
        if os.path.exists(WUXING_STATE_F):
            return json.load(open(WUXING_STATE_F, encoding='utf-8'))
    except Exception:
        pass
    return {}


def _wuxing_write(d):
    try:
        d['_updated'] = time.strftime('%F %T')
        json.dump(d, open(WUXING_STATE_F, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    except Exception:
        pass


def _wuxing_tick(k, n=1):
    '''相克链路放行计数(择向结论必须走完制衡链路方可放行)'''
    try:
        d = {}
        if os.path.exists(WUXING_COUNTER_F):
            d = json.load(open(WUXING_COUNTER_F, encoding='utf-8'))
        d[k] = int(d.get(k, 0)) + n
        d['_updated'] = time.strftime('%F %T')
        json.dump(d, open(WUXING_COUNTER_F, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    except Exception:
        pass


def _wuxing_link(stage, win=None, side=None):
    '''🐉 五行相生·五环真接(择向输出→推演→沉淀→归档→迭代) + 迭代反哺择向
       沉淀环按"多/空"分账记胜负; 每满5笔结算 → 迭代出"反哺权重"(0.85~1.15) 供择向排序用.
       ⇒ 末环真反哺首环(不是只计数): 哪一方向近期赚, 择向就多给那一方向机会.'''
    d = _wuxing_read()
    d[stage] = int(d.get(stage, 0)) + 1
    if stage == '沉淀' and side is not None:
        _sd = '多' if str(side).startswith('l') else '空'
        _k = ('沉淀胜_' + _sd) if win else ('沉淀负_' + _sd)
        d[_k] = int(d.get(_k, 0)) + 1
        # 🈲 工单 1-2: 禁止行情实时线程热改内存权重 —— 此处**只采样本**, 迭代交离线定时器
        #   离线器 `_五行_迭代_offline.py`: 过滤样本(1-3) → 算权重(±7.5%硬上限·1-4) → 只写快照
        #   内核仅在整点窗口读快照("原子替换")。解耦 ⇒ 抑闭环自激发散。
    _wuxing_write(d)


def _wuxing_sample(pos, pr, pnl_pct, pnl_usd, why):
    '''🈸工单1-3 迭代样本质料: 落一行 JSONL, 带齐过滤所需标记
       (相位 / probe / 知止是否通过 / 是否异常终止) → 供**离线**迭代器筛选用.'''
    try:
        _ph = (pos.get('_ctx') or {}).get('regime_at_open') or (pos.get('_ctx') or {}).get('regime') or '?'
        _rec = {
            'ts': time.strftime('%F %T'), 'coin': pos.get('coin'), 'side': pos.get('side'),
            'pnl': round(float(pnl_usd or 0), 4), 'pnl_pct': round(float(pnl_pct or 0) * 100, 4),
            'why': str(why)[:40], 'phase': _ph,
            'probe': bool(pos.get('_probe') or pos.get('probe')),
            'zhizhi_ok': bool(pos.get('_zhizhi_ok', True)),
            'abnormal': ('异常' in str(why) or 'err' in str(why).lower()),
            'peak_pct': round(float(pos.get('peak_pct') or 0) * 100, 4),
        }
        with open(WUXING_SAMPLE_F, 'a', encoding='utf-8') as _f:
            _f.write(json.dumps(_rec, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _wuxing_side_w(side):
    '''反哺权重(按方向) → 参与择向排序: 五行"迭代"真影响"择向输出"'''
    if _hundun_frozen():
        return 1.0        # 🌫 铁律③: 混沌中反哺权重冻结(不自动抬权重)
    _wuxing_refresh()   # 🩹2026-09-25 补漏: 先热加载(否则缓存永远1.0→反哺空转·单元实证抓出)
    try:
        return float(_WUXING_CACHE['w']['多' if str(side).startswith('l') else '空'])
    except Exception:
        return 1.0


def _wuxing_refresh():
    '''每300秒热加载: 反哺权重 + 沙箱相克(veto)'''
    _now = time.time()
    if _now - _WUXING_CACHE['t'] < 300:
        return
    _WUXING_CACHE['t'] = _now
    # 🈸工单 1-2: 权重**只从离线快照**读(内核不自行计算) + 相生总开关(灰度④·默认关)
    _snap = {}
    try:
        if five_phase_generation_enable and os.path.exists(WUXING_SNAP_F):
            _snap = json.load(open(WUXING_SNAP_F, encoding='utf-8'))
    except Exception:
        _snap = {}
    for _sd in ('多', '空'):
        try:
            _v = float(_snap.get('权重_' + _sd, 1.0) or 1.0)
            _v = max(0.925, min(1.075, _v))   # 🈸工单 1-4: 因子钳位(±7.5%硬界·双保险)
            _WUXING_CACHE['w'][_sd] = _v
        except Exception:
            _WUXING_CACHE['w'][_sd] = 1.0
    _v = False
    try:
        _f = 'data_v2/mtsim/_推演_三态机制沙箱_20260925.json'
        if os.path.exists(_f):
            _j = json.load(open(_f, encoding='utf-8'))
            _rows = _j.get('阶段') or _j.get('groups') or []
            for _r in _rows:
                _nm = str(_r.get('档') or _r.get('name') or '')
                _exp = _r.get('净期望%/笔')
                if _exp is None:
                    _exp = _r.get('net_exp')
                if _nm.startswith('A') and _exp is not None and float(_exp) < 0:
                    _v = True
            if _v:
                _wuxing_tick('相克·沙箱制衡')
                try:
                    log('🐉 五行相克·沙箱制衡实盘参数: 沙箱现制净期望<0 → 择向门槛上调×1.5')
                except Exception:
                    pass
    except Exception:
        _v = False
    _WUXING_CACHE['veto'] = _v


def _wuxing_veto():
    try:
        _wuxing_refresh()
        return bool(_WUXING_CACHE['veto'])
    except Exception:
        return False
# ═══ 五行链路结束 ═══


def _funding_leg_pick():
    """🪙 金蟾·积沙成塔·空仓期费率反向腿（火印 ED-20260927-244·默认关）
       近30天资金费率尾部分位 ≤5% → 做多(空头拥挤·反向) / ≥95% → 做空(多头拥挤·反向)；只取最极端一币。
       数据源: data_v2/mtsim/_资金费率缓存.json（由 _资金费率_缓存.py 刷新）。"""
    try:
        import json as _js, bisect as _bi
        _p = 'data_v2/mtsim/_资金费率缓存.json'
        if not os.path.exists(_p): return None
        _d = _js.load(open(_p, encoding='utf-8'))
        _now = _time.time(); _best = None
        for _c in WATCH_COINS:
            _row = _d.get(_c) or []
            if len(_row) < 30: continue
            _t = [int(x[0]) for x in _row]; _r = [float(x[1]) for x in _row]
            _j = _bi.bisect_right(_t, _now) - 1
            if _j < 30: continue
            _seg = _r[max(0, _j - 89):_j + 1]; _s = sorted(_seg); _m = len(_s)
            _lo = _s[max(0, int(FUND_LEG_TAIL * _m) - 1)]; _hi = _s[min(_m - 1, _m - int(FUND_LEG_TAIL * _m))]
            _cur = _r[_j]
            if _cur <= _lo: _sd = 'long'
            elif _cur >= _hi: _sd = 'short'
            else: continue
            if (_best is None) or (abs(_cur) > abs(_best[1])): _best = (_c, _cur, _sd)
        if not _best: return None
        _c, _rate, _sd = _best
        _sig = None
        try: _sig = _coin_sig(_c)
        except Exception: _sig = None
        if not _sig: _sig = {'coin': _c, 'score': 0.0}
        _sig['coin'] = _c; _sig['side'] = _sd
        _sig['_fund_leg'] = True
        # 🔧🆕2026-10-06 火印 ED-20261006-536（参经修器）：经 ED-378 老板准「点亮费率腿·第九路归位」，
        #   但 _coin_sig 因「相位观望」返回 None 时走兜底 sig **无 tp** ⇒ 被《知止》(ED-138)判废 ⇒ 该路 100% 空转
        #   （今日五户共 452 次弃单）。治：补齐 tp（按 15m 动能定 UP/DOWN），使费率腿合契约、真正在岗。
        try:
            if _sig.get('tp') in (None, '', '?', 0, '0'):
                _c15f = _candles(_c, '15m', 30)
                if _c15f and len(_c15f) >= 11:
                    _mff = sum(_c15f[-5:]) / 5.0; _msf = sum(_c15f[-10:]) / 10.0
                    _sig['tp'] = 'UP' if _mff >= _msf else 'DOWN'
                else:
                    _sig['tp'] = 'UP' if _sd == 'long' else 'DOWN'
        except Exception:
            _sig['tp'] = 'UP' if _sd == 'long' else 'DOWN'
        try: _sig['score'] = max(abs(float(_sig.get('score') or 0)), PICK_ABS_MIN)
        except Exception: _sig['score'] = PICK_ABS_MIN
        if not _sig.get('pr'):
            try: _sig['pr'] = _price(_c)
            except Exception: pass
        log('🪙 金蟾·空仓期费率反向腿: %s %s (近端费率%.5f%%·极端尾部·反拥挤)' % (
            _c, '做多' if _sd == 'long' else '做空', _rate * 100))
        return _sig
    except Exception as _e:
        try: log('🪙 费率腿跳过(异常): %s' % _e)
        except Exception: pass
        return None


def _pick():
    """腾蛇·择强(辨向增强·老板23:33选A): 不只挑|score|最大, 更要挑'方向最清'的币开——
       同一币多周期(4H大势4H / 15m趋势tp / MACD金死叉)一致=方向清=优先; 强冲突(想开的就是跟4H大势顶牛→逆势隐患)=弃.
       这样腾蛇做方向(块1)时, 从'看谁冲就开谁'升级为'挑方向不矛盾的那个开', 治那2类'被我错塞进门闸'的逆势摸.
       规则: ①只放 |score|≥阀 的候选; ②在候选里先筛掉'重逆势'(4H对持仓向明显相反+15m急反抽顶牛)币; ③剩下按|score|取最强(同清度的优先清)."""
    _L = globals().get('log')   # 🈴2026-09-27 火印 ED-20260927-245: 修 _L 未赋值(ED-240/243 新码在非全阴路径引用 ⇒ UnboundLocalError · 择向中断)
    cands=[]
    _LAST_SIGS.clear()
    for c in WATCH_COINS:
        s=_coin_sig(c)
        if s: _LAST_SIGS[c]=s
        # 🐉五行相克·沙箱⟂实盘参数: 沙箱判现制净期望<0 → 择向门槛抬×1.5(有牙)
        if s and abs(s.get('score',0))>=PICK_ABS_MIN*(1.5 if _wuxing_veto() else 1.0):
            cands.append(s)
    if not cands: return None
    # ②先剔除 重逆势摸 币: 想开方向但4H大势明显反向反对(t4符号与side相反)且已是急动量顶牛(last15强反向)
    clean=[]
    for s in cands:
        t4=s.get('t4',0) or 0; last15=s.get('last15',0) or 0; tp=s.get('tp')
        side=s.get('side')
        macro_against = (side=='long' and t4<=-0.8) or (side=='short' and t4>=0.8)
        loud_conflict = ((side=='long' and tp=='DOWN' and last15<-0.3) or (side=='short' and tp=='UP' and last15>0.3))
        if macro_against and loud_conflict:
            continue   # 重逆势·弃(腾蛇不选逆4H大势又要摸的币)
        # 🆕2026-09-09 高周期认向闸(治方向中枢噪声病): 短窗想开的方向 vs 高层regime('up'/'dn') 明显顶牛→弃
        #   例: 短窗想 long 但 4H/1H 大势 regime='dn'(更高层一致向下)→ 逆大势摸多, 掐; 反之亦然.
        #   只弃“高层有一致反向”; regime='chop'(高层无同向)不在此弃(留给下面的宁缺毋滥判定).
        reg=s.get('regime')
        reg_against = (side=='long' and reg=='dn') or (side=='short' and reg=='up')
        if reg_against:
            continue   # 高层一致反对短方向→弃(不逆更高大势开)
        # 🔪丁刀·源头(ED-386): 凡 side 逆 **3.3日大势(t4l)** ⇒ 弃(与「逆势做空闸」同口径)。
        #   治: SOL 3日+2.21%上升, 短窗回抽却给"空" ⇒ 在择强处即剔(不再靠下游兜)。
        if SIGN_TREND_ALIGN_ON:
            _t4lv = float(s.get('t4l') or 0)
            if (side == 'long' and _t4lv < 0) or (side == 'short' and _t4lv > 0):
                continue
        # ⚫🆕2026-09-15 10:16 A: 择向精准闸已封存(死代码移除) → 交"精准择向雷达"接管择向(见 _coin_sig 提质).
        clean.append(s)
    if not clean:
        return None   # 全部重逆势/无方向清→宁缺毋滥(腾蛇不硬开矛盾币)

    # ═══ 🐉 阴阳消长·相位闸 (2026-09-25 火印 ED-20260925-138 · 写死常驻·非开关) ═══
    #   原理: 择向层输出研判之前, 先判系统阳-阴运行相位。阳态许可开仓, 阴态拦截。
    #   阳态判据(实测有效·43笔扩样: 阳66.7% vs 阴20.0%): 三周期对齐≥2 且 4H大势(t4l)方向与持仓同向。
    _yang = []
    for s in clean:
        _side = s.get('side'); _t4l = float(s.get('t4l') or s.get('t4') or 0)
        _e4 = s.get('e4'); _e1 = s.get('e1')
        _al = 0
        _al += 1 if ((_side == 'long' and _e4 == 'up') or (_side == 'short' and _e4 == 'dn')) else 0
        _al += 1 if ((_side == 'long' and _e1 == 'up') or (_side == 'short' and _e1 == 'dn')) else 0
        _al += 1 if ((_side == 'long' and _t4l > 0.15) or (_side == 'short' and _t4l < -0.15)) else 0
        # 阳态: 三周期对齐≥2 且 大势方向与持仓同向
        _is_yang = (_al >= 2) and ((_side == 'long' and _t4l > 0) or (_side == 'short' and _t4l < 0))
        if _hundun_frozen():
            s['_yx_phase'] = 'hundun'; _yang.append(s)   # 🌫 铁律①: 混沌中**不二分阴阳**(交混沌门处置)
        elif _is_yang:
            s['_yx_phase'] = 'yang'; _yang.append(s)
        else:
            s['_yx_phase'] = 'yin'
    if not _yang:
        _L = globals().get('log')
        if _L: _L(f"☯ 相位闸·阴态 → 全候选{len(clean)}个皆阴 → 拦截开仓(等阳态再来)")
        return None
    clean = _yang
    _wuxing_tick('择向输出')
    # ═══ 相位闸结束 ═══

    # ═══ 🐉 择向加严①②·多空失衡+币池分层 (2026-10-09 火印 ED-20261009-723 · 试验田门·**默认关**) ═══
    #   ①多头加严: 多头须 相位表=顺 且 该币同向率≥DIR_LONG_HR_MIN(默认0.55) —— 实据 空57.0% vs 多47.4%
    #   ②币池分层: 低准七币(ADA/AVAX/LTC/FIL/ARB/XRP/NEAR)须 |score|≥DIR_LOW_MIN(默认2.5) 方入候选
    if os.environ.get('DIR_HARDEN_ON', '0') == '1':
        _tier_bad = {x.strip().upper() for x in (os.environ.get('DIR_LOW_TIER') or '').split(',') if x.strip()}
        _low_min = float(os.environ.get('DIR_LOW_MIN', '2.5') or 2.5)
        _long_hr = float(os.environ.get('DIR_LONG_HR_MIN', '0.55') or 0.55)
        _keep_h = []
        for s in clean:
            _hc = str(s.get('coin') or '').upper()
            _hs = s.get('side')
            _hsc = abs(float(s.get('score') or 0))
            if _hc in _tier_bad and _hsc < _low_min:
                if _L: _L(f"🐉 择向加严②: {_hc} 低准币弱信(|score|{_hsc:.1f}<{_low_min}) → 弃")
                continue
            if _hs == 'long':
                _hp = _phase_of(s.get('coin')) or {}
                if _hp.get('相位') != '顺' or float(_hp.get('同向率') or 0) < _long_hr:
                    if _L: _L(f"🐉 择向加严①: {_hc} 多头不达标(相位={_hp.get('相位')}·同向率={_hp.get('同向率')}) → 弃")
                    continue
            _keep_h.append(s)
        if _keep_h:
            clean = _keep_h
        else:
            if _L: _L(f"🐉 择向加严: 候选{len(clean)} 皆不达标 → 不做单")
            return None
    # ═══ 择向加严①② 结束 ═══

    # ═══ 🐉 趋势边际判别器 (2026-09-25 火印 ED-20260925-138 · 写死常驻) ═══
    #   原理: 消耗/分歧/疲劳 三因子观测趋势是否衰竭。原口径"≥2项触发"实测只触发1项→失效。
    #   新口径(重标定): **任一因子触发即下调置信权重**(而非拦死)·两项及以上则暂缓。
    _surv = []
    for s in clean:
        _t4 = float(s.get('t4') or 0); _t4l = float(s.get('t4l') or 0)
        _sc = abs(float(s.get('score') or 0))
        # 消耗因子: 近端位移相对大势过大(>2.5倍) → 衰竭
        _burn = 1 if (abs(_t4) > 0.9 and abs(_t4) > abs(_t4l) * 2.5) else 0
        # 分歧因子: 短窗方向与4H大势相悖
        _side = s.get('side')
        _diverge = 1 if ((_side == 'long' and _t4l < -0.15) or (_side == 'short' and _t4l > 0.15)) else 0
        # 疲劳因子: score 已被时空梭/位置加权推高但大势未跟(虚高)
        _fatigue = 1 if (_sc >= 2.5 and abs(_t4l) < 0.15) else 0
        _trip = _burn + _diverge + _fatigue
        s['_mg_trip'] = _trip
        if _trip >= 2:
            _L = globals().get('log')
            if _L: _L(f"⚖ 边际判别器: {s.get('coin')} 衰减≥2项(消耗{_burn}/分歧{_diverge}/疲劳{_fatigue}) → 暂缓")
            if _hundun_frozen():
                if _L: _L('❄ 混沌守无: 判别器暂缓/降权冻结(铁律③·不自动压低频次)')
            else:
                continue
        if _trip == 1 and not _hundun_frozen():
            s['score'] = (s.get('score') or 0) * 0.7   # 单项触发 → 降权30%
        _surv.append(s)
    if not _surv:
        _L = globals().get('log')
        if _L: _L("⚖ 边际判别器: 全候选衰减 → 暂缓开仓")
        return None
    clean = _surv
    # ═══ 判别器结束 ═══
    # 🔗🆕 药②·与腾蛇双链路(2026-09-11 老板令): 快链(感知)+稳链(确认)并行
    #   快链(感知): 高certify(信号矛盾/量能背离=伪信号前兆)的币 → 稳链执行前先剔除/降级
    #   稳链(确认): 原4H大势+15m+MACD一致性链照旧执行
    #   腾蛇双腿并行: 快链预警伪信号, 稳链只在'方向清且非伪'时才执行开仓
    _dual = os.environ.get('DUAL_CHAIN_ON','1') != '0'
    if _hundun_frozen():      # 🌫 铁律③: 混沌中相生推演环冻结休眠
        log('❄ 混沌守无: 五行相生·推演环冻结休眠(不放大·不压制)')
    else:
        _wuxing_link('推演')   # 🌀五行相生·第2环 Agent推演(快链+稳链并行推演)
    if _dual:
        _clean2=[]
        for s in clean:
            _ce=_certify_of(s)   # 🧬快链: 引擎certify + 触突军情certify 取大
            # 🈸工单 2-2 第二层·校验评分三级(高放行/中降权/低否决) —— 受相克总开关控(灰度③)
            if five_phase_restrain_enable and not _hundun_frozen():   # 🌫 铁律③: 混沌中相克链冻结
                _q = 1.0 - float(_ce or 0)     # 校验得分: certify低=分高=好
                if _q < 0.2:                   # 低分 → 直接否决丢弃
                    _wuxing_tick('相克·校验')
                    _wuxing_tick('相克·校验否决')
                    log(f"🔗 相克·校验否决: {s['coin']} 得分{_q:.2f}(certify{_ce}) <0.2 → 丢弃候选")
                    continue
                if _q < 0.5:                   # 中等 → 降权
                    s['score'] = (s.get('score') or 0) * 0.5
                    _wuxing_tick('相克·校验')
                    _wuxing_tick('相克·校验降权')
                    log(f"🔗 相克·校验降权: {s['coin']} 得分{_q:.2f}(certify{_ce}) 中等区间 → 权重×0.5")
            elif _ce>=CERTIFY_HOT:   # 🧪ED-20261004-449 死阈值接回 env(默认0.5不变·三臂与六户同步)
            #    (相克开关关时的旧行为) 伪信号高危 → 快链拦下
                _wuxing_tick('相克·校验')
                log(f"🔗 快链感知: {s['coin']} 伪信号高危(certify{_ce}) → 腾蛇稳链不开(避伪信号小亏)")
                continue
            _clean2.append(s)
        if _clean2:
            clean=_clean2            # 有存活候选 → 用过滤后的
        else:
            # 🔴2026-09-11 治“拦了又开”死病(老板令): 若全部候选均被快链/母子融合拦下(伪信号高危)
            #   → 绝不回退到被拦候选(那等于白拦·ADA实盘被拦了却照样开).
            # 🛡🆕2026-09-11 21:4x 老板令“放开宁缺毋滥·给麒麟兽兜底”
            # 🔧🆕2026-09-12 06:5x 老板"睡一觉漏光光"纠错(恢复"宁缺毋滥"本意):
            #   全候选伪信号+无肉(振幅不足)→真空仓; 仅当"有肉"(至少一个候选振幅≥RANGE_AMP)才择强开.
            if os.environ.get('OPEN_WHEN_ALLHOT','1') != '0':
                _meaty=[s for s in clean if float(s.get('amp6',0) or 0)>=RANGE_AMP]
                if _meaty:
                    _best=max(_meaty, key=lambda s:abs(s.get('score',0)))
                    log(f"🤸 放开宁缺毋滥(有肉): 全{len(clean)}候选certify高危·{len(_meaty)}个有肉 → 择最强开({_best['coin']} {_best.get('side')} |{_best.get('score'):+.1f}|振幅{_best.get('amp6')}%) + 麒麟兜底")
                    return _best
                log(f"🛑 快链/融合: 全{len(clean)}候选均伪信号高危且无肉(振幅<{RANGE_AMP}%) → 腾蛇不开(宁缺毋滥·真空仓)")
                return None
            log(f"🛑 快链/融合: 全{len(clean)}候选均伪信号高危 → 腾蛇不开(宁缺毋滥·不硬凑)")
            return None
    # 🆕 优先挑“短窗方向与高层大势同向”的那一个(顺大势的强于只凭短窗蒙的); 其余按旧|score|取强
    # 🆕 优先挑“短窗方向与高层大势同向”的那一个(顺大势的强于只凭短窗蒙的); 其余按旧|score|取强
    agree=[s for s in clean if s.get('side')==('long' if s.get('regime')=='up' else 'short') and s.get('regime') in ('up','dn')]
    pool = agree if agree else clean
    pool = _wang_edict_first(pool)   # 👑🔥2026-10-10 王令至上·择向降权为奴仆(ED-20261010-827)
    # 🧭🆕2026-09-28 势位共振优先（ED-20260928-300 · 老板「做势位共振优先」）：有共振 ⇒ 只从共振中择强；无 ⇒ 回旧(不困死)
    if SIGN_TREND_POS_RESO_ON:
        _ob3 = _sign_pool_obs() or {}
        _reso = []
        for _s3 in pool:
            _ok3, _why3 = _reso_ok(_s3.get('coin'), _ob3)
            if _ok3:
                if SIGN_RESO_BOOST != 1.0:
                    _s3['score'] = (_s3.get('score') or 0) * SIGN_RESO_BOOST
                _s3['_reso'] = _why3
                _reso.append(_s3)
        if _reso:
            if _L: _L("🧭 势位共振优先: 候选%d → 共振%d个(%s) → 只从共振中择强" % (
                len(pool), len(_reso), ','.join('%s:%s' % (x['coin'], x.get('_reso')) for x in _reso)))
            pool = _reso
        else:
            if _L: _L("🧭 势位共振优先: 候选%d 无共振 → 回旧口径(不困死)" % len(pool))
    # 💊🆕2026-09-28 药④ 多单贴顶禁用带（老板令「新增 pos≥70 禁多」）: 多单已贴顶 ⇒ 弃(不追顶)
    if SIGN_TOP_BAN_ON:
        _ob4 = _sign_pool_obs() or {}
        _keep4 = []
        for _s4 in pool:
            _p4v = (_ob4.get(_s4.get('coin')) or {}).get('pos')
            _ban4 = SIGN_TOP_BAN_POS
            if SIGN_ADAPT_TRADE_ON:
                _okA, _whyA = _sign_shi_zheng(_s4.get('coin'), _s4.get('side'), _ob4)
                if _okA:
                    _ban4 = SIGN_ADAPT_TOPBAN   # 🌊势正 ⇒ 顶带放宽(随行就市)
            if _s4.get('side') == 'long' and _p4v is not None and float(_p4v) >= _ban4:
                if _L: _L("🛑 多单贴顶禁用带: %s pos%.0f≥%.0f → 弃(禁顶部追多)" % (_s4.get('coin'), float(_p4v), _ban4))
                continue
            _keep4.append(_s4)
        if pool and not _keep4:
            if _L: _L("🛑 多单贴顶禁用带: 候选 %d 皆贴顶 → 不做单" % len(pool))
            return None
        if _keep4:
            pool = _keep4
    # 🧭🆕ED-20260927-240《择向三刀》门①池内同向 门②位置带（默认关·模拟/仿真基因开）
    if SIGN_POS_BAND_ON or SIGN_SAME_DIR_MIN > 0:
        _ob = _y5_obs() or {}
        _rt, _ln, _sn = _sign_same_ratio(_ob)
        if SIGN_SAME_DIR_MIN > 0 and _ob and _rt < SIGN_SAME_DIR_MIN:
            if _L: _L(f"🧭 择向·池内同向不足(ED-240): 同向率 {_rt:.2f} < {SIGN_SAME_DIR_MIN:.2f}(多{_ln}/空{_sn}) → 不做单")
            return None
        if SIGN_POS_BAND_ON:
            _keep = [s for s in pool if (_sign_pos_ok(s.get('coin'), _ob, s.get('side'))[0]
                                        or (SIGN_PHASE_SPLIT_ON and (_phase_of(s.get('coin')) or {}).get('相位') == '反'))]   # 🔪ED-393 "反"币豁免位置带
            if _keep:
                pool = _keep
            else:
                if _L: _L(f"🧭 择向·位置带(ED-240): 候选 {len(pool)} 个皆出带[{SIGN_POS_BAND_LO:.0f},{SIGN_POS_BAND_HI:.0f}] → 不做单")
                return None
    # 🧬🆕ED-20260927-243《自演化第四轮落地·择回踩深》
    if SIGN_REGIME_GATE_ON or SIGN_RANK_PULL:
        _ob2 = _sign_pool_obs() or {}
        if SIGN_REGIME_GATE_ON:
            _kept = []
            for s in pool:
                _v = _ob2.get(s.get('coin')) or {}
                if not _v:
                    _kept.append(s); continue
                # 🔪ED-393 相位分门: "反"币改用**位置极值门**(贴顶做空/贴底做多) —— 反转要极端, 不要趋势
                if SIGN_PHASE_SPLIT_ON and (_phase_of(s.get('coin')) or {}).get('相位') == '反':
                    _pv = float(_v.get('pos') or 50)
                    if (s.get('side') == 'short' and _pv >= SIGN_REV_POS_HI) or (s.get('side') == 'long' and _pv <= SIGN_REV_POS_LO):
                        _kept.append(s)
                    continue
                _t4v = float(_v.get('t4') or 0); _erv = float(_v.get('er') or 0)
                _volv = float(_v.get('vol') or 0); _t96v = float(_v.get('t96') or 0)
                if _erv < SIGN_ER_MIN or _volv > SIGN_VOL_CAP or abs(_t4v) < SIGN_T4_MIN2:
                    continue
                if SIGN_T96_SAME and ((_t96v > 0) != (_t4v > 0)):
                    continue
                _kept.append(s)
            if _kept:
                pool = _kept
            else:
                if _L: _L("🧬 市况门(ED-243): 候选皆不合市况(效率/波动/强度/长窗) → 不做单")
                return None
        if SIGN_RANK_PULL:
            _res = max(pool, key=lambda s: abs(float((_ob2.get(s.get('coin')) or {}).get('m1') or 0)))
        # 🧲🆕ED-20260927-246 择向·追高闸 + 回踩闸（默认关: 99/0 = 旧行为逐字不变）
        if SIGN_CHASE_M1_MAX < 99.0 or SIGN_PULL_MIN > 0:
            _kept2 = []
            for _s2 in pool:
                _v2 = _ob2.get(_s2.get('coin')) or {}
                _m1v = float(_v2.get('m1') or 0)
                if SIGN_CHASE_M1_MAX < 99.0 and abs(_m1v) > SIGN_CHASE_M1_MAX:
                    continue
                if SIGN_PULL_MIN > 0:
                    _sdv = _s2.get('side')
                    if not ((_sdv == 'long' and _m1v <= -SIGN_PULL_MIN) or
                            (_sdv == 'short' and _m1v >= SIGN_PULL_MIN)):
                        continue
                _kept2.append(_s2)
            if _kept2:
                pool = _kept2
            else:
                if _L: _L("🧲 追高/回踩闸(ED-20260927-246): 候选皆追高或未回踩 → 不做单")
                return None
        if SIGN_RANK_PULL:
            _res = max(pool, key=lambda s: abs(float((_ob2.get(s.get('coin')) or {}).get('m1') or 0)))
            if _L: _L(f"🧬 择强·回踩深(ED-243): {_res['coin']} {_res.get('side')} 回踩{abs(float((_ob2.get(_res['coin']) or {}).get('m1') or 0)):.3f}%")
            if DIR_RADAR_FEED:
                _radar_feed(pool, _res)
            if _res and zhizhi_check_enable and not _zhizhi_ok(_res):
                return None
            _LAST_CHOSEN[0]=(_res['coin']+' '+_res['side']) if _res else ''
            return _res
    # 📡🆕2026-09-15 10:16 C(老板令"精准择向雷达·照亮2/3启动点"): 雷达择优接管"防追高".
    #   理念: 不用"闸拦截", 而用"雷达照亮" — 用"方向胚胎度"评分, 优选"将成未成(2/3对齐)"启动点.
    #   沙箱实证: 对齐2/3最佳(均-0.011%) > 3/3(均-0.055%,共识点=追高陷阱) > 0/3(最差).
    #   DIR_RADAR_ON=0 一键回旧(纯|score|择强).
    if DIR_RADAR_ON:
        def _embryo(s):
            """方向胚胎度: 越高=越接近"启动点(将成未成)"""
            sd=s.get('side')
            _al=sum([
                1 if (sd=='long' and s.get('e4')=='up') or (sd=='short' and s.get('e4')=='dn') else 0,
                1 if (sd=='long' and s.get('e1')=='up') or (sd=='short' and s.get('e1')=='dn') else 0,
                1 if (sd=='long' and (s.get('t4l',0) or 0)>0.15) or (sd=='short' and (s.get('t4l',0) or 0)<-0.15) else 0,
            ])
            sc=abs(float(s.get('score',0) or 0))
            if RADAR_EMBRYO_V2:  # 🎯2026-09-15 A方案: 3/3全共振最优(数据铁证)
                base = 2.0 if _al==3 else (1.0 if _al==2 else (-0.5 if _al==1 else -1.0))
            else:  # 旧(回退)
                base = 2.0 if _al==2 else (1.0 if _al==1 else (0.0 if _al==3 else -1.0))
            _v = (sc + base + RADAR_W_ALIGN*_al) * _wuxing_side_w(sd)   # 🌀五行迭代反哺
            # 🌟2026-09-15 B加权: 黄金窗口(北京0-2点)得分乘权 → 同分下优先选黄金窗口的信号
            if SEG_GOLD_ON:
                try:
                    import time as _gt
                    _h = _gt.localtime().tm_hour
                    if SEG_GOLD_HOURS[0] <= _h < SEG_GOLD_HOURS[1]:
                        _v *= SEG_GOLD_BOOST
                except Exception:
                    pass
            return _v
        _res = max(pool, key=_embryo)
        log(f"📡 雷达照亮: {_res['coin']} {_res.get('side')} 胚胎度择优(|分|{abs(_res.get('score',0)):.1f}·照辉2/3启动点·避3/3共识)")
        if DIR_RADAR_FEED:
            _radar_feed(pool, _res)   # 📡 情报化: 照见结果 写总线 → 白虎→烛龙/腾蛇
        if _res and zhizhi_check_enable and not _zhizhi_ok(_res):
            return None   # 🈸工单3-1 知止校验·出口一(雷达路径)
        _LAST_CHOSEN[0]=(_res['coin']+' '+_res['side']) if _res else ''
        return _res
    _res = max(pool, key=lambda s:abs(s['score'])*_wuxing_side_w(s.get('side')))   # 🌀五行迭代反哺
    if _res and zhizhi_check_enable and not _zhizhi_ok(_res):
        return None   # 🈸工单3-1 知止校验·出口二(fallback)
    _LAST_CHOSEN[0]=(_res['coin']+' '+_res['side']) if _res else ''
    return _res

def _halfmountain_block(sig):
    """🚦 半山腰守门(治旧母体通用门松): 想顺势开多但4H大势显著向下 + 中位虚弹 → 拦.
       下跌日(4H动量<-0.3%)里 15m反向弹一下就当多开=旧病复发 → 不给开."
    多向: t4<-0.3(大势下)+score由弱转多(recent) → 拦(不在下跌中段虚弹抄多).
    对称: 上涨日4H>+0.3 里 15m回弹想开空也不给(不在上升中段逆势摸顶)."""
    if sig.get('_sovereign'):
        return None          # ☯2026-10-01 半山腰闸并入道统: 道统先导单不叠拦(一个声音)
    try:
        t4=sig.get('t4',0); score=sig.get('score',0); tp=sig.get('tp')
        # 📡🆕2026-09-15 C(老板令): 雷达接管→只拦极端逆大势(|t4|≥1.0%); 缓区(0.3~1.0)放行交雷达择优.
        _thr = 1.0 if HALFMOUNTAIN_RADAR_TAKEOVER else 0.3
        _p4=sig.get('pos4'); _t4l=float(sig.get('t4l') or 0); _amp=float(sig.get('amp6') or 2.0)
        if HALFM_ADAPT_ON:   # 📶ED-20260927-253 波动自适应: 大波动放宽(免误拦真推进)/小波动收紧(严治中段)
            _thr=max(0.3, min(1.5, _thr*(0.75+0.3*min(2.0, _amp))))
        if score>0 and t4<-_thr and tp=='UP':
            return f"半山腰守门: 4H大势{t4:+.2f}%还在跌,仅15m{tp}虚弹想开多→不在下跌中段抄多(等真反转/破位)"
        if score<0 and t4>_thr and tp=='DOWN':
            return f"半山腰守门: 4H大势{t4:+.2f}%还在涨,仅15m{tp}回弹想开空→不在上升中段逆势摸顶"
        # 📶🆕ED-20260927-253 非常规半山腰禁开(自适应·常规豁免) —— 老板令「禁止非常规半山腰开多开空…常规可亦豁免」
        if HALFM_ADAPT_ON and _p4 is not None:
            _reg=(abs(_t4l)>=HALFM_IMP_THR and (_t4l*float(score or 0))>0)   # 常规: 短线与信号同向推进
            _edge=(_p4>=SIGN_HALF_BAND_HI or _p4<=SIGN_HALF_BAND_LO)          # 常规: 位在两端(非半山腰·35/65)
            if (not _reg) and (not _edge) and SIGN_HALF_BAND_LO<=_p4<=SIGN_HALF_BAND_HI and abs(float(t4 or 0))<HALFM_TREND_THR:
                return f"半山腰闸(自适应): {sig.get('coin')} 位{_p4:.0f}%中段·4H{t4:+.2f}%趋势弱·短线{_t4l:+.2f}%无推进 → 非常规半山腰不开(等启动/破位)"
    except Exception:
        pass
    return None

def _topbot_state(sig):
    """📶 顶底自适应识别(火印 ED-20260927-253·老板令「赋予系统多空顶底信号识别自适应增强功能」)
    口径: 以 4H区间位(pos4) 为主, 阈值**随波动(amp6)伸缩** —— 大波动里±80%是常态⇒收紧(要更极端才算顶底);
          小波动⇒放宽(及时识别)。辅以 4H动量(t4)/近端转向(tp)/评分反向 确认。
    返回: (kind, conf, why)  kind∈{'顶','底',''}"""
    try:
        _p4 = sig.get('pos4')
        if _p4 is None:
            return ('', 0.0, '无区间位数据')
        _amp = float(sig.get('amp6') or 2.0); _t4 = float(sig.get('t4') or 0)
        _t4l = float(sig.get('t4l') or 0); _tp = sig.get('tp'); _sc = float(sig.get('score') or 0)
        _z = TOPBOT_ZONE_HI
        if TOPBOT_ADAPT_ON:
            _z = max(TOPBOT_ZONE_HI, min(TOPBOT_ADAPT_MAX, TOPBOT_ZONE_HI + (_amp - 2.0) * 2.0))
        _why = '位%.0f%%(顶底阈%.0f%%/%.0f%%)·4H%+.2f%%·短%+.2f%%·15m%s' % (_p4, _z, 100.0 - _z, _t4, _t4l, _tp)
        if _p4 >= _z and (_t4 >= 0.6 or _tp == 'DOWN' or _sc < 0):
            return ('顶', min(1.0, (_p4 - 50.0) / 40.0), _why)
        if _p4 <= (100.0 - _z) and (_t4 <= -0.6 or _tp == 'UP' or _sc > 0):
            return ('底', min(1.0, (50.0 - _p4) / 40.0), _why)
    except Exception:
        pass
    return ('', 0.0, '')

def _topbot_rechase_block(sig):
    """📶 禁顶部追多 · 禁底部追空(火印 ED-20260927-253)
    只拦**同向追单**(顶部还想开多/底部还想开空); 反向(顶部做空/底部做多=抄底摸顶)不拦——交择向。
    费率腿(_fund_leg)=反向腿, 豁免(其信号源是资金费率, 与价格位置无关)。"""
    if not TOPBOT_GATE_ON or sig.get('_fund_leg'):
        return None
    if sig.get('_sovereign'):
        return None          # ☯2026-10-01 顶底闸并入道统: 道统先导单已避极端位 ⇒ 不叠拦(一个声音)
    # 🌊🆕2026-10-02 老板令「适应做交易权·择向为正时随行就市」(火印 ED-20261002-380): 有势 ⇒ 不硬拦(顺势而为)
    try:
        _okA, _whyA = _sign_shi_zheng((sig or {}).get('coin'), (sig or {}).get('side'), _sign_pool_obs() or {})
        if _okA:
            return None
    except Exception:
        pass
    try:
        _k, _cf, _w = _topbot_state(sig)
        if _cf < 0.5:
            return None
        _sd = sig.get('side')
        if _k == '顶' and _sd == 'long':
            return '顶底闸·禁顶部追多: %s 已至区间顶(%s) → 不在顶部追多(等回踩/破位确认)' % (sig.get('coin'), _w)
        if _k == '底' and _sd == 'short':
            return '顶底闸·禁底部追空: %s 已至区间底(%s) → 不在底部追空(等反弹/破位确认)' % (sig.get('coin'), _w)
    except Exception:
        pass
    return None

def _quality_block(sig):
    """🆕2026-09-11 道器行情质量闸(治"窄市硬做→手续费吃利润"):
       实证: 今日fee $5.43吃已实现利润33%; 窄市(SOL/XRP 6h振幅1.5-2%/趋势~0)反复进出.
       规则: 该币近6h振幅<QUALITY_AMP6_MIN(1.2%) 且 4H净趋势|t4|<0.3%(纯震荡) → 不硬做(宁缺毋滥).
       有肉行情(振幅够 或 有真趋势)不受影响. 可 QUALITY_GATE_ON=0 整关."""
    if not QUALITY_GATE_ON: return None
    if sig.get('_sovereign'):
        # ☯2026-10-01 质量闸并入道统: 道统先导选币时已优先“有肉”的顺势币(见 _sovereign_first_pick)，
        #  天清(池均有趋势)前提保证下, 不再对单币叠拦(一个声音)。
        return None
    try:
        amp6=sig.get('amp6'); t4=abs(sig.get('t4',0) or 0)
        if amp6 is None: return None
        if amp6 < QUALITY_AMP6_MIN and t4 < 0.3:
            return f"行情质量不足: {sig.get('coin')}近6h振幅{amp6:.2f}%<{QUALITY_AMP6_MIN}%且4H趋势{t4:.2f}%≈0(窄市没肉)→不硬做(手续费吃利润)"
        # 🌟🆕2026-09-15 09:11 A方案治本(老板令): chop区(震荡)+低把握(|score|<CHOP_OPEN_MIN_SCORE) → 不开.
        #   病: DOGE 04:32在chop区(把握47%)开多 → 行情转势后被刹车(-1.19%) → 反复买卖白送手续费.
        #   药: 开仓源头把关 — chop模糊区只接中高把握(score≥2.5), 低把握宁缺毋滥.
        _reg=sig.get('regime'); _sc=abs(float(sig.get('score',0) or 0))
        if _reg=='chop' and _sc < CHOP_OPEN_MIN_SCORE:
            return f"chop区把握不足: {sig.get('coin')} regime=chop且|score|{_sc:.1f}<{CHOP_OPEN_MIN_SCORE}(模糊区不开)→宁缺毋滥(避反复买卖)"
        # 🧭💊2026-09-24 23:2x 老板令「一切归因于择向」: 择向确认闸(env ENTRY_ALIGN_MIN·默认0=零影响)
        #   铁证: 最近30笔 峰≥1%的9笔全赚(+8127$) / 峰<1%的21笔全亏(-10981$) ⇒ 入场方向是胜负分水岭
        if ENTRY_ALIGN_MIN > 0:
            try:
                _sd = sig.get('side')
                _alc = sum([
                    1 if (_sd == 'long' and sig.get('e4') == 'up') or (_sd == 'short' and sig.get('e4') == 'dn') else 0,
                    1 if (_sd == 'long' and sig.get('e1') == 'up') or (_sd == 'short' and sig.get('e1') == 'dn') else 0,
                    1 if (_sd == 'long' and (sig.get('t4l', 0) or 0) > 0.15) or (_sd == 'short' and (sig.get('t4l', 0) or 0) < -0.15) else 0,
                ])
                if _alc < ENTRY_ALIGN_MIN:
                    return f"择向确认闸: {sig.get('coin')} {_sd} 周期对齐{_alc}/3<{ENTRY_ALIGN_MIN} → 方向未共振·宁缺毋滥(等启动点)"
            except Exception:
                pass
        # 🕐2026-09-15 B方案(老板令): 时段闸 — 美欧时段(北京8-22)噪音大, 只接强信号.
        if (SEG_GATE_ON or BAD_HOURS) and not (FUND_LEG_BYPASS_GATE and sig.get('_fund_leg')):
            try:
                import time as _seg_t
                _seg_hr=_seg_t.localtime().tm_hour
                # 💊劣时段闸(env BAD_HOURS·默认空=零影响)
                if BAD_HOURS and ('%02d' % _seg_hr) in BAD_HOURS and BAD_HOUR_MIN_SCORE > 0 and _sc < BAD_HOUR_MIN_SCORE:
                    return f"劣时段闸: {sig.get('coin')} 当前{_seg_hr}点属实测负期望时段·|score|{_sc:.1f}<{BAD_HOUR_MIN_SCORE}→只接强信号(避该时段噪音)"
                if SEG_GATE_ON and SEG_STRONG_HOURS[0] <= _seg_hr < SEG_STRONG_HOURS[1] and _sc < SEG_MIN_SCORE:
                    return f"时段闸: {sig.get('coin')} 当前{_seg_hr}点美欧时段·|score|{_sc:.1f}<{SEG_MIN_SCORE}→只做强信号(避欧美噪音)"
            except Exception:
                pass
    except Exception:
        pass
    return None

def _exhaust_rechase_block(sig):
    """🚻 高位衰竭禁再追(与半山腰对称·治'该歇时追'): 币已大涨到高位(4H涨幅大)却还想开多买回 →
       若非真破新高续涨(15m强推/创新高)而是高位衰竭(近端走弱/tp反向) → 拦, 等回落企稳或真破位续涨。
       多向(对称): 想开多 且 4H已大涨(≥~2.5%) 但 15m已不主导推(非UP/tp停/score回落) → 高位衰竭禁裸追;
       空向: 想开空 且 4H已深跌(≤~-2.5%) 但 15m已不主导跌 → 地板禁追空。
       只在此二重(4H高位&15m不续推)同真时拦; 强刚破位/续推不受影响(真突破照开)。"""
    try:
        t4=sig.get('t4',0); score=sig.get('score',0); tp=sig.get('tp'); gck=sig.get('gck')
        # 现净分含15m/末根分量: 若score已不强烈同向说明近端在衰减
        if score>0 and t4>=2.5 and tp!='UP':
            return f"高位衰竭禁再追: {sig.get('coin')}4H已涨{t4:+.2f}%至高位,15m{tp}不再主导推→非真破位裸追多(等企稳或破新高)"
        if score>0 and t4>=2.5 and gck=='death':
            return f"高位衰竭禁再追: {sig.get('coin')}4H已涨{t4:+.2f}%但MACD死叉→高位衰竭不追多"
        if score<0 and t4<=-2.5 and tp!='DOWN':
            return f"高位衰竭禁再空: {sig.get('coin')}4H已跌{t4:+.2f}%至深位,15m{tp}不再主导跌→地板不追空"
        if score<0 and t4<=-2.5 and gck=='golden':
            return f"高位衰竭禁再空: {sig.get('coin')}4H已跌{t4:+.2f}%但MACD金叉→深位衰竭不追空"
        # 🆕2026-09-11 董事长择向·区间位维度(治"接飞刀"): 想开空但已跌到4H区间底(pos4≤20, 超卖) 且15m不主导跌
        #   → 地板裸追空=接飞刀(实盘SOL/XRP/LINK/NEAR全在pos2~19%仍被追空→反弹即早断).
        #   真破位续跌(15m仍DOWN/创新低)不受影响; 镜像防高位追多(pos4≥80 & 15m不UP).
        _p4=sig.get('pos4')
        if _p4 is not None:
            if score<0 and _p4<=20 and tp!='DOWN':
                return f"深位禁裸追空: {sig.get('coin')}已跌至4H区间底(pos{_p4:.0f}%≤20)15m{tp}不续跌→接飞刀(等反弹/真破位)"
            if score>0 and _p4>=80 and tp!='UP':
                return f"高位禁裸追多: {sig.get('coin')}已涨至4H区间顶(pos{_p4:.0f}%≥80)15m{tp}不续涨→追高(等回踩/真破位)"
    except Exception:
        pass
    return None

# ─── 账本(SIM隔离) ───
def load():
    if os.path.exists(STATE_FILE):
        try: return json.load(open(STATE_FILE))
        except Exception: pass
    return {'pos':None,'realized':0.0,'trades':[]}
def save(st):
    tmp=STATE_FILE+'.tmp'; json.dump(st,open(tmp,'w')); os.replace(tmp,STATE_FILE)

# ── 🎚 自适应智能调仓 (2026-09-10 老板令: 为模拟母子系统增加·“小钱办大事”) ──
#   把握度 = 信号强度|score| × 认向共振(顺高层大势regime) × 趋势顺应(tp同向)
#   名义 = NOTIONAL × (0.35 + 0.65×f)  → 把握大接近满仓·把握小收缩(下限0.35×). 保证金=名义/LEVER.
#   ⚠量程铁律(2026-09-10 22:52 老板"固化成常态·不容重复"): score真实量程=±4(t4±1 tp±1 macd±1.5 last15±0.5).
#     档位必须按真实量程校准, 绝非0-100! 曾因档位写95/90/88/84(0-100量程)→满分顺势单被打入末档→保证金偏小事故.
#     本函数与实盘层 _母体实盘.py 的 _adaptive_notional 同口径(改动须两侧一起改).
# ── ☯🆕2026-09-26 易经闸入模拟域 (火印 ED-20260926-194 · 老板令「可行」) ──
#   ①三才闸: 天=行情(效率比) · 地=风险(位不偏极) · 人=策略(有号) ⇒ **三才缺一即不开新仓**
#   ②谦卦闸: 单币名义 ≤ NOTIONAL×QIAN_CAP_RATIO (谦=六十四卦唯一「六爻皆吉」⇒ 防单币独大)
#   **默认全关**(YIJING_GATE_ON=0 ⇒ 与旧行为完全一致); 只给模拟户基因开; 真钱基因无此变量。
YIJING_GATE_ON   = os.environ.get('YIJING_GATE_ON', '0') != '0'
# 🌟 ED-20260928-294 铁律·评分七十建仓令(老板 2026-09-28 19:49): 建仓评分(0~100)未过门限 ⇒ 不得建仓
#   默认 '0' = 逐字回旧(不设门); 老板令设 70。口径见 _entry_score100()。
ENTRY_SCORE100_MIN = float(os.environ.get('ENTRY_SCORE100_MIN', '0') or 0)
ENTRY_SCORE100_ON  = ENTRY_SCORE100_MIN > 0
YIJING_TIAN_EFF  = float(os.environ.get('YIJING_TIAN_EFF', '0.10'))
YIJING_REN_SCORE = float(os.environ.get('YIJING_REN_SCORE', '1.5'))
QIAN_CAP_RATIO   = float(os.environ.get('QIAN_CAP_RATIO', '1.0'))

def _yijing_tai():
    """三才之象: 天(池均效率比) · 地(池均位)"""
    try:
        _effs=[]; _poss=[]
        for _c in WATCH_COINS:
            _cc=_candles(_c,'15m',97) or []
            if len(_cc)<20: continue
            _ab=sum(abs(_cc[_i]-_cc[_i-1]) for _i in range(1,len(_cc)))
            _effs.append(abs(_cc[-1]-_cc[0])/_ab if _ab else 0.0)
            _hi=max(_cc); _lo=min(_cc)
            _poss.append((_cc[-1]-_lo)/(_hi-_lo)*100 if _hi>_lo else 50.0)
        if not _effs: return '不明',50.0,0.0,50.0
        _e=sum(_effs)/len(_effs); _p=sum(_poss)/len(_poss)
        return ('明' if _e>=YIJING_TIAN_EFF else '不明'), ('清' if abs(_p-50)<45 else '偏极'), _e, _p
    except Exception:
        return '明','清',0.0,50.0          # 测量失败→放行(不误杀)

def _yijing_gate(sig):
    """⇒ (放行, 拦因); 默认关=旧行为"""
    if not YIJING_GATE_ON:
        return True,''
    if sig and sig.get('_sovereign'):
        return True,''         # ☯2026-10-01 三才闸并入道统: 道统先导单已过三才(天清) ⇒ 不叠拦
    try:
        _tian,_di,_e,_p=_yijing_tai()
        _ren='有号' if abs(float((sig or {}).get('score',0) or 0))>=YIJING_REN_SCORE else '无号'
        _que=[]
        if _tian!='明': _que.append('天(效率%.2f<%.2f)'%(_e,YIJING_TIAN_EFF))
        if _di!='清': _que.append('地(位%.0f偏极)'%_p)
        if _ren=='无号': _que.append('人(号弱)')
        if _que:
            _yijing_ledger(sig,False,'三才缺: '+'·'.join(_que))
            return False,'三才缺: '+'·'.join(_que)
        _yijing_ledger(sig,True,'')
        return True,''
    except Exception as _e2:
        return True,'闸异常放行(%s)'%_e2

# 🎯🆕2026-10-06 火印 ED-20261006-521 精准放行（老板令 丙「放宽闸以提高出手：懂交易·会交易·能建议·精准交易」）
#   三凭齐 ⇒ 豁免『评分/形态/三态门/知止/三才』诸闸；**风控·护栏·闪崩·伪信号·止损·紧急闸 绝不豁免**
#   默认 0=零行为变化 ｜ 回退: env PRECISE_PASS_ON=0
PRECISE_PASS_ON = os.environ.get('PRECISE_PASS_ON', '0') == '1'
PRECISE_CONF_MIN = float(os.environ.get('PRECISE_CONF_MIN', '0.85'))
PRECISE_M1_MAX = float(os.environ.get('PRECISE_M1_MAX', '0.6'))
_pz = False


def _precise_pass(pick):
    """🎯 精准放行(ED-521): 三凭齐 → 豁免评分/形态闸; 差一凭 → 写建议档。异常→(False,'')。"""
    try:
        if not pick:
            return (False, '')
        _c = pick.get('coin')
        _sd = str(pick.get('side') or pick.get('dir') or '')
        if not _c or _sd not in ('long', 'short'):
            return (False, '')
        _sg = 1 if _sd == 'long' else -1
        _miss = []
        _v = str(ZHU_EDICT.get('verdict') or '')
        _cf = float(ZHU_EDICT.get('conf') or 0.0)
        _ec = str(ZHU_EDICT.get('coin') or '')
        _c1 = (_v in ('long', 'short')) and (_v == _sd) and (_cf >= PRECISE_CONF_MIN) and ((not _ec) or _ec == _c)
        if not _c1:
            _miss.append('凭①王令(圣裁=%s 信%.2f vs 拟%s)' % (_v or '无', _cf, _sd))
        _o = (_sign_pool_obs() or {}).get(_c) or {}
        _t4 = float(_o.get('t4') or 0.0)
        _t96 = float(_o.get('t96') or 0.0)
        _m1 = float(_o.get('m1') or 0.0)
        _ph = (_phase_of(_c) or {}).get('相位')
        _c2 = (_sg * _t4 > 0) and (_sg * _t96 > 0) and ((_sg * _m1) >= -PRECISE_M1_MAX) and (_ph != '反')
        if not _c2:
            _miss.append('凭②认读(4H%+.2f 长窗%+.2f 15m%+.2f 相位%s)' % (_t4, _t96, _m1, _ph or '?'))
        _vt = ZHU_EDICT.get('votes') or {}
        _same = 0
        for _k, _x in _vt.items():
            try:
                _xi = int(_x)
            except Exception:
                _xi = 0
            if _xi and ((1 if _xi > 0 else -1) == _sg):
                _same += 1
        _c3 = (_same >= 3) or (_ph == '顺')
        if not _c3:
            _miss.append('凭③共识(同向票%d 相位%s)' % (_same, _ph or '?'))
        if _c1 and _c2 and _c3:
            return (True, '%s %s 三凭齐(王令%s信%.2f · 认读4H%+.2f/长%+.2f/15m%+.2f · 同向票%d · 相位%s)'
                    % (_c, _sd, _v, _cf, _t4, _t96, _m1, _same, _ph or '?'))
        if len(_miss) == 1:
            try:
                with open('data_v2/mtsim/_精准放行_建议.jsonl', 'a', encoding='utf-8') as _f:
                    _f.write(json.dumps({'时刻': _time.strftime('%F %T'), '币': _c, '向': _sd, '差': _miss[0],
                                         '王令信': _cf, '4H': _t4, '长窗': _t96, '15m': _m1, '相位': _ph,
                                         '同向票': _same}, ensure_ascii=False) + '\n')
            except Exception:
                pass
        return (False, '')
    except Exception:
        return (False, '')


def _yijing_ledger(sig,ok,why):
    """留痕入《卦象台账》(append·不打搅交易·失败即静默)"""
    try:
        _f='data_v2/mtsim/_卦象台账.json'
        _d={'条':[]}
        if os.path.exists(_f):
            try: _d=json.load(open(_f))
            except Exception: _d={'条':[]}
        if not isinstance(_d,dict) or '条' not in _d: _d={'条':[]}
        _d['条'].append({'键':'engine|%s|%s'%(_time.strftime('%F %T'),(sig or {}).get('coin')),
            '时刻':_time.strftime('%F %T'),'币':(sig or {}).get('coin'),'向':(sig or {}).get('side'),
            '爻位':[],'相位':'regime=%s'%((sig or {}).get('regime')),
            '亢龙收敛':'tp=%s'%((sig or {}).get('tp')),
            '卦象':{'本卦':'引擎三才闸','之卦':''},'放行':ok,'拦因':why,'结果':None,'k':None,
            '记于':_time.strftime('%F %T')})
        if len(_d['条'])>8000: _d['条']=_d['条'][-8000:]
        _t=_f+'.tmp'; json.dump(_d,open(_t,'w'),ensure_ascii=False); os.replace(_t,_f)
    except Exception: pass


# ═══ ☯ 觉悟·体用合一（火印 ED-20260927-222 · 令 HD-20260925-YFXJ-001）═══
#   【体】心经觉知: 旁路观测(只记不决) · 执念三标记(起执/贪相/惧相) · 公理写保护
#   【用】阴符经顺势: 态势分值谱(阳/阴/混沌) · 绝利一源节流阀 · 势随天道浮动
#   **默认关**（JUE_AWARE_ON=0 ⇒ 与旧行为一致）· 灰度 JUE_GRAY_PCT（令: 20%→40%→70%→100%·禁跳级）
JUE_AWARE_ON    = os.environ.get('JUE_AWARE_ON', '0') != '0'
JUE_SPECTRUM_ON = os.environ.get('JUE_SPECTRUM_ON', '1') != '0'
JUE_DRIFT_ON    = os.environ.get('JUE_DRIFT_ON', '1') != '0'
JUE_THROTTLE_ON = os.environ.get('JUE_THROTTLE_ON', '1') != '0'
JUE_AXIOM_LOCK  = os.environ.get('JUE_AXIOM_LOCK', '')
JUE_AXIOM_PIN   = '9b82160336cdb1ff'          # 公理定版锁（写保护·不可被演化覆盖）
JUE_HOLD_BASE   = float(os.environ.get('JUE_HOLD_BASE', '96'))
JUE_THR_BASE    = float(os.environ.get('JUE_THR_BASE', '4.5'))
JUE_RATIO_MIN   = float(os.environ.get('JUE_RATIO_MIN', '0.20'))
JUE_RATIO_MAX   = float(os.environ.get('JUE_RATIO_MAX', '0.42'))
JUE_GRAY_PCT    = float(os.environ.get('JUE_GRAY_PCT', '0.20'))
# ── ☯🆕2026-09-27 药五·势位（火印 ED-20260927-228 · 老板「准·选甲」）──
#   唯一加成点 = 「或跃在渊」(九四·位次4)＝势已成而未亢 ⇒ ×JUE_Y5_BOOST；**他位不加成·亦不减量**
#   沙箱实证(V42 249战72.7%+3.30%/笔 · V43 101战70.3%+2.84%/笔): 「位置之识别」为真；系数减量层反降净利⇒不取
#   置信度门(防伪势): 或跃在渊 若置信<JUE_Y5_CONF_MIN ⇒ 不加成。**默认关**=旧行为不变。
JUE_Y5_ON       = os.environ.get('JUE_Y5_ON', '0') != '0'
JUE_Y5_BOOST    = float(os.environ.get('JUE_Y5_BOOST', '1.15'))
JUE_Y5_CONF_MIN = float(os.environ.get('JUE_Y5_CONF_MIN', '0.60'))
_Y5_NM = ['潜龙勿用', '见龙在田', '终日乾乾', '或跃在渊', '飞龙在天', '亢龙有悔']
_Y5_MOD = None


def _y5_mod():
    """惰性载入六爻机件(既有件·不新增模块)"""
    global _Y5_MOD
    if _Y5_MOD is not None:
        return _Y5_MOD or None
    try:
        import importlib.util as _il
        _base = os.path.dirname(os.path.abspath(__file__))
        for _p in (os.path.join(_base, '_易经_六爻_20260926.py'),
                   os.path.join(_base, '..', '_易经_六爻_20260926.py'),
                   os.path.join(os.getcwd(), '_易经_六爻_20260926.py')):
            if os.path.exists(_p):
                _sp = _il.spec_from_file_location('yj6', _p)
                _m = _il.module_from_spec(_sp); _sp.loader.exec_module(_m)
                _Y5_MOD = _m; return _m
    except Exception:
        pass
    _Y5_MOD = False; return None


def _sign_pool_obs():
    """🧬🆕ED-20260927-243 池内全观测(自演化第四轮·与沙箱 obs2 同口径):
       每币 t4(16根·4H) / pos(96根分位) / er(效率比·96根) / vol(96根均绝对变动%/根) / t96(96根收益) / m1(末根15m收益)
       注: 与 _y5_obs 并存(后者取113根却校验≥120根→恒返空·ED-240两门空转·另案呈报)"""
    try:
        _o = {}
        for _c in WATCH_COINS:
            _k = _candles(_c, '15m', 200) or []
            if len(_k) < 120:
                continue
            _t4 = (_k[-1] - _k[-17]) / _k[-17] * 100
            _h = max(_k[-96:]); _l = min(_k[-96:])
            _pos = (_k[-1] - _l) / (_h - _l) * 100 if _h > _l else 50.0
            _ab = sum(abs(_k[_i] - _k[_i - 1]) for _i in range(1, len(_k)))
            _er = abs(_k[-1] - _k[0]) / _ab if _ab else 0.0
            _t96 = (_k[-1] - _k[-97]) / _k[-97] * 100 if _k[-97] else 0.0
            _m1 = (_k[-1] - _k[-2]) / _k[-2] * 100 if _k[-2] else 0.0
            _vol = sum(abs(_k[_i] - _k[_i - 1]) / _k[_i - 1] for _i in range(len(_k) - 96, len(_k)) if _k[_i - 1]) / 96.0 * 100
            _phz = (_phase_sign(_c) if SIGN_PHASE_ADAPT_ON else 1)
            _o[_c] = {'t4': _t4 * _phz, 'pos': _pos, 'er': _er, 't96': _t96 * _phz, 'm1': _m1 * _phz, 'vol': _vol, 'side': (1 if _t4 > 0 else -1) * _phz}
        return _o
    except Exception:
        return {}


def _y5_obs():
    """池内观测(与沙箱同口径): 每币 t4(16根)/位置(96根区间)/乖离(对16根均)/效率比"""
    try:
        _o = {}
        for _c in WATCH_COINS:
            _k = _candles(_c, '15m', 113) or []
            if len(_k) < 120:
                continue
            _t4 = (_k[-1] - _k[-17]) / _k[-17] * 100
            _h = max(_k[-96:]); _l = min(_k[-96:])
            _pos = (_k[-1] - _l) / (_h - _l) * 100 if _h > _l else 50.0
            _ma = sum(_k[-16:]) / 16.0
            _bias = (_k[-1] - _ma) / _ma * 100 if _ma else 0.0
            _ab = sum(abs(_k[_i] - _k[_i - 1]) for _i in range(1, len(_k)))
            _er = abs(_k[-1] - _k[0]) / _ab if _ab else 0.0
            _o[_c] = {'t4': _t4, 'pos': _pos, 'bias': _bias, 'er': _er, 'side': 1 if _t4 > 0 else -1}
        return _o
    except Exception:
        return {}


def _y5_state(coin, obs):
    """按 位阶(池内|t4|分位)/相生/相克/同向/位置/乖离 构 state（与沙箱同口径）"""
    try:
        if not obs or coin not in obs or len(obs) < 2:
            return None
        _order = sorted(obs, key=lambda c: abs(obs[c]['t4']))
        _N = len(_order); _q = (list(_order).index(coin) + 0.5) / _N
        _pk = 1 if _q > 0.8 else 2 if _q > 0.6 else 3 if _q > 0.4 else 4 if _q > 0.2 else 5
        _lead = max(obs, key=lambda c: abs(obs[c]['t4'])); _ls = obs[_lead]['side']
        _me = obs[coin]; _same = (_me['side'] == _ls)
        _xs = 2 if (_same and abs(_me['t4']) >= 3.0) else (1 if _same else 0)
        _xk = 2 if ((not _same) and abs(_me['t4']) >= 3.0) else (1 if not _same else 0)
        _sd = sum(1 for c in obs if obs[c]['side'] == _me['side']) / float(_N)
        return {'位阶': _pk, '相生': _xs, '相克': _xk, '同向': _sd, '位置': _me['pos'],
                '乖离': _me['bias'], 't4': _me['t4'], 'er': _me['er']}
    except Exception:
        return None


def _y5_boost(sig):
    """⇒ (倍率, 势位名)。「或跃在渊」为唯一加成点；置信不足则不加成(防伪势)。"""
    if not JUE_Y5_ON:
        return 1.0, ''
    try:
        _coin = (sig or {}).get('coin')
        _stt = _y5_state(_coin, _y5_obs())
        if not _stt:
            return 1.0, ''
        _z = 0
        _yj = _y5_mod()
        if _yj is not None:
            _d = _yj.断卦({'位阶': _stt['位阶'], '相生': _stt['相生'], '相克': _stt['相克'],
                          '同向': _stt['同向'], '位置': _stt['位置'], '乖离': _stt['乖离']})
            _v = _d['卦']['变爻']; _z = (max(_v) + 1) if _v else 0
        _nm = _Y5_NM[min(max(_z, 1), 6) - 1]
        _conf = (0.4 * max(0.0, min(1.0, (_stt['同向'] - 0.4) / 0.5))
                 + 0.3 * max(0.0, min(1.0, abs(_stt['t4']) / 6.0))
                 + 0.3 * max(0.0, min(1.0, _stt['er'] / 0.25)))
        if _nm != '或跃在渊':
            return 1.0, _nm
        if _conf < JUE_Y5_CONF_MIN:
            _jue_ledger('药五·伪势不加成', {'币': _coin, '置信': round(_conf, 3)})
            return 1.0, _nm
        _jue_ledger('药五·或跃在渊加成', {'币': _coin, '倍': JUE_Y5_BOOST, '置信': round(_conf, 3)})
        return JUE_Y5_BOOST, _nm
    except Exception:
        return 1.0, ''
_jue_n = 0; _jue_side_streak = 0; _jue_last_side = None
_jue_wins = []; _jue_eq = 0.0; _jue_peak = 0.0
_jue_fear = False; _jue_greedy = False; _jue_w = 1.0

def _jue_evolve():
    """因果不二·迭代回写择向权重（闭环不截断·术层自演化）"""
    global _jue_w
    try:
        _jue_w = max(0.80, min(1.20, round(_jue_w * 0.95, 3)))
        _jue_ledger('迭代回写', {'择向权重': _jue_w})
    except Exception:
        pass

try:
    log('☯ 觉悟·体用合一载入(内核): 开关=%s 灰度=%.0f%% 公理锁=%s' % ('开' if JUE_AWARE_ON else '关', JUE_GRAY_PCT * 100, JUE_AXIOM_LOCK or '(未设)'))
    log('☯ 药五势位载入(内核): 加成=%s 甜位=或跃在渊 倍=%.2f 置信门=%.2f 灰度=%.0f%%' % ('开' if JUE_Y5_ON else '关', JUE_Y5_BOOST, JUE_Y5_CONF_MIN, JUE_GRAY_PCT * 100))
    log('☯ 不二法则公理(HD-20260927-BE-001): 生=%s 克=%s 阴门=%s ｜ 目标=sense_potential_flow ｜ 信号中性 ｜ 只出态势谱'
        % ('开' if five_phase_generation_enable else '关', '开' if five_phase_restrain_enable else '关', '开' if SANT_YIN_ON else '关'))
except Exception:
    pass


def _jue_ledger(kind, detail):
    """觉悟台账（append·只记不决·失败静默）"""
    try:
        _f = 'data_v2/mtsim/_觉悟台账.jsonl'
        _d = os.path.dirname(os.path.abspath(_f))
        if _d and not os.path.isdir(_d):
            os.makedirs(_d, exist_ok=True)
        with open(_f, 'a', encoding='utf-8') as _fh:
            _fh.write(json.dumps({'时刻': time.strftime('%F %T'), '类别': kind,
                                  '币': (detail or {}).get('coin') if isinstance(detail, dict) else None,
                                  '详情': detail if isinstance(detail, (str, int, float)) else {
                                      _k: _v for _k, _v in (detail or {}).items() if _k in ('coin', 'side', 'score', 'regime', '滚动胜率', '回撤', '连向', '向', '锁', '定版')}},
                                 ensure_ascii=False) + '\n')
    except Exception:
        pass

def _jue_spectrum():
    """【用】态势分值谱: 阳势/阴势/混沌 分值（只陈当下·不断言未来）"""
    try:
        _wy = 0.0; _wn = 0.0; _hc = 0; _tot = 0
        for _c in WATCH_COINS:
            _cc = _candles(_c, '15m', 97) or []
            if len(_cc) < 17:
                continue
            _m1 = (_cc[-1] - _cc[-2]) / _cc[-2] * 100
            _t4 = (_cc[-1] - _cc[-17]) / _cc[-17] * 100
            _tot += 1
            if _t4 > 0.3 and _m1 > 0:
                _wy += abs(_t4)
            elif _t4 < -0.3 and _m1 < 0:
                _wn += abs(_t4)
            else:
                _hc += 1
        _s = (_wy + _wn) or 1.0
        return _wy / _s, _wn / _s, (_hc / float(_tot) if _tot else 1.0)
    except Exception:
        return 0.0, 0.0, 1.0

def _jue_after_close(pnl):
    """【体】执念判别·贪相/惧相（平仓后即算·只记不决）"""
    global _jue_eq, _jue_peak, _jue_wins, _jue_fear, _jue_greedy
    if not JUE_AWARE_ON:
        return
    try:
        _jue_eq += float(pnl or 0); _jue_peak = max(_jue_peak, _jue_eq)
        _jue_wins.append(1 if (pnl or 0) > 0 else 0)
        if len(_jue_wins) > 20:
            _jue_wins = _jue_wins[-20:]
        if len(_jue_wins) >= 20:
            _wr = sum(_jue_wins) / 20.0
            if _wr >= 0.65 and not _jue_greedy:
                _jue_greedy = True
                _jue_ledger('贪相', {'滚动胜率': round(_wr, 3)})
            if _wr < 0.55:
                _jue_greedy = False
        _dd = (_jue_peak - _jue_eq) / _jue_peak if _jue_peak > 0 else 0.0
        if _dd > 0.06 and not _jue_fear:
            _jue_fear = True
            _jue_ledger('惧相', {'回撤': round(_dd, 4)})
        if _dd < 0.03:
            _jue_fear = False
    except Exception:
        pass

def _jue_gate(pick, st=None):
    """⇒ (放行, 因)  默认关=旧行为；公理写保护 + 节流阀 + 势随天道浮动 + 起执告警"""
    global _jue_n, _jue_side_streak, _jue_last_side
    if not JUE_AWARE_ON:
        return True, ''
    if JUE_AXIOM_LOCK and JUE_AXIOM_LOCK != JUE_AXIOM_PIN:
        _jue_ledger('公理异动', {'锁': JUE_AXIOM_LOCK, '定版': JUE_AXIOM_PIN})
        return False, '公理锁不符(写保护)'
    _jue_n += 1
    _a, _b, _hc = _jue_spectrum()
    _strength = max(_a, _b)
    if (_jue_n % 100) >= int(round(JUE_GRAY_PCT * 100)):      # 灰度: 未入阶 ⇒ 仅观不拦
        if JUE_SPECTRUM_ON and _jue_n % 20 == 0:
            log('☯ 觉悟·态势谱: 阳%.2f 阴%.2f 混沌%.2f (灰度%.0f%%·观而不拦)' % (_a, _b, _hc, JUE_GRAY_PCT * 100))
        return True, '灰度外观测'
    if JUE_SPECTRUM_ON:
        log('☯ 觉悟·态势谱: 阳%.2f 阴%.2f 混沌%.2f 势强%.2f' % (_a, _b, _hc, _strength))
    _side = (pick or {}).get('side')
    # 🔧2026-09-27 老板令「确认，1+2」(火印 ED-20260927-233) 治本:
    #   本系统 side 为**字符串**('long'/'short') ⇒ 旧码 `_side > 0` 是 **str 比 int** ⇒ TypeError
    #   ⇒ 被外层 except 兜成「觉悟闸异常放行」⇒ 闸形同虚设(实证 04:43)。今先归一号再比较。
    try:
        _side = float(_side)
    except (TypeError, ValueError):
        _s = str(_side or '').strip().lower()
        _side = 1.0 if _s in ('long', 'buy', '多', 'up') else (-1.0 if _s in ('short', 'sell', '空', 'down') else 0.0)
    _lead = 1 if _a >= _b else -1
    if JUE_THROTTLE_ON and _side and ((_side > 0) != (_lead > 0)):
        _jue_ledger('节流阀', pick)
        return False, '绝利一源: 逆主势'
    if _jue_fear:
        _jue_ledger('惧相入表决', pick)                      # 体用不二: 觉知接入制衡集合
        return False, '惧相未复(硬切·觉知入表决)'
    if JUE_DRIFT_ON:
        _thr = max(1.0, JUE_THR_BASE - 1.5 * _strength) * _jue_w * (1.5 if _jue_greedy else 1.0)
        if abs(float((pick or {}).get('score', 0) or 0)) < _thr:
            return False, '势弱: 门槛%.2f未达' % _thr
    if _side == _jue_last_side:
        _jue_side_streak += 1
    else:
        _jue_side_streak = 1; _jue_last_side = _side
    if _jue_side_streak >= 12:
        _jue_ledger('起执', {'连向': _jue_side_streak, '向': _side})
        _jue_evolve()                                        # 因果不二: 迭代回写择向权重
    return True, '觉悟放行(势强%.2f·权%.2f)' % (_strength, _jue_w)


def _wuxing_entry_coef(sig):
    """☯ 五行生克·入场系数(读 `_五行_本命归属_V1.0.json`)· 回测用(ED-20261002-374)
    态势五行由 t4/tp 推 · 与本命比生克 → 相生回 GEN_COEF / 相克回 RES_COEF / 同气 1.0
    """
    global _WUXING_CFG_CACHE
    try:
        _c = _WUXING_CFG_CACHE
    except NameError:
        _c = None
    if _c is None:
        try:
            _c = json.load(open(os.path.join(HERE, '_五行_本命归属_V1.0.json'), encoding='utf-8'))
        except Exception:
            _c = {}
        globals()['_WUXING_CFG_CACHE'] = _c
    _bm = {}
    for _el, _toks in (_c.get('本命归属') or {}).items():
        for _t in _toks:
            _bm[_t] = _el
    _sc = _c.get('生克环') or {}
    _sheng = _sc.get('相生') or {}
    _ke = _sc.get('相克') or {}
    _ct = _c.get('烛龙统御') or {}
    _gen = float(_ct.get('weight_generate_coeff', 1.25) or 1.25)
    _res = float(_ct.get('weight_restrain_coeff', 0.60) or 0.60)
    _coin = (sig or {}).get('coin')
    _ben = _bm.get(_coin)
    if not _ben:
        return 1.0
    _t4 = float((sig or {}).get('t4') or 0)
    _tp = str((sig or {}).get('tp') or '?').upper()
    if _t4 > 0.5 or _tp == 'UP':
        _shi = '火' if _t4 > 1.0 else '木'
    elif _t4 < -0.5 or _tp == 'DOWN':
        _shi = '水' if _t4 < -1.0 else '金'
    else:
        _shi = '土'
    if _shi == _ben:
        return 1.0
    if _sheng.get(_shi) == _ben or _sheng.get(_ben) == _shi:
        return _gen
    if _ke.get(_shi) == _ben or _ke.get(_ben) == _shi:
        return _res
    return 1.0


def _adaptive_notional(sig):
    try:
        sc=abs(float(sig.get('score',0) or 0)); reg=sig.get('regime'); side=sig.get('side'); tp=sig.get('tp')
        # 按真实量程±4校准: 3.5+→1.0 / 2.5+→0.85 / 1.5+→0.65 / 其余→0.5
        f_score = 1.0 if sc>=3.5 else (0.85 if sc>=2.5 else (0.65 if sc>=1.5 else 0.5))
        agree = (reg=='up' and side=='long') or (reg=='dn' and side=='short')
        f_reg = 1.0 if agree else (0.55 if reg in ('chop',None,'') else 0.7)
        f_tp = 1.0 if ((tp=='UP' and side=='long') or (tp=='DOWN' and side=='short')) else 0.85
        f_pos = 1.0
        if SIGN_POS_THROTTLE_ON:
            # 🧭 位置定仓(ED-20260930-350): 带内=满量程; 出带按偏离递减, 下限 SIGN_POS_THROTTLE_MIN(不拦死)
            try:
                _p = sig.get('pos4')
                if _p is None:
                    _p = sig.get('pos')
                if _p is not None:
                    _p = float(_p)
                    if _p < SIGN_POS_BAND_LO:
                        _d = SIGN_POS_BAND_LO - _p
                    elif _p > SIGN_POS_BAND_HI:
                        _d = _p - SIGN_POS_BAND_HI
                    else:
                        _d = 0.0
                    f_pos = max(SIGN_POS_THROTTLE_MIN, 1.0 - _d / 50.0)
            except Exception:
                f_pos = 1.0
        f=max(0.0,min(1.0, f_score*f_reg*f_tp*f_pos))
        # ☯2026-10-02 老板令「回测五行生克调度」·火印 ED-20261002-374(临时实验开关·**默认关=零行为变化**)
        #   相生(态势生/生态势)→×GEN_COEF放大 · 相克→×RES_COEF压制。read 配置 `_五行_本命归属_V1.0.json`
        if os.environ.get('WUXING_ENTRY_COEF_ON', '0') != '0':
            try:
                _c = _wuxing_entry_coef(sig)
                if _c != 1.0:
                    f = max(0.0, min(1.0, f * _c))
            except Exception:
                pass
        # 🆕2026-09-11 结果导向·弱信号封顶(治"方向不清却开大仓"): sc<1.5→名义≤40%仓; 与"空仓休不硬开"同源
        cap=1.0 if sc>=1.5 else 0.40
        return min(NOTIONAL*(0.35+0.65*f), NOTIONAL*cap), f
    except Exception:
        return NOTIONAL, 0.0

def _zhongshu_entry_judge(coin):
    """🎯2026-09-24 中枢·入场把关（拒追高）—— 老板令「先挂纸面跑通」
    实证(368 笔·1m 行情·三关全过): 进场后 1h 命中 38.9%→57.6%; 样本外(后40%) 33.8%→61.8%; 病根=追高
      ① 价处 60m 区间顶部(≥95%)  ② 5m 涨速过大(>0.4%)  ③ 跑赢大盘过多(>0.7%)  → 任一命中 = 拒开
    """
    try:
        _pmax=float(os.environ.get('ZHONGSHU_POS_MAX','95'))
        _smax=float(os.environ.get('ZHONGSHU_SPD_MAX','0.4'))
        _dmax=float(os.environ.get('ZHONGSHU_DIV_MAX','0.7'))
        _cl=_candles(coin,'1m',61) or []
        if len(_cl)<20: return True,'缺行情·放行'
        _last=_cl[-1]; _lo=min(_cl); _hi=max(_cl)
        _pos=(_last-_lo)/(_hi-_lo)*100 if _hi>_lo else 50.0
        _spd5=(_last-_cl[-6])/_cl[-6]*100 if len(_cl)>=6 else 0.0
        if _pos>=_pmax: return False, f'追高·价在60m区间顶部({_pos:.0f}%≥{_pmax:.0f})'
        if _spd5>_smax: return False, f'追高·刚急拉({_spd5:.2f}%>{_smax})'
        _spd60=(_last-_cl[0])/_cl[0]*100
        _sp=[]
        for _c in WATCH_COINS:
            _x=_candles(_c,'1m',61) or []
            if len(_x)>=2: _sp.append((_x[-1]-_x[0])/_x[0]*100)
        _med=__import__('statistics').median(_sp) if _sp else 0.0
        _div=_spd60-_med
        if _div>_dmax: return False, f'追高·跑赢大盘过多({_div:.2f}%>{_dmax})'
        return True, f'过关(位置{_pos:.0f}/5m{_spd5:+.2f}/背离{_div:+.2f})'
    except Exception as _e:
        return True, f'异常放行({_e})'

def _zhongshu_pullback_cycle(st):
    """🎣2026-09-24 中枢·等回抽挂限价（**默认关** ZHONGSHU_PULLBACK_ON=0）
    实证: 不等回抽直接进 → 1h 命中 38.9%; 挂限价等回抽 d=0.5%/窗口60m → **54.1%**（叠加拒追高 57.6%·样本外61.8%）
    做法: 信号点到 → 不立即吃单, 挂限价(多: 低于现价 d%; 空: 高于现价 d%), 窗口内回抽到位才成交, 过期撤单.
    只在内存存一份挂单(不写账本·重启即弃·无害)。
    返回: None=无挂单 · 'pending_pullback'=还在等 · 'pullback_expired'=过期撤 · 'open'=已成交开仓
    """
    _p = _ZH_PEND.get('cur')
    if not _p:
        return None
    _now = _time.time()
    _pr = _price(_p['coin'])
    if not _pr:
        return 'pending_pullback'
    if _now > _p['deadline']:
        _ZH_PEND.pop('cur', None)
        log(f"⌛ 中枢等回抽: {_p['coin']} 窗口内未回抽到 {_p['limit']:.4f}(现 {_pr:.4f}) → 撤单·不追")
        return 'pullback_expired'
    _hit = (_pr <= _p['limit']) if _p['side'] == 'long' else (_pr >= _p['limit'])
    # ⏳🆕ED-20260927-240 门③回踩后等一根(不抢第一根·V46 Q7)
    if _hit and SIGN_WAIT_ONE and not _p.get('armed_at'):
        _p['armed_at'] = _now
        log(f"⏳ 择向·等一根(ED-240): {_p['coin']} 已回抽到位(现 {_pr:.4f} 限价 {_p['limit']:.4f}) → 先确认一根再进")
        return 'pending_pullback'
    if _hit:
        _ZH_PEND.pop('cur', None)
        log(f"🎣 中枢等回抽: {_p['coin']} 回抽到位(现 {_pr:.4f} ≤ 限价 {_p['limit']:.4f}) → 成交开仓")
        _ok = _open_paper(st, _p['sig'], min(_pr, _p['limit']) if _p['side'] == 'long' else max(_pr, _p['limit']))
        return 'open' if _ok is not False else 'open_fail'
    _left = (_p['deadline'] - _now) / 60.0
    log(f"🎣 中枢等回抽: {_p['coin']} 挂单在等(限价 {_p['limit']:.4f}·现 {_pr:.4f}·剩 {_left:.0f}分)")
    return 'pending_pullback'


_ZH_PEND = {}   # 🎣 中枢等回抽·内存挂单（仅一项·不落盘）


def _zhizhi_ok(sig):
    '''🐉 知止约束 (2026-09-25 火印 ED-20260925-138 · 写死常驻)
       择向层每一笔潜在开仓信号, 必须同步具备 止盈/止损兜底线/紧急闸 完整离场集合。
       离场定义缺失 → 信号直接作废。
       ☯2026-10-01 老板令「知止闸并入道统」: 道统先导单(_sovereign)已补齐 tp ⇒ 不因缺字段拦(一个声音)。'''
    if not sig:
        return False
    if sig.get('_sovereign'):
        return True          # ☯ 道统先导单: 离场集合由内核统一给予(道统已当家)
    _sid = '%s|%s|%s' % (sig.get('coin'), sig.get('side'), sig.get('day') or sig.get('ts') or '-')   # 🈸工单3-3 信号唯一ID
    _probe = bool(sig.get('probe') or sig.get('_probe'))
    _tp = sig.get('tp')
    # 🈸工单 3-2: **probe 探针豁免止盈校验**(保全观测数据源·免被整体误杀)
    _has_tp = _probe or (bool(_tp) and (_tp not in ('?', '', 0, '0')))
    _has_sl = ('SL' in globals()) and (float(SL or 0) > 0)                       # 兜底线(探针亦强制)
    _has_em = ('QILIN_EMERGENCY_STOP' in globals()) and (float(QILIN_EMERGENCY_STOP or 0) < 0)  # 紧急闸(探针亦强制)
    if not (_has_tp and _has_sl and _has_em):
        _miss = ','.join([n for n, ok in (('止盈', _has_tp), ('兜底线', _has_sl), ('紧急闸', _has_em)) if not ok])
        _L = globals().get('log')
        if _L: _L(f"🚪 知止弃单: id={_sid} 缺失字段=[{_miss}] 探针={_probe} → 信号作废")
        try:
            _wuxing_tick('知止弃单')
        except Exception:
            pass
        return False
    return True


def _entry_score100(sig, st=None):
    """🌟 ED-20260928-294 铁律·评分七十建仓令(老板 2026-09-28 19:49 君主原文):
       「铁律评分没有超过70分的币不得建仓，低分必败。正确时机+正确判向+准确动能/动势+精准金叉，死叉×烛龙大起势+腾蛇精准执行。」
       四路各 25 分: ①正确时机(pos4居带中) ②正确判向(regime+e4/e1同向) ③准确动能/动势(|t4|+t96同向) ④精准金叉/死叉(gck)
       再 × 烛龙大起势(大势门票) × 腾蛇精准执行(执行层收紧则折)。
       口径全取内核既有真实信号(不另造数据源); 任何异常 ⇒ 返回 0(宁缺毋滥·不建仓)。纯只读。"""
    try:
        _long = str(sig.get('side') or '') == 'long'
        pos4 = float(sig.get('pos4') or 50)
        s1 = 25.0 * max(0.0, 1.0 - abs(pos4 - 50.0) / 50.0)                     # ① 正确时机
        rg = str(sig.get('regime') or '')
        s2 = 25.0 if ((_long and rg in ('up', 'golden')) or ((not _long) and rg in ('dn', 'death'))) else (12.0 if rg in ('chop', 'neutral') else 0.0)   # ② 正确判向
        try:
            _e4 = float(sig.get('e4') or 0.0); _e1 = float(sig.get('e1') or 0.0)
            s2 = min(25.0, s2 + 2.5 * ((1 if (_e4 > 0) == _long else 0) + (1 if (_e1 > 0) == _long else 0)))
        except Exception:
            pass
        t4 = abs(float(sig.get('t4') or 0.0))
        s3 = min(25.0, t4 / 2.0 * 25.0)                                          # ③ 准确动能/动势
        try:
            _t96 = float(sig.get('t96') or 0.0)
            if abs(_t96) >= 1.0 and (_t96 > 0) == _long:
                s3 = min(25.0, s3 + 4.0)
        except Exception:
            pass
        gck = str(sig.get('gck') or '')                                          # ④ 精准金叉/死叉
        if (_long and ('金叉' in gck or 'golden' in gck.lower())) or ((not _long) and ('死叉' in gck or 'death' in gck.lower())):
            s4 = 25.0
        elif gck in ('', '-', '无', 'none', 'None'):
            s4 = 10.0
        else:
            s4 = 0.0
        _sc = s1 + s2 + s3 + s4
        try:                                                                     # × 烛龙大起势
            _zv = int((ZHU_EDICT.get('votes') or {}).get('大势门') or 0)
            _want = 1 if _long else -1
            _sc *= (1.0 if _zv == _want else (0.75 if _zv == 0 else 0.5))
        except Exception:
            _sc *= 0.75
        try:                                                                     # × 腾蛇精准执行(执行层收紧则折)
            _g = (st or {}).get('guard') or {}
            if float(_g.get('_consec') or 0) >= CONSEC_LOSS_K or float(_g.get('_cool') or 0) > 0:
                _sc *= 0.6
        except Exception:
            pass
        return round(max(0.0, min(100.0, _sc)), 1)
    except Exception:
        return 0.0


def _open_paper(st, sig, pr):
    _zg = _zhulong_gate(st, sig)      # 🐉 王袍加身·一票之闸(拟开与圣裁相左即拦)·费率腿豁免
    if _zg: return _zg
    if ENTRY_SCORE100_ON and not sig.get('_fund_leg') and not sig.get('_sovereign'):      # 🌟派ED-20260928-294 评分七十建仓令(boss 19:49)
        # ☯2026-10-01 老板令「闸并入道统」: 道统先导单(_sovereign)由道统三才(天明+混t4阈)定库 ⇒ 不叠评分门(一个声音)。
        _s100 = _entry_score100(sig, st)
        if _s100 < ENTRY_SCORE100_MIN:
            log('🌟 评分门(ED-294): %s %s 评分 %.1f < %.0f ⇒ 不建仓(低分必败·宁缺毋滥)' % (sig.get('coin'), sig.get('side'), _s100, ENTRY_SCORE100_MIN))
            return 'blocked_score100'
        log('🌟 评分门(ED-294): %s %s 评分 %.1f ≥ %.0f ⇒ 放行' % (sig.get('coin'), sig.get('side'), _s100, ENTRY_SCORE100_MIN))
        sig['_score100'] = _s100
    q=WATCH_COINS[sig['coin']]['quanto']
    _nt,_conf=_adaptive_notional(sig)   # 🎚 自适应名义(把握度)
    try:                                     # ☯🆕药五·唯一加成点(或跃在渊)·火印 ED-20260927-228
        _b5, _n5 = _y5_boost(sig)
        if _b5 > 1.0:
            _nt = min(_nt * _b5, NOTIONAL)       # 只加成·不减量；受既有量程/硬闸夹住
            log('☯ 药五·或跃在渊加成: 倍%.2f ⇒ 名义%.2f' % (_b5, _nt))
    except Exception:
        pass
    _nt=min(_nt, NOTIONAL*QIAN_CAP_RATIO)   # ☯谦卦闸(势不独大·单币上限·防独大)
    if sig.get('_hundun_probe'):        # 🌫 ED-141 混沌态: 最小探测仓(金蟾采样·不为收益)
        _ps=float(_hundun_state(st).get('probe_scale') or HUNDUN_PROBE_SCALE)
        _nt=max(1.0,_nt*_ps)
    size_ct=max(1,int(round(_nt/pr/q)))
    st['pos']={'coin':sig['coin'],'side':sig['side'],'entry':pr,'notional':_nt,
               'peak':0.0,'peak_pct':0.0,'floor_pct':0.0,'size_ct':size_ct,
               'big_meat':False,'tier':0,'open_ts':_time.time(),'_opened_ts':_time.time(),'conf':round(_conf,3),   # 🆕_opened_ts供方向自检
               'mae':0.0,'mae_pct':0.0,   # 🈸ED-138⑤ 知止硬校验料: 最大逆行(MAE)
               '_hundun_probe':bool(sig.get('_hundun_probe')),
'_fund_leg':bool(sig.get('_fund_leg')),   # 🪙ED-20260927-246 费率腿标记(专属止盈/止损)   # 🌫 甲: 是否混沌探测仓(供"震荡期内"真口径统计)
               'amp6':sig.get('amp6'),'sl_adapt':round(_sl_adapt_pct(sig.get('amp6')),4),   # 📏ED-20260927-253 开仓波动率/自适应止损(留痕)
               'exit_set':{'sl':round(_sl_adapt_pct(sig.get('amp6')),4),'sl_base':round(SL,4),'lock':round(LOCK_START_PCT,4),'hard':round(QILIN_LAST_DEFENSE,6),'emerg':round(QILIN_EMERGENCY_STOP,6),'min_hold':MIN_HOLD_SEC},   # 🈸ED-138⑤ 离场集合留痕(自适应硬止损/锁盈启动/兜底线/紧急闸)
               '_ctx':{'score':sig.get('score'),'regime':sig.get('regime'),'t4':sig.get('t4'),
                       't4l':sig.get('t4l'),'gck':sig.get('gck'),'tp':sig.get('tp'),
                       'last15':sig.get('last15'),'regime_at_open':sig.get('regime')}}
    log(f"🚀[SIM开] {sig['coin']} {sig['side']} score{sig['score']:+.1f}(t4{sig.get('t4',0):+.2f}%/{sig.get('gck')})"+(f" 🎯{sig.get('topbot')}" if sig.get('topbot') else "")+f" {size_ct}张@{pr:.4f} 名义${_nt:.0f}(把握{_conf*100:.0f}%)")
    return True

def _close_here(st, pos, pr, pnl_pct, pnl_usd, why):
    st['realized']=st.get('realized',0)+pnl_usd
    # 🆕2026-09-11 老板令"三标分台账·注明当日胜率": 加 ts(平仓时刻) + day(当日) 供面板算当日胜率
    _now=_time.time()
    st.setdefault('trades',[]).append({'coin':pos['coin'],'side':pos['side'],
        'entry':round(pos['entry'],4),'exit':round(pr,4),'pnl':round(pnl_usd,2),
        'pnl_pct':round(pnl_pct*100,3),'why':why,'peak_pct':round(pos.get('peak_pct',0)*100,3),
        'mae_pct':round(float(pos.get('mae_pct',0) or 0)*100,3),'exit_set':pos.get('exit_set'),   # 🈸ED-138⑤
        'regime':(pos.get('_ctx') or {}).get('regime'),'hundun_probe':bool(pos.get('_hundun_probe')),   # 🌫甲 真口径料
        'ts':round(_now,1),'day':_time.strftime('%Y-%m-%d',_time.localtime(_now))})
    _note_close(st,pnl_usd,why)   # 🛡护栏: 计日亏/止损/连亏(供熔断闸)
    _life_sample(pos, pr, pnl_pct, pnl_usd, why)   # 🧬 生命体训练数据集(开仓全景+结果)
    log(f"🔒[SIM平] {pos['coin']} {pos['side']} {why} pnl{pnl_usd:+.2f}$({pnl_pct*100:+.2f}%) 累计{st.get('realized',0):+.2f}$ 峰{pos.get('peak_pct',0)*100:.2f}%")
    # 🌀🆕2026-09-25 完善: 五行相生·第3环"知识库沉淀"(按多/空分账记胜负→喂迭代) + 第4环"卷宗归档"
    _wuxing_link('沉淀', win=(pnl_usd > 0), side=pos['side'])
    _wuxing_link('归档')
    _wuxing_sample(pos, pr, pnl_pct, pnl_usd, why)   # 🈸工单1-3 样本料(相位/probe/知止/终止标记·供离线迭代)
    if BEASTBUS_ON and int(pos.get('_fandou',0) or 0) > 0:
        _flip_outcome_fb(pos['coin'], pos['side'], pnl_usd, pnl_pct, why, pos.get('_fandou',1))   # 🧩双回流·平仓回填
    st['pos']=None

def _weak_signal(pos, sig):
    """近端转弱(供金蟾判伪/大肉确无发展): 反持仓向的15m/MACD/末根短下破"""
    if pos['side']=='long':
        if sig.get('tp')=='DOWN': return True,'15m转跌'
        if sig.get('gck')=='death': return True,'MACD死叉'
    else:
        if sig.get('tp')=='UP': return True,'15m转涨'
        if sig.get('gck')=='golden': return True,'MACD金叉'
    return False,''

def cycle_once(st, now_price=None, now_sig=None, external_flat=False):
    try: _zhulong_cycle(st)   # 🐉 烛龙圣裁(先·诸路归一): 多币择强+阴阳五行择向+情报/哨探/费率腿/制衡 → 唯一声音
    except Exception as _ze: log('🐉 圣裁异常(不影响交易): %s' % str(_ze)[:80])
    try: _jiugong_cycle(st)   # 🏛 九宫八卦方阵: 每周期常驻并行(相生闭环+相克约束·禁互斥) · 旁路不改交易判定
    except Exception as _jge: log('🏛 方阵异常(不影响交易): %s' % str(_jge)[:80])
    pos=st.get('pos')
    if pos:
        # 🛟 幽灵仓即时恢复(继承母体基因·2026-B): 账本说有仓但真实(Gate/外挂在器)已无 → 该仓已被外部手平/紧急平
        #   = 若当"实盘网关为判据"运行时(由驱动传 external_flat=True)立即清幽灵、记恢复轨迹、回干净空仓继续
        #   (防: 引擎误当"尚在持仓"继续管一个不存在的仓: 误判盈亏/错触发却平不到/空仓却不开新)
        if external_flat:
            st.setdefault('trades',[]).append({'coin':pos['coin'],'side':pos['side'],
                'entry':round(pos.get('entry',0),4),'exit':0.0,'pnl':0.0,'pnl_pct':0.0,'why':'manual_rec_ghost',
                'note':'手工平仓即时恢复: 账本有仓但网关已空 → 清幽灵, 现金已在网关'})
            # 不在账本落地盈亏(外部已收, 盈亏只在网关), 只记恢复轨迹
            log(f"🛟 手工平仓即时恢复: 账本有{pos['coin']} {pos['side']}但网关已空 → 清幽灵仓, 回干净空仓继续")
            st['pos']=None; return 'ghost_cleared'
        # ── 持仓管理: 择强节点持某币某向, 用金蟾/貔貅躯体管退出 ──
        sig = now_sig or _coin_sig(pos['coin'], manage=True)   # 🔓ED-20261008-628 持仓管理豁免开仓闸
        if not sig: return 'net_err'
        pr = now_price or sig.get('pr') or _price(pos['coin'])
        if not pr: return 'net_err'
        ppct = (pr-pos['entry'])/pos['entry'] if pos['side']=='long' else (pos['entry']-pr)/pos['entry']
        pnl_usd = ppct*pos['notional']
        peak_pct = max(pos.get('peak_pct',0), ppct)
        pos['peak_pct']=peak_pct; pos['peak']=pos['notional']*peak_pct
        _mae = min(float(pos.get('mae_pct',0.0) or 0.0), ppct)   # 🈸ED-138⑤ 最大逆行(最深浮亏)
        pos['mae_pct']=_mae; pos['mae']=pos['notional']*_mae
        # 🪙🆕ED-20260927-246 金蟾·费率反向腿·专属目/损（**默认关**·FUND_LEG_TGT=0 即旧行为逐字不变）
        if pos.get('_fund_leg') and FUND_LEG_TGT > 0:
            if FUND_LEG_STP > 0 and ppct * 100.0 <= -FUND_LEG_STP:
                return _finish(st,pos,pr,ppct,pnl_usd,'🪙费率腿专属止损(-%.2f%%)' % FUND_LEG_STP,sig)
            if ppct * 100.0 >= FUND_LEG_TGT:
                return _finish(st,pos,pr,ppct,pnl_usd,'🪙费率腿专属止盈(%.2f%%)' % FUND_LEG_TGT,sig)
        # 🛡2026-09-25 老板令「让环境变量生效」: 最小持有时间 —— 开仓后 W 秒内不认「软亏」
        #   源: 老母体 `_多币母体进化2_SIM.py` 1608-1617 (ED-141③·老板原设计) 原意搬入:
        #     「软性认亏出口」暂缓(慢阴保护/早断/麒麟认亏) —— 硬止损/紧急闸/兜底/单币快崩 **仍全效**; 锁盈不动.
        #   0=关(老行为逐字不变); 基因给 300 → 生效.
        _minhold = False
        _age = 0.0
        if MIN_HOLD_SEC > 0:
            try:
                _age = _time.time() - float(pos.get('open_ts', 0) or 0)
                _minhold = (_age < MIN_HOLD_SEC)
                if _minhold and not pos.get('_mh_log'):
                    pos['_mh_log'] = 1
                    log(f"⏳ 最小持有: {pos['coin']} {pos['side']} 开仓{_age:.0f}秒<{MIN_HOLD_SEC}秒 → 软性认亏出口暂缓(硬止损/紧急闸/兜底/单币快崩 仍全效)")
            except Exception:
                _minhold = False
        # 硬止损(2.5%)最优先护本金 · 📏ED-20260927-253 宽幅自适应(按开仓波动率伸缩·上限夹紧)
        _SLV = _sl_adapt_pct(pos.get('amp6'))
        if ppct <= -_SLV:
            return _finish(st,pos,pr,ppct,pnl_usd,'硬止损',sig)
        # 🎯🆕2026-09-12 方A1·开仓后方向自检(老板"择向精准度直接关联最终胜率"):
        #   病: 开仓后方向错(逆势/信号矛盾)时, 旧逻辑要等到浅浅亏(-0.25%)或早断线才反应 → 已损一节.
        #   药: 开仓后头 DIRCHK_WINDOW 秒内(刚开), 若"信号自证伪"(certify高=信号矛盾/背离 + 近端反向 + 逆大势) → 极速自检砍(承认选错, 不硬扛).
        #   只动"刚开仓窗", 不影响已持仓的靠鳄鱼/麒麟正常管. ⚫2026-09-15 A: 已封存(DIRCHK_LEGACY) → 移除死代码.
        # ── 融入貔貅抬地板/递增阶梯 + 大义闸 + 一键换向 (更细的肉) ──
        wk,wkty=_weak_signal(pos,sig)
        pt=pos['peak_pct']; pp=ppct; m,pw=_trend_strength(pos,sig)
        tp=sig.get('tp'); gck=sig.get('gck'); t4=sig.get('t4',0) or 0
        last15=sig.get('last15',0) or 0
        flock_g=(pos['side']=='long'  and gck=='death' and tp=='DOWN')
        flock_l=(pos['side']=='long'  and tp=='DOWN' and last15<-0.1)
        flock = flock_g or (flock_l and pos.get('_fl2',0)>=1)   # 快腿需连2; gck腿即时
        if flock_l: pos['_fl2']=pos.get('_fl2',0)+1
        else:       pos['_fl2']=0
        sfk_g=(pos['side']=='short' and gck=='golden' and tp=='UP')
        sfk_l=(pos['side']=='short' and tp=='UP' and last15>0.1)
        sfk = sfk_g or (sfk_l and pos.get('_fs2',0)>=1)
        if sfk_l: pos['_fs2']=pos.get('_fs2',0)+1
        else:     pos['_fs2']=0
        # 🐍🆕早断·深水急冲腿(2026-09-10 老板“下猛药治慢断”·自适应治疗):
        #   病案: 早断线在-0.6%, 但实测多笔在-1.2~-1.58%才断(等MACD/15m死叉确认出来, 价已滑近硬止损2.5%) → “早断”沦为“慢断”,
        #   均亏-567极高. 药: 仓位已滑到较深水(≤-0.9%)且该币近端单根对持仓急冲(≥0.5%)→ 属近端已真转坏,
        #   不再等均线确认(等出来就晚了)→ 立即小亏早走, 把“-567慢断”压向“-200~300”. 只对“先跌后急冲”双条件(避浅水噪声误断).
        deep_long  = (pos['side']=='long'  and ppct<=-DEEPWATER_CUT_PCT and last15<=-0.5)   # 🔌20260923 接线
        deep_short = (pos['side']=='short' and ppct<=-DEEPWATER_CUT_PCT and last15>=0.5)   # 🔌20260923 接线
        # 🐉🆕 证伪确诊反向 (2026-09-10 老板令·赋予系统“证伪确诊反向”: 发现方向错→广播警报→烛龙令腾蛇执行→于最早区间扭亏为盈)
        # 🦄🆕 麒麟摆尾(2026-09-12 07:1x 老板令"以后不要有麒麟摆尾这个名,统一'麒麟摆尾',麒麟兽天生神通"):
        #   收权归麒麟: 原散落的"证伪确诊反向/智能麒麟摆尾/保卫科麒麟摆尾/区间顶底麒麟摆尾"四门 → 融合为麒麟一盘"摆尾"统一决策.
        #   麒麟摆尾 = 镇守/守护/兜底 (守之职·唯一执刃者), 一刀判"该摆不摆" → 该摆则反手扭亏, 不该摆则按兵不动.
        _why=''  # 🩹2026-09-17 22:12 心跳自愈修: 原缺默认值→下方早断分支用 _why 时 NameError(21:39-21:42 dss/lbh/zls 连续异常·整轮cycle中断)
        _qt=_qilin_baiwei(pos, sig, st, ppct, pt, gck, tp, t4, last15, flock, sfk, deep_long, deep_short)
        if _qt:
            _act, _nw, _why = _qt[0], _qt[1], _qt[2]
            if _act=='flip':
                return _flip(st,pos,pr,ppct,pnl_usd,_why,sig,_nw)
            elif _act=='cut':
                if _minhold:
                    if not pos.get('_mh_cut_log'):
                        pos['_mh_cut_log'] = 1
                        log(f"⏳ 最小持有: {pos['coin']} 开仓{_age:.0f}秒<{MIN_HOLD_SEC}秒 → 麒麟认亏口暂缓(硬止损/紧急闸/兜底/单币快崩 仍全效)")
                else:
                    return _finish(st,pos,pr,ppct,pnl_usd,_why,sig)
        # 🚨单币快崩守护(护栏·行情侧·老板23:48归位): 持仓币自己近端单根对持仓惨冲(非大盘联动才叫单币快崩)→ 应急信号,
        #   不等满损/不等辨向证伪, 小亏早护走—— 专兜那类'被单币拉起/自己崩'到-2.5%硬止损的单(ADA空被拉飞/LINK多自己崩).
        #   只对[已小幅水下(<=-0.3%) 且 单币近端一根对持仓爆冲>=1.1%]触发; 健康的浅回踩/水上波动不误杀.
        crash_long  = (pos['side']=='long'  and ppct<=FAST_CRASH_ON and (last15<=-FAST_CRASH_BAR))
        crash_short = (pos['side']=='short' and ppct<=FAST_CRASH_ON and (last15>=FAST_CRASH_BAR))
        if crash_long or crash_short:
            _cc=pos['coin']
            return _finish(st,pos,pr,ppct,pnl_usd,f'单币快崩应急护(水下{ppct*100:.2f}%/{_cc}近端|{last15:+.2f}%|惨冲→不等满损早走·护本金)',sig)
        # 0) 一键换向(已归入🦄麒麟摆尾·⓪获利转向): 此处不再单独处理(防两处重复)
        # 🐸金蟾·区间小肉(含大义闸识大体 + 微势衰减咬): 只对"未达貔貅大肉带"的区间利负责
        # 💊🆕2026-09-12 老板令"金蟾首档0.6%-1.6%": 金蟾负责 0.6%~1.6% 带(峰<1.6%=未到大肉带); 峰≥1.6%→貔貅接手.
        #   (旧: 峰<1.0%就交貔貅→0.6~1.6%带无人管; 现统一为峰<BIG_MEAT_PCT=1.6% 金蟾管)
        # 💊🆕2026-09-12 自查纠错(老板"做事不仔细"): 旧代码只在 pp≥tier[0] 咬 → 5档阶梯形同虚设(tier只初始化不递增).
        #   真阶梯: 金蟾按"当前已到档位"逐步抬升——峰刚过0.6%咬0.6档价; 峰上到0.85%→锁位抬到0.85档(不吐回); 逐级向上.
        #   这样"阶梯"才真起到"只赚不吐·逐步爬高"的作用(而非一刀0.6%剪).
        _jch_cap = max(BIG_MEAT_PCT, JCH_TIER_PCT[-1]) if FLEX_ON else 0.010   # 金蟾上界=大肉带与顶档取大(1.6%·避免顶档被截)
        # 🥇🆕2026-09-15 自适应吞金(老板令): 首档随"大势+趋势度"活——强趋势抬首档(让肉跑)·震荡弱降首档(快咬落袋).
        #   阶梯整体随首档平移(相对间距不变), 保持"只赚不吐·逐级抬升"的阶梯义.
        _tiers = JCH_TIER_PCT
        if JCH_ADAPT_ON:
            _strong = ((pos['side']=='long' and t4>=JCH_ADAPT_T4) or (pos['side']=='short' and t4<=-JCH_ADAPT_T4))
            _wk_tsig = _weak_signal(pos, sig)[0]
            if _strong and pw>=JCH_ADAPT_PW:
                _first = JCH_ADAPT_HI        # 强趋势 → 抬首档0.55(让肉跑)
            elif (not _strong) and _wk_tsig:
                _first = JCH_ADAPT_LO        # 震荡弱+近端转弱 → 降首档0.40(快咬)
            else:
                _first = JCH_FIRST_PCT       # 常态0.45
            _delta = _first - JCH_TIER_PCT[0]
            _tiers = tuple(max(0.0015, round(x+_delta,4)) for x in JCH_TIER_PCT)
        # 🐸 计算当前已到档位(按峰值 pt 定): 峰≥档位值 → 该档已达成
        _cur_tier = 0
        for _i, _tv in enumerate(_tiers):
            if pt >= _tv:
                _cur_tier = _i + 1
        pos['tier'] = max(int(pos.get('tier', 0) or 0), _cur_tier)   # 档位只升不降(已锁定)
        # 阶梯锁位: 已达某档 → 锁该档价位(回落跌破即锁走·只赚不吐); 未达首档→按首档
        _jch_lock = _tiers[_cur_tier - 1] if _cur_tier > 0 else _tiers[0]
        pos['_jch_first'] = _tiers[0]   # 供日志/面板显化
        if pp>0 and pp>=_tiers[0] and pt< BIG_MEAT_PCT*2 and pt<_jch_cap:
            _dayi = BEASTBUS_ON and ((pos['side']=='long' and t4>=DAYI_T4) or (pos['side']=='short' and t4<=-DAYI_T4))   # 🚌并入三兽巴士(②金蟾→貔貅 让吐/退返)
            # 💊🆕2026-09-12 方A1: 大义闸放宽(让赢单多跑)——大势稍旺(≥DAYI_T4_LOOSE)且趋势不弱 → 也让位貔貅.
            _dayi_loose = BEASTBUS_ON and ((pos['side']=='long' and t4>=DAYI_T4_LOOSE) or (pos['side']=='short' and t4<=-DAYI_T4_LOOSE))   # 🚌并入三兽巴士(放宽档)
            # 大义闸(不剪顺大势winner): 大势仍旺顺持仓向 & 趋势度真强(pw>=1.0 顺势) → 让貔貅/阶梯接力吃整羊,
            #   即今日回放抓到的"金蟾见强趋势一根15m回落就咬走小winner→付双费重开更贵"的病(该让勿乱让)
            #   咬的两个正当理由: 大势不在(弱市区间咬小利) 或 (大势在但趋势度不强(<1.0)且近端真转弱→伪突破小咬)
            # 🔄回路B 麒麟→金蟾(降档): 该币摆尾翻错过 ⇒ 暂缓让吐(不交棒·金蟾自行阶梯锁)
            _loop_hold = bool(_loop_get(pos.get('coin'), '金蟾暂缓', 0.0))
            if ((_dayi and pw>=1.0) or (_dayi and not wk) or (FLEX_ON and _dayi_loose and pw>=0.5)) and not _loop_hold:
                pass  # 让位貔貅 顺大势 / 未真弱 / (方A1)大势稍旺且趋势不弱: 不截
            elif FLEX_ON:
                # 💊真阶梯: 峰已爬到某档(峰≥该档)后, 回落到该档锁位以下→按该档锁走(只赚不吐·逐级抬).
                if pp <= _jch_lock and _cur_tier > 0:
                    return _finish(st,pos,pr,pp,pnl_usd,f'金蟾阶梯锁(到{_jch_lock*100:.2f}%档·回吐至{pp*100:.2f}%·峰{pt*100:.2f}%·{('近端'+wkty if wk else '弱市')})',sig)
            else:
                return _finish(st,pos,pr,pp,pnl_usd,f'金蟾咬区间小利(带{pw:+.2f}/{('近端'+wkty if wk else '弱市')}/峰{pt*100:.2f}%)',sig)
        # 🦁貔貅·抬地板/递增阶梯锁定(旧母体核心 只在这档启动: 峰值已真爬到>1.6%利锁地板才锁, 0.7~1.6%young利不剪)
        #   语义: TRAIL_LEG_FLOOR=1.6% 是锁位只在峰值真上到≥1.6%后才参与的一级地板(回吐跌破即保该级);
        #   1.6%以下小利归金蟾区间(吃或让貔貅), 貔貅不在此截young利。
        # 🦁🆕 貔貅·自适应回撤锁(2026-09-11 老板令"自适应最优·确保正向把钱收进肚子·滴水不漏"):
        #   病: 旧"递增阶梯"(step1%/1.5%/2%)在峰1.6~2.7%段锁位全卡1.6%不动(漏0.4~1.1%), 且峰<1.6%根本不锁(裸奔).
        #   药: 锁位**紧跟峰**(锁=峰-允许回吐), 允许回吐随(趋势度×涨速)自适应, 上下限夹紧(0.2%~0.8%)→ 滴水不漏.
        #   自适应: 强顺势(pw高/缓涨)给稍宽(防噪声甩下车); 逆势/急涨给紧(快锁防插针吐肉). GIVE_BACK_FRAC 由此复活.
        _LOCK_START = LOCK_START_PCT   # 🔌20260923 接线(默认0.010=旧值)
        if pt>=_LOCK_START and pp>0:
            _fr = 0.35 if pw>=1.30 else (0.30 if pw>=0.9 else 0.25)   # 越顺势越给宽
            _pace_rc,_pc = _rise_pace(sig,pos['side'])
            if _pc=='alert':  _fr=0.25
            if _pc=='buffer': _fr=0.40
            _give = max(GIVE_FLOOR_PCT, min(pt*_fr, GIVE_CAP_PCT))   # 🔌20260923 接线(默认0.20%~0.80%=旧值)
            # 🔄回路A 貔貅→金蟾(退返入肚): 该币近期落袋 ⇒ 让吐档上调(更早落袋·不再乱让)
            _lg = _loop_get(pos.get('coin'), '让吐+', 0.0)
            if _lg:
                _give = min(GIVE_CAP_PCT, _give + _lg)
            _lock = max(0.0, pt-_give)
            # 🔄回路C 麒麟→貔貅(抬地板): 该币摆尾翻错过 ⇒ 地板抬高(少给回撤·更早锁)
            _lf = _loop_get(pos.get('coin'), '貔貅地板+', 0.0)
            if _lf:
                _lock += _lf
            if pp<=_lock:
                return _finish(st,pos,pr,pp,pnl_usd,f'貔貅自适应回撤锁(锁{_lock*100:.2f}%·峰{pt*100:.2f}%·让吐{_give*100:.2f}%·{_pc})',sig)
        # 🦁→🐸 盈利回落·退返金蟾肚(块2滴水不漏·老板图纸): 曾养出貔貅大肉(big_meat)后自峰值大回吐,
        #   且近端已真转弱(不愿再往大肉续跑)→ 不再让肉滑剩到$10/无兜, 立刻把这只大肉单退返金蟾肚子,
        #   金蟾按当前仍在正盈利的档位逐档兑住(最大退返$100带内, 最小$20/0.3%档不死漏).
        #   🐉烛龙大趋势闸(老板23:13精化·防误伤极强趋势单): 先问"这是真大趋势的回踩、还是无趋势回吐":
        #     短回踩但烛龙仍判持仓向强趋势仍在(强顺势量能/高位微势同向/近端未反方)→ 不兑付, 放赊貁续跑吃大肉;
        #     仅当烛龙也判趋势真断(此处近端真转弱 wk) + 回踩已深到金蟾带才由金蟾肚兑付滴滤守住.
        #     净效果: 纯回吐仍滴水不漏; 少数极强趋势单不再被腰在边缘提前止盈.
        if pos.get('big_meat') and wk and 0<pp<=BIG_MEAT_PCT*3.33 and pt>=BIG_MEAT_PCT:
            # 蜡烛·仍强趋势闸: 回踩淺但烛龙判持仓向强趋势仍续(pw高顺势 / 高位微势同向) → 不兑, 让赊貁续跑
            still_up = (pos['side']=='long'  and (pw>=0.9 or t4>=DAYI_T4*0.3) and tp!='DOWN')
            still_dn = (pos['side']=='short' and (pw<=-0.9 or t4<=-DAYI_T4*0.3) and tp!='UP')
            if (still_up or still_dn) and pp>=BIG_MEAT_PCT:   # 仍强趋势且只回踩到还保大肉带→不兑付让跑
                pass  # 🐉烛龙闸: 不动(本轮续让赊貅吃, 防强趋势单被提前止盈)
            else:
                if pp>=JCH_TIER_PCT[0]:
                    return _finish(st,pos,pr,pp,pnl_usd,f'金蟾肚·大肉回落退返兑付(峰{pt*100:.2f}%→现{pp*100:.2f}%, 没让肉漏剩无兜)',sig)
        # 🦁貔貅·目标止盈终点收割(双链终局)
        # 🎯🆕2026-09-12 方A1: 改用共享 _target_pct_from_pw(门户与引擎同口径)
        _tg,_tmult=_target_pct_from_pw(pw)
        if pp>=_tg:
            return _finish(st,pos,pr,pp,pnl_usd,f'貔貅目标盈禾·终点收割({pp*100:.2f}%≥{_tg*100:.2f}%·倍率{_tmult})',sig)
        # 🦁貔貅·确无发展收官(曾达大肉带被拖回且近端转弱→不裸赌续肉)
        if pos.get('big_meat') and wk and pp<=BIG_MEAT_PCT:
            return _finish(st,pos,pr,pp,pnl_usd,'貔貅大肉无发展收官',sig)
        # 大肉带判定(供下轮":让跑): 曾↑史≥BIG_MEAT
        if pt>=BIG_MEAT_PCT: pos['big_meat']=True
        return 'hold'
    # ── 空仓择强(多币自切换: 关一单→重选最强) ──
    cooldown=st.get('cooldown',0)
    if cooldown>0:
        st['cooldown']=cooldown-1; return 'cooldown'
    # 🛡护栏闸(先拦: 连亏冷却/日亏熔断/日止损超限/黑天鹅; 硬护栏优先于择强)
    # 🔧 2026-09-10 修复: 跨日复位(此前 _roll_guard 定义了却从未调用→日锁跨天不消·护栏窗口卡死) → 每日自愈
    _roll_guard(st, _time.strftime('%Y-%m-%d'))
    gb=_guard_block(st, macro=None, pick=None)
    if gb:
        log(f"🛡 {gb} → 空仓休(护栏优先, 不下单)"); return 'blocked_guard'
    pick=_pick()
    # ☯🐉🆕2026-10-01 道统先导(老板令「重排架构·阴阳五行站第一岗」·火印 ED-20261001-366 续):
    #   病: 旧序「候选→择强闸(PICK_ABS_MIN)→...→道统」⇒ 道统坐最后岗, 前闸先把候选筛光 ⇒ 主宰形同虚设。
    #   治: SOVEREIGN=1 且 _pick 无候选 → 由道统三才定乾坤, 在顺势币里选最强 → 交下游闸把关。
    if (not pick) and YIJING_YINYANG_SOVEREIGN:
        pick=_sovereign_first_pick(st)
    # 🪙🆕2026-09-27 金蟾·空仓期费率反向腿（火印 ED-20260927-244·**默认关**·仅模拟域开）
    if (not pick) and os.environ.get('FUND_LEG_ON','0')=='1':
        pick=_funding_leg_pick()
    # 🎯🆕2026-10-06 火印 ED-20261006-521 精准放行(ED-521): 三凭齐 ⇒ 豁免评分/形态闸(风控/铁律仍守)
    _pz, _pzw = _precise_pass(pick) if PRECISE_PASS_ON else (False, '')
    if _pz:
        log(f"🎯 精准放行: {_pzw} → 放行(风控/铁律仍守)")
    # ☯🆕2026-09-25 完善: **三态门前置** —— 混沌守无/阴阳相位 必须站在一切择向闸之前
    #   (病: 原挂在 _guard_block 第二处, 被更早的"chop区把握不足"截胡 ⇒ 实盘 0 触发·沙箱C组=A组铁证)
    if pick and not _pz and SANT_GATE_ON and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
        _stg_front = _santai_gate(pick)
        if _stg_front:
            _wuxing_tick('相克·麒麟风控')
            log(f"☯ {_stg_front} → 择向前置拦截(三态门·守无)")
            return 'blocked_santai_front'
    # 🚪🆕2026-09-25 完善: **知止约束接线**(原为死代码) —— 离场集合不全则信号作废
    if pick and not _pz and ZHIZHI_ON and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')) and not _zhizhi_ok(pick):
        return 'blocked_zhizhi'
    # 🎣🆕2026-09-24 中枢·等回抽挂限价（**默认关**）—— 有挂单时优先处理挂单
    if os.environ.get('ZHONGSHU_PULLBACK_ON','0')=='1':
        _rb=_zhongshu_pullback_cycle(st)
        if _rb:
            return _rb
    if pick:
        _tbb=None if _pz else _topbot_rechase_block(pick)
        if _tbb:
            log(f"📶 {_tbb}"); return 'blocked_topbot'
        hm=None if (_pz or (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg'))) else _halfmountain_block(pick)
        if hm:
            log(f"🚦 {hm} → 空仓守(宁缺毋滥)"); return 'blocked_halfmountain'
        _qb=None if (_pz or (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg'))) else _quality_block(pick)
        if _qb:
            log(f"💤 {_qb}"); return 'blocked_quality'
        ex=None if (_pz or (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg'))) else _exhaust_rechase_block(pick)
        if ex:
            log(f"🚦 {ex} → 高位衰竭守(非真破位不追)"); return 'blocked_exhaust'
        # 🛡护栏·闪崩闸(选定币近端单根爆幅→不追插针)
        gb2=_guard_block(st, macro=None, pick=pick)
        if gb2:
            log(f"🛡 {gb2} → 闪崩拒开"); return 'blocked_flash'
        pr=pick.get('pr') or _price(pick['coin'])
        if not pr: return 'net_err'
        # 🎯🆕2026-09-24 中枢·入场把关（拒追高）—— **默认关**(ZHONGSHU_ENTRY_GATE_ON=0)
        # ☯🆕2026-09-26 三才闸(火印 ED-20260926-194)· 三才不备不开 · **默认关**
        if YIJING_GATE_ON and not _pz and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
            _yjok,_yjw=_yijing_gate(pick)
            if not _yjok:
                log(f"☯ 三才闸: {pick['coin']} 不开 → {_yjw}")
                return 'blocked_yijing_three'
            log(f"☯ 三才闸: {pick['coin']} 三才皆备 → 放行")
        # ☯🆕2026-09-27 觉悟·体用合一（火印 ED-20260927-222·默认关·灰度JUE_GRAY_PCT）
        if JUE_AWARE_ON and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
            try:
                _jok, _jw = _jue_gate(pick, st)
                if not _jok:
                    log(f"☯ 觉悟: {pick['coin']} 不开 → {_jw}")
                    return 'blocked_jue'
            except Exception as _je:
                log(f"☯ 觉悟闸异常放行({_je})")
        if os.environ.get('ZHONGSHU_ENTRY_GATE_ON','0')=='1' and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
            _zok,_zw=_zhongshu_entry_judge(pick['coin'])
            if not _zok:
                log(f"🎯 中枢入场把关: {pick['coin']} 拒开 → {_zw}")
                return 'blocked_zhongshu_entry'
            log(f"🎯 中枢入场把关: {pick['coin']} {_zw}")
        # 🔴🆕2026-09-11 开仓前双保险(治“拦了又开”): 快链/母子融合任一判该币伪信号高危(certify≥0.5)→不开.
        #   (即使 _pick 漏过, 此处也兵底; 守住“伪信号绝不开仓”铁律)
        try:
            _ce2=_certify_of(pick) if os.environ.get('DUAL_CHAIN_ON','1')!='0' else 0.0
            _fcv=0.0
            if _ce2>=CERTIFY_HOT or _fcv>=CERTIFY_HOT:   # ⚔ED-20261010 补齐接回env(与快链一致·修漏改)
                # 🛡🆕2026-09-11 21:4x 老板令"放开宁缺毋滥·给麒麟兽兜底"
                # 🔧🆕2026-09-12 06:5x 老板"睡一觉漏光光"纠错·恢复"宁缺毋滥"本意:
                #   病: 全伪信号(无肉)也硬开 → 开了就往麒麟摆尾跑 → 麒麟摆尾沦为"变相止损" → 小亏+手续费累积(隔夜漏-$55.5).
                #   药: "放开宁缺毋滥"仅在**有肉**(该币振幅够·值得博)时生效; 无肉(震荡死水/振幅不足)→真宁缺毋滥空仓.
                #   OPEN_WHEN_ALLHOT=0 整关; 有肉阈值 RANGE_AMP(5%). 无肉=该币近6h振幅< RANGE_AMP.
                _meat=float(pick.get('amp6',0) or 0)   # 该币近6h振幅
                if (os.environ.get('OPEN_WHEN_ALLHOT','1') == '0' or _meat < RANGE_AMP) and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
                    log(f"🛑 开仓前二次校验: {pick['coin']} 伪信号高危(certify{max(_ce2,_fcv)}) 且无肉(振幅{_meat:.1f}%<{RANGE_AMP}%) → 真空仓(守宁缺毋滥)")
                    return 'blocked_certify'
                log(f"🤸 放开宁缺毋滥: {pick['coin']} 伪信号高危但**有肉**(振幅{_meat:.1f}%≥{RANGE_AMP}%) → 仍开(交麒麟兜底: 麒麟摆尾/早断分流)")
        except Exception:
            pass
        # 🌟🆕2026-09-15 09:11 药③(老板令): 麒麟刹车后同币冷却 — 防"刚杀又开"(减同向多频次交易+手续费)
        _cc = st.get('_coin_cool',{}).get(pick['coin'],0)
        if _cc > _time.time() and not (FUND_LEG_NO_HUIZHU and pick.get('_fund_leg')):
            _left=(_cc-_time.time())/60.0
            log(f"❄️ 同币冷却: {pick['coin']} 平仓后冷却中(剩{_left:.1f}min) → 不开(治反复开)")
            return 'coin_cooldown'
        _qc=st.get('_qilin_cut',{}).get(pick['coin'],0)
        if QILIN_CUT_COOLDOWN>0 and _qc>_time.time():
            _left=(_qc-_time.time())/60.0
            log(f"❄️ 刹车冷却: {pick['coin']} 麒麟刹车后冷却中(剩{_left:.1f}min) → 不开(防反复)")
            return 'qilin_cooldown'
        # 🌐🆕2026-09-16 事件一·网络自愈「断网冻结开仓」: 三源全不可达→不瞎开(保命)
        if _net_is_down():
            log(f"🌐 网络断线冻结: 行情三源(OKX/Gate/Binance)全不可达 → 拒开仓(保命·不瞎开)")
            return 'blocked_netdown'
        if os.environ.get('ZHONGSHU_PULLBACK_ON','0')=='1' and not (FUND_LEG_BYPASS_TREND and pick.get('_fund_leg')):
            _d=float(os.environ.get('ZHONGSHU_PULLBACK_PCT','0.5'))
            if os.environ.get('ZHONGSHU_PULLBACK_ADAPT_ON','0')=='1':   # 🐍 ED-238 自适应(沙箱 V44/V45)
                _d=_pull_need_adaptive((pick or {}).get('t4l'))
            _w=int(float(os.environ.get('ZHONGSHU_PULLBACK_MIN','60')))
            _lim=pr*(1-_d/100.0) if pick['side']=='long' else pr*(1+_d/100.0)
            _ZH_PEND['cur']={'coin':pick['coin'],'side':pick['side'],'limit':_lim,
                             'deadline':_time.time()+_w*60,'sig':pick,'first':pr,
                             'ts':_time.strftime('%F %T')}
            log(f"🎣 中枢等回抽: {pick['coin']} {pick['side']} 挂限价 {_lim:.4f}(回调{_d}%·窗口{_w}分) 等回抽到位再进(不吃追高单)")
            return 'pending_pullback'
        _ok=_open_paper(st,pick,pr)
        # 🛡🆕2026-09-11 修"开仓失败未回滚"(老板令): 开仓返回False(如Gate 400重复/保证金不足)→
        #   绝不当'open'成功, 不写幽灵仓(账本与Gate脱节) → 返回'open_fail'让上游知实情.
        if _ok is False:
            return 'open_fail'
        # 🔧2026-10-01 修潜伏bug(老板令“继续努力·甲”): _open_paper 遇闸拦(如 blocked_score100)返回**字符串**,
        #   但此处只判 `is False` ⇒ 字符串(非False)被误当成功 ⇒ 返回 'open' (假开仓·open:187却0笔真开之根)。
        #   治: 字符串且非True ⇒ 如实传递拦截结果(不再假报'open')。
        if isinstance(_ok, str) and _ok != 'open':
            return _ok
        return 'open'
    log(f"⚾ 空仓休: 方向不够清(|分|<{PICK_ABS_MIN}) 不硬开")
    return 'idle'

def _zhulong_fire_seal(pos, sig, ppct, pt, gck, tp, last15, flock, sfk, _cert):
    """🔥 烛龙火印 — 烛龙中枢终审许可(2026-09-12 老板令"无火中枢印不得擅自行动")
    铁律: 开明(探)+白虎(哨)报证伪军情 → 烛龙终审 → 盖火印 → 麒麟才准摆尾.
    火印条件(三者齐备):
      ①烛龙大势明朗: regime非chop(烛龙已定大势方向)
      ②开明/白虎证伪军情: certify≥ZHULONG_SEAL_CERT 或 白虎近端证伪(flock/sfk)
      ③军情与持仓矛盾: 持仓方向已不被大势支持
    🔧2026-09-12 保健(老板令"给予保健到最优状态"): chop松绑——regime=chop不放一票否决:
      当chop但极强证伪(certify≥ZHULONG_SEAL_STRONG=0.7 或 开明+白虎双证 flock&&sfk) → 仍发印.
      治"该变不变": chop是常态(噪声带), 若chop永不摆尾 → 麒麟形同虚设, 又回病根.
    返回: True(盖印可摆) / False(无印→只守只兜)
    """
    if not ZHULONG_SEAL_ON:
        return True   # 关印→回旧行为(不走火印闸)
    _reg=sig.get('regime')
    # ② 开明/白虎证伪军情齐备
    _have_intel = (_cert>=ZHULONG_SEAL_CERT) or flock or sfk
    if not _have_intel:
        return False
    # ① 烛龙大势明朗(非chop = 中枢已定大势). chop松绑: 极强证伪/双证时仍发印.
    if _reg not in ('up','dn'):
        # 🆕2026-09-13 00:1x 老板令"死水一潭翻个毛线": 死水闸——chop+窄市没肉(振幅<AMP6_MIN) → 不发印.
        #   死水期 certify 易虚高 → 白摆尾(价格回摆) → 机械亏损+双向手续费. 静观其变即可, 除非手工干预.
        if CHOP_FLIP_OFF:
            _amp = sig.get('amp6')
            try:
                _amp = float(_amp) if _amp is not None else None
            except Exception:
                _amp = None
            if _amp is not None and _amp < QUALITY_AMP6_MIN:
                return False   # 死水(窄市没肉) → 不发火印 → 麒麟只守只兜(不白摆尾)
        _strong = (_cert>=ZHULONG_SEAL_STRONG) or (flock and sfk)
        if not _strong:
            return False
        # chop但军情极强 → 放行(需③矛盾性检查用"非混沌"处理: 既无大势支持则视为背离)
    else:
        # ③ 军情与持仓矛盾(大势已不支持现持仓; 若大势仍顺持仓=态一→不发印)
        _reg_supports=(pos['side']=='long' and _reg=='up') or (pos['side']=='short' and _reg=='dn')
        if _reg_supports:
            return False
    # 🔧2026-09-12 降噪: 不在盖印处刷日志(每轮都盖但未必摆→刷屏). 改由消费处(摆尾/刹车)打印.
    return True

def _teng_she_verdict(pos, sig, st, ppct, nw):
    """🐍🆕ED-20260928-278 腾蛇总裁·**执行层裁决**(准/缓/止): 这笔「反手」(平+反向开新仓)该不该由执行层承接。
       **止** = 连亏达上限 或 执行层冷却中(收紧·不再反手) · **缓** = 反手向与烛龙圣裁相左 或 逆大势门(不逆终审/大势) · **准** = 其余。
       纯只读·不改任何状态。返回 (裁决, 因由)。"""
    try:
        _g = (st or {}).get('guard') or {}
        if float(_g.get('_consec') or 0) >= CONSEC_LOSS_K:
            return ('止', '执行层收紧(连亏≥%d)' % CONSEC_LOSS_K)
        if float(_g.get('_cool') or 0) > 0:
            return ('止', '执行层冷却中')
        _zd = str(ZHU_EDICT.get('verdict') or '')
        if _zd in ('long', 'short') and nw and _zd != nw:
            return ('缓', '反手向%s与烛龙圣裁(%s)相左' % (nw, _zd))
        _td = int((ZHU_EDICT.get('votes') or {}).get('大势门') or 0)
        if _td and nw and _td != (1 if nw == 'long' else -1):
            return ('缓', '反手向%s逆大势门' % nw)
        return ('准', '执行层可承接反手')
    except Exception as _e:
        return ('准', '裁决异常放行:%s' % str(_e)[:40])


def _qilin_receipt_last():
    """📡🆕ED-20260928-277 三兽闭环: 读麒麟最近一次出手回执(只读·只作情报)"""
    try:
        import json as _j, os as _o
        _bdir = _o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir) == '子引擎': _bdir = _o.path.dirname(_bdir)
        _d = _j.load(open(_o.path.join(_bdir, 'data_v2', 'mtsim', '_麒麟回执.json'), encoding='utf-8'))
        return _d.get('last') or None
    except Exception:
        return None


def _qilin_receipt_write(coin, side, act, nw, why, ppct, link=''):
    """📡🐍🆕ED-20260928-277/278 双回流: 麒麟出手(flip/cut) → **双写**回执 ①`_麒麟回执.json`(烛龙) ②`_腾蛇回执.json`(腾蛇)
       均带『链路』(烛龙印/腾蛇裁决)留痕 · **只作情报·不作新锁**(防困死)"""
    try:
        import json as _j, os as _o, time as _t
        _bdir = _o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir) == '子引擎': _bdir = _o.path.dirname(_bdir)
        _bdir = _o.environ.get('QILIN_RECEIPT_DIR') or _bdir   # 🧪自检隔离: 可用 QILIN_RECEIPT_DIR 指向临时目录(生产不受污染)
        _rec = {'ts': _t.strftime('%F %T'), 'coin': coin, 'side': side, 'act': act, 'reverse': nw,
                'why': str(why or '')[:120], 'pnl_pct': round(float(ppct or 0) * 100, 3),
                '链路': link or ('双回流(烛龙印+腾蛇准)' if DUAL_RETURN_LINK_ON else '烛龙印(单链)')}
        for _fn in ('_麒麟回执.json', '_腾蛇回执.json'):
            try:
                _fp = _o.path.join(_bdir, 'data_v2', 'mtsim', _fn)
                _o.makedirs(_o.path.dirname(_fp), exist_ok=True)   # 🧪自检隔离钩子用: 临时目录可自动建
                _d = {'nodes': []}
                try:
                    _d = _j.load(open(_fp, encoding='utf-8'))
                except Exception:
                    pass
                _d.setdefault('nodes', [])
                _d['nodes'].append(dict(_rec))
                _d['nodes'] = _d['nodes'][-50:]
                _d['updated'] = _t.strftime('%F %T')
                _d['last'] = _d['nodes'][-1]
                _j.dump(_d, open(_fp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            except Exception:
                pass
    except Exception:
        pass


# 🔄2026-09-30 老板令「打通麒麟与金蟾链路双回路，打通金蟾与貔貅链路双回路，打通貔貅与麒麟链路双回路。互联互通，形成三才闭环」
#   原状: 三边只有正向 ①金蟾→麒麟(摆尾/知会) ②金蟾→貔貅(让吐/退返) ③貔貅→麒麟(转弱/承接) ⇒ 不是闭环
#   本次补三条**反向回路**(带回授): A 貔貅→金蟾(大肉落袋⇒让吐档上调·退返入肚) · B 麒麟→金蟾(翻错⇒该币暂缓让吐/翻对⇒恢复)
#     · C 麒麟→貔貅(翻错⇒抬地板少给回撤/翻对⇒回正常)。只改**既有旋钮的临期值**(带TTL)·不动交易方向口径
#   总闸: TRIPLE_LOOP_ON(默认0=逐字回旧; =1 生效) · 簿: 内存 _LOOP_MEM + data_v2/mtsim/_三才回路.jsonl
TRIPLE_LOOP_ON  = os.environ.get('TRIPLE_LOOP_ON', '0') != '0'
TRIPLE_LOOP_TTL = int(os.environ.get('TRIPLE_LOOP_TTL', '14400') or 14400)
LOOP_GIVE_STEP  = float(os.environ.get('LOOP_GIVE_STEP', '0.0010'))    # A: 每笔落袋 ⇒ 让吐档 +0.10%
LOOP_GIVE_CAP   = float(os.environ.get('LOOP_GIVE_CAP', '0.0020'))     # A: 让吐档上调上限 +0.20%
LOOP_FLOOR_STEP = float(os.environ.get('LOOP_FLOOR_STEP', '0.0020'))   # C: 翻错 ⇒ 地板 +0.20%
_LOOP_MEM = {}
if TRIPLE_LOOP_ON:
    print('🔄 三才双回路已载入(TRIPLE_LOOP_ON=1): A貔貅→金蟾(退返入肚) B麒麟→金蟾(降档/恢复) C麒麟→貔貅(抬地板) · TTL=%d秒' % TRIPLE_LOOP_TTL, flush=True)


def _loop_set(coin, key, val, ttl=None):
    """写回路簿(币级·带TTL)"""
    if (not TRIPLE_LOOP_ON) or (not coin):
        return
    try:
        _LOOP_MEM.setdefault(str(coin), {})[key] = (val, time.time() + (ttl or TRIPLE_LOOP_TTL))
    except Exception:
        pass


def _loop_get(coin, key, default=0.0):
    """读回路簿(过期即失效·默认0 ⇒ 未开/未记 = 逐字回旧)"""
    if (not TRIPLE_LOOP_ON) or (not coin):
        return default
    try:
        _v = (_LOOP_MEM.get(str(coin)) or {}).get(key)
        if not _v:
            return default
        if time.time() > _v[1]:
            _LOOP_MEM[str(coin)].pop(key, None)
            return default
        return _v[0]
    except Exception:
        return default


def _loop_log(edge, coin, detail):
    """回路留痕(JSONL·可查可核)"""
    try:
        import json as _j, os as _o, time as _t
        _b = _o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_b) == '子引擎':
            _b = _o.path.dirname(_b)
        _fp = _o.path.join(_o.environ.get('QILIN_RECEIPT_DIR') or _b, 'data_v2', 'mtsim', '_三才回路.jsonl')
        _o.makedirs(_o.path.dirname(_fp), exist_ok=True)
        open(_fp, 'a', encoding='utf-8').write(_j.dumps({'ts': _t.strftime('%F %T'), '回路': edge, 'coin': coin,
            'detail': detail, '簿': {_k: _v[0] for _k, _v in (_LOOP_MEM.get(str(coin)) or {}).items()}}, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _flip_outcome_fb(coin, side, pnl_usd, pnl_pct, why, n_flip=1):
    """📡🆕2026-09-30 老板令《四环闭环·双回流补全》(火印 ED-20260930-338): **平仓回填半链**
    摆尾孪生仓平仓 → 把**结果**回填: ①`_摆尾回填.json`(逐条·封顶200) ②`_麒麟回执.json`/`_腾蛇回执.json`
    末条(同币 flip)挂 `outcome`。**只作情报·不作新锁**(供白泽复盘/烛龙学习)。异常静默跳过。"""
    try:
        import json as _j, os as _o, time as _t
        _bdir = _o.path.dirname(_o.path.abspath(__file__))
        if _o.path.basename(_bdir) == '子引擎': _bdir = _o.path.dirname(_bdir)
        _bdir = _o.environ.get('QILIN_RECEIPT_DIR') or _bdir
        _rec = {'ts': _t.strftime('%F %T'), 'coin': coin, 'side': side,
                'pnl$': round(float(pnl_usd or 0), 2), 'pnl_pct': round(float(pnl_pct or 0) * 100, 3),
                'why': str(why or '')[:120], 'fandou': int(n_flip or 1),
                '判': ('翻对' if float(pnl_usd or 0) > 0 else '翻错')}
        _fp = _o.path.join(_bdir, 'data_v2', 'mtsim', '_摆尾回填.json')
        _o.makedirs(_o.path.dirname(_fp), exist_ok=True)
        try:
            _d = _j.load(open(_fp, encoding='utf-8'))
        except Exception:
            _d = {'nodes': []}
        _d.setdefault('nodes', []).append(dict(_rec))
        _d['nodes'] = _d['nodes'][-200:]
        _d['updated'] = _t.strftime('%F %T'); _d['last'] = _d['nodes'][-1]
        _j.dump(_d, open(_fp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        # 🔄三才双回路(2026-09-30 老板令): 平仓回填同时**回授三兽**
        if TRIPLE_LOOP_ON:
            _ju = _rec.get('判')
            if _ju == '翻对':
                if _LOOP_MEM.get(str(coin)):
                    _LOOP_MEM[str(coin)].pop('金蟾暂缓', None); _LOOP_MEM[str(coin)].pop('貔貅地板+', None)
                _loop_log('B 麒麟→金蟾·恢复', coin, '摆尾翻对 ⇒ 该币恢复让吐')
                _loop_log('C 麒麟→貔貅·回正常', coin, '摆尾翻对 ⇒ 地板回正常')
            else:
                _loop_set(coin, '金蟾暂缓', 1)
                _loop_set(coin, '貔貅地板+', LOOP_FLOOR_STEP)
                _loop_log('B 麒麟→金蟾·降档', coin, '摆尾翻错 ⇒ 该币暂缓让吐(不再交棒)')
                _loop_log('C 麒麟→貔貅·抬地板', coin, '摆尾翻错 ⇒ 地板 +%.2f%%(少给回撤)' % (LOOP_FLOOR_STEP * 100))
        if TRIPLE_LOOP_ON and float(pnl_usd or 0) > 0 and ('貔貅' in str(why) or '金蟾' in str(why)):
            _g = _loop_get(coin, '让吐+', 0.0)
            if _g < LOOP_GIVE_CAP:
                _loop_set(coin, '让吐+', min(LOOP_GIVE_CAP, _g + LOOP_GIVE_STEP))
                _loop_log('A 貔貅→金蟾·退返入肚', coin, '落袋 ⇒ 让吐档上调至 %.2f%%(更早落袋)' % ((_g + LOOP_GIVE_STEP) * 100))
        for _fn in ('_麒麟回执.json', '_腾蛇回执.json'):
            try:
                _rp = _o.path.join(_bdir, 'data_v2', 'mtsim', _fn)
                _rd = _j.load(open(_rp, encoding='utf-8'))
                for _n in reversed(_rd.get('nodes') or []):
                    if _n.get('coin') == coin and _n.get('act') == 'flip':
                        _n['outcome'] = dict(_rec)
                        break
                _j.dump(_rd, open(_rp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            except Exception:
                pass
    except Exception:
        pass


def _qilin_baiwei(*a, **kw):
    """🦄 麒麟摆尾(包壳·ED-20260928-277 三兽闭环): 决策交内核 + **出手即写回执**(供开明/烛龙知情)"""
    _LAST_TS[0], _LAST_TS[1] = '', ''   # 🔧ED-20260929-316 每轮重置·防回执照抄旧裁决(伪证)
    _r = _qilin_baiwei_core(*a, **kw)
    if _r and (THREE_BEAST_LINK_ON or DUAL_RETURN_LINK_ON):
        try:
            _p = a[0] if a else (kw.get('pos') or {})
            _pc = a[3] if len(a) > 3 else (kw.get('ppct') or 0)
            _qilin_receipt_write(_p.get('coin'), _p.get('side'), _r[0], _r[1], _r[2], _pc,
                                 link=('双回流(烛龙印+腾蛇%s)' % (_LAST_TS[0] or '?') if DUAL_RETURN_LINK_ON else '烛龙印(单链)'))
        except Exception:
            pass
    return _r


def _qilin_baiwei_core(pos, sig, st, ppct, pt, gck, tp, t4, last15, flock, sfk, deep_long, deep_short):
    """🦄 麒麟摆尾 — 麒麟兽天生神通·统一摆尾决策(2026-09-12 老板令: 取消"麒麟摆尾"名, 四门合一)
    收权: 镇守/守护/兜底 (守之职·唯一执刃者). 一刀判"该摆不摆".
    返回: ('flip',反手向,原因) 或 ('cut',原因) 或 None(按兵不动).
    开关: QILIN_TAIL_ON=0 整关(回旧: 无摆尾).
    融合原四门(按优先级): ①证伪确诊 ②智能及早 ③区间顶底 ④保卫科高感知/证伪
    """
    if not QILIN_TAIL_ON:
        return None
    _reg=sig.get('regime')
    _nw='short' if pos['side']=='long' else 'long'
    _blk=(_nw=='long' and _reg=='dn') or (_nw=='short' and _reg=='up')   # 反手向逆高层大势→不摆
    _reg_still_ok=(pos['side']=='long' and _reg=='up') or (pos['side']=='short' and _reg=='dn')
    _deep=(pos['side']=='long' and last15<=-0.5) or (pos['side']=='short' and last15>=0.5)
    # 🔧2026-09-12 保健(老板令): 深水闸精修——不是所有深水急冲都不摆.
    #   逆大势深水急冲(行情突发·易插针) → 不摆(护本不赌);
    #   但若急冲方向与"高层大势"一致(真反转确认) → 该摆(拿准方向不放过).
    if _deep:
        _rip_dir = 'long' if (pos['side']=='short' and last15>=0.5) else 'short'   # 急冲方向(=反手向)
        _rip_align = (_rip_dir=='long' and _reg=='up') or (_rip_dir=='short' and _reg=='dn')
        if _rip_align:
            _deep = False   # 急冲与大势同向=真反转 → 解锁可摆(不护本放弃)
            log(f"🦄🔥 麒麟摆尾·深水解锁: {pos['coin']} 急冲{last15:+.2f}%与大势{_reg}同向(真反转) → 解锁不护本")
    _already=pos.get('_fandou',0)>0    # 已摆过→不再摆二
    _once_ok=(not QILIN_FLIP_ONCE_ON) or (not _already)   # 🧩环四·只翻一次硬闸(⓪门同守)
    _cert=sig.get('certify',0) if CERTIFY_SENSE_ON else 0
    if FEEDBACK_ON:
        _nerve=_nerve_read(pos['coin'])
        if _nerve>_cert: _cert=_nerve
    # 🦄🆕2026-09-14 22:29 老板令"中段震荡豁免": regime=chop(震荡)+非极强证伪 → 麒麟按兵不动(态一).
    # 🌟🆕2026-09-15 09:11 加敏(药④): 豁免用"开明监督融合强度" adms — 开明(flock)+白虎(sfk)+触觉(_nerve)任一强→豁免失效(更灵敏).
    # 🔧2026-09-15 09:27 体检修复: 单flock/sfk原只抦0.5<7门槛=监督未生效 → 改flock/sfk为"确证级"(各搟0.7·命中即豁免失效).
    _adms = _cert
    if QILIN_SENS_ADM:
        _sup = (0.7 if flock else 0.0)
        _sup += (0.7 if sfk else 0.0)
        _sup += 0.3*(_nerve if 'FEEDBACK_ON' in dir() and FEEDBACK_ON else 0.0)
        _adms = max(_cert, _sup, _cert)
    if QILIN_CHOP_EXEMPT and _reg=='chop' and _adms<CHOP_EXEMPT_CERT and not (flock and sfk):
        return None   # 震荡+非极强证伪 → 不干预(随多空自动上下)
    # 🚨🆕2026-09-25 紧急兜底固定闸(无条件·自四户内核回填): 深套≥|紧急闸| → 砍仓护本(不依赖火印/certify)
    if QILIN_EMERGENCY_STOP < 0 and ppct <= QILIN_EMERGENCY_STOP:
        log(f"🚨 紧急兜底固定闸: {pos['coin']} {ppct*100:+.2f}%≤{QILIN_EMERGENCY_STOP*100:.2f}% → 砍仓护本")
        st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
        return ('cut',None,f'麒麟紧急兜底固定闸({ppct*100:+.2f}%≤{QILIN_EMERGENCY_STOP*100:.2f}%)(护本)')
    # 🔥 烛龙火印校验(老板铁律: 无火印不得擅自摆尾 → 只守只兜)
    _fire=_zhulong_fire_seal(pos, sig, ppct, pt, gck, tp, last15, flock, sfk, _cert)
    _seal_tag=('🔥印' if _fire else '🚫无印')
    # 🌟🆕2026-09-15 加敏(药②): 自适应收紧刹车线 — chop区(震荡)且certify≥0.5 → 提前到QILIN_TIGHT_LOSS(早收少亏)
    _cut_line = -0.004
    if QILIN_TIGHT_ON and _reg=='chop' and _cert>=0.5:
        _cut_line = max(_cut_line, QILIN_TIGHT_LOSS)   # chop+证伪→收紧(-0.35%> -0.4%·更浅=早收)
    if not _fire:
        # 无火印: 麒麟不得自主摆尾. 但"已摆过/半山腰+伪信号"的刹车(认小亏)仍可(那是守本非摆尾).
        _already0=pos.get('_fandou',0)>0
        _deep0=(pos['side']=='long' and last15<=-0.5) or (pos['side']=='short' and last15>=0.5)
        # 🦄🆕2026-09-15 A+B: 撤权后 → 麒麟不再"有肉时半山腰刹车"(交金蟾貔貅按阶梯管);
        #   只在"深套≥QILIN_LAST_DEFENSE(1.2%)"才做最后兜底(终极保险). 可 QILIN_RETREAT_ON=0 回旧.
        if QILIN_RETREAT_ON:
            _qln,_qwhy,_qhold=_qilin_line(pos, ppct, last15, _cert, _reg)
            if (_cert>=0.5 or QILIN_DEFENSE_UNCOND) and ppct<=_qln and not _deep0 and not _qhold:
                log(f"🛡 麒麟最后兜底(深套): {pos['coin']} {ppct*100:+.2f}%≤{QILIN_LAST_DEFENSE*100:.2f}% → 认赔护本")
                st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
                return ('cut',None,f'麒麟最后兜底·深套({ppct*100:+.2f}%≤{QILIN_LAST_DEFENSE*100:.2f}%)(护本)')
            return None   # 有肉/浅亏 → 交金蟾貔貅管(麒麟不插手)
        # 🦄🆕2026-09-16 老板令"半山腰只许反手或扛住, 绝不许止损": 半山腰刹车(割肉)已剥夺.
        #   半山腰(-0.6%~-1.2%) → 扛住不动(等真证伪/等回本); 深套兜底仍保留(守底仓).
        #   可 QILIN_HALFMOUNT_CUT=1 回旧(恢复半山腰刹车).
        if os.environ.get('QILIN_HALFMOUNT_CUT','0') == '1':
            if _cert>=0.5 and ppct<=_cut_line and (_already0 or ppct<FANDOU_MAX_LOSS) and not _deep0:
                _rsn='已摆过(不再摆二)' if _already0 else f'已半山腰({ppct*100:+.2f}%<{_cut_line*100:.2f}%)'
                log(f"🦄🛑 麒麟摆尾刹车(回旧·半山腰): {pos['coin']} {_rsn}")
                st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
                return ('cut',None,f'麒麟摆尾刹车·{_rsn}(护本)')
        return None   # 无火印 → 只守只兜(不动)·半山腰扛住不割
    # 🐍🆕ED-20260928-278 双回流链路·**腾蛇总裁**: 执行层裁决(准/缓/止) —— 与**烛龙出印**双齐方可反手摆尾
    # 🔧🆕ED-20260929-316 补全(老板令「按计划优化补全」): 原序『⓪获利转向 return』在本裁决**之前** ⇒
    #   该门**绕过双回流闸**(半闸之病·XWU 连环翻手皆出此门)。今将 ⓪ 移至本裁决**之后**并加 `and _ts_ok` ⇒ 五门一视同仁。
    _ts_v, _ts_why = ('准', '未接链路')
    if DUAL_RETURN_LINK_ON:
        _ts_v, _ts_why = _teng_she_verdict(pos, sig, st, ppct, _nw)
        _LAST_TS[0], _LAST_TS[1] = _ts_v, _ts_why
    _ts_ok = (not DUAL_RETURN_LINK_ON) or (_ts_v == '准')
    if DUAL_RETURN_LINK_ON and _fire and not _ts_ok:
        log('🐍 腾蛇总裁·不接反手(%s·%s) → 麒麟不摆尾(只守只兜)' % (_ts_v, _ts_why))
    # ── ⓪ 获利转向摆尾(曾持大肉转弱+MACD反向): 锁肉翻向 ──
    _pw=0.0
    try:
        _m2,_pw=_trend_strength(pos,sig)
    except Exception:
        pass
    if pt>=FLIP_TRAIL_ON and _pw<=FLIP_PACO and not _deep and _ts_ok and not _once_ok:
        log('🧩 环四·只翻一次硬闸: %s 已翻过(%d次) → ⓪获利转向门不再摆尾(只守只兜)' % (pos['coin'], pos.get('_fandou',0)))
    if pt>=FLIP_TRAIL_ON and _pw<=FLIP_PACO and not _deep and _ts_ok and _once_ok:
        _f_long=(pos['side']=='long' and gck=='death' and tp=='DOWN')
        _f_short=(pos['side']=='short' and gck=='golden' and tp=='UP')
        if _f_long or _f_short:
            log(f"🦄 麒麟摆尾(获利转向): {pos['coin']} {pos['side']} 峰{pt*100:.2f}%转弱(pw{_pw:+.2f}) → 拿肉换{_nw}")
            return ('flip',_nw,f'{_seal_tag}麒麟摆尾·获利转向({gck}+{tp}/峰{pt*100:.2f}%锁肉换向)')
    # 🐉🛡🆕ED-20260928-277 三兽拟合②·防误伤护仓: 烛龙已判**顺势**(圣裁方向=持仓方向) 且未深套 ⇒ 麒麟**不作早断/摆尾**(交金蟾貔貅正常离场)
    _keep_trend = bool(THREE_BEAST_LINK_ON and str(ZHU_EDICT.get('verdict') or '') == str(pos.get('side') or '')
                       and ppct > QILIN_LAST_DEFENSE)
    if _keep_trend:
        log("🛡🐉 麒麟护仓(顺势不摆尾): %s 烛龙判顺势(%s) 浮亏%+.2f%% 未深套 → 不早断/不摆尾(交金蟾貔貅)"
            % (pos['coin'], pos['side'], ppct*100))
    # ── ① 证伪确诊反向(逆大势+双确认): 最笃, 已承压→摆尾 (深水急冲例外:守本不赌) ──
    if QILIN_CERTAIN_FLIP_ON and not _blk and not _deep and not _keep_trend and _ts_ok and ((pos['side']=='long' and _reg=='dn' and tp=='DOWN' and last15<=-0.1 and ppct<=-0.002) or
                     (pos['side']=='short' and _reg=='up' and tp=='UP' and last15>=0.1 and ppct<=-0.002)):
        log(f"🦄 麒麟摆尾(证伪确诊): {pos['coin']} {pos['side']} 逆高层大势regime={_reg}+近端双确认 → 反手{_nw}(扭亏)")
        return ('flip',_nw,f'{_seal_tag}麒麟摆尾·证伪确诊(逆regime{_reg}/{gck}/{tp}/{last15:+.2f}·最早区间扭亏)')
    # ── ② 智能及早摆尾(certify≥0.5浅亏+未摆过+大势不支): 半山腰前就摆 ──
    # 💊🆕2026-09-12 方A1: 灵敏度增强(浅亏线-0.4%→-0.25%, certify闸0.5→0.45), 让及早真早(半山腰前).
    if QILIN_EARLY_FLIP_ON and _cert>=QILIN_SENS_CERT and QILIN_SENS_LOSS<=ppct<=-0.0015 and not _already and not _reg_still_ok and not _blk and not _deep and not _keep_trend and _ts_ok:
        log(f"🦄 麒麟摆尾(及早·灵敏): {pos['coin']} {pos['side']} 浅亏{ppct*100:+.2f}%+伪信号certify{_cert} → 半山腰前摆尾{_nw}(扭亏)")
        return ('flip',_nw,f'{_seal_tag}麒麟摆尾·及早(浅亏{ppct*100:+.2f}%/certify{_cert}·半山腰前扭亏)')
    # ── ③ 区间顶底摆尾(大幅区间+顶底区+动量衰竭): 上下吃利 ──
    if RANGE_FLIP_ON and not _already and not _keep_trend and _ts_ok:
        try:
            _rc=_candles(pos['coin'],'15m',24)
            if _rc and len(_rc)>=20:
                _rhi=max(_rc); _rlo=min(_rc); _rcur=_rc[-1]
                _ramp=(_rhi-_rlo)/_rlo*100 if _rlo else 0
                _rpos=(_rcur-_rlo)/(_rhi-_rlo)*100 if _rhi>_rlo else 50
                _rmom=(_rc[-1]-_rc[-4])/_rc[-4]*100 if _rc[-4] else 0
                _rexh=abs(_rmom)<RANGE_EXHAUST
                if _ramp>=RANGE_AMP and pos['side']=='long' and _rpos>=RANGE_POS_HI and (_rexh or pt>=BIG_MEAT_PCT*0.5):
                    log(f"🦄🔝 麒麟摆尾(区间顶): {pos['coin']} long 达顶{_rpos:.0f}%(振幅{_ramp:.1f}%)+动量{_rmom:+.2f}%衰竭 → 摆尾空(吃回撤利)")
                    return ('flip','short',f'{_seal_tag}麒麟摆尾·区间顶(顶{_rpos:.0f}%/振幅{_ramp:.1f}%/衰竭{_rmom:+.2f}%)')
                if _ramp>=RANGE_AMP and pos['side']=='short' and _rpos<=RANGE_POS_LO and (_rexh or pt>=BIG_MEAT_PCT*0.5):
                    log(f"🦄🔻 麒麟摆尾(区间底): {pos['coin']} short 达底{_rpos:.0f}%(振幅{_ramp:.1f}%)+动量{_rmom:+.2f}%衰竭 → 摆尾多(吃反弹利)")
                    return ('flip','long',f'{_seal_tag}麒麟摆尾·区间底(底{_rpos:.0f}%/振幅{_ramp:.1f}%/衰竭{_rmom:+.2f}%)')
        except Exception:
            pass
    # ── ④ 保卫科摆尾(近端证伪 flock/sfk + 承压): 只摆非深水急冲(护本不赌) ──
    if QILIN_CERTAIN_FLIP_ON and (flock or sfk) and not _already and not _deep and not _blk and not _keep_trend and _ts_ok:
        if ppct<=-0.004 or _cert>=0.5:
            log(f"🦄 麒麟摆尾(近端证伪): {pos['coin']} {pos['side']} {gck}+{tp}承压{ppct*100:+.2f}% → 摆尾{_nw}(扭亏非止损)")
            return ('flip',_nw,f'{_seal_tag}麒麟摆尾·近端证伪({gck}/{tp}·反手{_nw}扭亏)')
    # ── 刹车: 已摆过/已半山腰 + 确有伪信号 → 认小亏走(不自相残杀) ──
    # 🦄🆕2026-09-15 A+B: 有火印也不"有肉刹车"(交金蟾貔貅); 仅深套≥QILIN_LAST_DEFENSE 兜底.
    if QILIN_RETREAT_ON:
        _qln,_qwhy,_qhold=_qilin_line(pos, ppct, last15, _cert, _reg)
        if (_cert>=0.5 or QILIN_DEFENSE_UNCOND) and ppct<=_qln and not _deep and not _qhold:
            log(f"🛡 麒麟最后兜底(深套·持火印): {pos['coin']} {ppct*100:+.2f}%≤{QILIN_LAST_DEFENSE*100:.2f}% → 认赔护本")
            return ('cut',None,f'麒麟最后兜底·深套({ppct*100:+.2f}%)(护本)')
        _cut_skip=True
    else:
        _cut_skip=False
    # 🦄🆕2026-09-16 老板令: 半山腰刹车已剥夺(只许反手/扛住); 深套兜底在上方保留. 可 QILIN_HALFMOUNT_CUT=1 回旧.
    if os.environ.get('QILIN_HALFMOUNT_CUT','0') == '1':
        if (not _cut_skip) and _cert>=0.5 and ppct<=_cut_line and (_already or ppct<FANDOU_MAX_LOSS) and not _deep:
            _rsn='已摆过(不再摆二)' if _already else f'已半山腰({ppct*100:+.2f}%<{_cut_line*100:.2f}%)'
            log(f"🦄🛑 麒麟摆尾刹车(回旧): {pos['coin']} {_rsn}")
            st.setdefault('_qilin_cut',{})[pos['coin']]=_time.time()+QILIN_CUT_COOLDOWN*CYCLE_SLEEP
            return ('cut',None,f'麒麟摆尾刹车·{_rsn}(护本)')
    return None

def _flip(st,pos,pr,ppct,pnl_usd,why,sig,nw):
    # 🛡🆕2026-09-12 06:5x 麒麟摆尾真实化钩子(老板"睡一觉漏光光"彻查): 若实盘注入 _FLIP_HOOK → 交给它真反手(真开Gate单);
    #   否则纸面默认(仅改账本). 治"麒麟摆尾在实盘形同虚设(账本反了Gate没动→判外部手平)".
    if _FLIP_HOOK is not None:
        return _FLIP_HOOK(st,pos,pr,ppct,pnl_usd,why,sig,nw)
    st['cooldown']=REOPEN_COOLDOWN
    _close_here(st,pos,pr,ppct,pnl_usd,why)
    # 立即反手开新方向(纸面)
    nsig=dict(sig); nsig['side']=nw
    st['pos']={'coin':pos['coin'],'side':nw,'entry':pr,'notional':pos['notional'],
               'peak':0.0,'peak_pct':0.0,'floor_pct':0.0,'size_ct':pos.get('size_ct',0),
               'big_meat':False,'tier':0,'open_ts':_time.time(),
               'mae':0.0,'mae_pct':0.0,
               'exit_set':{'sl':round(SL,4),'lock':round(LOCK_START_PCT,4),'hard':round(QILIN_LAST_DEFENSE,6),'emerg':round(QILIN_EMERGENCY_STOP,6),'min_hold':MIN_HOLD_SEC},
               '_fandou':pos.get('_fandou',0)+1,
'_fund_leg':bool(pos.get('_fund_leg')),   # 🪙ED-20260927-246 摆尾继承腿标记   # 🤸🆕麒麟摆尾计数+1(翻过来的孪生仓: 已翻过1次→不再翻二)
               '_ctx':{'score':sig.get('score'),'regime':sig.get('regime'),'t4':sig.get('t4'),
                       't4l':sig.get('t4l'),'gck':sig.get('gck'),'tp':sig.get('tp'),
                       'last15':sig.get('last15'),'regime_at_open':sig.get('regime'),'flipped_from':pos['side']}}
    log(f"☯️ 一键换向: {pos['coin']} {pos['side']}→{nw} 拿肉{pnl_usd:+.2f}$后反手(麒麟摆尾第{pos.get('_fandou',0)+1}次·已锁定不再翻)")
    return 'flip'

def _finish(st,pos,pr,ppct,pnl_usd,why,sig):
    st['cooldown']=REOPEN_COOLDOWN
    # 🩸🆕2026-09-16 老板令"同币连续开仓·亏损再开又开止住": 任何平仓都设"同币冷却"
    try:
        _cc = int(os.environ.get('COIN_REOPEN_COOLDOWN','60'))
        if _cc > 0:
            st.setdefault('_coin_cool',{})[pos['coin']] = _time.time() + _cc*CYCLE_SLEEP
    except Exception:
        pass
    # 🦌🐚🆕ED-20260927-246 白鹿(池级连亏歇) + 白泽(逐币连亏升温) —— **默认关**(0=旧行为逐字不变)
    try:
        _win = pnl_usd > 0
        _cl = st.setdefault('_coin_lose', {})
        _leg_imm = FUND_LEG_NO_HUIZHU and bool(pos.get('_fund_leg'))
        _cl[pos['coin']] = 0 if (_win or _leg_imm) else int(_cl.get(pos['coin'], 0) or 0) + 1
        if HUIZHU_STREAK > 0 and _cl[pos['coin']] >= HUIZHU_STREAK:
            st.setdefault('_coin_cool', {})[pos['coin']] = max(
                float(st.get('_coin_cool', {}).get(pos['coin'], 0) or 0),
                _time.time() + HUIZHU_HOLD_SEC)
            st['_coin_lose'][pos['coin']] = 0
            log('🐚 白泽·回注升温: %s 连亏%d笔 → 该币升温(歇%d分)' % (pos['coin'], HUIZHU_STREAK, HUIZHU_HOLD_SEC // 60))
        _ls = 0 if (_win or _leg_imm) else int(st.get('_lose_streak', 0) or 0) + 1
        st['_lose_streak'] = _ls
        if POOL_COOL_STREAK > 0 and _ls >= POOL_COOL_STREAK:
            st['cooldown'] = max(int(st.get('cooldown', 0) or 0),
                                 int(round(POOL_COOL_BARS * 900.0 / max(1, CYCLE_SLEEP))))
            st['_lose_streak'] = 0
            log('🦌 白鹿·池冷却: 池内连亏%d笔 → 全池歇%d根15m' % (POOL_COOL_STREAK, POOL_COOL_BARS))
    except Exception:
        pass
    _close_here(st,pos,pr,ppct,pnl_usd,why)
    return 'close'

def main():
    log("☯️ 多币母体·进化2 [SIM模拟修行·绝不下真实单] | 三币择强×金蟾貔貅阶梯 | PAPER")
    st=load()
    log(f"  已实现{st.get('realized',0):+.2f}$ | 持仓: {st.get('pos')}")
    while True:
        try:
            cycle_once(st); save(st)
        except Exception as e:
            log(f"⚠️ 轮异常: {str(e)[:100]}")
        # 🛡🆕2026-09-11 20:1x 提速(漏点4·救命速度): 持仓时用"快巡"短隔(持仓管理只需1币),
        #   方向不对→快速麒麟摆尾=扭亏重中之重; 空仓时用常规隔(需扫全池择强·慢).
        #   FAST_HOLD_SLEEP 可由 env 调; =0 则关提速(回常规).
        _fast = int(os.environ.get('FAST_HOLD_SLEEP','8'))
        time.sleep(_fast if (st.get('pos') and _fast>0) else CYCLE_SLEEP)

if __name__=='__main__':
    main()
