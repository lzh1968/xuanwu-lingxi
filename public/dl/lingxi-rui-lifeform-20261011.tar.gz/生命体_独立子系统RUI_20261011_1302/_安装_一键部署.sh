#!/data/data/com.termux/files/usr/bin/bash
# 🐢 玄武灵犀 · 生命体独立子系统(RUI/锐 完善版) —— 一键部署 (在**新机**上运行)
# 用法:  bash _安装_一键部署.sh [--dir 目标目录] [--名 rui] [--起] [--带自巡]
set -u
SRC="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEST="$HOME/.openclaw/workspace/skills/sniper-engine"
NODE="rui"; DO_START=0; DO_GUARD=0
GENE="B2_MIN_RATIO=0.40 B2_STRONG_RATIO=0.70 B2_WEAK_FLOOR=0.50 B2_HARD_CAP=0.70 B2_HARD_CAP_ON=1 QILIN_DEFENSE_UNCOND=1 CHOP_OPEN_MIN_SCORE=2.5 SEG_MIN_SCORE=3.0 QILIN_LAST_DEFENSE=-0.009 QILIN_ADAPT_ON=0 QILIN_EMERGENCY_STOP=-0.02 QILIN_TURN_HOLD_ON=1 GLOBAL_CIRCUIT_ON=1 SIGN_TREND_FALLBACK_ON=1 SIGN_T96_FB_MIN=1.0 SIGN_T4_FB_MIN=0.30 SIGN_FB_POS_HI=85 SIGN_FB_POS_LO=15 SIGN_ADAPT_TRADE_ON=0 SIGN_ADAPT_T4_MIN=0.30 SIGN_ADAPT_T96_MIN=1.0 SIGN_ADAPT_POS_HI=92 SIGN_ADAPT_POS_LO=8 SIGN_ADAPT_TOPBAN=96 SIGN_TOP_BAN_POS=70 SIGN_ER_MIN=0.07 SIGN_T4_MIN2=1.30 SIGN_T96_SAME=1 SIGN_ER_GATE_HARD_ON=1 SIGN_NEAR_CONFIRM_ON=1 SIGN_NEAR_MIN=0.30 YIJING_CF_ER_ON=1 SIGN_TREND_ALIGN_ON=1 SIGN_PHASE_ADAPT_ON=1 SIGN_PHASE_SPLIT_ON=1 SIGN_REV_POS_HI=75 SIGN_REV_POS_LO=25 THREE_BEAST_LINK_ON=1 DUAL_RETURN_LINK_ON=1 ZHU_TREND_FOLLOW_ON=1 COIN_REOPEN_COOLDOWN=900 ENTRY_SCORE100_MIN=70 SIGN_REGIME_GATE_ON=1 SIGN_TOP_BAN_ON=1 JUE_SPECTRUM_ON=0 JUE_AWARE_ON=0 FUND_LEG_ON=1 SIGN_POS_BAND_ON=1 SIGN_POS_BAND_LO=35 SIGN_POS_BAND_HI=65 SIGN_SAME_DIR_MIN=0.75 SIGN_RANK_PULL=1 SIGN_VOL_CAP=0.70 SIGN_TREND_POS_RESO_ON=1 SIGN_RESO_POS_LO=35 SIGN_RESO_POS_HI=65 SIGN_RESO_BOOST=1.0 ZHU_TREND_FOLLOW_ON=1 PICK_ABS_MIN=1.0 SIGN_WAIT_ONE=1 TOPBOT_GATE_ON=1 BEASTBUS_ON=1 QILIN_FLIP_ONCE_ON=1 SIGN_MISALIGN_SIZING_ON=1 SIGN_MISALIGN_MAX=0.50 TRIPLE_LOOP_ON=1 TRIPLE_LOOP_TTL=14400 LOOP_GIVE_STEP=0.0010 LOOP_GIVE_CAP=0.0020 LOOP_FLOOR_STEP=0.0020 DUAL_CHAIN_ON=1 FLEX_ON=1 HALFM_ADAPT_ON=1 HI_STEP_LOCK=1 HUNDUN_FREEZE_ON=1 JCH_ADAPT_ON=1 JIU_GONG_ON=1 JUE_DRIFT_ON=1 JUE_THROTTLE_ON=1 QILIN_RETREAT_ON=1 QILIN_SENS_ON=1 SANT_CHAOS_ON=1 SK_GENE_ON=1 SL_ADAPT_ON=1 TOPBOT_ADAPT_ON=1 ZHU_EDICT_ENFORCE=1 ZHU_EDICT_ON=1 zhizhi_check_enable=1 YIJING_YINYANG_SOVEREIGN=1 YIJING_GATE_ON=1 YIJING_TIAN_EFF=0.10 YIJING_REN_SCORE=1.5 SANT_GATE_ON=1 SANT_YIN_ON=0 SANT_YIN_SCORE=2.5 WUXING_VETO_ON=1 WUXING_VETO_WIN=0.45 WUXING_VETO_N=24 SIM_POOL=500 SIGN_TREND_ALIGN_ON=0 ZX_ON=1 ZX_BAN_COINS=NEAR ZX_BAN_HRS=5,6,9,13,14,22 ZX_WANGWANG_PASS=1 ZX_LONG_MIN=0 ZX_PHASE_ON=1 GLOBAL_CIRCUIT_ON=0 PICK_ABS_MIN=0.2 RANGE_AMP=1.0 QUALITY_AMP6_MIN=0.3 CHOP_OPEN_MIN_SCORE=1.0 SEG_MIN_SCORE=1.2 ENTRY_SCORE100_MIN=45 CERTIFY_HOT=0.9 SIGN_T4_MIN2=0.5 VETO_SOFT_ON=1 VETO_SOFT_SCORE=1.0 TONG_SHENG_ON=1 TONG_SHENG_MIN=0.4 WUXING_VETO_ON=0 EV_GATE_ON=1 EV_GATE_MIN=0.0 B2_HARD_CAP=0.68 B2_MIN_RATIO=0.28 B2_STRONG_RATIO=0.68 B2_WEAK_FLOOR=0.35 BIG_MEAT_PCT=0.015 CHOP_OPEN_MIN_SCORE=2.0 DAO_DECIDE_ONLY=1 FIRST_MOVE_ZL_CHECK=1 FIRST_MOVE_ZL_DW=0.3 FIRST_MOVE_ZL_MIN=0.6 GIVE_BACK_FRAC=0.7 GIVE_CAP=0.0200 GIVE_LO=0.0040 PAPER_FEE_RATE=0.0005 PICK_ABS_MIN=2.0 QILIN_LAST_DEFENSE=-0.007 QILIN_TAIL_GRIND_ON=0 SEG_MIN_SCORE=2.6 SHORT_MIN_SCORE=2.0 SHORT_POS4_LO=20 SHORT_REGIME_GATE_ON=1 SHORT_T4_MAX=0.0 TA_SAND_UNIT=0.20 TA_TIER_SIZE=6 TRAIL_FLOOR_PCT=0.012 ZHULONG_GATE_ON=1 ZL_DISCRETION_ON=1 ZL_STRONG_MIN=0.55 WANG_HAND_EDICT_ON=1 PRECISE_PASS_ON=1 PHASE_REGIME_ON=1 PHASE_FRESH_ON=1 EDICT_FIX_ON=1 EDICT_TTL_MIN=120 DIR_HARDEN_ON=1 DIR_LOW_TIER=ADA,AVAX,LTC,FIL,ARB,XRP,NEAR DIR_LOW_MIN=2.5 DIR_LONG_HR_MIN=0.50 ZHU_EDICT_STRICT=1 WANG_HAND_EDICT_ON=1 WANG_EDICT_FIRST=1 ZHU_SOVEREIGN_PICK=1 ZHU_SOV_PHASE_GATE=1 TIANYAN_GATE_ON=1 TIANYAN_RED_LOCK=0 TIANYAN_YELLOW_HALF=1 ZHU_BRAIN_GATE_ON=1 ZHU_BRAIN_HALF=1 SUPREME_ON=1 BWL_GATE_ON=1"
while [ $# -gt 0 ]; do
  case "$1" in
    --dir) DEST="$2"; shift 2;;
    --名|--node) NODE="$2"; shift 2;;
    --起|--带自巡) DO_START=1; shift;;
    *) shift;;
  esac
done
echo "🐢 生命体·独立子系统(锐 · 完善版) 一键部署"
echo "  源: $SRC"
echo "  目标: $DEST"
echo "──────────────────────────────"
echo "▸ ① 环境自检"
command -v python3 >/dev/null 2>&1 || { echo "  ❌ 未找到 python3 —— 请先装好 Termux 环境(同款 NextFlowOSAi)"; exit 1; }
python3 -c "import sys,json,urllib.request,hashlib;print('  ✅ python3', sys.version.split()[0], '基础库齐全')"
echo "▸ ② 清单校验"
if [ -f "$SRC/清单.md5" ]; then (cd "$SRC" && md5sum -c 清单.md5 --quiet) && echo "  ✅ 清单校验通过" || echo "  ⚠️ 清单有出入(继续, 请人工看一眼)"; fi
echo "▸ ③ 就位文件"
mkdir -p "$DEST/子引擎/data_v2/mtsim" "$DEST/data_v2/mtsim/sub" "$DEST/data_v2/logs" "$DEST/烛龙大脑"
for f in _子引擎.py _隔离防护墙.py _费损入账.py _同步冷却.py _开仓归序.py _天眼_辨真伪.py _择向密钥.py _自巡_独立子系统.sh; do
  [ -f "$SRC/$f" ] && cp -f "$SRC/$f" "$DEST/" && echo "   + $f"
done
[ -f "$SRC/子引擎/_内核_rui.py" ] && cp -f "$SRC/子引擎/_内核_rui.py" "$DEST/子引擎/" && echo "   + 子引擎/_内核_rui.py"
for f in _life_train_data.json _雷达情报.json; do
  [ -f "$SRC/子引擎/data_v2/mtsim/$f" ] && cp -f "$SRC/子引擎/data_v2/mtsim/$f" "$DEST/子引擎/data_v2/mtsim/" && echo "   + 子引擎/data_v2/mtsim/$f"
done
if [ ! -f "$DEST/data_v2/mtsim/sub/_sub_${NODE}_state.json" ]; then
  cp -f "$SRC/data_v2/mtsim/sub/_sub_rui_state.json" "$DEST/data_v2/mtsim/sub/_sub_${NODE}_state.json" && echo "   + 空账本(起始 \$5000) _sub_${NODE}_state.json"
else
  echo "   · 已有账本, 保留不动(不覆盖历史)"
fi
chmod +x "$DEST/_自巡_独立子系统.sh" 2>/dev/null
echo "▸ ④ 试跑自检(10 秒)"
( cd "$DEST" && timeout 10 env $GENE python3 -u _子引擎.py "$NODE" --mode paper > "data_v2/logs/_试跑.log" 2>&1 ) || true
if [ -s "$DEST/data_v2/logs/_试跑.log" ]; then
  echo "  ✅ 引擎可跑(样例输出下行)"
  tail -3 "$DEST/data_v2/logs/_试跑.log" | sed 's/^/     /'
else
  echo "  ⚠️ 试跑无输出 —— 请看 $DEST/data_v2/logs/_试跑.log"
fi
if [ "$DO_START" = "1" ]; then
  echo "▸ ⑤ 启动"
  ( cd "$DEST" && setsid nohup env $GENE GATELOCK="._sub_$NODE.lock" python3 -u _子引擎.py "$NODE" --mode paper >> "data_v2/logs/sub_${NODE}_paper.log" 2>&1 < /dev/null & )
  echo "   ✅ 引擎已起(模拟档·$NODE)"
  if [ "$DO_GUARD" = "1" ]; then
    ( cd "$DEST" && LINGXI_NODE="$NODE" setsid nohup bash _自巡_独立子系统.sh >/dev/null 2>&1 & )
    echo "   ✅ 常驻自巡已起(掉线自愈)"
  fi
else
  echo "▸ ⑤ 未启动"
  echo "   要起: cd $DEST && bash _安装_一键部署.sh --起   (或 --带自巡 连守护一起)"
fi
echo "──────────────────────────────"
echo "✅ 部署完成。看活: tail -f $DEST/data_v2/logs/sub_${NODE}_paper.log"
echo "⚠️ 只跑模拟: 本包含**没有任何密钥**; 若要接真钱 → 新机自配自家 Key + 同意码, 且**旧机必须先停**(同一账户严禁双开)"
